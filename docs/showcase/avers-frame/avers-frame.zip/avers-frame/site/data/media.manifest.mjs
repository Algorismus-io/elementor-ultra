/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "avers-frame--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'avers-frame--';

export default [
  { slot: `${PREFIX}detail_stair`, file: join(MEDIA_DIR, "detail_stair.jpg"), alt: "Concrete stair detail, raking daylight" },
  { slot: `${PREFIX}exterior_dusk`, file: join(MEDIA_DIR, "exterior_dusk.jpg"), alt: "Completed building photographed at dusk" },
  { slot: `${PREFIX}interior_plate`, file: join(MEDIA_DIR, "interior_plate.jpg"), alt: "Finished interior, furnished and lived in" },
];
