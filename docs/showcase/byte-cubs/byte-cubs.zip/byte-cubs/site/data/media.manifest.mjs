/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "byte-cubs--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'byte-cubs--';

export default [
  { slot: `${PREFIX}kids_building`, file: join(MEDIA_DIR, "kids_building.jpg"), alt: "Two kids at a laptop building a game together in an after-school club room" },
  { slot: `${PREFIX}showcase_night`, file: join(MEDIA_DIR, "showcase_night.jpg"), alt: "Parents playing the games their children built at a Byte Cubs showcase night" },
  { slot: `${PREFIX}sketch_desk`, file: join(MEDIA_DIR, "sketch_desk.jpg"), alt: "A desk covered in hand-drawn game sketches and level plans" },
];
