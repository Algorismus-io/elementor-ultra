/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "the-ward-paper--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'the-ward-paper--';

export default [
  { slot: `${PREFIX}ward-council-chamber`, file: join(MEDIA_DIR, "council_chamber.jpg"), alt: "The empty public gallery and press bench of a city council chamber" },
  { slot: `${PREFIX}ward-reporter-street`, file: join(MEDIA_DIR, "reporter_street.jpg"), alt: "A reporter working on a city street outside the civic buildings" },
];
