/** Tracewell — replay console landing page. Archetype: terminal / console log. */

export const meta = {
  title: 'Tracewell — Replay the agent run that broke',
  slug: 'tracewell',
  seo: {
    title: 'Tracewell — Replay the agent run that broke',
    description:
      'Tracewell captures every span, tool call and token of your agent in production, then lets you re-run the exact failure against a different prompt or model. Fix it before you ship it.',
  },
};

/* ── shared atoms ─────────────────────────────────────────────────────────── */

const MONO = 'JetBrains Mono';
const BODY = 'Inter';

/** thin console rule */
const Rule = ({ from = '#1A2224', to = '#07090A' }) => (
  <box tw="w-full" h={1} grad={[90, from, to]} />
);

/** dim mono micro-label, e.g. `// 02 · anatomy` */
const Tag = ({ children, color = '#4A5A57', size = 12 }) => (
  <text cls="tag" font={MONO} size={size} color={color} ls={0.08} weight={500} lh={1.4} mobile={{ size: 11 }}>
    {children}
  </text>
);

/** one line of a console log */
const Line = ({ time, tag, tagColor = '#4CFFB0', msg, msgColor = '#C8D6D2', dur }) => (
  <box cls="log-line" tw="flex flex-row w-full items-start" gap={10} wrap="wrap">
    <text cls="log-time" font={MONO} size={12} color="#33403E" lh={1.7} mobile={{ size: 11 }}>{time}</text>
    <text cls="log-tag" font={MONO} size={12} color={tagColor} weight={600} lh={1.7} mobile={{ size: 11 }}>{tag}</text>
    <text cls="log-msg" font={MONO} size={12} color={msgColor} lh={1.7} flex={1} mobile={{ size: 11 }}>{msg}</text>
    {dur ? <text cls="log-dur" font={MONO} size={12} color="#33403E" lh={1.7} mobile={{ size: 11 }}>{dur}</text> : null}
  </box>
);

/** the window chrome of a console panel */
const Chrome = ({ title, right, rightColor = '#4A5A57' }) => (
  <box
    cls="panel-chrome"
    tw="flex flex-row w-full items-center justify-between"
    gap={12}
    pad={{ t: 12, b: 12, l: 16, r: 16 }}
    bg="#0A1012"
    border={[1, '#161E20']}
  >
    <box tw="flex flex-row items-center" gap={8}>
      <box cls="chrome-dot" w={9} h={9} radius={9} bg="#20292B" />
      <box cls="chrome-dot" w={9} h={9} radius={9} bg="#20292B" />
      <box cls="chrome-dot" w={9} h={9} radius={9} bg="#20292B" />
      <text cls="chrome-title" font={MONO} size={12} color="#4A5A57" tw="pl-2" mobile={{ size: 11 }}>{title}</text>
    </box>
    {right ? <text cls="chrome-badge" font={MONO} size={11} color={rightColor} weight={600} ls={0.06}>{right}</text> : null}
  </box>
);

/** primary / secondary console buttons */
const Btn = ({ href, children, kind = 'primary' }) =>
  kind === 'primary' ? (
    <text
      cls="btn-primary"
      href={href}
      font={MONO}
      size={14}
      weight={700}
      color="#07090A"
      bg="#4CFFB0"
      radius={6}
      pad={{ t: 15, b: 15, l: 24, r: 24 }}
      ta="center"
      hover={{ bg: '#7DFFC7', color: '#07090A' }}
    >
      {children}
    </text>
  ) : (
    <text
      cls="btn-ghost"
      href={href}
      font={MONO}
      size={14}
      weight={500}
      color="#C8D6D2"
      radius={6}
      border={[1, '#222E30']}
      pad={{ t: 14, b: 14, l: 22, r: 22 }}
      ta="center"
      hover={{ border: [1, '#4CFFB0'], color: '#4CFFB0' }}
    >
      {children}
    </text>
  );

/* ── registered repeaters (content props only) ────────────────────────────── */

const AnatomyCard = defineComponent(
  ({ idx = '01', name = 'span', signature = '', body = '', sample = '' }) => (
    <box
      cls="anatomy-card"
      tw="flex flex-col w-full"
      gap={12}
      pad={24}
      bg="#0E1315"
      border={[1, '#161E20']}
      radius={8}
      minh={230}
      hover={{ border: [1, '#2C3B38'], bg: '#111719' }}
      mobile={{ pad: 20, minh: 0 }}
    >
      <box tw="flex flex-row items-center justify-between w-full">
        <text font={MONO} size={11} color="#33403E" ls={0.1}>{idx}</text>
        <text font={MONO} size={11} color="#4CFFB0" ls={0.06}>{signature}</text>
      </box>
      <text font={MONO} size={19} weight={700} color="#C8D6D2" lh={1.3}>{name}</text>
      <text font={BODY} size={14} color="#7B8B88" lh={1.6}>{body}</text>
      <text font={MONO} size={12} color="#4A5A57" lh={1.6} tw="pt-1">{sample}</text>
    </box>
  ),
  {
    title: 'Trace anatomy card',
    props: {
      idx: { label: 'Index', group: 'Content' },
      name: { label: 'Name', group: 'Content' },
      signature: { label: 'Signature', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
      sample: { label: 'Sample value', group: 'Content' },
    },
  },
);

const CompareRow = defineComponent(
  ({ label = '', selfHost = '', cloud = '' }) => (
    <grid cls="cmp-row" cols="1.1fr 1fr 1fr" gap={0} tw="w-full" tablet={{ gridCols: '1.1fr 1fr 1fr' }} mobile={{ gridCols: 1 }}>
      <box cls="cmp-cell-label" pad={{ t: 16, b: 16, r: 16 }} border={[1, '#141B1D']}>
        <text cls="cmp-label" font={MONO} size={13} color="#7B8B88" lh={1.6}>{label}</text>
      </box>
      <box cls="cmp-cell-self" pad={{ t: 16, b: 16, l: 16, r: 16 }} border={[1, '#141B1D']} bg="#0B1112">
        <text cls="cmp-val-self" font={MONO} size={13} color="#C8D6D2" lh={1.6}>{selfHost}</text>
      </box>
      <box cls="cmp-cell-cloud" pad={{ t: 16, b: 16, l: 16, r: 16 }} border={[1, '#141B1D']}>
        <text cls="cmp-val-cloud" font={MONO} size={13} color="#7B8B88" lh={1.6}>{cloud}</text>
      </box>
    </grid>
  ),
  {
    title: 'Comparison row',
    props: {
      label: { label: 'Row label', group: 'Content' },
      selfHost: { label: 'Self-hosted', group: 'Content' },
      cloud: { label: 'Cloud', group: 'Content' },
    },
  },
);

/* ── the page ─────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>
    {/* ── console status bar ── */}
    <box tw="flex flex-col w-full items-center" bg="#0A0D0E" border={[1, '#141B1D']}>
      <box
        tw="flex flex-row w-full items-center justify-between max-md:px-5"
        maxw={1280}
        pad={{ t: 12, b: 12, l: 32, r: 32 }}
        gap={16}
      >
        <box tw="flex flex-row items-center" gap={10}>
          <box w={8} h={8} radius={8} bg={t.color.accent} />
          <text font={MONO} size={14} weight={700} color={t.color.ink} ls={0.02}>tracewell</text>
        </box>
        <box tw="flex flex-row items-center max-md:hidden" gap={24}>
          <Tag>status: capturing</Tag>
          <Tag>region: eu-west-1</Tag>
          <text href="#install" font={MONO} size={12} color={t.color.accent} weight={600} hover={{ color: '#7DFFC7' }}>
            docs
          </text>
        </box>
      </box>
    </box>

    {/* ── 1. hero: replay console ── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground} id="top">
      <grid
        cols="1.02fr 0.98fr"
        gap={56}
        tw="w-full max-md:px-5 max-md:py-14 max-lg:px-8"
        maxw={1280}
        pad={{ t: 88, b: 88, l: 32, r: 32 }}
        m={{ l: 'auto', r: 'auto' }}
        align="center"
        tablet={{ gridCols: 1, gap: 40 }}
        mobile={{ gridCols: 1, gap: 32 }}
      >
        <box tw="flex flex-col w-full" gap={26} align="flex-start">
          <box
            tw="flex flex-row items-center"
            gap={8}
            pad={{ t: 6, b: 6, l: 10, r: 12 }}
            radius={4}
            border={[1, '#1C2628']}
            bg="#0C1113"
          >
            <text font={MONO} size={11} color={t.color.accent} weight={700}>●</text>
            <Tag size={11}>run 8f2a1c · 12 spans · exit 1</Tag>
          </box>

          <h1
            font={MONO}
            size={58}
            weight={700}
            color={t.color.ink}
            lh={1.06}
            ls={-0.02}
            tablet={{ size: 46 }}
            mobile={{ size: 32 }}
          >
            Replay the agent run that broke.
          </h1>

          <text font={BODY} size={17} color="#8A9A97" lh={1.7} maxw={540} mobile={{ size: 15 }}>
            Tracewell captures every span, tool call and token of your agent in production, then lets you
            re-run the exact failure against a different prompt or model. <strong>Fix it before you ship it.</strong>
          </text>

          <box tw="flex flex-row w-full max-md:flex-col" gap={12} wrap="wrap">
            <Btn href="#install">Start capturing traces</Btn>
            <Btn href="#anatomy" kind="ghost">Read the trace format spec</Btn>
          </box>

          <box tw="flex flex-row w-full items-stretch pt-2 max-md:flex-col" gap={0}>
            <box tw="flex flex-col" gap={4} pad={{ r: 28 }} border={[1, '#141B1D']}>
              <text font={MONO} size={20} weight={700} color={t.color.accent} mobile={{ size: 17 }}>3.4ms</text>
              <Tag>median overhead per span</Tag>
            </box>
            <box tw="flex flex-col max-md:pl-0 max-md:pt-4" gap={4} pad={{ l: 28, r: 28 }}>
              <text font={MONO} size={20} weight={700} color={t.color.ink} mobile={{ size: 17 }}>90 days</text>
              <Tag>traces retained on the free tier</Tag>
            </box>
          </box>
        </box>

        {/* live trace stream */}
        <box tw="flex flex-col w-full" radius={10} bg="#0B0F10" border={[1, '#161E20']} shadow={[[24, 60, -20, 'rgba(0,0,0,0.65)'], [2, 0, 0, 'rgba(76,255,176,0.06)']]}>
          <Chrome title="tracewell stream — checkout-agent" right="LIVE" rightColor="#4CFFB0" />
          <box tw="flex flex-col w-full" gap={2} pad={{ t: 18, b: 18, l: 16, r: 16 }} mobile={{ pad: 12 }}>
            <Line time="12:04:07.118" tag="span" msg="agent.plan  · 4 msgs → 1,204 tok" dur="812ms" />
            <Line time="12:04:07.930" tag="tool" tagColor="#8A9A97" msg="search_inventory(sku=A-771)" dur="61ms" />
            <Line time="12:04:08.001" tag="tool" tagColor="#8A9A97" msg="search_inventory(sku=A-771)" dur="58ms" />
            <Line time="12:04:08.070" tag="tool" tagColor="#8A9A97" msg="search_inventory(sku=A-771)" dur="63ms" />
            <Line time="12:04:08.140" tag="warn" tagColor="#FF5C4D" msg="repeat tool call ×3 — no state change" dur="—" />
            <Line time="12:04:08.220" tag="span" msg="agent.act   · 9,881 tok · $0.0412" dur="2.10s" />
            <Line time="12:04:10.330" tag="fail" tagColor="#FF5C4D" msgColor="#FF5C4D" msg="max_iterations exceeded · exit 1" dur="—" />
            <Line time="12:04:10.331" tag="save" msg="trace persisted · replayable" dur="3.4ms" />
          </box>
          <box
            tw="flex flex-row w-full items-center justify-between"
            gap={12}
            pad={{ t: 12, b: 12, l: 16, r: 16 }}
            bg="#0A0D0E"
            border={[1, '#161E20']}
            wrap="wrap"
          >
            <Tag size={11}>12 spans · 11,085 tok · $0.0412</Tag>
            <text font={MONO} size={11} color={t.color.accent} weight={700} ls={0.06}>REPLAY ⏎</text>
          </box>
        </box>
      </grid>
    </box>

    <Rule from="#1A2224" to="#07090A" />

    {/* ── 2. the failure that costs you a weekend ── */}
    <box tw="flex flex-col w-full items-center" bg="#090C0D">
      <grid
        cols="0.8fr 1.2fr"
        gap={56}
        tw="w-full max-md:px-5 max-md:py-16 max-lg:px-8"
        maxw={1280}
        pad={{ t: 96, b: 96, l: 32, r: 32 }}
        m={{ l: 'auto', r: 'auto' }}
        tablet={{ gridCols: 1, gap: 36 }}
        mobile={{ gridCols: 1, gap: 28 }}
      >
        <box tw="flex flex-col w-full" gap={20} align="flex-start">
          <Tag color="#FF5C4D">// 01 · incident</Tag>
          <h2 font={MONO} size={36} weight={700} color={t.color.ink} lh={1.15} tablet={{ size: 30 }} mobile={{ size: 25 }}>
            The failure that costs you a weekend.
          </h2>
          <text font={BODY} size={16} color="#8A9A97" lh={1.75} maxw={430} mobile={{ size: 15 }}>
            The agent answered wrong at 02:41. Your logs have the prompt and the final string, and nothing
            in between — no tool arguments, no intermediate messages, no token accounting. So you guess,
            you patch, you deploy, and you wait to see if it happens again.
          </text>
          <box tw="flex flex-col w-full" gap={6} pad={{ t: 18, l: 18, b: 18, r: 18 }} bg="#120C0C" border={[1, '#2B1614']} radius={6} maxw={430}>
            <text font={MONO} size={13} color="#FF5C4D" weight={700} lh={1.5}>$400 / night · 11 nights</text>
            <text font={BODY} size={14} color="#8A9A97" lh={1.6}>
              A tool-call loop nobody could see, billed at full rate until someone read the invoice.
            </text>
          </box>
        </box>

        <box tw="flex flex-col w-full" gap={0} radius={10} bg="#0B0F10" border={[1, '#161E20']}>
          <Chrome title="app.log — what you actually have" right="GREP" />
          <box tw="flex flex-col w-full" gap={10} pad={{ t: 20, b: 20, l: 18, r: 18 }} mobile={{ pad: 14 }}>
            <Line time="02:41:03" tag="INFO" tagColor="#4A5A57" msg="request received · user 44120" />
            <Line time="02:41:09" tag="INFO" tagColor="#4A5A57" msg="agent responded (6.2s)" />
            <Line time="02:41:09" tag="WARN" tagColor="#FF5C4D" msg="customer flagged answer as wrong" />
            <box tw="w-full" h={1} bg="#141B1D" m={{ t: 8, b: 8 }} />
            <text font={MONO} size={12} color="#33403E" lh={1.8} mobile={{ size: 11 }}>
              {'# which tool ran?          — not logged'}
            </text>
            <text font={MONO} size={12} color="#33403E" lh={1.8} mobile={{ size: 11 }}>
              {'# what arguments?          — not logged'}
            </text>
            <text font={MONO} size={12} color="#33403E" lh={1.8} mobile={{ size: 11 }}>
              {'# how many tokens burned?  — not logged'}
            </text>
            <text font={MONO} size={12} color="#33403E" lh={1.8} mobile={{ size: 11 }}>
              {'# can you run it again?    — no'}
            </text>
            <box tw="w-full" h={1} bg="#141B1D" m={{ t: 8, b: 8 }} />
            <text font={MONO} size={13} color="#4CFFB0" lh={1.7} mobile={{ size: 12 }}>
              {'tracewell: 12 spans · every argument · replayable ✓'}
            </text>
          </box>
        </box>
      </grid>
    </box>

    <Rule from="#07090A" to="#1A2224" />

    {/* ── 3. anatomy of a trace ── */}
    <box tw="flex flex-col w-full items-center" bg={t.color.ground} id="anatomy">
      <box
        tw="flex flex-col w-full max-md:px-5 max-md:py-16 max-lg:px-8"
        maxw={1280}
        pad={{ t: 96, b: 96, l: 32, r: 32 }}
        gap={40}
        m={{ l: 'auto', r: 'auto' }}
      >
        <box tw="flex flex-row w-full items-end justify-between max-md:flex-col max-md:items-start" gap={24}>
          <box tw="flex flex-col" gap={14} maxw={620}>
            <Tag>// 02 · anatomy</Tag>
            <h2 font={MONO} size={36} weight={700} color={t.color.ink} lh={1.15} tablet={{ size: 30 }} mobile={{ size: 25 }}>
              Anatomy of a trace.
            </h2>
            <text font={BODY} size={16} color="#8A9A97" lh={1.7} mobile={{ size: 15 }}>
              Four record types, one append-only stream, open schema. Everything the runtime knew at the
              moment it decided — kept in the shape you can query, diff and replay.
            </text>
          </box>
          <text font={MONO} size={12} color="#33403E" lh={1.8} mobile={{ size: 11 }}>
            {'schema v3 · JSONL · OTel-compatible'}
          </text>
        </box>

        <grid
          cols={4}
          gap={16}
          tw="w-full"
          motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}
          tablet={{ gridCols: 2 }}
          mobile={{ gridCols: 1 }}
        >
          <AnatomyCard
            idx="01"
            name="span"
            signature="span_id · parent_id"
            body="One unit of agent work — plan, act, reflect — with its start, end and causal parent. Nest them and you get the run's real control flow, not a flat log."
            sample={'dur=812ms  depth=2  status=ok'}
          />
          <AnatomyCard
            idx="02"
            name="tool call"
            signature="name · args · result"
            body="Full arguments in, full result out, serialised verbatim. This is the record that shows you the loop: same call, same args, three times, no state change."
            sample={'search_inventory(sku="A-771")'}
          />
          <AnatomyCard
            idx="03"
            name="token"
            signature="prompt · completion"
            body="Per-span token accounting with the exact message list that produced it. Context-window blowups become a number on a line instead of a hunch."
            sample={'in=9,204  out=677  ctx=61%'}
          />
          <AnatomyCard
            idx="04"
            name="cost"
            signature="model · rate · usd"
            body="Priced per span at the model's rate, rolled up per run, per route, per customer. The $400 night is visible on the first chart you open."
            sample={'gpt-4o  $0.0412  run total'}
          />
        </grid>
      </box>
    </box>

    {/* ── 4. replay against a new model ── */}
    <box tw="flex flex-col w-full items-center" bg="#090C0D" border={[1, '#141B1D']}>
      <box
        tw="flex flex-col w-full max-md:px-5 max-md:py-16 max-lg:px-8"
        maxw={1280}
        pad={{ t: 96, b: 96, l: 32, r: 32 }}
        gap={36}
        m={{ l: 'auto', r: 'auto' }}
      >
        <box tw="flex flex-col" gap={14} maxw={640}>
          <Tag color="#4CFFB0">// 03 · replay</Tag>
          <h2 font={MONO} size={36} weight={700} color={t.color.ink} lh={1.15} tablet={{ size: 30 }} mobile={{ size: 25 }}>
            Re-run the exact failure against a different model.
          </h2>
          <text font={BODY} size={16} color="#8A9A97" lh={1.7} mobile={{ size: 15 }}>
            Pick a captured run, swap the prompt version or the model, and Tracewell replays it against the
            recorded tool responses. Same inputs, new brain — a diff you can put in the pull request.
          </text>
        </box>

        <box tw="flex flex-col w-full" radius={10} bg="#0B0F10" border={[1, '#1C2628']}>
          <Chrome title="tracewell replay --run 8f2a1c" right="DIFF" rightColor="#4CFFB0" />

          <box tw="flex flex-row w-full items-center max-md:flex-col max-md:items-start" gap={10} pad={{ t: 14, b: 14, l: 16, r: 16 }} border={[1, '#141B1D']} wrap="wrap">
            <Tag size={11}>prompt: v3 → v4</Tag>
            <Tag size={11}>model: gpt-4o → claude-opus</Tag>
            <Tag size={11}>tools: recorded</Tag>
            <Tag size={11}>temp: 0.2</Tag>
          </box>

          <grid cols="1fr 1fr" gap={0} tw="w-full" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
            <box tw="flex flex-col w-full" gap={8} pad={20} border={[1, '#141B1D']} mobile={{ pad: 14 }}>
              <box tw="flex flex-row items-center justify-between w-full" gap={10}>
                <text font={MONO} size={12} color="#FF5C4D" weight={700}>ORIGINAL · gpt-4o</text>
                <text font={MONO} size={12} color="#33403E">exit 1</text>
              </box>
              <text font={MONO} size={12} color="#8A9A97" lh={1.8} mobile={{ size: 11 }}>{'- plan: 4 steps'}</text>
              <text font={MONO} size={12} color="#FF5C4D" lh={1.8} mobile={{ size: 11 }}>{'- tool: search_inventory ×7'}</text>
              <text font={MONO} size={12} color="#FF5C4D" lh={1.8} mobile={{ size: 11 }}>{'- loop: no state change'}</text>
              <text font={MONO} size={12} color="#8A9A97" lh={1.8} mobile={{ size: 11 }}>{'- tokens: 11,085'}</text>
              <text font={MONO} size={12} color="#FF5C4D" lh={1.8} mobile={{ size: 11 }}>{'- cost: $0.0412'}</text>
              <text font={MONO} size={12} color="#FF5C4D" lh={1.8} weight={700} mobile={{ size: 11 }}>{'- result: max_iterations'}</text>
            </box>
            <box tw="flex flex-col w-full" gap={8} pad={20} bg="#0A1210" border={[1, '#17251F']} mobile={{ pad: 14 }}>
              <box tw="flex flex-row items-center justify-between w-full" gap={10}>
                <text font={MONO} size={12} color="#4CFFB0" weight={700}>REPLAY · claude-opus</text>
                <text font={MONO} size={12} color="#4CFFB0">exit 0</text>
              </box>
              <text font={MONO} size={12} color="#8A9A97" lh={1.8} mobile={{ size: 11 }}>{'+ plan: 3 steps'}</text>
              <text font={MONO} size={12} color="#4CFFB0" lh={1.8} mobile={{ size: 11 }}>{'+ tool: search_inventory ×1'}</text>
              <text font={MONO} size={12} color="#4CFFB0" lh={1.8} mobile={{ size: 11 }}>{'+ loop: none'}</text>
              <text font={MONO} size={12} color="#8A9A97" lh={1.8} mobile={{ size: 11 }}>{'+ tokens: 3,902'}</text>
              <text font={MONO} size={12} color="#4CFFB0" lh={1.8} mobile={{ size: 11 }}>{'+ cost: $0.0148'}</text>
              <text font={MONO} size={12} color="#4CFFB0" lh={1.8} weight={700} mobile={{ size: 11 }}>{'+ result: answered · correct'}</text>
            </box>
          </grid>

          <box tw="flex flex-row w-full items-center justify-between max-md:flex-col max-md:items-start" gap={12} pad={{ t: 16, b: 16, l: 20, r: 20 }} bg="#0A0D0E" border={[1, '#161E20']} wrap="wrap">
            <text font={MONO} size={13} color="#C8D6D2" lh={1.6} mobile={{ size: 12 }}>
              {'64% fewer tokens · loop gone · verdict: ship it'}
            </text>
            <Tag size={11}>replayed 1,000 runs in 4m 12s</Tag>
          </box>
        </box>
      </box>
    </box>

    {/* ── 5. drop-in SDK ── */}
    <box tw="flex flex-col w-full items-center" bg={t.color.ground} id="install">
      <grid
        cols="0.7fr 1.3fr"
        gap={48}
        tw="w-full max-md:px-5 max-md:py-16 max-lg:px-8"
        maxw={1280}
        pad={{ t: 96, b: 96, l: 32, r: 32 }}
        m={{ l: 'auto', r: 'auto' }}
        tablet={{ gridCols: 1, gap: 32 }}
        mobile={{ gridCols: 1, gap: 26 }}
      >
        <box tw="flex flex-col w-full" gap={16} align="flex-start">
          <Tag>// 04 · install</Tag>
          <h2 font={MONO} size={36} weight={700} color={t.color.ink} lh={1.15} tablet={{ size: 30 }} mobile={{ size: 25 }}>
            Two lines, then it is recording.
          </h2>
          <text font={BODY} size={16} color="#8A9A97" lh={1.7} mobile={{ size: 15 }}>
            No sidecar, no collector to run, no agent rewrite. Import it, call <strong>init</strong>, and every
            span, tool call and token starts landing in the stream — at <strong>3.4ms</strong> median overhead
            per span.
          </text>
          <box tw="flex flex-col w-full" gap={10} pad={{ t: 16 }}>
            <Tag>works with</Tag>
            <text font={MONO} size={13} color="#7B8B88" lh={1.9} mobile={{ size: 12 }}>
              {'LangGraph · LlamaIndex · OpenAI SDK'}
            </text>
            <text font={MONO} size={13} color="#7B8B88" lh={1.9} mobile={{ size: 12 }}>
              {'Anthropic SDK · CrewAI · bare loops'}
            </text>
          </box>
        </box>

        <box tw="flex flex-col w-full" radius={10} bg="#0B0F10" border={[1, '#161E20']}>
          <Chrome title="quickstart" right="SDK" />
          <box
            tw="flex flex-col w-full"
            pad={{ t: 8, b: 20, l: 12, r: 12 }}
            raw={
              "& .e-tab p { color: #7B8B88; font-family: 'JetBrains Mono', monospace; font-size: 13px; letter-spacing: 0.04em; margin: 0; } " +
              '& .e-tab { border-bottom: 1px solid #161E20; padding: 10px 14px; } ' +
              '& .e-tab.e--selected p { color: #4CFFB0; } ' +
              '& .e-tab.e--selected { border-bottom: 1px solid #4CFFB0; }'
            }
          >
            {tabs([
              {
                label: 'python',
                content: [
                  <box tw="flex flex-col w-full" gap={6} pad={{ t: 18, l: 8, r: 8 }}>
                    <text font={MONO} size={13} color="#4CFFB0" lh={1.9} mobile={{ size: 11 }}>{'pip install tracewell'}</text>
                    <text font={MONO} size={13} color="#8A9A97" lh={1.9} mobile={{ size: 11 }}>{'import tracewell'}</text>
                    <text font={MONO} size={13} color="#C8D6D2" lh={1.9} mobile={{ size: 11 }}>{'tracewell.init("checkout-agent")'}</text>
                    <text font={MONO} size={13} color="#4A5A57" lh={1.9} mobile={{ size: 11 }}>{'# every span is now captured'}</text>
                    <text font={MONO} size={13} color="#C8D6D2" lh={1.9} mobile={{ size: 11 }}>{'run = agent.invoke(task)'}</text>
                    <text font={MONO} size={13} color="#4CFFB0" lh={1.9} mobile={{ size: 11 }}>{'tracewell.replay(run.id, model="opus")'}</text>
                  </box>,
                ],
              },
              {
                label: 'typescript',
                content: [
                  <box tw="flex flex-col w-full" gap={6} pad={{ t: 18, l: 8, r: 8 }}>
                    <text font={MONO} size={13} color="#4CFFB0" lh={1.9} mobile={{ size: 11 }}>{'npm i tracewell'}</text>
                    <text font={MONO} size={13} color="#8A9A97" lh={1.9} mobile={{ size: 11 }}>{'import { init, replay } from "tracewell"'}</text>
                    <text font={MONO} size={13} color="#C8D6D2" lh={1.9} mobile={{ size: 11 }}>{'init({ service: "checkout-agent" })'}</text>
                    <text font={MONO} size={13} color="#4A5A57" lh={1.9} mobile={{ size: 11 }}>{'// every span is now captured'}</text>
                    <text font={MONO} size={13} color="#C8D6D2" lh={1.9} mobile={{ size: 11 }}>{'const run = await agent.invoke(task)'}</text>
                    <text font={MONO} size={13} color="#4CFFB0" lh={1.9} mobile={{ size: 11 }}>{'await replay(run.id, { model: "opus" })'}</text>
                  </box>,
                ],
              },
              {
                label: 'go',
                content: [
                  <box tw="flex flex-col w-full" gap={6} pad={{ t: 18, l: 8, r: 8 }}>
                    <text font={MONO} size={13} color="#4CFFB0" lh={1.9} mobile={{ size: 11 }}>{'go get go.tracewell.dev/tw'}</text>
                    <text font={MONO} size={13} color="#8A9A97" lh={1.9} mobile={{ size: 11 }}>{'import "go.tracewell.dev/tw"'}</text>
                    <text font={MONO} size={13} color="#C8D6D2" lh={1.9} mobile={{ size: 11 }}>{'tw.Init("checkout-agent")'}</text>
                    <text font={MONO} size={13} color="#4A5A57" lh={1.9} mobile={{ size: 11 }}>{'// every span is now captured'}</text>
                    <text font={MONO} size={13} color="#C8D6D2" lh={1.9} mobile={{ size: 11 }}>{'run, _ := agent.Invoke(ctx, task)'}</text>
                    <text font={MONO} size={13} color="#4CFFB0" lh={1.9} mobile={{ size: 11 }}>{'tw.Replay(run.ID, tw.Model("opus"))'}</text>
                  </box>,
                ],
              },
            ])}
          </box>
        </box>
      </grid>
    </box>

    <Rule from="#1A2224" to="#07090A" />

    {/* ── 6. self-host vs cloud ── */}
    <box tw="flex flex-col w-full items-center" bg="#090C0D">
      <box
        tw="flex flex-col w-full max-md:px-5 max-md:py-16 max-lg:px-8"
        maxw={1280}
        pad={{ t: 96, b: 96, l: 32, r: 32 }}
        gap={32}
        m={{ l: 'auto', r: 'auto' }}
      >
        <box tw="flex flex-row w-full items-end justify-between max-md:flex-col max-md:items-start" gap={24}>
          <box tw="flex flex-col" gap={14} maxw={560}>
            <Tag>// 05 · deployment</Tag>
            <h2 font={MONO} size={36} weight={700} color={t.color.ink} lh={1.15} tablet={{ size: 30 }} mobile={{ size: 25 }}>
              Self-host or cloud. Same binary.
            </h2>
          </box>
          <text font={MONO} size={13} color="#4CFFB0" lh={1.7} maxw={420} mobile={{ size: 12 }}>
            {'Yes, it self-hosts. One Postgres, one container, no vendor telemetry leaving your VPC.'}
          </text>
        </box>

        <box tw="flex flex-col w-full" radius={10} bg="#0B0F10" border={[1, '#161E20']} pad={{ t: 4, b: 8, l: 20, r: 20 }} mobile={{ pad: 14 }}>
          <grid cols="1.1fr 1fr 1fr" gap={0} tw="w-full" mobile={{ gridCols: 1 }}>
            <box pad={{ t: 16, b: 16, r: 16 }} border={[1, '#141B1D']}>
              <Tag size={11}>capability</Tag>
            </box>
            <box pad={16} border={[1, '#141B1D']} bg="#0B1112">
              <text font={MONO} size={12} color="#4CFFB0" weight={700} ls={0.06}>SELF-HOSTED</text>
            </box>
            <box pad={16} border={[1, '#141B1D']}>
              <text font={MONO} size={12} color="#7B8B88" weight={700} ls={0.06}>CLOUD</text>
            </box>
          </grid>
          <CompareRow label="runtime" selfHost="1 container + 1 Postgres" cloud="managed, multi-region" />
          <CompareRow label="trace data" selfHost="never leaves your VPC" cloud="encrypted, EU or US" />
          <CompareRow label="retention" selfHost="your disk, your rules" cloud="90 days on the free tier" />
          <CompareRow label="replay engine" selfHost="identical, offline capable" cloud="identical, autoscaled" />
          <CompareRow label="upgrades" selfHost="pinned image tags" cloud="continuous" />
          <CompareRow label="egress" selfHost="zero vendor telemetry" cloud="agent → ingest only" />
        </box>
      </box>
    </box>

    {/* ── 7. postmortem quote ── */}
    <box tw="flex flex-col w-full items-center" bg={t.color.ground}>
      <box
        tw="flex flex-col w-full max-md:px-5 max-md:py-16 max-lg:px-8"
        maxw={1280}
        pad={{ t: 88, b: 88, l: 32, r: 32 }}
        m={{ l: 'auto', r: 'auto' }}
      >
        <box tw="flex flex-col w-full" radius={10} bg="#0B0F10" border={[1, '#161E20']} motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}>
          <Chrome title="postmortem-2026-04-11.md — resolved" right="P1" rightColor="#FF5C4D" />
          <grid cols="1.35fr 0.65fr" gap={0} tw="w-full" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
            <box tw="flex flex-col w-full" gap={20} pad={40} mobile={{ pad: 22 }}>
              <text font={MONO} size={12} color="#33403E" ls={0.08}>{'## root cause'}</text>
              <text font={MONO} size={23} weight={500} color={t.color.ink} lh={1.55} tablet={{ size: 20 }} mobile={{ size: 17 }}>
                We had a tool-call loop burning 400 dollars a night for eleven days. <em>Tracewell found it in one replay.</em>
              </text>
              <box tw="flex flex-row items-center" gap={12} pad={{ t: 6 }}>
                <box w={28} h={1} bg="#4CFFB0" />
                <text font={MONO} size={12} color="#7B8B88" lh={1.6} mobile={{ size: 11 }}>
                  {'Infrastructure lead, mid-size logistics platform'}
                </text>
              </box>
            </box>
            <box tw="flex flex-col w-full" gap={18} pad={40} bg="#0A0D0E" border={[1, '#141B1D']} mobile={{ pad: 22 }}>
              <box tw="flex flex-col" gap={4}>
                <text font={MONO} size={19} weight={700} color="#FF5C4D" mobile={{ size: 17 }}>$4,400</text>
                <Tag>burned before detection</Tag>
              </box>
              <box tw="flex flex-col" gap={4}>
                <text font={MONO} size={19} weight={700} color={t.color.accent} mobile={{ size: 17 }}>1 replay</text>
                <Tag>to reproduce the loop</Tag>
              </box>
              <box tw="flex flex-col" gap={4}>
                <text font={MONO} size={19} weight={700} color={t.color.ink} mobile={{ size: 17 }}>18 min</text>
                <Tag>from trace to merged fix</Tag>
              </box>
            </box>
          </grid>
        </box>
      </box>
    </box>

    {/* ── 8. install line footer ── */}
    <box tw="flex flex-col w-full items-center" bg="#0A0D0E" border={[1, '#141B1D']}>
      <box
        tw="flex flex-col w-full max-md:px-5 max-md:py-14 max-lg:px-8"
        maxw={1280}
        pad={{ t: 72, b: 40, l: 32, r: 32 }}
        gap={36}
        m={{ l: 'auto', r: 'auto' }}
      >
        <grid cols="1.15fr 0.85fr" gap={40} tw="w-full" tablet={{ gridCols: 1, gap: 28 }} mobile={{ gridCols: 1, gap: 24 }} align="center">
          <box tw="flex flex-col w-full" gap={18} align="flex-start">
            <h3 font={MONO} size={28} weight={700} color={t.color.ink} lh={1.25} mobile={{ size: 22 }}>
              Start capturing traces.
            </h3>
            <box
              tw="flex flex-row w-full items-center"
              gap={12}
              pad={{ t: 16, b: 16, l: 18, r: 18 }}
              radius={6}
              bg="#0B0F10"
              border={[1, '#1C2628']}
              wrap="wrap"
            >
              <text font={MONO} size={14} weight={700} color={t.color.accent}>$</text>
              <text font={MONO} size={14} color={t.color.ink} lh={1.6} flex={1} mobile={{ size: 11 }}>
                {'pip install tracewell && tracewell init'}
              </text>
              <Tag size={11}>copy</Tag>
            </box>
            <Tag>3.4ms median overhead per span · traces retained for 90 days on the free tier</Tag>
          </box>

          <box tw="flex flex-col w-full" gap={12} align="flex-start">
            <Btn href="#install">Start capturing traces</Btn>
            <Btn href="#anatomy" kind="ghost">Read the trace format spec</Btn>
          </box>
        </grid>

        <box tw="w-full" h={1} bg="#141B1D" />

        <box tw="flex flex-row w-full items-center justify-between max-md:flex-col max-md:items-start" gap={16} pad={{ b: 8 }}>
          <box tw="flex flex-row items-center" gap={10}>
            <box w={8} h={8} radius={8} bg={t.color.accent} />
            <text font={MONO} size={13} weight={700} color={t.color.ink}>tracewell</text>
            <Tag size={11}>· observability for agent runs</Tag>
          </box>
          <Tag size={11}>docs · trace format spec · status · security</Tag>
        </box>
      </box>
    </box>
  </box>
);
