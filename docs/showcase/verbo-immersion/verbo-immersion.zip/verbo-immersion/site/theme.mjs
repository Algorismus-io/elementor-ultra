/** Verbo — design tokens. */
export default defineTheme({
  name: 'verbo',
  color: {
    ground: '#FFF8F0',
    ink: '#22201E',
    terracotta: '#C25E3A',
    indigo: '#31456B',
    olive: '#7C8C4E',
    rule: '#E4D8C9',
    white: '#FFFFFF',
  },
  font: { head: 'Zilla Slab', body: 'Epilogue' },
  mode: 'literal',
});
