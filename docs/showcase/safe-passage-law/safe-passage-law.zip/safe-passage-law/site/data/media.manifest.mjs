/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "safe-passage-law--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'safe-passage-law--';

export default [
  { slot: `${PREFIX}corridor`, file: join(MEDIA_DIR, "corridor.jpg"), alt: "A quiet tribunal corridor with rows of empty chairs" },
  { slot: `${PREFIX}hands_documents`, file: join(MEDIA_DIR, "hands_documents.jpg"), alt: "Hands resting on a stack of asylum case documents" },
];
