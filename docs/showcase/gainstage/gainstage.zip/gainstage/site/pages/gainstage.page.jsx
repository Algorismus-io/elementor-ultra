/** Gainstage — bento landing page. */
import { defineComponent } from 'elementor-jsx';
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Gainstage',
  slug: 'gainstage',
  seo: {
    title: 'Gainstage — edit the transcript, the audio follows',
    description:
      'Delete a sentence and Gainstage removes it from every track, smooths the room tone across the join, and keeps your guest in sync. A 90-minute conversation becomes a finished episode in about 25 minutes.',
  },
};

/* ── local vocabulary ─────────────────────────────────────────────── */

const seq = (n, f) => Array.from({ length: n }, (_, i) => f(i));
const RISE = { effect: 'fade', trigger: 'scrollIn', duration: 520 };

const TILE_SHADOW = [
  [0, 0, 1, 'rgba(255,255,255,0.06)'],
  [18, 40, -24, 'rgba(0,0,0,0.75)'],
];

/** monospace-ish transcript line; <strong> is the highlighted token. */
const CUT = '& strong { color: #FF6B6B; font-weight: 600; }';
const KEEP = '& strong { color: #48E0A0; font-weight: 600; }';
const STRUCK =
  '& { text-decoration: line-through; text-decoration-color: #FF6B6B; text-decoration-thickness: 2px; }';

/** A bar-graph waveform. Pure presentation, deterministic heights. */
const Wave = ({ n = 30, h = 56, w = 3, color = '#7C5CFF', phase = 0, floor = 0.22 }) => (
  <row tw="flex flex-row items-end" gap={3} h={h} w="100%">
    {seq(n, (i) => (
      <div
        w={w}
        h={Math.max(3, Math.round(h * (floor + (1 - floor) * Math.abs(Math.sin(i * 0.79 + phase)))))}
        radius={2}
        bg={color}
      />
    ))}
  </row>
);

const Eyebrow = ({ children, color = '#9AA1B0' }) => (
  <text size={11} weight={700} ls={0.14} color={color} font="Manrope" tw="uppercase">
    {children}
  </text>
);

/* Repeaters — content props only (native Elementor components where available). */

const ExportCard = defineComponent(
  ({ format = 'MP3', spec = '', body = '' }) => (
    <div
      tw="flex flex-col hover:bg-[#1E222B]"
      bg="#181B22"
      radius={18}
      pad={26}
      gap={10}
      border={[1, '#272B35']}
      h="100%"
    >
      <text size={13} weight={700} ls={0.1} color="#7C5CFF" font="Manrope" tw="uppercase">
        {format}
      </text>
      <heading tag="h3" size={22} weight={600} font="Outfit" color="#EDEEF2" lh={1.25}>
        {spec}
      </heading>
      <text size={15} color="#9AA1B0" font="Manrope" lh={1.65}>
        {body}
      </text>
    </div>
  ),
  {
    title: 'Gainstage export card',
    props: {
      format: { label: 'Format', group: 'Export' },
      spec: { label: 'Spec', group: 'Export' },
      body: { label: 'Body', group: 'Export' },
    },
  },
);

const PriceTier = defineComponent(
  ({ tier = 'Free', price = '0', unit = 'a month', hours = '', body = '', action = 'Start free' }) => (
    <div
      tw="flex flex-col hover:bg-[#1E222B]"
      bg="#181B22"
      radius={20}
      pad={30}
      gap={14}
      border={[1, '#272B35']}
      h="100%"
    >
      <Eyebrow>{tier}</Eyebrow>
      <row tw="flex flex-row items-end" gap={8}>
        <heading tag="h3" size={44} weight={600} font="Outfit" color="#EDEEF2" lh={1}>
          {price}
        </heading>
        <text size={14} color="#9AA1B0" font="Manrope">
          {unit}
        </text>
      </row>
      <text size={15} weight={600} color="#48E0A0" font="Manrope">
        {hours}
      </text>
      <text size={15} color="#9AA1B0" font="Manrope" lh={1.65}>
        {body}
      </text>
      <text
        href="#start"
        tw="hover:bg-[#7C5CFF] hover:text-[#0F1116]"
        size={14}
        weight={700}
        font="Manrope"
        color="#EDEEF2"
        bg="#0F1116"
        border={[1, '#272B35']}
        radius={999}
        pad={{ t: 12, b: 12, l: 20, r: 20 }}
        ta="center"
        m={{ t: 6 }}
      >
        {action}
      </text>
    </div>
  ),
  {
    title: 'Gainstage price tier',
    props: {
      tier: { label: 'Tier', group: 'Plan' },
      price: { label: 'Price', group: 'Plan' },
      unit: { label: 'Unit', group: 'Plan' },
      hours: { label: 'Hours', group: 'Plan' },
      body: { label: 'Body', group: 'Plan' },
      action: { label: 'Button label', group: 'Plan' },
    },
  },
);

/* ── page ─────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
    {/* ── 1 · bento hero ─────────────────────────────────────────── */}
    <section
      id="top"
      tw="flex flex-col w-full items-center"
      pad={{ t: 28, b: 96, l: 24, r: 24 }}
      bg={t.color.ground}
      mobile={{ pad: { t: 20, b: 64, l: 16, r: 16 } }}
    >
      <row
        tw="flex flex-row items-center justify-between w-full"
        maxw={1200}
        pad={{ t: 12, b: 40 }}
        gap={16}
        mobile={{ pad: { b: 28 } }}
      >
        <text size={19} weight={700} ls={-0.01} font="Outfit" color={t.color.ink}>
          Gainstage
        </text>
        <row tw="flex flex-row items-center" gap={26}>
          <text href="#room-tone" tw="hover:text-[#7C5CFF]" size={14} font="Manrope" color={t.color.dim}>
            How it works
          </text>
          <text href="#pricing" tw="hover:text-[#7C5CFF]" size={14} font="Manrope" color={t.color.dim}>
            Pricing
          </text>
          <text
            href="#start"
            tw="hover:bg-[#8F74FF]"
            size={14}
            weight={700}
            font="Manrope"
            color="#0F1116"
            bg={t.color.wave}
            radius={999}
            pad={{ t: 10, b: 10, l: 18, r: 18 }}
            mobile={{ size: 12, pad: { t: 8, b: 8, l: 13, r: 13 } }}
          >
            Try it free
          </text>
        </row>
      </row>

      <grid cols={12} gap={16} w="100%" maxw={1200} tablet={{ gridCols: 6 }}>
        {/* headline tile */}
        <div
          span={7}
          rowSpan={2}
          tablet={{ span: 6 }}
          tw="flex flex-col justify-between"
          bg={t.color.tile}
          radius={24}
          pad={44}
          gap={28}
          shadow={TILE_SHADOW}
          mobile={{ span: 1, pad: 26 }}
        >
          <div tw="flex flex-col" gap={22}>
            <Eyebrow color={t.color.wave}>Transcript-first editing</Eyebrow>
            <h1
              size={62}
              weight={600}
              lh={1.05}
              ls={-0.03}
              font={t.font.head}
              color={t.color.ink}
              tablet={{ size: 50 }}
              mobile={{ size: 34 }}
            >
              Edit the transcript. The audio follows.
            </h1>
            <text
              size={17}
              lh={1.7}
              font={t.font.body}
              color={t.color.dim}
              maxw={560}
              mobile={{ size: 15 }}
            >
              Delete a sentence and Gainstage removes it from every track, smooths the room tone
              across the join, and keeps your guest in sync. A 90-minute conversation becomes a
              finished episode in about 25 minutes.
            </text>
          </div>
          <row tw="flex flex-row items-center flex-wrap" gap={14}>
            <text
              href="#start"
              tw="hover:bg-[#8F74FF]"
              size={16}
              weight={700}
              font={t.font.body}
              color="#0F1116"
              bg={t.color.wave}
              radius={999}
              pad={{ t: 16, b: 16, l: 28, r: 28 }}
            >
              Edit your first episode free
            </text>
            <text size={13.5} font={t.font.body} color="#6E7585">
              No card. Two hours of audio a month, forever.
            </text>
          </row>
        </div>

        {/* transcript tile */}
        <div
          span={5}
          tablet={{ span: 6 }}
          mobile={{ span: 1 }}
          tw="flex flex-col"
          bg={t.color.tile}
          radius={24}
          pad={26}
          gap={14}
          shadow={TILE_SHADOW}
          motion={RISE}
        >
          <Eyebrow>The edit surface</Eyebrow>
          <div tw="flex flex-col" gap={9}>
            <text size={14.5} lh={1.55} font={t.font.body} color={t.color.ink} raw={KEEP}>
              <strong>[00:14:02]</strong> So the thing nobody tells you about launching a show
            </text>
            <text size={14.5} lh={1.55} font={t.font.body} color="#6E7585" raw={STRUCK}>
              um, is that, you know, the editing is the actual job, right
            </text>
            <text size={14.5} lh={1.55} font={t.font.body} color={t.color.ink} raw={KEEP}>
              is that the editing is the actual job. <strong>Every week.</strong>
            </text>
          </div>
          <row tw="flex flex-row items-center" gap={8} m={{ t: 4 }}>
            <div w={8} h={8} radius={999} bg={t.color.hot} />
            <text size={12.5} font={t.font.body} color="#6E7585">
              1 line deleted · 6.2 s removed from 4 tracks
            </text>
          </row>
        </div>

        {/* waveform tile */}
        <div
          span={3}
          tablet={{ span: 3 }}
          mobile={{ span: 1 }}
          tw="flex flex-col justify-between"
          bg={t.color.tile}
          radius={24}
          pad={24}
          gap={18}
          shadow={TILE_SHADOW}
          motion={RISE}
        >
          <Eyebrow>Room tone</Eyebrow>
          <Wave n={26} h={64} color="#7C5CFF" />
          <text size={12.5} font={t.font.body} color="#6E7585" lh={1.5}>
            The join is crossfaded against the room, not against silence.
          </text>
        </div>

        {/* timer tile */}
        <div
          span={2}
          tablet={{ span: 3 }}
          mobile={{ span: 1 }}
          tw="flex flex-col justify-between"
          bg={t.color.tile}
          radius={24}
          pad={24}
          gap={12}
          shadow={TILE_SHADOW}
          motion={RISE}
        >
          <Eyebrow>Sunday</Eyebrow>
          <div tw="flex flex-col" gap={2}>
            <text size={15} font={t.font.body} color="#6E7585" raw={STRUCK}>
              4h 10m
            </text>
            <heading tag="h2" size={34} weight={600} font={t.font.head} color={t.color.ok} lh={1.1}>
              25m
            </heading>
          </div>
          <text size={12.5} font={t.font.body} color="#6E7585" lh={1.5}>
            Recording to published.
          </text>
        </div>

        {/* photo tile */}
        <div
          span={5}
          tablet={{ span: 6 }}
          tw="flex flex-col overflow-hidden"
          radius={24}
          h={260}
          shadow={TILE_SHADOW}
          mobile={{ span: 1, h: 200 }}
        >
          <img src={media.host_recording.id} w="100%" h={260} fit="cover" radius={24} mobile={{ h: 200 }} />
        </div>

        {/* stat tile */}
        <div
          span={7}
          tablet={{ span: 6 }}
          mobile={{ span: 1 }}
          tw="flex flex-row items-center justify-between flex-wrap"
          bg={t.color.tile}
          radius={24}
          pad={30}
          gap={20}
          shadow={TILE_SHADOW}
        >
          <div tw="flex flex-col" gap={4}>
            <heading tag="h2" size={30} weight={600} font={t.font.head} color={t.color.ink}>
              8
            </heading>
            <text size={13.5} font={t.font.body} color="#6E7585">
              tracks locked together
            </text>
          </div>
          <div w={1} h={44} bg={t.color.line} mobile={{ h: 28 }} />
          <div tw="flex flex-col" gap={4}>
            <heading tag="h2" size={30} weight={600} font={t.font.head} color={t.color.ink}>
              531
            </heading>
            <text size={13.5} font={t.font.body} color="#6E7585">
              filler words in a typical hour
            </text>
          </div>
          <div w={1} h={44} bg={t.color.line} mobile={{ h: 28 }} />
          <div tw="flex flex-col" gap={4}>
            <heading tag="h2" size={30} weight={600} font={t.font.head} color={t.color.ink}>
              0
            </heading>
            <text size={13.5} font={t.font.body} color="#6E7585">
              timeline dragging
            </text>
          </div>
        </div>
      </grid>
    </section>

    {/* ── 2 · cut the words, keep the room tone ──────────────────── */}
    <section
      id="room-tone"
      tw="flex flex-col w-full items-center"
      pad={{ t: 104, b: 104, l: 24, r: 24 }}
      bg={t.color.tile2}
      mobile={{ pad: { t: 64, b: 64, l: 16, r: 16 } }}
    >
      <grid cols={12} gap={44} w="100%" maxw={1200} tablet={{ gridCols: 6 }}>
        <div span={5} tablet={{ span: 6 }} mobile={{ span: 1 }} tw="flex flex-col" gap={20} motion={RISE}>
          <Eyebrow color={t.color.wave}>01 — The join</Eyebrow>
          <heading
            tag="h2"
            size={44}
            weight={600}
            lh={1.12}
            ls={-0.02}
            font={t.font.head}
            color={t.color.ink}
            mobile={{ size: 30 }}
          >
            Cut the words, keep the room tone
          </heading>
          <text size={16.5} lh={1.72} font={t.font.body} color={t.color.dim}>
            A cut in a waveform editor leaves a hole: the hiss of your room stops for a frame and
            every listener hears the seam. Gainstage samples the tone either side of the cut and
            rebuilds the gap, so the sentence disappears and the room stays.
          </text>
          <div tw="flex flex-col" gap={12} m={{ t: 8 }}>
            <row tw="flex flex-row items-start" gap={12}>
              <div w={6} h={6} radius={999} bg={t.color.ok} m={{ t: 8 }} />
              <text size={15} lh={1.6} font={t.font.body} color={t.color.dim}>
                Crossfades sized to the noise floor, not a fixed 10 ms.
              </text>
            </row>
            <row tw="flex flex-row items-start" gap={12}>
              <div w={6} h={6} radius={999} bg={t.color.ok} m={{ t: 8 }} />
              <text size={15} lh={1.6} font={t.font.body} color={t.color.dim}>
                Breaths kept or dropped per cut — the choice is one keypress.
              </text>
            </row>
            <row tw="flex flex-row items-start" gap={12}>
              <div w={6} h={6} radius={999} bg={t.color.ok} m={{ t: 8 }} />
              <text size={15} lh={1.6} font={t.font.body} color={t.color.dim}>
                Undo is a word, not a region. Retype it and the audio comes back.
              </text>
            </row>
          </div>
        </div>

        <div
          span={7}
          tablet={{ span: 6 }}
          tw="flex flex-col justify-center"
          bg={t.color.tile}
          radius={24}
          pad={32}
          gap={26}
          border={[1, t.color.line]}
          mobile={{ span: 1, pad: 20 }}
        >
          <div tw="flex flex-col" gap={10}>
            <Eyebrow>Before — the sentence is still there</Eyebrow>
            <row tw="flex flex-row items-end" gap={0}>
              <Wave n={16} h={70} color="#3A3F4D" />
              <Wave n={8} h={70} color="#FF6B6B" phase={2.1} />
              <Wave n={16} h={70} color="#3A3F4D" phase={4.3} />
            </row>
          </div>
          <div tw="flex flex-col" gap={10}>
            <Eyebrow color={t.color.ok}>After — the room survives the cut</Eyebrow>
            <row tw="flex flex-row items-end" gap={0}>
              <Wave n={16} h={70} color="#7C5CFF" />
              <Wave n={4} h={70} color="#48E0A0" floor={0.12} phase={5.5} />
              <Wave n={16} h={70} color="#7C5CFF" phase={4.3} />
            </row>
          </div>
          <text size={13.5} font={t.font.body} color="#6E7585" lh={1.6}>
            The green span is 180 ms of rebuilt room tone. Nobody has ever noticed one.
          </text>
        </div>
      </grid>
    </section>

    {/* ── 3 · filler word sweep ──────────────────────────────────── */}
    <section
      id="filler"
      tw="flex flex-col w-full items-center"
      pad={{ t: 104, b: 104, l: 24, r: 24 }}
      bg={t.color.ground}
      mobile={{ pad: { t: 64, b: 64, l: 16, r: 16 } }}
    >
      <div tw="flex flex-col w-full" maxw={1200} gap={40}>
        <row
          tw="flex flex-row items-end justify-between flex-wrap w-full"
          gap={24}
          motion={RISE}
        >
          <div tw="flex flex-col" gap={16} maxw={640}>
            <Eyebrow color={t.color.wave}>02 — The sweep</Eyebrow>
            <heading
              tag="h2"
              size={44}
              weight={600}
              lh={1.12}
              ls={-0.02}
              font={t.font.head}
              color={t.color.ink}
              mobile={{ size: 30 }}
            >
              Filler word sweep, with a before and after
            </heading>
            <text size={16.5} lh={1.72} font={t.font.body} color={t.color.dim}>
              One click removes 412 ums, 88 likes and 31 you knows, and you can hear each one
              before it goes.
            </text>
          </div>
          <row tw="flex flex-row flex-wrap" gap={10}>
            <text size={13} weight={700} font={t.font.body} color={t.color.hot} bg="#231A1E" radius={999} pad={{ t: 9, b: 9, l: 16, r: 16 }}>
              412 um
            </text>
            <text size={13} weight={700} font={t.font.body} color={t.color.hot} bg="#231A1E" radius={999} pad={{ t: 9, b: 9, l: 16, r: 16 }}>
              88 like
            </text>
            <text size={13} weight={700} font={t.font.body} color={t.color.hot} bg="#231A1E" radius={999} pad={{ t: 9, b: 9, l: 16, r: 16 }}>
              31 you know
            </text>
          </row>
        </row>

        <grid cols={2} gap={16} w="100%" tablet={{ gridCols: 2 }}>
          <div
            span={1}
            tw="flex flex-col"
            bg={t.color.tile}
            radius={22}
            pad={30}
            gap={16}
            border={[1, '#3A2A30']}
            mobile={{ span: 1, pad: 20 }}
          >
            <row tw="flex flex-row items-center justify-between" gap={12}>
              <Eyebrow color={t.color.hot}>Raw recording</Eyebrow>
              <text size={12.5} font={t.font.body} color="#6E7585">
                62:41
              </text>
            </row>
            <text size={15.5} lh={1.8} font={t.font.body} color={t.color.dim} raw={CUT}>
              <strong>So um</strong>, the thing about doing this every week is, <strong>like</strong>,
              you sit down on Sunday and, <strong>you know</strong>, you think it's going to take an
              hour and, <strong>um</strong>, it never does.
            </text>
          </div>

          <div
            span={1}
            tw="flex flex-col"
            bg={t.color.tile}
            radius={22}
            pad={30}
            gap={16}
            border={[1, '#1E3B33']}
            mobile={{ span: 1, pad: 20 }}
          >
            <row tw="flex flex-row items-center justify-between" gap={12}>
              <Eyebrow color={t.color.ok}>After the sweep</Eyebrow>
              <text size={12.5} font={t.font.body} color={t.color.ok}>
                58:04
              </text>
            </row>
            <text size={15.5} lh={1.8} font={t.font.body} color={t.color.ink}>
              The thing about doing this every week is you sit down on Sunday and you think it's
              going to take an hour, and it never does.
            </text>
            <text size={13.5} font={t.font.body} color="#6E7585" lh={1.6} m={{ t: 'auto' }}>
              Every removal is a checkbox. Play it, keep it, or let it go — the same list, in the
              order you speak.
            </text>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 4 · multitrack sync ────────────────────────────────────── */}
    <section
      id="multitrack"
      tw="flex flex-col w-full items-center"
      pad={{ t: 104, b: 104, l: 24, r: 24 }}
      bg={t.color.tile2}
      mobile={{ pad: { t: 64, b: 64, l: 16, r: 16 } }}
    >
      <grid cols={12} gap={44} w="100%" maxw={1200} tablet={{ gridCols: 6 }}>
        <div
          span={7}
          tablet={{ span: 6 }}
          tw="flex flex-col"
          bg={t.color.tile}
          radius={24}
          pad={30}
          gap={14}
          border={[1, t.color.line]}
          mobile={{ span: 1, pad: 18 }}
        >
          {['Host — SM7B', 'Guest 1 — remote', 'Guest 2 — remote', 'Call backup', 'Intro bed', 'Ad read', 'Room mic', 'Scratch'].map(
            (label, i) => (
              <row tw="flex flex-row items-center" gap={14}>
                <text size={12} weight={600} font={t.font.body} color="#6E7585" w={132} mobile={{ w: 92, size: 10 }}>
                  {label}
                </text>
                <Wave
                  n={34}
                  h={i === 0 ? 26 : 20}
                  w={3}
                  phase={i * 1.3}
                  color={i === 0 ? '#7C5CFF' : i < 3 ? '#5A4BB0' : '#333846'}
                  floor={0.18}
                />
              </row>
            ),
          )}
          <row tw="flex flex-row items-center" gap={10} m={{ t: 6 }}>
            <div w={8} h={8} radius={999} bg={t.color.ok} />
            <text size={12.5} font={t.font.body} color="#6E7585">
              Drift corrected across 62 minutes — max offset 0.4 ms
            </text>
          </row>
        </div>

        <div span={5} tablet={{ span: 6 }} mobile={{ span: 1 }} tw="flex flex-col justify-center" gap={20} motion={RISE}>
          <Eyebrow color={t.color.wave}>03 — The lock</Eyebrow>
          <heading
            tag="h2"
            size={44}
            weight={600}
            lh={1.12}
            ls={-0.02}
            font={t.font.head}
            color={t.color.ink}
            mobile={{ size: 30 }}
          >
            Multitrack sync for remote guests
          </heading>
          <text size={16.5} lh={1.72} font={t.font.body} color={t.color.dim}>
            Up to eight tracks stay locked together. Cut on the host track and the guest track cuts
            with it, drift-corrected across the whole file.
          </text>
          <text size={15.5} lh={1.7} font={t.font.body} color="#6E7585">
            Drop in the local recordings your guest uploaded after the call and Gainstage aligns
            them against the call backup, then throws the backup away.
          </text>
        </div>
      </grid>
    </section>

    {/* ── 5 · chapters, notes, clips ─────────────────────────────── */}
    <section
      id="derived"
      tw="flex flex-col w-full items-center"
      pad={{ t: 104, b: 104, l: 24, r: 24 }}
      bg={t.color.ground}
      mobile={{ pad: { t: 64, b: 64, l: 16, r: 16 } }}
    >
      <div tw="flex flex-col w-full" maxw={1200} gap={36}>
        <div tw="flex flex-col" gap={16} maxw={720} motion={RISE}>
          <Eyebrow color={t.color.wave}>04 — The by-products</Eyebrow>
          <heading
            tag="h2"
            size={44}
            weight={600}
            lh={1.12}
            ls={-0.02}
            font={t.font.head}
            color={t.color.ink}
            mobile={{ size: 30 }}
          >
            Chapters, show notes and clips, generated from the edit
          </heading>
        </div>

        <grid cols={12} gap={16} w="100%" tablet={{ gridCols: 6 }}>
          <div
            span={7}
            rowSpan={2}
            tablet={{ span: 6 }}
            tw="flex flex-col justify-between"
            bg={t.color.tile}
            radius={24}
            pad={34}
            gap={24}
            shadow={TILE_SHADOW}
            mobile={{ span: 1, pad: 22 }}
          >
            <div tw="flex flex-col" gap={14}>
              <Eyebrow color={t.color.wave}>Clips</Eyebrow>
              <heading tag="h3" size={26} weight={600} font={t.font.head} color={t.color.ink} lh={1.25}>
                Mark a moment, get a vertical cut
              </heading>
              <text size={16} lh={1.72} font={t.font.body} color={t.color.dim} maxw={520}>
                Mark a moment and get a vertical clip with burned captions, sized for three
                platforms, without opening a video editor.
              </text>
            </div>
            <row tw="flex flex-row flex-wrap" gap={12}>
              <div tw="flex flex-col justify-end" w={112} h={150} radius={12} bg="#0F1116" pad={10} border={[1, t.color.line]}>
                <text size={10.5} weight={700} font={t.font.body} color={t.color.ink} lh={1.35}>
                  "the editing is the actual job"
                </text>
              </div>
              <div tw="flex flex-col justify-end" w={112} h={150} radius={12} bg="#0F1116" pad={10} border={[1, t.color.line]}>
                <text size={10.5} weight={700} font={t.font.body} color={t.color.ink} lh={1.35}>
                  "we recorded it in a closet"
                </text>
              </div>
              <div tw="flex flex-col justify-end" w={112} h={150} radius={12} bg="#0F1116" pad={10} border={[1, t.color.line]}>
                <text size={10.5} weight={700} font={t.font.body} color={t.color.ink} lh={1.35}>
                  "nobody listens to episode one"
                </text>
              </div>
              <div tw="flex flex-col justify-center items-center" w={112} h={150} radius={12} bg="#14171E" border={[1, t.color.line]}>
                <text size={11} weight={700} font={t.font.body} color="#6E7585" ta="center" lh={1.4}>
                  9:16 · 1:1 · 4:5
                </text>
              </div>
            </row>
          </div>

          <div
            span={5}
            tablet={{ span: 6 }}
            tw="flex flex-col hover:bg-[#1E222B]"
            bg={t.color.tile}
            radius={24}
            pad={30}
            gap={12}
            shadow={TILE_SHADOW}
            mobile={{ span: 1, pad: 22 }}
          >
            <Eyebrow color={t.color.ok}>Show notes</Eyebrow>
            <heading tag="h3" size={22} weight={600} font={t.font.head} color={t.color.ink} lh={1.25}>
              Written from the final cut
            </heading>
            <text size={15.5} lh={1.68} font={t.font.body} color={t.color.dim}>
              Chapters, a summary and a link list generated from the final edit, not the raw
              recording, so nothing you cut comes back.
            </text>
          </div>

          <div
            span={5}
            tablet={{ span: 6 }}
            tw="flex flex-col"
            bg={t.color.tile}
            radius={24}
            pad={30}
            gap={12}
            shadow={TILE_SHADOW}
            mobile={{ span: 1, pad: 22 }}
          >
            <Eyebrow>Chapters</Eyebrow>
            <div tw="flex flex-col" gap={9}>
              <row tw="flex flex-row items-end" gap={12}>
                <text size={13} weight={700} font={t.font.body} color={t.color.wave} w={54}>
                  00:00
                </text>
                <text size={14.5} font={t.font.body} color={t.color.dim}>
                  Cold open
                </text>
              </row>
              <row tw="flex flex-row items-end" gap={12}>
                <text size={13} weight={700} font={t.font.body} color={t.color.wave} w={54}>
                  04:12
                </text>
                <text size={14.5} font={t.font.body} color={t.color.dim}>
                  Why the Sunday edit eats the week
                </text>
              </row>
              <row tw="flex flex-row items-end" gap={12}>
                <text size={13} weight={700} font={t.font.body} color={t.color.wave} w={54}>
                  29:48
                </text>
                <text size={14.5} font={t.font.body} color={t.color.dim}>
                  The closet studio question
                </text>
              </row>
              <row tw="flex flex-row items-end" gap={12}>
                <text size={13} weight={700} font={t.font.body} color={t.color.wave} w={54}>
                  51:03
                </text>
                <text size={14.5} font={t.font.body} color={t.color.dim}>
                  Listener mail and the sign-off
                </text>
              </row>
            </div>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 6 · export targets ─────────────────────────────────────── */}
    <section
      id="export"
      tw="flex flex-col w-full items-center"
      pad={{ t: 104, b: 104, l: 24, r: 24 }}
      bg={t.color.tile2}
      mobile={{ pad: { t: 64, b: 64, l: 16, r: 16 } }}
    >
      <div tw="flex flex-col w-full" maxw={1200} gap={36}>
        <row tw="flex flex-row items-end justify-between flex-wrap" gap={24} motion={RISE}>
          <div tw="flex flex-col" gap={16} maxw={620}>
            <Eyebrow color={t.color.wave}>05 — The hand-off</Eyebrow>
            <heading
              tag="h2"
              size={44}
              weight={600}
              lh={1.12}
              ls={-0.02}
              font={t.font.head}
              color={t.color.ink}
              mobile={{ size: 30 }}
            >
              Export targets, and what each one is for
            </heading>
          </div>
          <text size={15.5} lh={1.7} font={t.font.body} color={t.color.dim} maxw={420}>
            Export a mastered MP3 at -16 LUFS, a WAV for your own mastering, or a project file for
            Reaper, Logic and Audition if you want to finish by hand.
          </text>
        </row>

        <grid cols={3} gap={16} w="100%" tablet={{ gridCols: 3 }}>
          <ExportCard
            format="MP3"
            spec="Mastered to -16 LUFS"
            body="Loudness-normalised for every podcast app, ID3 tags and chapter markers already written. Drop it straight into your host."
          />
          <ExportCard
            format="WAV"
            spec="24-bit, untouched"
            body="The edit without the master, for when you have your own chain or a mastering engineer who has opinions about yours."
          />
          <ExportCard
            format="Project"
            spec="Reaper, Logic, Audition"
            body="Every track, every cut, every crossfade as real regions on a real timeline. Finish by hand from exactly where the transcript left off."
          />
        </grid>
      </div>
    </section>

    {/* ── 7 · pricing ────────────────────────────────────────────── */}
    <section
      id="pricing"
      tw="flex flex-col w-full items-center"
      pad={{ t: 104, b: 104, l: 24, r: 24 }}
      bg={t.color.ground}
      mobile={{ pad: { t: 64, b: 64, l: 16, r: 16 } }}
    >
      <div tw="flex flex-col w-full" maxw={1200} gap={36}>
        <div tw="flex flex-col" gap={16} maxw={640} motion={RISE}>
          <Eyebrow color={t.color.wave}>06 — The bill</Eyebrow>
          <heading
            tag="h2"
            size={44}
            weight={600}
            lh={1.12}
            ls={-0.02}
            font={t.font.head}
            color={t.color.ink}
            mobile={{ size: 30 }}
          >
            Priced by hours of audio, not seats
          </heading>
          <text size={16.5} lh={1.72} font={t.font.body} color={t.color.dim}>
            Free for two hours a month. 19 a month for twenty hours. 49 for unlimited, with every
            co-host included at no extra cost.
          </text>
        </div>

        <grid cols={3} gap={16} w="100%" tablet={{ gridCols: 3 }}>
          <PriceTier
            tier="Free"
            price="0"
            unit="a month"
            hours="Two hours of audio"
            body="The whole editor. Transcript cuts, room-tone joins, MP3 export. Enough for a fortnightly show that runs under an hour."
            action="Start free"
          />
          <PriceTier
            tier="Weekly"
            price="19"
            unit="a month"
            hours="Twenty hours of audio"
            body="Filler sweep, multitrack sync, clips and generated show notes. The plan for a show that ships every week without fail."
            action="Choose Weekly"
          />
          <PriceTier
            tier="Unlimited"
            price="49"
            unit="a month"
            hours="Unlimited audio"
            body="Every co-host included at no extra cost, project-file export, and back-catalogue re-edits whenever you feel like it."
            action="Choose Unlimited"
          />
        </grid>
      </div>
    </section>

    {/* ── 8 · start a free episode (the one centred section) ─────── */}
    <section
      id="start"
      tw="flex flex-col w-full items-center"
      pad={{ t: 104, b: 88, l: 24, r: 24 }}
      bg={t.color.tile2}
      mobile={{ pad: { t: 64, b: 56, l: 16, r: 16 } }}
    >
      <div tw="flex flex-col items-center w-full" maxw={780} gap={22} ta="center" motion={RISE}>
        <Eyebrow color={t.color.wave}>Start a free episode</Eyebrow>
        <heading
          tag="h2"
          size={50}
          weight={600}
          lh={1.1}
          ls={-0.02}
          font={t.font.head}
          color={t.color.ink}
          ta="center"
          mobile={{ size: 32 }}
        >
          Give Sunday afternoon back to yourself
        </heading>
        <text size={17} lh={1.7} font={t.font.body} color={t.color.dim} ta="center" maxw={620} mobile={{ size: 15 }}>
          Upload one episode, cut it by reading it, and export a mastered file before the kettle
          boils. Nothing to install and no card to enter.
        </text>
        <text
          href="#top"
          tw="hover:bg-[#8F74FF]"
          size={17}
          weight={700}
          font={t.font.body}
          color="#0F1116"
          bg={t.color.wave}
          radius={999}
          pad={{ t: 18, b: 18, l: 34, r: 34 }}
          m={{ t: 6 }}
        >
          Edit your first episode free
        </text>
        <text size={13} font={t.font.body} color="#6E7585" ta="center">
          Two hours of audio a month, free forever · MP3, WAV and project export on every plan
        </text>
      </div>

      <div tw="flex flex-col w-full overflow-hidden" maxw={1200} radius={24} m={{ t: 64 }} shadow={TILE_SHADOW}>
        <img src={media.studio_desk.id} w="100%" h={320} fit="cover" radius={24} mobile={{ h: 190 }} />
      </div>

      <row
        tw="flex flex-row items-center justify-between flex-wrap w-full"
        maxw={1200}
        m={{ t: 40 }}
        pad={{ t: 28 }}
        gap={16}
        border={[1, 'transparent']}
      >
        <text size={14} weight={700} font={t.font.head} color={t.color.ink}>
          Gainstage
        </text>
        <text size={13} font={t.font.body} color="#6E7585">
          Transcript-first editing for people who record their own show. © 2026 Gainstage.
        </text>
      </row>
    </section>
  </box>
);
