import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Kilnhouse — Flame-fired stoneware from Coimbra',
  seo: {
    title: 'Kilnhouse — Six pieces. One kiln. Made to outlive us.',
    description:
      'Flame-fired stoneware cookware from a single workshop in Coimbra: six shapes, four glazes, sold direct. No nonstick, no coatings, no seasoning rituals.',
  },
};

/* ── catalogue data ─────────────────────────────────────────────── */

const SHAPES = [
  { no: '01', name: 'The 26cm Braiser', price: '190 euro', note: 'Oven to table to fridge. The one most people start with.' },
  { no: '02', name: 'The 24cm Deep Skillet', price: '165 euro', note: 'Sears on the hob, finishes in the oven, keeps its heat on the board.' },
  { no: '03', name: 'The 3.5L Stockpot', price: '210 euro', note: 'Stock, beans, and the long Sunday braise nobody watches.' },
  { no: '04', name: 'The 28cm Baking Dish', price: '145 euro', note: 'Gratins, tray bakes, and a crumble that comes out edge-crisp.' },
  { no: '05', name: 'The 1.2L Saucier', price: '120 euro', note: 'Sauces, grains, and dinner for one without apology.' },
  { no: '06', name: 'The 32cm Roasting Plate', price: '175 euro', note: 'A whole chicken with room around it, potatoes underneath.' },
];

const GLAZES = [
  { name: 'Ash', swatch: '#B9B2A4', note: 'Pale, matte, moves in the fire' },
  { name: 'Ox Blood', swatch: '#7E2B21', note: 'Deep red, pooling at the foot' },
  { name: 'Fig', swatch: '#4A3550', note: 'Bruised purple, near black in shade' },
  { name: 'Raw', swatch: '#9C8368', note: 'Unglazed outside, glazed within' },
];

const FIRING = [
  { no: '01', img: media.kiln_firing.id, title: 'Thrown', body: 'Every piece is thrown on the wheel in Coimbra, one of six shapes, no moulds.' },
  { no: '02', img: media.glaze_macro.id, title: 'Glazed', body: 'Dipped by hand in one of four glazes, food-safe and lead-free, tested twice a year.' },
  { no: '03', img: media.catalogue_still.id, title: 'Fired', body: 'Flame-fired to 1280°C over two days. The kiln decides the last ten percent.' },
  { no: '04', img: media.kitchen_use.id, title: 'Checked and boxed', body: 'Rung for tone, checked for crazing, signed by the four people who made it.' },
];

const YES = [
  'The dishwasher, every day, forever',
  'The oven to 260°C, lid on or off',
  'Gas, electric, induction, open flame',
  'Metal spoons, knives, whisks',
  'Straight from oven to table to fridge',
];

const NO = [
  'Freezer to a hot oven — thermal shock',
  'A cold sink under a hot pan',
  'Empty on a high flame for ten minutes',
  'Bleach or oven cleaner, it does not need it',
  'Seasoning. There is no coating to feed.',
];

/* ── small repeaters (content props only) ───────────────────────── */

const Shape = defineComponent(
  ({ no, name, price, note }) => (
    <box
      tw="flex flex-col gap-3 px-7 py-8 bg-[#FFFFFF]"
      minh={230}
      border={[1, '#CDC3B4']}
      hover={{ bg: '#F4EFE6' }}
    >
      <row tw="flex flex-row justify-between items-start w-full">
        <text size={12} weight={600} ls={0.14} font="Karla" color="#B4572F">{no}</text>
        <text size={12} weight={500} ls={0.08} font="Karla" color="#221D18">{price}</text>
      </row>
      <heading tag="h3" size={27} weight={500} lh={1.15} font="Fraunces" color="#221D18" mobile={{ size: 24 }}>
        {name}
      </heading>
      <text size={15} lh={1.6} font="Karla" color="#221D18" tw="max-w-[306px]">{note}</text>
    </box>
  ),
  {
    title: 'Kilnhouse Shape Cell',
    props: {
      no: { label: 'Index', group: 'Catalogue' },
      name: { label: 'Shape', group: 'Catalogue' },
      price: { label: 'Price', group: 'Catalogue' },
      note: { label: 'Note', group: 'Catalogue' },
    },
  },
);

const Swatch = defineComponent(
  ({ name, swatch, note }) => (
    <box tw="flex flex-col gap-3 w-full">
      <box h={92} w="100%" bg={swatch} border={[1, 'rgba(244,239,230,0.35)']} />
      <heading tag="h3" size={19} weight={500} font="Fraunces" color="#F4EFE6">{name}</heading>
      <text size={13} lh={1.55} font="Karla" color="rgba(244,239,230,0.72)">{note}</text>
    </box>
  ),
  {
    title: 'Kilnhouse Glaze Swatch',
    props: {
      name: { label: 'Glaze', group: 'Glazes' },
      swatch: { label: 'Swatch hex', group: 'Glazes' },
      note: { label: 'Note', group: 'Glazes' },
    },
  },
);

const Line = ({ text: t, mark, tone }) => (
  <row tw="flex flex-row gap-3 items-start w-full py-3" border={[1, '#CDC3B4']} pad={{ t: 12, b: 12 }}>
    <text size={14} weight={700} font="Karla" color={tone} w={18}>{mark}</text>
    <text size={15} lh={1.55} font="Karla" color="#221D18" flex={1}>{t}</text>
  </row>
);

const ORDER_FORM = `
<form class="kh-order" method="post" action="#order" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 20px;font-family:Karla,sans-serif;">
  <label style="display:flex;flex-direction:column;gap:7px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#221D18;">
    Shape
    <select name="shape" style="font-family:Karla,sans-serif;font-size:15px;letter-spacing:0;text-transform:none;padding:13px 12px;border:1px solid #CDC3B4;background:#FFFFFF;color:#221D18;border-radius:0;">
      <option>The 26cm Braiser — 190 euro</option>
      <option>The 24cm Deep Skillet — 165 euro</option>
      <option>The 3.5L Stockpot — 210 euro</option>
      <option>The 28cm Baking Dish — 145 euro</option>
      <option>The 1.2L Saucier — 120 euro</option>
      <option>The 32cm Roasting Plate — 175 euro</option>
    </select>
  </label>
  <label style="display:flex;flex-direction:column;gap:7px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#221D18;">
    Glaze
    <select name="glaze" style="font-family:Karla,sans-serif;font-size:15px;letter-spacing:0;text-transform:none;padding:13px 12px;border:1px solid #CDC3B4;background:#FFFFFF;color:#221D18;border-radius:0;">
      <option>Ash</option><option>Ox Blood</option><option>Fig</option><option>Raw</option>
    </select>
  </label>
  <label style="display:flex;flex-direction:column;gap:7px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#221D18;">
    Name
    <input type="text" name="name" placeholder="Who is it for" style="font-family:Karla,sans-serif;font-size:15px;letter-spacing:0;text-transform:none;padding:13px 12px;border:1px solid #CDC3B4;background:#FFFFFF;color:#221D18;border-radius:0;">
  </label>
  <label style="display:flex;flex-direction:column;gap:7px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#221D18;">
    Email
    <input type="email" name="email" placeholder="you@example.com" style="font-family:Karla,sans-serif;font-size:15px;letter-spacing:0;text-transform:none;padding:13px 12px;border:1px solid #CDC3B4;background:#FFFFFF;color:#221D18;border-radius:0;">
  </label>
  <label style="grid-column:1 / -1;display:flex;flex-direction:column;gap:7px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#221D18;">
    Anything we should know
    <textarea name="note" rows="3" placeholder="Gift note, delivery window, a question about the glaze" style="font-family:Karla,sans-serif;font-size:15px;letter-spacing:0;text-transform:none;padding:13px 12px;border:1px solid #CDC3B4;background:#FFFFFF;color:#221D18;border-radius:0;resize:vertical;"></textarea>
  </label>
  <div style="grid-column:1 / -1;display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between;">
    <button type="submit" style="font-family:Karla,sans-serif;font-size:14px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;padding:16px 30px;border:0;background:#B4572F;color:#F4EFE6;cursor:pointer;">Place the order</button>
    <span style="font-size:13px;line-height:1.5;color:#221D18;">Ships in 4 days from Portugal. Free over 120 euro in the EU and UK.</span>
  </div>
</form>
<style>
@media (max-width: 767px) { .kh-order { grid-template-columns: minmax(0,1fr) !important; } }
</style>
`;

/* ── page ───────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>

    {/* 1 · Masthead — wordmark and premise */}
    <section align="flex-start" tw="flex flex-col w-full px-14 pt-10 pb-20 max-lg:px-9 max-md:px-5 max-md:pt-7 max-md:pb-12" bg={t.color.ground}>
      <row
        tw="flex flex-row justify-between items-center w-full pb-5 max-md:flex-col max-md:items-start max-md:gap-2"
        border={[1, t.color.rule]}
        pad={{ b: 18 }}
      >
        <text size={17} weight={600} ls={0.28} font={t.font.head} color={t.color.ink}>
          KILNHOUSE
        </text>
        <text size={12} weight={500} ls={0.14} font={t.font.body} color={t.color.clay}>
          CATALOGUE N°4 · COIMBRA, PORTUGAL
        </text>
      </row>

      <grid cols={12} gapX={40} gapY={28} tw="w-full pt-12 max-md:pt-8" mobile={{ gridCols: 1 }}>
        <box span={7} tw="flex flex-col gap-6" mobile={{ span: 1 }}>
          <h1
            size={76}
            weight={400}
            lh={1.02}
            ls={-0.02}
            font={t.font.head}
            color={t.color.ink}
            tablet={{ size: 56 }}
            mobile={{ size: 38 }}
          >
            Six pieces. One kiln. Made to outlive us.
          </h1>
        </box>
        <box span={5} tw="flex flex-col gap-7 justify-end" mobile={{ span: 1 }}>
          <text size={17} lh={1.68} font={t.font.body} color={t.color.ink} tw="max-w-[414px]">
            Flame-fired stoneware from a single workshop in Coimbra, thrown and glazed by four
            people whose names are on the box. No nonstick, no coatings, no seasoning rituals.
          </text>
          <row tw="flex flex-row items-center gap-5 max-md:flex-col max-md:items-start max-md:gap-3">
            <text
              href="#the-six-shapes"
              tw="px-8 py-4 bg-[#B4572F]"
              size={13}
              weight={600}
              ls={0.12}
              font={t.font.body}
              color={t.color.ground}
              hover={{ bg: t.color.ink }}
            >
              SEE THE SIX SHAPES
            </text>
            <text size={13} lh={1.5} font={t.font.body} color={t.color.ink}>
              Ships in 4 days from Portugal
            </text>
          </row>
        </box>
      </grid>
    </section>

    {/* 2 · Six-shape catalogue grid */}
    <section id="the-six-shapes" align="flex-start" tw="flex flex-col w-full px-14 py-20 max-lg:px-9 max-md:px-5 max-md:py-12" bg={t.color.chalk}>
      <row
        tw="flex flex-row justify-between items-end w-full pb-6 max-md:flex-col max-md:items-start max-md:gap-3"
        border={[1, t.color.rule]}
        pad={{ b: 22 }}
      >
        <heading tag="h2" size={40} weight={400} lh={1.1} font={t.font.head} color={t.color.ink} mobile={{ size: 30 }}>
          The six shapes
        </heading>
        <text size={13} lh={1.55} font={t.font.body} color={t.color.ink} tw="max-w-[360px]">
          Six shapes is the whole range. We have made the same six since 2009 and have no plans for a seventh.
        </text>
      </row>

      <img
        src={media.catalogue_still.id}
        w="100%"
        h={440}
        fit="cover"
        tw="w-full my-10 max-md:my-6"
        tablet={{ h: 340 }}
        mobile={{ h: 220 }}
        motion={{ effect: 'fade', trigger: 'scrollIn' }}
      />

      <grid cols={3} gapX={0} gapY={0} tw="w-full" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
        {SHAPES.map((s) => Shape(s))}
      </grid>

      <text size={13} lh={1.6} font={t.font.body} color={t.color.ink} tw="pt-7 max-w-[558px]">
        The 26cm Braiser, 190 euro, oven to table to fridge — the piece we would keep if we could
        only keep one.
      </text>
    </section>

    {/* 3 · Glaze swatch strip */}
    <section align="flex-start" tw="flex flex-col w-full px-14 py-20 max-lg:px-9 max-md:px-5 max-md:py-12" bg={t.color.glaze}>
      <grid cols={12} gapX={44} gapY={30} tw="w-full" mobile={{ gridCols: 1 }}>
        <box span={5} tw="flex flex-col" mobile={{ span: 1 }}>
          <img src={media.glaze_macro.id} w="100%" h={420} fit="cover" tablet={{ h: 320 }} mobile={{ h: 240 }} />
        </box>
        <box span={7} tw="flex flex-col gap-8 justify-center" mobile={{ span: 1 }}>
          <heading tag="h2" size={40} weight={400} lh={1.1} font={t.font.head} color={t.color.ground} mobile={{ size: 30 }}>
            Four glazes
          </heading>
          <text size={16} lh={1.7} font={t.font.body} color="rgba(244,239,230,0.82)" tw="max-w-[468px]">
            Four glazes: Ash, Ox Blood, Fig, Raw. Every one is food-safe and lead-free, tested twice
            a year. Each pot takes the fire differently, so no two leave the kiln identical.
          </text>
          <grid cols={4} gapX={22} gapY={26} tw="w-full" mobile={{ gridCols: 2 }}>
            {GLAZES.map((g) => Swatch(g))}
          </grid>
        </box>
      </grid>
    </section>

    {/* 4 · How it is fired — four-photo sequence */}
    <section align="flex-start" tw="flex flex-col w-full px-14 py-20 max-lg:px-9 max-md:px-5 max-md:py-12" bg={t.color.ground}>
      <row
        tw="flex flex-row justify-between items-end w-full pb-6 max-md:flex-col max-md:items-start max-md:gap-3"
        border={[1, t.color.rule]}
        pad={{ b: 22 }}
      >
        <heading tag="h2" size={40} weight={400} lh={1.1} font={t.font.head} color={t.color.ink} mobile={{ size: 30 }}>
          How it is fired
        </heading>
        <text size={13} lh={1.55} font={t.font.body} color={t.color.clay} tw="max-w-[342px]">
          Four people. Two days in the kiln. One address.
        </text>
      </row>

      <grid cols={4} gapX={26} gapY={34} tw="w-full pt-10 max-md:pt-6" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
        {FIRING.map((f) => (
          <box tw="flex flex-col gap-4" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            <img src={f.img} w="100%" h={260} fit="cover" tablet={{ h: 240 }} mobile={{ h: 210 }} />
            <text size={12} weight={600} ls={0.14} font={t.font.body} color={t.color.clay}>{f.no}</text>
            <heading tag="h3" size={24} weight={500} lh={1.15} font={t.font.head} color={t.color.ink}>
              {f.title}
            </heading>
            <text size={14} lh={1.6} font={t.font.body} color={t.color.ink}>{f.body}</text>
          </box>
        ))}
      </grid>
    </section>

    {/* 5 · Care card */}
    <section align="flex-start" tw="flex flex-col w-full px-14 py-20 max-lg:px-9 max-md:px-5 max-md:py-12" bg={t.color.chalk}>
      <grid cols={12} gapX={44} gapY={30} tw="w-full" mobile={{ gridCols: 1 }}>
        <box span={4} tw="flex flex-col gap-6" mobile={{ span: 1 }}>
          <heading tag="h2" size={40} weight={400} lh={1.1} font={t.font.head} color={t.color.ink} mobile={{ size: 30 }}>
            What it takes, and what it will not
          </heading>
          <text size={17} lh={1.65} font={t.font.head} color={t.color.clay} tw="max-w-[306px]">
            Dishwasher yes. Thermal shock no. Do not take it from freezer to a hot oven and it will
            see out your kitchen.
          </text>
        </box>
        <box span={8} tw="flex flex-col p-9 max-md:p-6" bg={t.color.ground} border={[1, t.color.rule]} mobile={{ span: 1 }}>
          <grid cols={2} gapX={40} gapY={0} tw="w-full" mobile={{ gridCols: 1 }}>
            <box tw="flex flex-col gap-1">
              <text size={12} weight={600} ls={0.14} font={t.font.body} color={t.color.glaze} tw="pb-3">
                IT CAN TAKE
              </text>
              {YES.map((y) => <Line text={y} mark="+" tone={t.color.glaze} />)}
            </box>
            <box tw="flex flex-col gap-1">
              <text size={12} weight={600} ls={0.14} font={t.font.body} color={t.color.clay} tw="pb-3">
                IT CANNOT
              </text>
              {NO.map((n) => <Line text={n} mark="—" tone={t.color.clay} />)}
            </box>
          </grid>
        </box>
      </grid>
    </section>

    {/* 6 · Kitchen in use, full bleed */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ink}>
      <img src={media.kitchen_use.id} w="100%" h={620} fit="cover" tablet={{ h: 460 }} mobile={{ h: 320 }} />
      <row
        tw="flex flex-row justify-between items-center w-full px-14 py-6 max-lg:px-9 max-md:px-5 max-md:flex-col max-md:items-start max-md:gap-2"
        bg={t.color.ink}
      >
        <text size={13} lh={1.5} font={t.font.body} color={t.color.ground}>
          The 26cm Braiser, Ox Blood, in its fourth year in a Lisbon kitchen.
        </text>
        <text size={12} weight={500} ls={0.14} font={t.font.body} color="rgba(244,239,230,0.6)">
          PHOTOGRAPHED UNRETOUCHED
        </text>
      </row>
    </box>

    {/* 7 · Lifetime replacement terms */}
    <section align="flex-start" tw="flex flex-col w-full px-14 py-20 max-lg:px-9 max-md:px-5 max-md:py-12" bg={t.color.ground}>
      <heading tag="h2" size={40} weight={400} lh={1.1} font={t.font.head} color={t.color.ink} tw="pb-8" mobile={{ size: 30 }}>
        Lifetime replacement, in plain terms
      </heading>
      <grid cols={3} gapX={36} gapY={28} tw="w-full" mobile={{ gridCols: 1 }}>
        <box tw="flex flex-col gap-4 pt-7" border={[1, t.color.rule]} pad={{ t: 26 }}>
          <heading tag="h3" size={22} weight={500} font={t.font.head} color={t.color.ink}>Ten years</heading>
          <text size={15} lh={1.65} font={t.font.body} color={t.color.ink}>
            Crack it in the first ten years and we replace it once, no receipt required.
          </text>
        </box>
        <box tw="flex flex-col gap-4 pt-7" border={[1, t.color.rule]} pad={{ t: 26 }}>
          <heading tag="h3" size={22} weight={500} font={t.font.head} color={t.color.ink}>Shipping</heading>
          <text size={15} lh={1.65} font={t.font.body} color={t.color.ink}>
            Ships in 4 days from Portugal. Free over 120 euro in the EU and UK.
          </text>
        </box>
        <box tw="flex flex-col gap-4 pt-7" border={[1, t.color.rule]} pad={{ t: 26 }}>
          <heading tag="h3" size={22} weight={500} font={t.font.head} color={t.color.ink}>Returns</heading>
          <text size={15} lh={1.65} font={t.font.body} color={t.color.ink}>
            Thirty days to change your mind, used or not. Send it back in the same box it arrived in.
          </text>
        </box>
      </grid>
    </section>

    {/* 8 · Order form footer */}
    <section id="order" align="flex-start" tw="flex flex-col w-full px-14 py-20 max-lg:px-9 max-md:px-5 max-md:py-12" bg={t.color.chalk}>
      <grid cols={12} gapX={44} gapY={34} tw="w-full" mobile={{ gridCols: 1 }}>
        <box span={4} tw="flex flex-col gap-5" mobile={{ span: 1 }}>
          <heading tag="h2" size={40} weight={400} lh={1.1} font={t.font.head} color={t.color.ink} mobile={{ size: 30 }}>
            Order a piece
          </heading>
          <text size={15} lh={1.65} font={t.font.body} color={t.color.ink} tw="max-w-[324px]">
            Tell us the shape and the glaze. We write back the same week, from the workshop, with a
            firing date.
          </text>
          <text size={13} lh={1.6} font={t.font.body} color={t.color.clay}>
            Rua das Olarias 12, 3000 Coimbra · hello@kilnhouse.pt
          </text>
        </box>
        <box span={8} tw="flex flex-col" mobile={{ span: 1 }}>
          <html raw={ORDER_FORM} />
        </box>
      </grid>

      <row
        tw="flex flex-row justify-between items-center w-full mt-14 pt-6 max-md:flex-col max-md:items-start max-md:gap-2 max-md:mt-8"
        border={[1, t.color.rule]}
        pad={{ t: 24 }}
      >
        <text size={15} weight={600} ls={0.28} font={t.font.head} color={t.color.ink}>
          KILNHOUSE
        </text>
        <text size={12} lh={1.5} font={t.font.body} color={t.color.ink}>
          Flame-fired stoneware · Six shapes · Four glazes · Made in Coimbra
        </text>
      </row>
    </section>

  </box>
);
