/** Byte Cubs — after-school coding clubs. Structural archetype: overlapping stacked cards. */
import { MEDIA as M } from '../data/media.mjs';

export const meta = {
  title: 'Byte Cubs — after-school coding clubs for 7 to 12 year olds',
  slug: 'byte-cubs',
  seo: {
    title: 'Byte Cubs — twelve weeks, one finished game, their name on it',
    description:
      'After-school coding clubs of eight kids in real rooms with real people. Every term ends with a game they built themselves, playable on any phone, with the code theirs to keep.',
  },
};

/* ── shared elevation vocabulary: the page is a stack of things kids actually made ── */
const STICKER = [[9, 0, 0, '#20223A', 9]];                                  // hard offset "cut out" edge
const STICKER_S = [[6, 0, 0, '#20223A', 6]];
const LIFT = [[22, 40, -16, 'rgba(32,34,58,0.34)'], [5, 10, -5, 'rgba(32,34,58,0.20)']];
const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 520 };

export default ({ theme: t }) => {
  const c = t.color;
  const H = t.font.head;
  const B = t.font.body;

  /* ---------- small inline pieces (styling varies → inline expansion) ---------- */

  const Chip = ({ label, bg, fg }) => (
    <text
      font={B}
      size={14}
      weight={800}
      color={fg}
      bg={bg}
      w="hug"
      pad={{ t: 8, b: 8, l: 16, r: 16 }}
      radius={999}
      border={[2, c.ink]}
    >
      {label}
    </text>
  );

  const Cta = ({ label, href, bg, fg, hoverBg }) => (
    <text
      href={href}
      font={H}
      size={19}
      weight={600}
      color={fg}
      bg={bg}
      w="hug"
      ta="center"
      pad={{ t: 18, b: 18, l: 34, r: 34 }}
      radius={18}
      border={[3, c.ink]}
      shadow={STICKER_S}
      tw="hover:shadow-none hover:translate-y-[6px]"
      hover={{ bg: hoverBg }}
      mobile={{ w: '100%', size: 17 }}
    >
      {label}
    </text>
  );

  const GameCard = ({ name, maker, blurb, bg, fg, tilt, pull }) => (
    <box
      bg={bg}
      radius={26}
      border={[3, c.ink]}
      shadow={STICKER}
      pad={26}
      gap={10}
      w="100%"
      m={{ t: pull }}
      tw={`flex flex-col ${tilt}`}
      mobile={{ m: { t: pull ? -14 : 0 }, pad: 20 }}
    >
      <text font={B} size={13} weight={800} color={fg} ls="1.4px">
        {maker}
      </text>
      <h3 font={H} size={30} weight={600} color={fg} lh={1.1} mobile={{ size: 25 }}>
        {name}
      </h3>
      <text font={B} size={15} weight={600} color={fg} lh={1.55}>
        {blurb}
      </text>
    </box>
  );

  /* ---------- registered repeaters (content props only) ---------- */

  const WeekBand = defineComponent(
    ({ weeks = 'Weeks 1 to 3', title = 'They draw it', body = '' }) => (
      <box
        bg="#FFFFFF"
        radius={22}
        border={[3, '#20223A']}
        shadow={[[7, 0, 0, '#20223A', 7]]}
        pad={24}
        gap={10}
        tw="flex flex-col h-full"
      >
        <text font="Fredoka" size={15} weight={600} color="#FF5D8F" ls="0.6px">
          {weeks}
        </text>
        <h3 font="Fredoka" size={24} weight={600} color="#20223A" lh={1.15}>
          {title}
        </h3>
        <text font="Nunito" size={15} weight={600} color="#4A4D6B" lh={1.6}>
          {body}
        </text>
      </box>
    ),
    {
      title: 'Term week band',
      props: {
        weeks: { label: 'Week range', group: 'Content' },
        title: { label: 'Headline', group: 'Content' },
        body: { label: 'Body', group: 'Content' },
      },
    },
  );

  const LeaderCard = defineComponent(
    ({ name = '', role = '', line = '', shipped = '' }) => (
      <box
        bg="#FFF9E8"
        radius={24}
        border={[3, '#20223A']}
        shadow={[[9, 0, 0, '#8BE04E', 9]]}
        pad={26}
        gap={9}
        tw="flex flex-col h-full"
      >
        <h3 font="Fredoka" size={26} weight={600} color="#20223A" lh={1.15}>
          {name}
        </h3>
        <text font="Fredoka" size={15} weight={600} color="#FF5D8F">
          {role}
        </text>
        <text font="Nunito" size={15} weight={600} color="#4A4D6B" lh={1.6}>
          {line}
        </text>
        <text font="Nunito" size={13} weight={800} color="#20223A" ls="0.5px">
          {shipped}
        </text>
      </box>
    ),
    {
      title: 'Club leader card',
      props: {
        name: { label: 'Name', group: 'Content' },
        role: { label: 'Role', group: 'Content' },
        line: { label: 'Bio line', group: 'Content' },
        shipped: { label: 'Shipped credit', group: 'Content' },
      },
    },
  );

  const VenueCard = defineComponent(
    ({ venue = '', day = '', room = '', spaces = '' }) => (
      <box
        bg="#FFFFFF"
        radius={22}
        border={[3, '#20223A']}
        shadow={[[7, 0, 0, '#3AA7FF', 7]]}
        pad={22}
        gap={6}
        tw="flex flex-col w-full"
      >
        <h3 font="Fredoka" size={23} weight={600} color="#20223A" lh={1.2}>
          {venue}
        </h3>
        <text font="Nunito" size={15} weight={700} color="#20223A">
          {day}
        </text>
        <text font="Nunito" size={14} weight={600} color="#4A4D6B" lh={1.55}>
          {room}
        </text>
        <text font="Fredoka" size={14} weight={600} color="#FF5D8F">
          {spaces}
        </text>
      </box>
    ),
    {
      title: 'Venue card',
      props: {
        venue: { label: 'Venue', group: 'Content' },
        day: { label: 'Day and time', group: 'Content' },
        room: { label: 'Room detail', group: 'Content' },
        spaces: { label: 'Spaces left', group: 'Content' },
      },
    },
  );

  const FaqCard = defineComponent(
    ({ q = '', a = '' }) => (
      <box
        bg="#FFFFFF"
        radius={22}
        border={[3, '#20223A']}
        shadow={[[8, 0, 0, '#FFC93C', 8]]}
        pad={26}
        gap={10}
        tw="flex flex-col w-full"
      >
        <h3 font="Fredoka" size={24} weight={600} color="#20223A" lh={1.25}>
          {q}
        </h3>
        <text font="Nunito" size={16} weight={600} color="#4A4D6B" lh={1.65}>
          {a}
        </text>
      </box>
    ),
    {
      title: 'FAQ card',
      props: {
        q: { label: 'Question', group: 'Content' },
        a: { label: 'Answer', group: 'Content' },
      },
    },
  );

  return (
    <box tw="flex flex-col w-full" pad={0} bg={c.ground}>
      {/* ═══ 1 · Card stack hero ═══ */}
      <section
        bg={c.ink}
        w="100%"
        pad={{ t: 84, b: 190, l: 24, r: 24 }}
        tw="flex flex-col items-center"
        mobile={{ pad: { t: 56, b: 150, l: 18, r: 18 } }}
      >
        <box w="100%" maxw={1180} tw="flex flex-col">
          <grid cols={12} gap={54} tw="w-full" mobile={{ gap: 40 }}>
            <box span={7} mobile={{ span: 1 }} tablet={{ span: 12 }} tw="flex flex-col gap-7">
              <Chip label="After-school coding clubs · ages 7 to 12" bg={c.sun} fg={c.ink} />
              <h1
                font={H}
                size={72}
                weight={600}
                color={c.ground}
                lh={1.02}
                tablet={{ size: 58 }}
                mobile={{ size: 40 }}
              >
                Twelve weeks. One finished game. Their name on it.
              </h1>
              <text font={B} size={18} weight={500} color={c.dim} lh={1.7} maxw={560} mobile={{ size: 16 }}>
                Byte Cubs runs after-school coding clubs of eight kids in real rooms with real people.
                Every term ends with a game they built themselves, playable on any phone, with the code
                theirs to keep forever.
              </text>
              <box tw="flex flex-row items-center gap-5 flex-wrap" mobile={{ dir: 'column', align: 'stretch' }}>
                <Cta label="Book a free trial session" href="#book" bg={c.berry} fg={c.ink} hoverBg={c.sun} />
                <text font={B} size={15} weight={700} color={c.dim} lh={1.5}>
                  £15 a session · second sibling half price
                </text>
              </box>
            </box>

            <box span={5} mobile={{ span: 1 }} tablet={{ span: 12 }} tw="flex flex-col gap-5">
              <h2 font={H} size={16} weight={600} color={c.sky} ls="1.6px">
                Made last term, by kids this age
              </h2>
              <GameCard
                name="Bin Goblin"
                maker="AYAAN, 9 · CUBS"
                blurb="A goblin who eats litter and grows one pixel per crisp packet. Boss fight at the recycling centre."
                bg={c.sun}
                fg={c.ink}
                tilt="-rotate-2"
              />
              <GameCard
                name="Toast Panic"
                maker="MARNIE, 11 · CODERS"
                blurb="Two players, one phone, one grill. Butter it before it burns. Her brother has never won."
                bg={c.lime}
                fg={c.ink}
                tilt="rotate-1"
                pull={-26}
              />
              <GameCard
                name="Cave of Nine Doors"
                maker="OLLIE, 12 · CODERS"
                blurb="Real JavaScript, written from scratch. Eight of the doors lie to you. He tested it on his nan."
                bg={c.berry}
                fg={c.ink}
                tilt="-rotate-1"
                pull={-26}
              />
            </box>
          </grid>
        </box>
      </section>

      {/* ═══ 2 · What happens in a term, week by week ═══ */}
      <section
        bg={c.ground}
        w="100%"
        pad={{ t: 0, b: 110, l: 24, r: 24 }}
        tw="flex flex-col items-center"
        mobile={{ pad: { t: 0, b: 80, l: 18, r: 18 } }}
      >
        <box w="100%" maxw={1180} tw="flex flex-col gap-16" mobile={{ gap: 40 }}>
          {/* the term card rides up over the hero — the first card in the stack */}
          <box
            bg={c.white}
            radius={32}
            border={[3, c.ink]}
            shadow={LIFT}
            m={{ t: -120 }}
            pad={{ t: 44, b: 44, l: 46, r: 46 }}
            tw="flex flex-row gap-12 items-center"
            tablet={{ dir: 'column', align: 'stretch', gap: 30 }}
            mobile={{ m: { t: -100 }, pad: 24, dir: 'column', align: 'stretch', gap: 22 }}
            motion={FADE}
          >
            <box flex={1} tw="flex flex-col gap-4">
              <h2 font={H} size={44} weight={600} color={c.ink} lh={1.08} mobile={{ size: 31 }}>
                What happens in a term
              </h2>
              <text font={B} size={17} weight={600} color="#4A4D6B" lh={1.7} mobile={{ size: 15 }}>
                Weeks 1 to 3 they draw it. Weeks 4 to 9 they build it and it breaks constantly.
                Week 10 they play each other's. Week 12 the grown-ups come and get beaten at it.
              </text>
            </box>
            <img
              src={M.sketch_desk.id}
              w="100%"
              maxw={380}
              h={240}
              fit="cover"
              radius={22}
              border={[3, c.ink]}
              mobile={{ h: 190, maxw: 640 }}
            />
          </box>

          {/* four bands, staggered so they read as a fanned-out deck */}
          <grid cols={12} gap={26} tw="w-full">
            <box span={3} mobile={{ span: 1 }} tablet={{ span: 6 }} tw="flex flex-col">
              <WeekBand
                weeks="Weeks 1 to 3"
                title="They draw it"
                body="Paper first, no screens. Characters, levels, one rule the game is about. The sketch goes on the wall and stays there."
              />
            </box>
            <box span={3} mobile={{ span: 1, m: { t: 0 } }} tablet={{ span: 6 }} m={{ t: 34 }} tw="flex flex-col">
              <WeekBand
                weeks="Weeks 4 to 9"
                title="They build it"
                body="And it breaks constantly. That is the lesson. Six weeks of fixing your own mess is the whole course, secretly."
              />
            </box>
            <box span={3} mobile={{ span: 1 }} tablet={{ span: 6 }} m={{ t: 14 }} tw="flex flex-col">
              <WeekBand
                weeks="Weeks 10 and 11"
                title="They swap"
                body="Everyone plays everyone else's. Kids are brutal testers and fix more bugs in one hour than we could name in three."
              />
            </box>
            <box span={3} mobile={{ span: 1 }} tablet={{ span: 6 }} m={{ t: 48 }} tw="flex flex-col">
              <WeekBand
                weeks="Week 12"
                title="Showcase night"
                body="The grown-ups come and get beaten at it. Everyone leaves with a link, the code, and a game with their name on the title screen."
              />
            </box>
          </grid>
        </box>
      </section>

      {/* ═══ 3 · Age bands ═══ */}
      <section
        bg={c.sky}
        w="100%"
        pad={{ t: 96, b: 104, l: 24, r: 24 }}
        tw="flex flex-col items-center"
        mobile={{ pad: { t: 64, b: 72, l: 18, r: 18 } }}
      >
        <box w="100%" maxw={1180} tw="flex flex-col gap-14" mobile={{ gap: 32 }}>
          <box tw="flex flex-col gap-4" maxw={640}>
            <h2 font={H} size={48} weight={600} color={c.ink} lh={1.06} mobile={{ size: 33 }}>
              Two age bands, two very different rooms
            </h2>
            <text font={B} size={17} weight={600} color="#123A5E" lh={1.7} mobile={{ size: 15 }}>
              We split by what they can hold in their head, not by school year. A kid can move up
              mid-term if they are ready, and nobody makes a thing of it.
            </text>
          </box>

          <grid cols={12} gap={40} tw="w-full">
            <box span={5} mobile={{ span: 1 }} tablet={{ span: 12 }} tw="flex flex-col">
              <img
                src={M.kids_building.id}
                w="100%"
                h={420}
                fit="cover"
                radius={28}
                border={[3, c.ink]}
                shadow={STICKER}
                tablet={{ h: 300 }}
                mobile={{ h: 250 }}
              />
            </box>

            <box span={7} mobile={{ span: 1 }} tablet={{ span: 12 }} tw="flex flex-col">
              <box
                bg={c.ground}
                radius={28}
                border={[3, c.ink]}
                shadow={STICKER}
                pad={34}
                gap={12}
                m={{ r: 44 }}
                tw="flex flex-col"
                tablet={{ m: { r: 28 } }}
                mobile={{ pad: 24, m: { r: 0 } }}
                motion={FADE}
              >
                <text font={B} size={13} weight={800} color={c.berry} ls="1.4px">
                  CUBS · 7 TO 9
                </text>
                <h3 font={H} size={34} weight={600} color={c.ink} lh={1.1} mobile={{ size: 27 }}>
                  Block-based, and a platformer with a boss they design
                </h3>
                <text font={B} size={16} weight={600} color="#4A4D6B" lh={1.65}>
                  Drag-and-drop blocks, so nothing is lost to a missing semicolon. They design the
                  boss first — its weakness, its stupid name — and build the game backwards from it.
                  Reading level does not hold anyone back here.
                </text>
              </box>

              {/* second band overlaps the first: the stack, again */}
              <box
                bg={c.lime}
                radius={28}
                border={[3, c.ink]}
                shadow={STICKER}
                pad={34}
                gap={12}
                m={{ t: -18 }}
                tw="flex flex-col"
                mobile={{ pad: 24, m: { t: -14 } }}
                motion={FADE}
              >
                <text font={B} size={13} weight={800} color={c.ink} ls="1.4px">
                  CODERS · 10 TO 12
                </text>
                <h3 font={H} size={34} weight={600} color={c.ink} lh={1.1} mobile={{ size: 27 }}>
                  Real JavaScript, and a two-player game that works on a phone
                </h3>
                <text font={B} size={16} weight={600} color="#274A15" lh={1.65}>
                  Typed code, real files, a real editor. Two players on one phone means they have to
                  think about somebody else using their thing — which is most of software, learned at ten.
                </text>
              </box>
            </box>
          </grid>
        </box>
      </section>

      {/* ═══ 4 · Meet the club leaders ═══ */}
      <section
        bg={c.ink}
        w="100%"
        pad={{ t: 100, b: 104, l: 24, r: 24 }}
        tw="flex flex-col items-center"
        mobile={{ pad: { t: 64, b: 72, l: 18, r: 18 } }}
      >
        <box w="100%" maxw={1180} tw="flex flex-col gap-14" mobile={{ gap: 32 }}>
          <box tw="flex flex-row gap-12 items-end" tablet={{ dir: 'column', align: 'stretch', gap: 24 }}>
            <box flex={1} tw="flex flex-col gap-4">
              <h2 font={H} size={48} weight={600} color={c.ground} lh={1.06} mobile={{ size: 33 }}>
                Meet the club leaders
              </h2>
              <text font={B} size={17} weight={600} color={c.dim} lh={1.7} maxw={620} mobile={{ size: 15 }}>
                Every club leader is DBS-checked, first-aid trained, and has actually shipped software.
                Ratio is never worse than one adult to eight kids.
              </text>
            </box>
            <box tw="flex flex-row gap-3 flex-wrap">
              <Chip label="DBS-checked" bg={c.lime} fg={c.ink} />
              <Chip label="First-aid trained" bg={c.sun} fg={c.ink} />
              <Chip label="1 adult : 8 kids" bg={c.sky} fg={c.ink} />
            </box>
          </box>

          <grid cols={12} gap={28} tw="w-full">
            <box span={4} mobile={{ span: 1 }} tablet={{ span: 12 }} tw="flex flex-col">
              <LeaderCard
                name="Priya Raman"
                role="Lead, Cubs"
                line="Ran a primary computing suite for nine years before this. Can settle a room of eight in about four seconds."
                shipped="SHIPPED: NHS BOOKING TOOLS, 2016–2021"
              />
            </box>
            <box span={4} mobile={{ span: 1 }} tablet={{ span: 12 }} m={{ t: 36 }} tw="flex flex-col">
              <LeaderCard
                name="Dan Okafor"
                role="Lead, Coders"
                line="Games programmer who got tired of crunch and would rather teach twelve-year-olds to name their variables properly."
                shipped="SHIPPED: TWO CONSOLE TITLES, ONE HE ADMITS TO"
              />
            </box>
            <box span={4} mobile={{ span: 1 }} tablet={{ span: 12 }} m={{ t: 16 }} tw="flex flex-col">
              <LeaderCard
                name="Cat Meredith"
                role="Roaming leader, all venues"
                line="Covers whichever room needs a second adult, which is every room. Keeps the plasters and the spare chargers."
                shipped="SHIPPED: ACCESSIBILITY TOOLING, STILL MAINTAINS IT"
              />
            </box>
          </grid>
        </box>
      </section>

      {/* ═══ 5 · Term dates, times and venues ═══ */}
      <section
        bg={c.ground}
        w="100%"
        pad={{ t: 100, b: 104, l: 24, r: 24 }}
        tw="flex flex-col items-center"
        mobile={{ pad: { t: 64, b: 72, l: 18, r: 18 } }}
      >
        <box w="100%" maxw={1180} tw="flex flex-col gap-12" mobile={{ gap: 30 }}>
          <h2 font={H} size={48} weight={600} color={c.ink} lh={1.06} maxw={620} mobile={{ size: 33 }}>
            Term dates, times and venues
          </h2>

          <grid cols={12} gap={34} tw="w-full">
            <box span={5} mobile={{ span: 1 }} tablet={{ span: 12 }} tw="flex flex-col">
              <box
                bg={c.sun}
                radius={30}
                border={[3, c.ink]}
                shadow={STICKER}
                pad={34}
                gap={18}
                tw="flex flex-col"
                mobile={{ pad: 24 }}
              >
                <h3 font={H} size={32} weight={600} color={c.ink} lh={1.1} mobile={{ size: 26 }}>
                  Tuesdays and Thursdays, 4pm to 5:30pm
                </h3>
                <text font={B} size={17} weight={600} color="#5A3F00" lh={1.65}>
                  In three venues. £15 a session, paid by the term. Second sibling half price.
                </text>
                <box bg={c.ground} radius={18} border={[2, c.ink]} pad={20} gap={8} tw="flex flex-col">
                  <text font={B} size={15} weight={800} color={c.ink}>
                    Autumn term: 9 September to 27 November
                  </text>
                  <text font={B} size={15} weight={800} color={c.ink}>
                    Spring term: 13 January to 2 April
                  </text>
                  <text font={B} size={14} weight={600} color="#4A4D6B" lh={1.6}>
                    Twelve sessions a term, £180, invoiced in one go. Half-term off. Join late and we
                    pro-rata it — nobody pays for a week they missed.
                  </text>
                </box>
              </box>
            </box>

            <box span={7} mobile={{ span: 1, m: { t: 0 } }} tablet={{ span: 12, m: { t: 0 } }} tw="flex flex-col gap-4" m={{ t: 30 }}>
              <VenueCard
                venue="Ashfield Community Hall"
                day="Tuesdays · 4:00pm to 5:30pm"
                room="Back room with the good tables. Parking behind the library, five minutes from Ashfield Primary gates."
                spaces="3 spaces left this term"
              />
              <VenueCard
                venue="St Anne's Scout Hut"
                day="Tuesdays and Thursdays · 4:00pm to 5:30pm"
                room="Both age bands run here, in separate rooms. Glass panel in the door if you want to watch."
                spaces="6 spaces left this term"
              />
              <VenueCard
                venue="Northgate Makerspace"
                day="Thursdays · 4:00pm to 5:30pm"
                room="Coders only, upstairs. Big screens, proper keyboards, and a soldering bench they are not allowed near."
                spaces="1 space left this term"
              />
            </box>
          </grid>
        </box>
      </section>

      {/* ═══ 6 · What parents ask before they book ═══ */}
      <section
        bg={c.berry}
        w="100%"
        pad={{ t: 96, b: 110, l: 24, r: 24 }}
        tw="flex flex-col items-center"
        mobile={{ pad: { t: 64, b: 76, l: 18, r: 18 } }}
      >
        <box w="100%" maxw={1180} tw="flex flex-row gap-16 items-start" tablet={{ dir: 'column', gap: 32 }}>
          <box flex={1} tw="flex flex-col gap-4" mobile={{ w: '100%' }}>
            <h2 font={H} size={46} weight={600} color={c.ink} lh={1.06} mobile={{ size: 32 }}>
              What parents ask before they book
            </h2>
            <text font={B} size={17} weight={600} color="#5A1030" lh={1.7} maxw={420} mobile={{ size: 15 }}>
              These four, nearly every time, usually in this order. Anything else, ring us — a person
              answers.
            </text>
          </box>

          {/* the answers, stacked and slightly overlapping */}
          <box flex={1} tw="flex flex-col gap-4" mobile={{ w: '100%' }}>
            <FaqCard q="Do they need a laptop?" a="No. We supply every machine, charged and set up, and they never carry anything home but the code." />
            <FaqCard
              q="Do they need to be good at maths?"
              a="No. Not once in twelve weeks does it come down to maths. It comes down to whether they will try the thing again after it breaks."
            />
            <FaqCard
              q="Can they join late and catch up?"
              a="Yes. We have done it fourteen times. They pair with someone for a session and by the second week you cannot tell who started when."
            />
            <FaqCard
              q="What if they hate it?"
              a="Then they stop and we refund the rest of the term, no conversation required. It has happened twice and both times we deserved it."
            />
          </box>
        </box>
      </section>

      {/* ═══ 7 · Trial session offer ═══ */}
      <section
        bg={c.ink}
        w="100%"
        pad={{ t: 100, b: 120, l: 24, r: 24 }}
        tw="flex flex-col items-center"
        mobile={{ pad: { t: 64, b: 80, l: 18, r: 18 } }}
      >
        <box w="100%" maxw={1180} tw="flex flex-col">
          <img
            src={M.showcase_night.id}
            w="100%"
            h={420}
            fit="cover"
            radius={30}
            border={[3, c.ground]}
            tablet={{ h: 320 }}
            mobile={{ h: 230 }}
          />
          {/* the card sits on top of the photo — last card on the pile */}
          <box
            bg={c.sun}
            radius={30}
            border={[3, c.ink]}
            shadow={LIFT}
            pad={40}
            gap={16}
            maxw={640}
            m={{ t: -110, l: 56 }}
            tw="flex flex-col"
            tablet={{ m: { t: -80, l: 24 } }}
            mobile={{ pad: 24, m: { t: -60, l: 0 }, maxw: 640 }}
            motion={FADE}
          >
            <text font={B} size={13} weight={800} color="#5A3F00" ls="1.4px">
              THE TRIAL
            </text>
            <h2 font={H} size={42} weight={600} color={c.ink} lh={1.08} mobile={{ size: 30 }}>
              First session is free, and you can watch through the glass
            </h2>
            <text font={B} size={17} weight={600} color="#5A3F00" lh={1.7} mobile={{ size: 15 }}>
              If you want to. Most parents leave after ten minutes. There is a café two doors down at
              St Anne's and we will text you if anything at all goes sideways.
            </text>
            <Cta label="Book a free trial session" href="#book" bg={c.ink} fg={c.ground} hoverBg={c.berry} />
          </box>
        </box>
      </section>

      {/* ═══ 8 · Booking with sibling discount ═══ */}
      <section
        id="book"
        bg={c.lime}
        w="100%"
        pad={{ t: 104, b: 116, l: 24, r: 24 }}
        tw="flex flex-col items-center"
        mobile={{ pad: { t: 68, b: 80, l: 18, r: 18 } }}
      >
        <box w="100%" maxw={760} tw="flex flex-col items-center gap-7" ta="center">
          <h2 font={H} size={54} weight={600} color={c.ink} lh={1.04} ta="center" mobile={{ size: 35 }}>
            Book a free trial session
          </h2>
          <text font={B} size={18} weight={600} color="#22400C" lh={1.7} maxw={580} ta="center" mobile={{ size: 16 }}>
            Tell us the venue and the age, and we will hold a place for the next Tuesday or Thursday.
            £15 a session after that, paid by the term. Second sibling half price, applied
            automatically — you never have to ask for it.
          </text>
          <box
            bg={c.ground}
            radius={26}
            border={[3, c.ink]}
            shadow={STICKER}
            pad={28}
            gap={14}
            w="100%"
            maxw={520}
            tw="flex flex-col items-center"
            motion={FADE}
          >
            <text font={H} size={30} weight={600} color={c.ink} ta="center" mobile={{ size: 25 }}>
              One kid £180 a term · two kids £270
            </text>
            <text font={B} size={15} weight={600} color="#4A4D6B" lh={1.6} ta="center">
              Twelve sessions each, one invoice, no joining fee and no kit to buy.
            </text>
            <Cta label="Book the free trial" href="mailto:hello@bytecubs.co.uk?subject=Free%20trial%20session" bg={c.berry} fg={c.ink} hoverBg={c.sun} />
            <text font={B} size={14} weight={700} color={c.ink} ta="center" lh={1.6}>
              Or ring 0161 496 0118 — Priya or Cat picks up between 9am and 6pm.
            </text>
          </box>
        </box>
      </section>
    </box>
  );
};
