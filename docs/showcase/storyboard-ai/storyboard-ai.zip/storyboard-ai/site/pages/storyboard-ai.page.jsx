/** Boardsmith — split-screen scroller landing page. */
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Boardsmith — storyboards that stay on model',
  seo: {
    title: 'Boardsmith — the same actor, the same coat, in all sixty panels',
    description:
      'Boardsmith reads your script, locks your characters and locations once, then boards the whole thing in a consistent style with real lens language. Fifty panels in about twenty minutes.',
  },
};

/* ── small typed repeaters (content props only) ───────────────────────────── */

const StyleCard = defineComponent(
  ({ index = '01', name = 'Style', note = '' }) => (
    <div
      cls="style-card" tw="flex flex-col gap-3 p-7 border border-[rgba(20,20,20,0.15)] hover:border-[#E2483C] hover:bg-[rgba(20,20,20,0.04)]"
      bg="#EFEBE2"
    >
      <text size={12} weight={600} font="Onest" color="#E2483C" tw="uppercase tracking-widest">
        {index}
      </text>
      <h3 size={22} weight={600} font="Bricolage Grotesque" color="#141414" lh={1.2}>
        {name}
      </h3>
      <text size={15} font="Onest" color="#57565A" lh={1.6}>
        {note}
      </text>
    </div>
  ),
  {
    title: 'Boardsmith style card',
    props: {
      index: { label: 'Index', group: 'Style' },
      name: { label: 'Style name', group: 'Style' },
      note: { label: 'Note', group: 'Style' },
    },
  },
);

const PriceCard = defineComponent(
  ({ tier = 'Tier', price = '£0', unit = 'per project', detail = '', panels = '' }) => (
    <div cls="price-card" tw="flex flex-col gap-5 p-8 border border-[rgba(20,20,20,0.15)] hover:border-[#141414]" bg="#EFEBE2">
      <text size={12} weight={600} font="Onest" color="#57565A" tw="uppercase tracking-widest">
        {tier}
      </text>
      <h3 size={44} weight={600} font="Bricolage Grotesque" color="#141414" lh={1} mobile={{ size: 36 }}>
        {price}
      </h3>
      <text size={13} font="Onest" color="#E2483C" tw="uppercase tracking-wider">
        {unit}
      </text>
      <text size={15} font="Onest" color="#57565A" lh={1.65}>
        {detail}
      </text>
      <text size={13} font="Onest" color="#141414" tw="pt-4 border-t border-[rgba(20,20,20,0.2)]">
        {panels}
      </text>
    </div>
  ),
  {
    title: 'Boardsmith price card',
    props: {
      tier: { label: 'Tier', group: 'Pricing' },
      price: { label: 'Price', group: 'Pricing' },
      unit: { label: 'Unit', group: 'Pricing' },
      detail: { label: 'Detail', group: 'Pricing' },
      panels: { label: 'Footnote', group: 'Pricing' },
    },
  },
);

const ExportRow = defineComponent(
  ({ format = 'Format', detail = '' }) => (
    <div
      cls="export-row" tw="flex flex-row items-start gap-6 py-5 border-t border-[rgba(240,239,236,0.2)] max-md:flex-col max-md:gap-2 hover:bg-[rgba(240,239,236,0.05)]"
    >
      <heading tag="h3" size={19} weight={600} font="Bricolage Grotesque" color="#F0EFEC" w="34%" mobile={{ w: '100%' }}>
        {format}
      </heading>
      <text size={15} font="Onest" color="#9A979A" lh={1.6} flex={1}>
        {detail}
      </text>
    </div>
  ),
  {
    title: 'Boardsmith export row',
    props: {
      format: { label: 'Format', group: 'Export' },
      detail: { label: 'Detail', group: 'Export' },
    },
  },
);

/* ── inline visual helpers (styles vary → plain functions, inline-expanded) ── */

const Frame = ({ no, slug, note, tone = '#1B1B1B' }) => (
  <div cls="frame" tw="flex flex-col justify-between p-5 border border-[rgba(240,239,236,0.15)]" bg={tone} minh={168}>
    <div tw="flex flex-row justify-between items-center">
      <text size={11} weight={600} font="Onest" color="#E2483C" tw="uppercase tracking-widest">
        {no}
      </text>
      <text size={11} font="Onest" color="#9A979A" tw="uppercase tracking-widest">
        {slug}
      </text>
    </div>
    <text size={14} font="Onest" color="#F0EFEC" lh={1.5}>
      {note}
    </text>
  </div>
);

const Chip = ({ label, sub }) => (
  <div
    cls="lens-chip" tw="flex flex-col gap-1 px-5 py-4 border border-[rgba(240,239,236,0.2)] hover:border-[#E2483C] hover:bg-[rgba(226,72,60,0.1)]"
  >
    <text size={16} weight={600} font="Bricolage Grotesque" color="#F0EFEC">
      {label}
    </text>
    <text size={12} font="Onest" color="#9A979A" tw="uppercase tracking-wider">
      {sub}
    </text>
  </div>
);

const Eyebrow = ({ children, color = '#E2483C' }) => (
  <text cls="eyebrow" size={12} weight={600} font="Onest" color={color} tw="uppercase tracking-widest">
    {children}
  </text>
);

const Cta = ({ label, href, dark }) => (
  <text
    cls="cta-button"
    href={href}
    tag="span"
    size={16}
    weight={600}
    font="Onest"
    tw={
      dark
        ? 'px-8 py-4 w-fit bg-[#E2483C] text-[#F0EFEC] hover:bg-[#F0EFEC] hover:text-[#141414]'
        : 'px-8 py-4 w-fit bg-[#141414] text-[#F0EFEC] hover:bg-[#E2483C] hover:text-[#141414]'
    }
  >
    {label}
  </text>
);

/* ── page ─────────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
    {/* 1 — SPLIT HERO: the script line, and the frame it produced */}
    <section tw="flex flex-row w-full max-md:flex-col" pad={0} bg={t.color.ground}>
      <div tw="flex flex-col justify-center gap-7 w-[54%] px-16 py-28 max-lg:px-10 max-md:w-full max-md:px-6 max-md:py-14">
        <Eyebrow>Boardsmith · script in, boards out</Eyebrow>
        <div tw="flex flex-col gap-2 pl-5 border-l-2 border-[#E2483C]" >
          <text size={13} weight={600} font="Onest" color="#F0EFEC" tw="uppercase tracking-widest">
            INT. LOCK-UP GARAGE — NIGHT
          </text>
          <text size={15} font="Onest" color="#9A979A" lh={1.7}>
            NADIA pulls the shutter down. Still in the grey wool coat. She does not look back at the
            car.
          </text>
        </div>
        <h1
          size={64}
          weight={600}
          font={t.font.head}
          color={t.color.ink}
          lh={1.02}
          ls={-0.02}
          tablet={{ size: 50 }}
          mobile={{ size: 34 }}
        >
          The same actor, the same coat, in all sixty panels.
        </h1>
        <text size={18} font={t.font.body} color="#9A979A" lh={1.65} maxw={520} mobile={{ size: 16 }}>
          Boardsmith reads your script, locks your characters and locations once, then boards the
          whole thing in a consistent style with real lens language. Fifty panels in about twenty
          minutes.
        </text>
        <div tw="flex flex-row items-center gap-6 pt-2 max-md:flex-col max-md:items-start">
          <Cta label="Board your first scene free" href="#board" dark />
          <text size={14} font={t.font.body} color="#57565A" lh={1.5}>
            No card. First scene on us.
          </text>
        </div>
      </div>

      <div tw="flex flex-col w-[46%] max-md:w-full" bg="#0F0F0F">
        <img src={media.board_wall.id} tw="w-full" h={620} fit="cover" tablet={{ h: 460 }} mobile={{ h: 260 }} />
        <div tw="flex flex-row justify-between items-center px-6 py-4 border-t border-[rgba(240,239,236,0.15)]">
          <text size={12} font={t.font.body} color="#E2483C" tw="uppercase tracking-widest">
            Panel 12 / 60
          </text>
          <text size={12} font={t.font.body} color="#9A979A" tw="uppercase tracking-widest">
            35mm · eye level · two-shot
          </text>
        </div>
      </div>
    </section>

    {/* 2 — CHARACTER LOCK: sticky script column, panels scrolling past */}
    <section tw="flex flex-row w-full items-start max-md:flex-col" pad={0} bg={t.color.paper}>
      <div
        tw="flex flex-col gap-6 w-[44%] px-16 py-28 max-lg:px-10 max-md:w-full max-md:px-6 max-md:py-14"
        pos="sticky"
        raw="top: 0px;"
        mobile={{ pos: 'static' }}
      >
        <Eyebrow>01 · Character lock</Eyebrow>
        <h2 size={44} weight={600} font={t.font.head} color={t.color.ground} lh={1.08} tablet={{ size: 36 }} mobile={{ size: 28 }}>
          The same face across 60 panels.
        </h2>
        <text size={17} font={t.font.body} color="#57565A" lh={1.7} maxw={460} mobile={{ size: 15 }}>
          Define a character once from a reference or a description. They keep the same face, hair,
          wardrobe and age across every panel, every scene, and every revision.
        </text>
        <text size={15} font={t.font.body} color={t.color.ground} lh={1.7} maxw={460} tw="pt-4 border-t border-[rgba(20,20,20,0.2)]">
          Locations lock the same way. Rebuild the garage in panel 48 and it is the same garage, the
          same shutter, the same sodium light.
        </text>
      </div>

      <div tw="flex flex-col w-[56%] gap-px p-10 max-lg:p-6 max-md:w-full max-md:p-4" bg={t.color.ground}>
        <grid cols={2} gap={12} mobile={{ gridCols: 1 }}>
          <Frame no="Panel 04" slug="EXT. FORECOURT" note="Nadia, grey wool coat, three-quarter back, walking out of frame left." />
          <Frame no="Panel 19" slug="INT. CAR" note="Same face at 50mm, seatbelt over the same coat, rain on glass." tone="#191919" />
          <Frame no="Panel 33" slug="INT. STAIRWELL" note="Hair wet now — the wardrobe holds, the continuity note carries." tone="#191919" />
          <Frame no="Panel 60" slug="EXT. BRIDGE" note="Sixty panels later, still recognisably the same person." />
        </grid>
        <text size={13} font={t.font.body} color="#9A979A" lh={1.6} tw="pt-6">
          One reference. Zero re-prompting. Revisions inherit the lock.
        </text>
      </div>
    </section>

    {/* 3 — LENS AND FRAMING */}
    <section tw="flex flex-col w-full gap-12 px-16 py-28 max-lg:px-10 max-md:px-6 max-md:py-16" bg={t.color.ground}>
      <div tw="flex flex-row gap-16 items-end max-lg:gap-10 max-md:flex-col max-md:items-start max-md:gap-6">
        <div tw="flex flex-col gap-5 w-[46%] max-md:w-full">
          <Eyebrow>02 · Lens and framing</Eyebrow>
          <h2 size={44} weight={600} font={t.font.head} color={t.color.ink} lh={1.08} tablet={{ size: 36 }} mobile={{ size: 28 }}>
            Controls that mean something.
          </h2>
        </div>
        <text size={17} font={t.font.body} color="#9A979A" lh={1.7} flex={1} mobile={{ size: 15 }}>
          Ask for a 35mm two-shot at eye level and you get a 35mm two-shot at eye level. Coverage,
          eyelines and screen direction stay consistent from panel to panel.
        </text>
      </div>

      <grid cols={4} gap={12} tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
        <Chip label="18mm" sub="Wide · distortion held" />
        <Chip label="35mm" sub="Two-shot · eye level" />
        <Chip label="50mm" sub="Clean single" />
        <Chip label="85mm" sub="Close · compressed" />
        <Chip label="Low angle" sub="Hero, 20° up" />
        <Chip label="Over shoulder" sub="Eyeline preserved" />
        <Chip label="Dutch 12°" sub="Only where you ask" />
        <Chip label="Screen left" sub="Direction held all scene" />
      </grid>
    </section>

    {/* 4 — SHOT LIST EXPORT (reversed split) */}
    <section tw="flex flex-row-reverse w-full items-stretch max-md:flex-col" pad={0} bg="#101010">
      <div tw="flex flex-col justify-center gap-6 w-[42%] px-14 py-28 max-lg:px-10 max-md:w-full max-md:px-6 max-md:py-14" bg={t.color.mark}>
        <Eyebrow color="#141414">03 · Export</Eyebrow>
        <h2 size={40} weight={600} font={t.font.head} color="#141414" lh={1.08} tablet={{ size: 34 }} mobile={{ size: 28 }}>
          Into the formats ADs actually use.
        </h2>
        <text size={17} font={t.font.body} color="#141414" lh={1.7} mobile={{ size: 15 }}>
          Export as a numbered PDF board, an Avid-compatible shot list, a Frame.io upload, or an
          animatic with your scratch VO cut to the panel durations.
        </text>
        <text size={14} font={t.font.body} color="#141414" lh={1.6} tw="pt-4 border-t border-[rgba(20,20,20,0.3)]">
          Panel numbers survive the round trip. Renumber in Boardsmith, re-export, and the shot list
          matches the board on the wall.
        </text>
      </div>

      <div tw="flex flex-col justify-center gap-0 w-[58%] px-16 py-24 max-lg:px-10 max-md:w-full max-md:px-6 max-md:py-12">
        <ExportRow format="Numbered PDF board" detail="Six-up or one-up, slugline header, panel numbers baked into the artwork." />
        <ExportRow format="Avid-compatible shot list" detail="CSV with scene, panel, lens, movement and duration columns your AD can paste straight in." />
        <ExportRow format="Frame.io upload" detail="Pushes each panel as its own asset so notes land on the frame they belong to." />
        <ExportRow format="Animatic with scratch VO" detail="Cut to your panel durations, exported as ProRes or H.264 with a timecode burn-in." />
      </div>
    </section>

    {/* 5 — SIX STYLES */}
    <section tw="flex flex-col w-full gap-12 px-16 py-28 max-lg:px-10 max-md:px-6 max-md:py-16" bg={t.color.paper}>
      <div tw="flex flex-row justify-between items-end gap-10 max-md:flex-col max-md:items-start max-md:gap-5">
        <div tw="flex flex-col gap-5 w-[52%] max-md:w-full">
          <Eyebrow>04 · Styles</Eyebrow>
          <h2 size={44} weight={600} font={t.font.head} color={t.color.ground} lh={1.08} tablet={{ size: 36 }} mobile={{ size: 28 }}>
            Six styles, rough marker to full comp.
          </h2>
        </div>
        <text size={16} font={t.font.body} color="#57565A" lh={1.7} maxw={420} mobile={{ size: 15 }}>
          Pick the finish that matches the conversation you are having. Switch style and the whole
          board re-renders with the character lock intact.
        </text>
      </div>

      <grid cols={3} gap={16} tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
        <StyleCard index="01" name="Rough marker" note="Grease-pencil weight, no shading. For the first pass you show nobody outside the room." />
        <StyleCard index="02" name="Clean line" note="Even contour, flat greys, readable at thumbnail size on a phone." />
        <StyleCard index="03" name="Noir ink wash" note="Hard key, deep blacks, wash gradients. Sells mood before it sells blocking." />
        <StyleCard index="04" name="Full colour comp" note="Client-facing finish with palette continuity across every scene." />
        <StyleCard index="05" name="Photoreal previz" note="Lens-accurate, lit, close enough to the plate to survive a director's read." />
        <StyleCard index="06" name="Loose thumbnail pass" note="Deliberately unfinished, for when the idea is not finished either." />
      </grid>
    </section>

    {/* 6 — RIGHTS */}
    <section tw="flex flex-row w-full gap-20 px-16 py-28 max-lg:px-10 max-lg:gap-12 max-md:flex-col max-md:px-6 max-md:py-16 max-md:gap-8" bg={t.color.ground}>
      <div tw="flex flex-col gap-6 w-[52%] max-md:w-full">
        <Eyebrow>05 · Rights and training data</Eyebrow>
        <h2 size={48} weight={600} font={t.font.head} color={t.color.ink} lh={1.06} ls={-0.015} tablet={{ size: 38 }} mobile={{ size: 30 }}>
          You own every frame.
        </h2>
        <text size={17} font={t.font.body} color="#9A979A" lh={1.7} maxw={520} mobile={{ size: 15 }}>
          We do not train on your scripts or your boards, and there is a written contractual
          commitment, not a toggle in settings.
        </text>
      </div>

      <div tw="flex flex-col justify-center gap-0 flex-1">
        <div tw="flex flex-col gap-2 py-6 border-t border-[rgba(240,239,236,0.2)]">
          <heading tag="h3" size={18} weight={600} font={t.font.head} color={t.color.ink}>Contract, not a setting</heading>
          <text size={15} font={t.font.body} color="#9A979A" lh={1.6}>The no-training clause is in the MSA every account signs. It does not move when the pricing page does.</text>
        </div>
        <div tw="flex flex-col gap-2 py-6 border-t border-[rgba(240,239,236,0.2)]">
          <heading tag="h3" size={18} weight={600} font={t.font.head} color={t.color.ink}>Scripts deleted on request</heading>
          <text size={15} font={t.font.body} color="#9A979A" lh={1.6}>Delete a project and the script, the character locks and the boards go with it, backups included, inside thirty days.</text>
        </div>
        <div tw="flex flex-col gap-2 py-6 border-t border-b border-[rgba(240,239,236,0.2)]">
          <heading tag="h3" size={18} weight={600} font={t.font.head} color={t.color.ink}>Clean for commercial delivery</heading>
          <text size={15} font={t.font.body} color="#9A979A" lh={1.6}>Boards go out to agency and network legal without an asterisk. Indemnity on request for feature work.</text>
        </div>
      </div>
    </section>

    {/* 7 — PRICING */}
    <section tw="flex flex-col w-full gap-12 px-16 py-28 max-lg:px-10 max-md:px-6 max-md:py-16" bg={t.color.paper}>
      <div tw="flex flex-row justify-between items-end gap-10 max-md:flex-col max-md:items-start max-md:gap-5">
        <div tw="flex flex-col gap-5 w-[54%] max-md:w-full">
          <Eyebrow>06 · Pricing</Eyebrow>
          <h2 size={44} weight={600} font={t.font.head} color={t.color.ground} lh={1.08} tablet={{ size: 36 }} mobile={{ size: 28 }}>
            Per project, not per image.
          </h2>
        </div>
        <text size={16} font={t.font.body} color="#57565A" lh={1.7} maxw={420} mobile={{ size: 15 }}>
          Boards get revised. Charging by the frame would just make you board less, which is the
          opposite of the point.
        </text>
      </div>

      <grid cols={3} gap={16} tablet={{ gridCols: 3 }} mobile={{ gridCols: 1 }}>
        <PriceCard tier="Spot" price="£39" unit="per single spot" detail="One commercial, up to 60 panels, every style, all exports." panels="Unlimited revisions for 30 days" />
        <PriceCard tier="Short" price="£180" unit="per short film" detail="Up to 300 panels across all scenes, with locked characters and locations reused throughout." panels="Unlimited revisions for 90 days" />
        <PriceCard tier="Feature" price="£640" unit="per feature-length board" detail="Full feature coverage, department-shared locks, animatic exports and priority render queue." panels="Unlimited revisions for six months" />
      </grid>
    </section>

    {/* 8 — FINAL CTA */}
    <section id="board" tw="flex flex-row w-full items-stretch max-md:flex-col" pad={0} bg={t.color.ground}>
      <div tw="flex flex-col w-[44%] max-md:w-full">
        <img src={media.director_desk.id} tw="w-full" h={520} fit="cover" tablet={{ h: 420 }} mobile={{ h: 240 }} />
      </div>
      <div tw="flex flex-col justify-center gap-7 w-[56%] px-16 py-28 max-lg:px-10 max-md:w-full max-md:px-6 max-md:py-14">
        <Eyebrow>07 · Start</Eyebrow>
        <h2
          size={52}
          weight={600}
          font={t.font.head}
          color={t.color.ink}
          lh={1.05}
          ls={-0.015}
          tablet={{ size: 40 }}
          mobile={{ size: 30 }}
          motion={{ effect: 'fade', trigger: 'scrollIn' }}
        >
          Board your next script.
        </h2>
        <text size={18} font={t.font.body} color="#9A979A" lh={1.7} maxw={520} mobile={{ size: 16 }}>
          Paste a scene, lock a character, and watch the panels come back in the style you asked for.
          The first scene is free and takes about four minutes.
        </text>
        <Cta label="Board your first scene free" href="#board" dark />
        <text size={13} font={t.font.body} color="#57565A" lh={1.6} tw="pt-6 border-t border-[rgba(240,239,236,0.2)]">
          Boardsmith · storyboards for directors and agency creatives · London
        </text>
      </div>
    </section>
  </box>
);
