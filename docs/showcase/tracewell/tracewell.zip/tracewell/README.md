# Tracewell

Terminal-native. The trace stream as hero is exactly right for the audience.

|  |  |
|---|---|
| **Slug** | `tracewell` (deploys to `/tracewell/`) |
| **Archetype** | terminal/console log |
| **Industry** | AI observability / dev tooling |
| **Page title** | Tracewell — Replay the agent run that broke |
| **Fonts** | JetBrains Mono, Inter — Google Fonts, imported by Elementor automatically |
| **Elements** | 298 |
| **Images** | none — this page is type + colour only |
| **Global classes used** | 0 — built `--inline` (131 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install tracewell
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
tracewell/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/tracewell.page.jsx             the page itself: layout + copy
    page.bundle.json            the built, inline bundle that gets deployed
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#07090A` |
| `panel` | `#0E1315` |
| `ink` | `#C8D6D2` |
| `accent` | `#4CFFB0` |
| `alert` | `#FF5C4D` |
| `dim` | `#4A5A57` |

Change a value, re-run `npx exjsx-kit install tracewell`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/tracewell.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — this page ships none by design; it is built from type, colour and layout. To add
some, create `site/data/media.manifest.mjs` following the pattern in any image-bearing page.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
