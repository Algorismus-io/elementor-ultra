import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Sediment — natural wine club',
  slug: 'sediment-wine',
  seo: {
    title: 'Sediment — six strange bottles, four times a year',
    description:
      'A natural wine club: six bottles a season from producers making fewer than 30,000 bottles a year, each with a card explaining what is unusual about it. £108 a season, delivered.',
  },
};

/* ── shared style constants ───────────────────────────────────────────── */
const CARD_SHADOW = [
  [2, 4, 0, 'rgba(42,26,31,0.05)'],
  [18, 34, -18, 'rgba(42,26,31,0.35)'],
];
const LIFT_SHADOW = [
  [4, 6, 0, 'rgba(42,26,31,0.07)'],
  [26, 48, -20, 'rgba(42,26,31,0.42)'],
];

/* ── repeaters (content props only) ───────────────────────────────────── */
const BottleCard = defineComponent(
  ({ no, name, who, hectares, note }) => (
    <div
      tw="flex flex-col gap-3 w-full p-7 rounded-[16px] border-[1px] border-[#E4D2BE] max-md:p-6"
      bg="#F5E6D6"
      shadow={CARD_SHADOW}
    >
      <div tw="flex flex-row items-center justify-between gap-4 w-full">
        <text tw="uppercase tracking-[0.22em] text-[11px]" font="Lora" color="#7B1E3A">
          {no}
        </text>
        <text tw="uppercase tracking-[0.16em] text-[11px]" font="Lora" color="#5C7A4A">
          {hectares}
        </text>
      </div>
      <heading tag="h3" tw="text-[26px] leading-tight max-md:text-[22px]" font="Petrona" weight={600} color="#2A1A1F">
        {name}
      </heading>
      <text tw="text-[13px]" font="Lora" color="#7B1E3A">
        {who}
      </text>
      <text tw="text-[15px] leading-relaxed" font="Lora" color="#5A4148">
        {note}
      </text>
    </div>
  ),
  {
    title: 'Bottle card',
    props: {
      no: { label: 'Number', group: 'Bottle' },
      name: { label: 'Wine', group: 'Bottle' },
      who: { label: 'Grower and place', group: 'Bottle' },
      hectares: { label: 'Hectares', group: 'Bottle' },
      note: { label: 'Tasting note', group: 'Bottle' },
    },
  },
);

const ProducerCard = defineComponent(
  ({ place, size, line }) => (
    <div tw="flex flex-col gap-2 w-full p-6 rounded-[14px] border-[1px] border-[#E4D2BE]" bg="#FFFFFF" shadow={CARD_SHADOW}>
      <text tw="uppercase tracking-[0.18em] text-[11px]" font="Lora" color="#5C7A4A">
        {size}
      </text>
      <heading tag="h4" tw="text-[21px] leading-tight" font="Petrona" weight={600} color="#2A1A1F">
        {place}
      </heading>
      <text tw="text-[14px] leading-relaxed" font="Lora" color="#5A4148">
        {line}
      </text>
    </div>
  ),
  {
    title: 'Producer card',
    props: {
      place: { label: 'Place', group: 'Producer' },
      size: { label: 'Size', group: 'Producer' },
      line: { label: 'Note', group: 'Producer' },
    },
  },
);

const StepCard = defineComponent(
  ({ verb, body }) => (
    <div tw="flex flex-col gap-3 w-full p-7 rounded-[14px] max-md:p-6" bg="#FDF6EF" shadow={CARD_SHADOW}>
      <heading tag="h3" tw="text-[24px] leading-tight" font="Petrona" weight={600} color="#7B1E3A">
        {verb}
      </heading>
      <text tw="text-[15px] leading-relaxed" font="Lora" color="#5A4148">
        {body}
      </text>
    </div>
  ),
  {
    title: 'Control step',
    props: { verb: { label: 'Verb', group: 'Step' }, body: { label: 'Body', group: 'Step' } },
  },
);

/* ── data ─────────────────────────────────────────────────────────────── */
const BOTTLES = [
  {
    no: 'Bottle 01',
    name: 'Chenin, Les Cailloux',
    who: 'Marie Fouquet · Loire',
    hectares: '3.2 ha',
    note: 'Cloudy as a January sky, and meant to be. Bruised apple, chalk, a squeeze of lemon at the end.',
  },
  {
    no: 'Bottle 02',
    name: 'Gamay, Deux Frères',
    who: 'Paul & Luc Berthaud · Beaujolais',
    hectares: '5 ha',
    note: 'Drink it cold. Raspberry juice with a grip, and the only bottle here nobody has ever sent back.',
  },
  {
    no: 'Bottle 03',
    name: 'Rkatsiteli, Qvevri',
    who: 'Nino Abashidze · Kakheti',
    hectares: '1.1 ha',
    note: 'Six months underground in a clay pot. Orange, grippy, dried apricot skin. Decant it if you can wait.',
  },
  {
    no: 'Bottle 04',
    name: 'Trousseau, Ligne Grise',
    who: 'Domaine Vallet · Jura',
    hectares: '2.4 ha',
    note: 'Pale enough to look like a rosé and savoury enough to argue with. Smells of a cellar, in the good way.',
  },
  {
    no: 'Bottle 05',
    name: 'Zibibbo sur lie',
    who: 'Cantina Rallo · Sicily',
    hectares: '4 ha',
    note: 'A prickle of fizz on the tongue. That is the wine still working, not a fault. Open it over a sink.',
  },
  {
    no: 'Bottle 06',
    name: "Pineau d'Aunis, Poivre",
    who: 'Hervé Colin · Loire',
    hectares: '1.8 ha',
    note: 'White pepper and cranberry, thin in the way good things are thin. The odd one we argue about most.',
  },
];

const PRODUCERS = [
  { place: 'Loire, France', size: '3.2 hectares', line: 'One grower, one tractor, and a cellar under the house she was born in.' },
  { place: 'Beaujolais, France', size: '5 hectares', line: 'Two brothers, granite slopes, and a shared press they book by the week.' },
  { place: 'Kakheti, Georgia', size: '1.1 hectares', line: 'Buried qvevri, no electricity in the cellar, 900 bottles in a good year.' },
  { place: 'Jura · Sicily · Loire', size: '2–4 hectares each', line: 'Three others of the same size, all of whom answer their own email.' },
];

const CARD_ROWS = [
  ['The grower', 'Who farms it, and whether they also drive the tractor.'],
  ['The hectares', 'The real number. Most are under five.'],
  ['Tastes like', 'Plain words. Never "gunflint", never "brooding".'],
  ['Eat with', 'One dish you already cook on a Tuesday.'],
  ['Why this one', 'Over the forty others we tasted that week.'],
];

const FINE = [
  ['Cloudy', 'Unfiltered wine has bits. Stand it up for an hour if it bothers you.'],
  ['A little fizz', 'In a still wine it is usually fine, and it will blow off in the glass.'],
  ['Sediment', 'It is the name of the club. Pour the last inch slowly or do not pour it.'],
];

const NOT_FINE = [
  ['Nail varnish', 'Volatile acidity gone too far. Not a style, a mistake.'],
  ['Wet cardboard', 'Cork taint. Nothing to do with low intervention.'],
  ['Our problem', 'We replace it, and we tell the producer which batch it came from.'],
];

/* ── page ─────────────────────────────────────────────────────────────── */
export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>

    {/* 1 — hero + the season's card stack */}
    <section tw="flex flex-col w-full items-center px-6 pt-20 pb-28 max-md:px-5 max-md:pt-14 max-md:pb-20" bg={t.color.ink}>
      <grid
        cols="1.05fr 0.95fr"
        tw="w-full max-w-[1180px] gap-16 items-start max-lg:grid-cols-1 max-lg:gap-12"
        mobile={{ gridCols: 1 }}
      >
        <div tw="flex flex-col gap-7 items-start">
          <text tw="uppercase tracking-[0.28em] text-[12px]" font="Lora" color={t.color.orange}>
            Sediment · natural wine club
          </text>
          <h1
            tw="text-[68px] leading-[1.02] max-lg:text-[56px] max-md:text-[38px]"
            font={t.font.head}
            weight={600}
            color={t.color.ground}
          >
            Six strange bottles, four times a year, explained properly.
          </h1>
          <text tw="text-[18px] leading-relaxed max-w-[520px] max-md:text-[16px]" font={t.font.body} color="#E3CFC2">
            Sediment sends wine from producers making fewer than 30,000 bottles a year, with a card for each one
            telling you what is unusual about it and whether you should be worried. Usually you should not.
          </text>
          <div tw="flex flex-row items-center gap-5 flex-wrap">
            <text
              href="#join"
              tw="px-8 py-4 rounded-[999px] text-[16px] hover:bg-[#C4682A]"
              font={t.font.body}
              weight={600}
              bg={t.color.orange}
              color={t.color.ink}
              shadow={LIFT_SHADOW}
            >
              Join for the autumn box
            </text>
            <text tw="text-[14px]" font={t.font.body} color="#B49A93">
              £108 a season · skip or cancel from the email
            </text>
          </div>
          <img
            src={media.bottles_table.id}
            tw="w-full max-w-[520px] rounded-[16px] mt-4 max-lg:hidden"
            h={180}
            fit="cover"
          />
        </div>

        {/* the stack */}
        <div tw="flex flex-col w-full max-w-[460px] pt-2 max-lg:max-w-[560px]">
          <text tw="uppercase tracking-[0.2em] text-[11px] pb-5" font={t.font.body} color="#B49A93">
            This season, in the order we would drink them
          </text>
          {BOTTLES.map((b, i) => (
            <div
              tw={[
                'flex flex-col w-full',
                i === 0 ? '' : '-mt-5 max-md:-mt-4',
                i % 2 === 0 ? 'rotate-[-1.4deg]' : 'rotate-[1.6deg] ml-5 max-md:ml-0',
              ].join(' ')}
              motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500, delay: i * 60 }}
            >
              <BottleCard {...b} />
            </div>
          ))}
        </div>
      </grid>
    </section>

    {/* 2 — what low-intervention means */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:px-5 max-md:py-16" bg={t.color.ground}>
      <grid cols="0.55fr 1.45fr" tw="w-full max-w-[1180px] gap-14 items-start max-lg:grid-cols-1 max-lg:gap-8" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col gap-4 items-start">
          <div tw="w-[64px] h-[4px] rounded-[2px]" bg={t.color.verdant} />
          <heading tag="h2" tw="text-[34px] leading-tight max-md:text-[27px]" font={t.font.head} weight={600} color={t.color.ink}>
            What it means, without the sermon
          </heading>
        </div>
        <div tw="flex flex-col gap-8 items-start">
          <text
            tw="text-[27px] leading-[1.45] max-w-[760px] max-md:text-[20px]"
            font={t.font.head}
            color={t.color.ink}
            motion={{ effect: 'fade', trigger: 'scrollIn' }}
          >
            Low-intervention means farmed without systemic chemicals, fermented with what was already on the grapes,
            and bottled with little or no added sulphur. <em>It does not mean it should taste like cider.</em>
          </text>
          <grid cols={3} tw="w-full gap-4 max-md:grid-cols-1" mobile={{ gridCols: 1 }}>
            {[
              ['In the vineyard', 'No systemic chemicals. Weeds get a plough, not a spray.'],
              ['In the cellar', 'Wild yeast only — whatever came in on the skins.'],
              ['At bottling', 'Little or no added sulphur, and we print the number.'],
            ].map(([k, v]) => (
              <div tw="flex flex-col gap-2 p-5 rounded-[12px] border-[1px] border-[#E4D2BE]" bg={t.color.cream}>
                <text tw="uppercase tracking-[0.16em] text-[11px]" font={t.font.body} color={t.color.wine}>
                  {k}
                </text>
                <text tw="text-[15px] leading-relaxed" font={t.font.body} color="#5A4148">
                  {v}
                </text>
              </div>
            ))}
          </grid>
        </div>
      </grid>
    </section>

    {/* 3 — the one card per bottle */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:px-5 max-md:py-16" bg={t.color.cream}>
      <grid cols="0.9fr 1.1fr" tw="w-full max-w-[1180px] gap-0 items-center max-lg:grid-cols-1 max-lg:gap-8" mobile={{ gridCols: 1 }}>
        <img src={media.pour.id} tw="w-full rounded-[18px]" h={520} fit="cover" tablet={{ h: 380 }} mobile={{ h: 300 }} />
        <div
          tw="flex flex-col gap-6 p-10 rounded-[18px] -ml-16 max-lg:ml-0 max-lg:-mt-14 max-md:p-7 max-md:-mt-10"
          bg={t.color.ground}
          shadow={LIFT_SHADOW}
          motion={{ effect: 'fade', trigger: 'scrollIn' }}
        >
          <div tw="flex flex-col gap-3 items-start">
            <text tw="uppercase tracking-[0.2em] text-[11px]" font={t.font.body} color={t.color.orange}>
              One card per bottle
            </text>
            <heading tag="h2" tw="text-[34px] leading-tight max-md:text-[26px]" font={t.font.head} weight={600} color={t.color.ink}>
              Every bottle gets a card, and the card is the point.
            </heading>
            <text tw="text-[16px] leading-relaxed" font={t.font.body} color="#5A4148">
              The grower, the hectares, what the wine tastes like in plain words, what to eat with it, and one line on
              why we picked it over the forty others we tasted that week.
            </text>
          </div>
          <div tw="flex flex-col w-full">
            {CARD_ROWS.map(([k, v], i) => (
              <div tw={`flex flex-row gap-6 py-4 border-t border-[#E4D2BE] max-md:flex-col max-md:gap-1 ${i === 0 ? 'border-t-0' : ''}`}>
                <text tw="uppercase tracking-[0.14em] text-[11px] w-[130px] max-md:w-full" font={t.font.body} color={t.color.verdant}>
                  {k}
                </text>
                <text tw="text-[15px] leading-relaxed flex-1" font={t.font.body} color={t.color.ink}>
                  {v}
                </text>
              </div>
            ))}
          </div>
        </div>
      </grid>
    </section>

    {/* 4 — faults */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:px-5 max-md:py-16" bg={t.color.wine}>
      <div tw="flex flex-col w-full max-w-[1180px] gap-10 items-start">
        <div tw="flex flex-row w-full gap-10 items-end max-lg:flex-col max-lg:items-start max-lg:gap-5">
          <heading tag="h2" tw="text-[44px] leading-tight flex-1 max-md:text-[30px]" font={t.font.head} weight={600} color={t.color.ground}>
            Cloudy, funky, fizzy: what is a fault and what is not.
          </heading>
          <text tw="text-[16px] leading-relaxed max-w-[380px]" font={t.font.body} color="#EBC9CE">
            Cloudy is fine. A little fizz in a still wine is usually fine and will blow off. Nail varnish and wet
            cardboard are not fine, and if you get one we replace it and tell the producer.
          </text>
        </div>
        <grid cols={2} tw="w-full gap-6 items-start max-lg:grid-cols-1" mobile={{ gridCols: 1 }}>
          <div tw="flex flex-col gap-5 p-8 rounded-[18px] rotate-[-0.8deg] max-md:p-6" bg={t.color.ground} shadow={CARD_SHADOW}>
            <text tw="uppercase tracking-[0.2em] text-[12px]" font={t.font.body} color={t.color.verdant}>
              Fine, actually
            </text>
            {FINE.map(([k, v]) => (
              <div tw="flex flex-col gap-1">
                <heading tag="h3" tw="text-[22px] leading-tight" font={t.font.head} weight={600} color={t.color.ink}>
                  {k}
                </heading>
                <text tw="text-[15px] leading-relaxed" font={t.font.body} color="#5A4148">
                  {v}
                </text>
              </div>
            ))}
          </div>
          <div
            tw="flex flex-col gap-5 p-8 rounded-[18px] rotate-[1deg] mt-6 max-lg:mt-0 max-md:p-6"
            bg={t.color.ink}
            shadow={LIFT_SHADOW}
            motion={{ effect: 'fade', trigger: 'scrollIn' }}
          >
            <text tw="uppercase tracking-[0.2em] text-[12px]" font={t.font.body} color={t.color.orange}>
              Not fine, tell us
            </text>
            {NOT_FINE.map(([k, v]) => (
              <div tw="flex flex-col gap-1">
                <heading tag="h3" tw="text-[22px] leading-tight" font={t.font.head} weight={600} color={t.color.cream}>
                  {k}
                </heading>
                <text tw="text-[15px] leading-relaxed" font={t.font.body} color="#C9AEA8">
                  {v}
                </text>
              </div>
            ))}
          </div>
        </grid>
      </div>
    </section>

    {/* 5 — producers */}
    <section tw="flex flex-col w-full items-center px-6 pt-24 pb-24 max-md:px-5 max-md:pt-14 max-md:pb-16" bg={t.color.ground}>
      <div tw="flex flex-col w-full max-w-[1180px] items-start">
        <img src={media.vineyard.id} tw="w-full rounded-[18px]" h={380} fit="cover" mobile={{ h: 220 }} />
        <div
          tw="flex flex-col gap-4 p-10 rounded-[18px] -mt-24 ml-10 max-w-[720px] rotate-[-0.7deg] max-lg:ml-0 max-md:p-7 max-md:-mt-14"
          bg={t.color.cream}
          shadow={LIFT_SHADOW}
          motion={{ effect: 'fade', trigger: 'scrollIn' }}
        >
          <text tw="uppercase tracking-[0.2em] text-[11px]" font={t.font.body} color={t.color.wine}>
            Producers, and how small they really are
          </text>
          <heading tag="h2" tw="text-[36px] leading-tight max-md:text-[26px]" font={t.font.head} weight={600} color={t.color.ink}>
            A 3.2 hectare estate is one person and a lot of walking.
          </heading>
          <text tw="text-[16px] leading-relaxed" font={t.font.body} color="#5A4148">
            This season: a 3.2 hectare estate in the Loire, two brothers in Beaujolais on 5 hectares, a Georgian
            qvevri maker with 1.1 hectares, and three others of the same size.
          </text>
        </div>
        <grid cols={4} tw="w-full gap-5 pt-10 max-lg:grid-cols-2 max-md:grid-cols-1" mobile={{ gridCols: 1 }}>
          {PRODUCERS.map((p) => (
            <ProducerCard {...p} />
          ))}
        </grid>
      </div>
    </section>

    {/* 6 — skip, swap, cancel */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:px-5 max-md:py-16" bg={t.color.cream}>
      <div tw="flex flex-col w-full max-w-[1180px] gap-9 items-start">
        <div tw="flex flex-row w-full gap-10 items-end max-lg:flex-col max-lg:items-start max-lg:gap-4">
          <heading tag="h2" tw="text-[38px] leading-tight flex-1 max-md:text-[28px]" font={t.font.head} weight={600} color={t.color.ink}>
            Skip, swap or cancel from the email.
          </heading>
          <text tw="text-[16px] leading-relaxed max-w-[420px]" font={t.font.body} color="#5A4148">
            Skip a season, swap a bottle you did not get on with, or cancel entirely from a link in the email. No
            phone call, no offer, no three-step flow.
          </text>
        </div>
        <grid cols={3} tw="w-full gap-5 max-lg:grid-cols-1" mobile={{ gridCols: 1 }}>
          <StepCard verb="Skip" body="One link, one click, and autumn goes past you. Your place is held for the winter box." />
          <StepCard verb="Swap" body="Did not get on with the qvevri? Tell us and the next one is something else entirely." />
          <StepCard verb="Cancel" body="Same email, same link. It ends there, and we do not send a win-back offer." />
        </grid>
      </div>
    </section>

    {/* 7 — price and shipping */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:px-5 max-md:py-16" bg={t.color.ink}>
      <grid cols="0.8fr 1.2fr" tw="w-full max-w-[1180px] gap-14 items-center max-lg:grid-cols-1 max-lg:gap-8" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col gap-2 items-start">
          <text tw="uppercase tracking-[0.22em] text-[12px]" font={t.font.body} color={t.color.orange}>
            Prices, and the shipping
          </text>
          <heading tag="h2" tw="text-[92px] leading-[0.95] max-md:text-[62px]" font={t.font.head} weight={600} color={t.color.ground}>
            £108
          </heading>
          <text tw="text-[17px]" font={t.font.body} color="#B49A93">
            a season · six bottles · delivered
          </text>
        </div>
        <div tw="flex flex-col w-full gap-4">
          <text tw="text-[19px] leading-relaxed max-md:text-[16px]" font={t.font.body} color={t.color.cream}>
            £108 a season for six bottles, delivered. That is £18 a bottle, and we publish what we paid for each one
            on the card.
          </text>
          <grid cols={3} tw="w-full gap-4 max-md:grid-cols-1" mobile={{ gridCols: 1 }}>
            {[
              ['£18', 'a bottle, all in'],
              ['£0', 'shipping — it is £7.20 and we absorb it'],
              ['4×', 'a year, billed the week it ships'],
            ].map(([k, v]) => (
              <div tw="flex flex-col gap-1 p-5 rounded-[12px] border-[1px] border-[#4A3239]" bg="#3A252B">
                <heading tag="h3" tw="text-[30px] leading-none" font={t.font.head} weight={600} color={t.color.orange}>
                  {k}
                </heading>
                <text tw="text-[14px] leading-relaxed" font={t.font.body} color="#B49A93">
                  {v}
                </text>
              </div>
            ))}
          </grid>
        </div>
      </grid>
    </section>

    {/* 8 — join */}
    <section id="join" tw="flex flex-col w-full items-center px-6 py-24 max-md:px-5 max-md:py-16" bg={t.color.ground}>
      <div
        tw="flex flex-col items-center text-center gap-6 w-full max-w-[820px] px-14 py-16 rounded-[22px] max-md:px-7 max-md:py-12"
        bg={t.color.wine}
        shadow={LIFT_SHADOW}
      >
        <text tw="uppercase tracking-[0.24em] text-[12px]" font={t.font.body} color="#EBC9CE">
          The autumn box ships in September
        </text>
        <heading tag="h2" tw="text-[46px] leading-tight max-md:text-[32px]" font={t.font.head} weight={600} color={t.color.ground}>
          Join for the autumn box
        </heading>
        <text tw="text-[17px] leading-relaxed max-w-[560px] max-md:text-[15px]" font={t.font.body} color="#EBC9CE">
          Six bottles, six cards, £108 delivered. Skip, swap or cancel from the email whenever you like — usually you
          will not want to.
        </text>
        <text
          href="#join"
          tw="px-9 py-4 rounded-[999px] text-[16px] hover:bg-[#C4682A]"
          font={t.font.body}
          weight={600}
          bg={t.color.orange}
          color={t.color.ink}
          shadow={CARD_SHADOW}
        >
          Join for the autumn box
        </text>
      </div>
    </section>
  </box>
);
