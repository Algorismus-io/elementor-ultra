# Carrow Valve Works

Industrial catalogue; the valve tables and forge photography work hard.

|  |  |
|---|---|
| **Slug** | `carrow-valve` (deploys to `/carrow-valve/`) |
| **Archetype** | spec-sheet table as hero |
| **Industry** | B2B industrial manufacturing |
| **Page title** | Valve selection table — Carrow Valve Works |
| **Fonts** | Oswald, Roboto Mono — Google Fonts, imported by Elementor automatically |
| **Elements** | 187 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (85 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install carrow-valve
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
carrow-valve/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/carrow-valve.page.jsx          the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F2F3F4` |
| `ink` | `#1A1D20` |
| `steel` | `#5B676E` |
| `safety` | `#C8102E` |
| `band` | `#DDE1E4` |

Change a value, re-run `npx exjsx-kit install carrow-valve`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/carrow-valve.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `forge_floor` | `media/forge_floor.jpg` | Forge floor at the Carrow Valve Works in Sheffield |
| `test_bay` | `media/test_bay.jpg` | Hydrostatic test bay with a valve under witnessed test |
| `valve_machined` | `media/valve_machined.jpg` | Machined forged valve body on the inspection bench |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
