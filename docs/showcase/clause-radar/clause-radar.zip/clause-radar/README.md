# Clause Radar

Spec-table hero, precise, visually quiet.

|  |  |
|---|---|
| **Slug** | `clause-radar` (deploys to `/clause-radar/`) |
| **Archetype** | spec-sheet table as hero |
| **Industry** | Legal technology |
| **Page title** | Clause Radar — Clause coverage and measured accuracy |
| **Fonts** | IBM Plex Serif, IBM Plex Mono — Google Fonts, imported by Elementor automatically |
| **Elements** | 222 |
| **Images** | none — this page is type + colour only |
| **Global classes used** | 0 — built `--inline` (127 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install clause-radar
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
clause-radar/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/clause-radar.page.jsx          the page itself: layout + copy
    page.bundle.json            the built, inline bundle that gets deployed
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FFFFFF` |
| `ink` | `#101418` |
| `legal` | `#1F3A5F` |
| `flag` | `#B3341E` |
| `safe` | `#2E7D5B` |
| `rule` | `#E1E5E9` |

Change a value, re-run `npx exjsx-kit install clause-radar`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/clause-radar.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — this page ships none by design; it is built from type, colour and layout. To add
some, create `site/data/media.manifest.mjs` following the pattern in any image-bearing page.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
