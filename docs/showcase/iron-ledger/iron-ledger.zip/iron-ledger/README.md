# Iron Ledger

Ochre and oxblood war-game ledger; the parchment panels sell it.

|  |  |
|---|---|
| **Slug** | `iron-ledger` (deploys to `/iron-ledger/`) |
| **Archetype** | full-bleed colour blocks with hard seams |
| **Industry** | Indie video game |
| **Page title** | Iron Ledger |
| **Fonts** | Chakra Petch, Rubik — Google Fonts, imported by Elementor automatically |
| **Elements** | 160 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (95 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install iron-ledger
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
iron-ledger/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/iron-ledger.page.jsx           the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#12100E` |
| `ink` | `#F0E6D2` |
| `rust` | `#A63A22` |
| `brass` | `#D8A64A` |
| `moss` | `#3E5240` |
| `bone` | `#E8DCC4` |

Change a value, re-run `npx exjsx-kit install iron-ledger`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/iron-ledger.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `battle_map` | `media/battle_map.jpg` | Campaign map of the retreat, roads and river crossings marked in chalk |
| `camp_night` | `media/camp_night.jpg` | The column camped at night, wagons drawn up around low fires |
| `ledger_still` | `media/ledger_still.jpg` | The supply ledger open on a field desk, grain columns tallied by hand |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
