/**
 * Avers Frame — editorial index rail.
 * A left label rail runs the whole page; content sits in the right column and the
 * photographs break full-bleed out of it. No centred hero, no card triptych.
 */
import { img as id } from '../data/media.mjs';

export const meta = {
  title: 'Avers Frame — Architectural Photography',
  slug: 'avers-frame',
  seo: {
    title: 'Avers Frame — Architectural photography, Lisbon',
    description:
      'Avers Frame shoots completed architecture for practices, developers and award submissions. Based in Lisbon, working across Iberia and the UK.',
  },
};

/* ── shared measures ── */
const WRAP = 1180;
const PAD_X = 40;
const RAIL = '260px 1fr';

/* One index entry: number, project, practice, year on a hairline-ruled rail row. */
const IndexRow = defineComponent(
  ({ num, project, practice, year }, { theme: t }) => (
    <box cls="index-row" w="100%" pad={0} gap={0}>
      <box cls="hairline" w="100%" h={1} bg={t.color.hairline} pad={0} />
      <grid
        cls="index-grid"
        cols="88px 1fr 240px 72px"
        gap={16}
        w="100%"
        pad={{ t: 22, b: 22 }}
        align="flex-start"
        mobile={{ gridCols: 1, gap: 4 }}
      >
        <text cls="index-num" font={t.font.body} size={13} ls={0.06} color={t.color.grey}>
          {num}
        </text>
        <text cls="index-title" font={t.font.head} size={26} lh={1.15} color={t.color.ink} mobile={{ size: 22 }}>
          {project}
        </text>
        <text cls="index-practice" font={t.font.body} size={14} lh={1.5} color={t.color.grey}>
          {practice}
        </text>
        <text cls="index-year" font={t.font.body} size={13} ls={0.04} color={t.color.grey} ta="right" mobile={{ ta: 'left' }}>
          {year}
        </text>
      </grid>
    </box>
  ),
  {
    title: 'Index row',
    props: {
      num: { label: 'Number', group: 'Entry' },
      project: { label: 'Project', group: 'Entry' },
      practice: { label: 'Practice', group: 'Entry' },
      year: { label: 'Year', group: 'Entry' },
    },
  },
);

/* One shoot format inside the hairline-gap grid. */
const ShootFormat = defineComponent(
  ({ name, price, frames, body }, { theme: t }) => (
    <box cls="format" bg={t.color.ground} pad={[32, 28]} gap={12} h="100%" align="flex-start">
      <text cls="format-name" font={t.font.body} size={12} ls={0.14} color={t.color.grey}>
        {name}
      </text>
      <text cls="format-price" font={t.font.head} size={40} lh={1} color={t.color.ink}>
        {price}
      </text>
      <text cls="format-frames" font={t.font.body} size={14} color={t.color.accent}>
        {frames}
      </text>
      <text cls="format-body" font={t.font.body} size={14.5} lh={1.65} color={t.color.grey}>
        {body}
      </text>
    </box>
  ),
  {
    title: 'Shoot format',
    props: {
      name: { label: 'Format', group: 'Format' },
      price: { label: 'Price', group: 'Format' },
      frames: { label: 'Deliverable', group: 'Format' },
      body: { label: 'Description', group: 'Format' },
    },
  },
);

const INDEX = [
  { num: '017', project: 'Casa Bento, Sesimbra', practice: 'Ferro Arquitectos', year: '2025' },
  { num: '016', project: 'Escola da Ribeira, Porto', practice: 'Matos Nunes', year: '2025' },
  { num: '015', project: 'Warehouse Nine, Bermondsey', practice: 'Hale & Ord', year: '2024' },
  { num: '014', project: 'Casa dos Pinheiros, Comporta', practice: 'Ferro Arquitectos', year: '2024' },
  { num: '013', project: 'Mercado de Alvalade, Lisbon', practice: 'Estúdio Ramalho', year: '2024' },
  { num: '012', project: 'Torre Bica, Lisbon', practice: 'Vega Arquitectura', year: '2023' },
  { num: '011', project: 'Two Houses, Sintra', practice: 'Matos Nunes', year: '2023' },
  { num: '010', project: 'Casa Rosal, Vigo', practice: 'Vega Arquitectura', year: '2023' },
];

const CLIENTS = [
  'Ferro Arquitectos',
  'Matos Nunes',
  'Hale & Ord',
  'Vega Arquitectura',
  'Estúdio Ramalho',
  'Bica Developments',
  'Comporta Land',
  'Prémio Valmor entries',
  'AJ Small Projects entries',
  'Câmara Municipal de Lisboa',
  'Herdade Living',
  'Norte Construção',
];

export default function AversFrame({ theme: t }) {
  /* Rail label — the page's recurring left column. */
  const Rail = ({ label, note }) => (
    <box cls="rail" pad={0} gap={10} align="flex-start">
      <text cls="rail-label" font={t.font.body} size={12} ls={0.16} color={t.color.ink}>
        {label}
      </text>
      {note && (
        <text cls="rail-note" font={t.font.body} size={13.5} lh={1.6} color={t.color.grey} maxw={220}>
          {note}
        </text>
      )}
    </box>
  );

  return (
    <Page theme={t}>
      {/* ── 1. Masthead: name, discipline, city, one sentence ── */}
      <section cls="masthead" bg={t.color.ground} pad={{ t: 28, b: 96 }} align="center" w="100%">
        <box cls="wrap" w="100%" maxw={WRAP} center pad={{ l: PAD_X, r: PAD_X }} gap={0} mobile={{ pad: { l: 20, r: 20 } }}>
          <row cls="topbar" w="100%" pad={{ b: 20 }} justify="space-between" align="center" gap={16} wrap>
            <text cls="wordmark" font={t.font.body} size={13} ls={0.22} color={t.color.ink}>
              AVERS FRAME
            </text>
            <text cls="topbar-meta" font={t.font.body} size={12.5} ls={0.08} color={t.color.grey}>
              Lisbon · Iberia · UK
            </text>
          </row>
          <box cls="hairline" w="100%" h={1} bg={t.color.hairline} pad={0} />

          <grid cls="masthead-grid" cols={RAIL} gap={48} w="100%" pad={{ t: 64 }} mobile={{ gridCols: 1, gap: 32 }}>
            <Rail label="ARCHITECTURAL PHOTOGRAPHY" note="A one-person studio photographing completed buildings for the practices that drew them." />
            <box cls="masthead-body" pad={0} gap={28} align="flex-start" maxw={760}>
              <h1
                cls="h1"
                font={t.font.head}
                size={68}
                lh={1.04}
                ls={-0.01}
                weight={400}
                color={t.color.ink}
                tablet={{ size: 52 }}
                mobile={{ size: 36 }}
                motion={{ effect: 'fade', trigger: 'load', duration: 700 }}
              >
                Buildings, photographed once they are finished and lived in.
              </h1>
              <text cls="sub" font={t.font.body} size={18} lh={1.7} color={t.color.grey} maxw={620} mobile={{ size: 16 }}>
                Avers Frame shoots completed architecture for practices, developers and award submissions. Based in
                Lisbon, working across Iberia and the UK.
              </text>
              <text
                cls="cta"
                href="#enquiry"
                font={t.font.body}
                size={14}
                ls={0.1}
                color={t.color.ground}
                bg={t.color.ink}
                pad={[16, 28]}
                w="hug"
                hover={{ bg: t.color.accent }}
                tw="cursor-pointer"
              >
                CHECK AVAILABILITY
              </text>
            </box>
          </grid>
        </box>
      </section>

      {/* ── 2. Numbered project index ── */}
      <section cls="index" bg={t.color.ground} pad={{ b: 96 }} align="center" w="100%">
        <box cls="wrap" w="100%" maxw={WRAP} center pad={{ l: PAD_X, r: PAD_X }} gap={0} mobile={{ pad: { l: 20, r: 20 } }}>
          <grid cls="index-rail" cols={RAIL} gap={48} w="100%" mobile={{ gridCols: 1, gap: 24 }}>
            <Rail label="INDEX" note="Seventeen buildings since 2023. Each one shot in a single visit, on a schedule built around the sun." />
            <box cls="index-list" pad={0} gap={0} w="100%" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              {INDEX.map((r) => (
                <IndexRow {...r} />
              ))}
              <box cls="hairline" w="100%" h={1} bg={t.color.hairline} pad={0} />
              <text cls="index-foot" font={t.font.body} size={13} lh={1.7} color={t.color.grey} pad={{ t: 18 }}>
                Earlier work and full sets available on request.
              </text>
            </box>
          </grid>
        </box>
      </section>

      {/* ── 3. Plate one: interior ── */}
      <section cls="plate-one" bg={t.color.ground} pad={0} align="center" w="100%">
        <box cls="plate" w="100%" pad={0} gap={0}>
          <img
            cls="plate-img"
            src={id('interior_plate')}
            w="100%"
            h={620}
            fit="cover"
            tablet={{ h: 460 }}
            mobile={{ h: 300 }}
            motion={{ effect: 'fade', trigger: 'scrollIn', duration: 800 }}
          />
          <box w="100%" align="center" pad={{ t: 14, b: 0 }}>
            <row cls="caption" w="100%" maxw={WRAP} pad={{ l: PAD_X, r: PAD_X }} justify="space-between" gap={16} wrap mobile={{ pad: { l: 20, r: 20 } }}>
              <text font={t.font.body} size={12.5} lh={1.6} color={t.color.grey}>
                Interior, morning light, furniture moved twice
              </text>
              <text font={t.font.body} size={12.5} ls={0.06} color={t.color.grey}>
                017 — Casa Bento, Sesimbra
              </text>
            </row>
          </box>
        </box>
      </section>

      {/* ── 4. Selected clients ── */}
      <section cls="clients" bg={t.color.ink} pad={[96, 0]} align="center" w="100%">
        <box cls="wrap" w="100%" maxw={WRAP} center pad={{ l: PAD_X, r: PAD_X }} gap={0} mobile={{ pad: { l: 20, r: 20 } }}>
          <grid cls="clients-rail" cols={RAIL} gap={48} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
            <box cls="rail" pad={0} gap={10} align="flex-start">
              <text font={t.font.body} size={12} ls={0.16} color={t.color.ground}>
                SELECTED CLIENTS
              </text>
              <text font={t.font.body} size={13.5} lh={1.6} color={t.color.grey} maxw={220}>
                Practices, developers, and the odd municipal client.
              </text>
            </box>
            <grid cls="clients-list" cols={2} gap={0} w="100%" mobile={{ gridCols: 1 }}>
              {CLIENTS.map((c) => (
                <box cls="client-row" pad={0} gap={0} w="100%">
                  <box cls="hairline-dark" w="100%" h={1} bg="#2A2A2A" pad={0} />
                  <text
                    cls="client-name"
                    font={t.font.body}
                    size={15.5}
                    lh={1.5}
                    color={t.color.ground}
                    pad={{ t: 14, b: 14, r: 24 }}
                    hover={{ color: t.color.accent }}
                  >
                    {c}
                  </text>
                </box>
              ))}
            </grid>
          </grid>
        </box>
      </section>

      {/* ── 5. Plate two: exterior at dusk ── */}
      <section cls="plate-two" bg={t.color.ground} pad={0} align="center" w="100%">
        <box cls="plate" w="100%" pad={0} gap={0}>
          <img
            cls="plate-img"
            src={id('exterior_dusk')}
            w="100%"
            h={680}
            fit="cover"
            tablet={{ h: 480 }}
            mobile={{ h: 320 }}
            motion={{ effect: 'fade', trigger: 'scrollIn', duration: 800 }}
          />
          <box w="100%" align="center" pad={{ t: 14 }}>
            <row cls="caption" w="100%" maxw={WRAP} pad={{ l: PAD_X, r: PAD_X }} justify="space-between" gap={16} wrap mobile={{ pad: { l: 20, r: 20 } }}>
              <text font={t.font.body} size={12.5} lh={1.6} color={t.color.grey}>
                Exterior, eleven minutes after sunset, tripod, no drone
              </text>
              <text font={t.font.body} size={12.5} ls={0.06} color={t.color.grey}>
                012 — Torre Bica, Lisbon
              </text>
            </row>
          </box>
        </box>
      </section>

      {/* ── 6. How a shoot runs ── */}
      <section cls="shoot" bg={t.color.ground} pad={[96, 0]} align="center" w="100%">
        <box cls="wrap" w="100%" maxw={WRAP} center pad={{ l: PAD_X, r: PAD_X }} gap={0} mobile={{ pad: { l: 20, r: 20 } }}>
          <grid cls="shoot-rail" cols={RAIL} gap={48} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
            <Rail label="HOW A SHOOT RUNS" note="One visit, one photographer, everything carried in. Half day, full day, or two days with styling." />
            <box pad={0} gap={40} w="100%">
              <grid
                cls="formats"
                cols={3}
                gap={1}
                bg={t.color.hairline}
                w="100%"
                shadow={[[1, 0, 0, '#E4E4E4'], [-1, 0, 0, '#E4E4E4']]}
                mobile={{ gridCols: 1 }}
                motion={{ effect: 'fade', trigger: 'scrollIn' }}
              >
                <ShootFormat
                  name="HALF DAY"
                  price="1,400 €"
                  frames="Six finished frames"
                  body="Four hours on site. Right for a single house, a completed interior, or a fast award deadline."
                />
                <ShootFormat
                  name="FULL DAY"
                  price="2,400 €"
                  frames="Fourteen finished frames"
                  body="The building through a whole arc of light — morning, afternoon, and the dusk exterior."
                />
                <ShootFormat
                  name="TWO DAY"
                  price="from 4,100 €"
                  frames="Interiors with styling"
                  body="Two days, furniture and props dressed with you, and time held for weather to turn."
                />
              </grid>
              <text cls="note" font={t.font.head} size={26} lh={1.5} color={t.color.ink} maxw={720} mobile={{ size: 20 }}>
                <em>
                  I shoot on a tripod, on a schedule built around the sun, and I move furniture. Allow me the building
                  for a full day and you will get frames a drone cannot.
                </em>
              </text>
            </box>
          </grid>
        </box>
      </section>

      {/* ── 7. Licensing and usage ── */}
      <section cls="licensing" bg="#FAFAFA" pad={[96, 0]} align="center" w="100%">
        <box cls="wrap" w="100%" maxw={WRAP} center pad={{ l: PAD_X, r: PAD_X }} gap={0} mobile={{ pad: { l: 20, r: 20 } }}>
          <grid cls="licensing-grid" cols="1fr 1fr" gap={64} w="100%" align="flex-start" mobile={{ gridCols: 1, gap: 32 }}>
            <img cls="detail" src={id('detail_stair')} w="100%" h={520} fit="cover" mobile={{ h: 300 }} />
            <box pad={0} gap={24} align="flex-start">
              <text font={t.font.body} size={12} ls={0.16} color={t.color.ink}>
                LICENSING AND USAGE
              </text>
              <h2 font={t.font.head} size={40} lh={1.15} weight={400} color={t.color.ink} mobile={{ size: 28 }}>
                Plain terms, written once, and they do not expire.
              </h2>
              <text font={t.font.body} size={16.5} lh={1.75} color={t.color.grey}>
                Practice licence covers your website, press, and award entries in perpetuity. Developer and
                product-brand usage is quoted separately because it is worth more to you.
              </text>
              <box w="100%" h={1} bg={t.color.hairline} pad={0} />
              <text font={t.font.body} size={15} lh={1.75} color={t.color.grey}>
                Files arrive as full-resolution TIFFs and web-sized JPEGs, colour-managed, with a credit line you are
                asked to carry. Re-touching of construction snags is included; compositing skies is not.
              </text>
            </box>
          </grid>
        </box>
      </section>

      {/* ── 8. Enquiry line and lead time ── */}
      <section cls="enquiry" id="enquiry" bg={t.color.ink} pad={[96, 0]} align="center" w="100%">
        <box cls="wrap" w="100%" maxw={WRAP} center pad={{ l: PAD_X, r: PAD_X }} gap={0} mobile={{ pad: { l: 20, r: 20 } }}>
          <grid cls="enquiry-rail" cols={RAIL} gap={48} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
            <box pad={0} gap={10} align="flex-start">
              <text font={t.font.body} size={12} ls={0.16} color={t.color.ground}>
                ENQUIRY
              </text>
              <text font={t.font.body} size={13.5} lh={1.6} color={t.color.grey} maxw={220}>
                Send the address, the practice, and the deadline. That is enough to quote.
              </text>
            </box>
            <box pad={0} gap={28} align="flex-start" w="100%">
              <h2 font={t.font.head} size={48} lh={1.1} weight={400} color={t.color.ground} maxw={720} tablet={{ size: 38 }} mobile={{ size: 30 }}>
                Currently booking eleven weeks out. Two emergency slots held each month for award deadlines.
              </h2>
              <text
                href="mailto:studio@aversframe.com"
                font={t.font.body}
                size={14}
                ls={0.1}
                color={t.color.ink}
                bg={t.color.ground}
                pad={[16, 28]}
                w="hug"
                hover={{ bg: t.color.accent, color: t.color.ground }}
                tw="cursor-pointer"
              >
                CHECK AVAILABILITY
              </text>
              <box w="100%" h={1} bg="#2A2A2A" pad={0} />
              <row w="100%" justify="space-between" gap={20} wrap>
                <text font={t.font.body} size={14} lh={1.7} color={t.color.grey}>
                  studio@aversframe.com · +351 912 004 118
                </text>
                <text font={t.font.body} size={14} lh={1.7} color={t.color.grey}>
                  Avers Frame · Rua da Boavista, Lisbon
                </text>
              </row>
            </box>
          </grid>
        </box>
      </section>
    </Page>
  );
}
