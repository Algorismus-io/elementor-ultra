/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "editionable--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'editionable--';

export default [
  { slot: `${PREFIX}artist_studio`, file: join(MEDIA_DIR, "artist_studio.jpg"), alt: "An artist at work in a daylit studio, prints drying on the wall" },
  { slot: `${PREFIX}gallery_wall`, file: join(MEDIA_DIR, "gallery_wall.jpg"), alt: "A hung gallery wall of framed editions at mixed scale" },
  { slot: `${PREFIX}print_macro`, file: join(MEDIA_DIR, "print_macro.jpg"), alt: "Macro detail of a giclée print showing paper grain and ink" },
];
