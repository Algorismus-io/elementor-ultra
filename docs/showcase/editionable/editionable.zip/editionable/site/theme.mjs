/** Editionable — design tokens. */
export default defineTheme({
  name: 'editionable',
  color: {
    ground: '#FAF7F4',
    ink: '#161412',
    accent: '#7B3FE4',
    warm: '#E8B04B',
    rule: '#DDD6CF',
    muted: '#6B635C',
    paper: '#FFFFFF',
    shade: '#F1EBE4',
  },
  font: { head: 'Italiana', body: 'Jost' },
  mode: 'literal',
});
