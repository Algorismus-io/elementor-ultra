export default { name: 'casa-ocotillo' };
