/**
 * Repeating content rows. Elementor components can only override SETTINGS, so every
 * visual decision is baked here and only copy arrives as props.
 */
import { defineComponent } from 'elementor-jsx';
import theme from '../theme.mjs';

const c = theme.color;

/** One room type: name, honest size, and the one thing worth knowing about it. */
export const RoomLine = defineComponent(
  ({ name = 'Room', size = '', note = '' }) => (
    <box cls="room-line" dir="column" gap={10} w="100%" pad={{ t: 26, b: 26 }}>
      <box h={1} w="100%" bg="rgba(51,42,34,0.18)" m={{ b: 16 }} />
      <box dir="row" justify="space-between" align="flex-end" gap={16} w="100%" wrap>
        <h3 size={27} weight={400} font={theme.font.head} color={c.ink} lh={1.2} mobile={{ size: 23 }}>
          {name}
        </h3>
        <text size={13} weight={600} ls={0.12} font={theme.font.body} color={c.adobe}>
          {size}
        </text>
      </box>
      <text size={16} font={theme.font.body} color="rgba(51,42,34,0.72)" lh={1.7} maxw={480} mobile={{ size: 15 }}>
        {note}
      </text>
    </box>
  ),
  {
    title: 'Room line',
    props: {
      name: { label: 'Room name', group: 'Room' },
      size: { label: 'Size', group: 'Room' },
      note: { label: 'Note', group: 'Room' },
    },
  },
);

/** One season on the rate card. */
export const RateLine = defineComponent(
  ({ season = 'Season', months = '', price = '', stay = '' }) => (
    <box cls="rate-line" dir="column" gap={12} w="100%" pad={{ t: 30, b: 30, l: 28, r: 28 }} bg="rgba(237,227,214,0.05)" radius={2}>
      <text size={12} weight={600} ls={0.16} font={theme.font.body} color={c.adobe}>
        {months}
      </text>
      <h3 size={24} weight={400} font={theme.font.head} color={c.ground} lh={1.25}>
        {season}
      </h3>
      <text size={38} weight={400} font={theme.font.head} color={c.ground} lh={1.1} mobile={{ size: 32 }}>
        {price}
      </text>
      <text size={14} font={theme.font.body} color="rgba(237,227,214,0.6)" lh={1.6}>
        {stay}
      </text>
    </box>
  ),
  {
    title: 'Rate line',
    props: {
      season: { label: 'Season', group: 'Rate' },
      months: { label: 'Months', group: 'Rate' },
      price: { label: 'Price', group: 'Rate' },
      stay: { label: 'Minimum stay', group: 'Rate' },
    },
  },
);

/** A single line in the there-is / there-is-not columns. */
export const PlainLine = defineComponent(
  ({ label = '' }) => (
    <box cls="plain-line" dir="row" gap={14} align="flex-start" w="100%" pad={{ t: 12, b: 12 }}>
      <text size={13} font={theme.font.body} color={c.adobe} w="14px">
        —
      </text>
      <text size={17} font={theme.font.body} color={c.ink} lh={1.6} flex={1} mobile={{ size: 16 }}>
        {label}
      </text>
    </box>
  ),
  { title: 'Plain line', props: { label: { label: 'Text', group: 'Line' } } },
);

/** One leg of the journey in. */
export const StepLine = defineComponent(
  ({ num = '01', label = '', note = '' }) => (
    <box cls="step-line" dir="row" gap={22} w="100%" pad={{ t: 22, b: 22 }} align="flex-start">
      <text size={13} weight={600} ls={0.12} font={theme.font.body} color={c.cactus} w="34px">
        {num}
      </text>
      <box dir="column" gap={6} flex={1}>
        <h3 size={20} weight={400} font={theme.font.head} color={c.ground} lh={1.3}>
          {label}
        </h3>
        <text size={15} font={theme.font.body} color="rgba(237,227,214,0.62)" lh={1.7}>
          {note}
        </text>
      </box>
    </box>
  ),
  {
    title: 'Step line',
    props: {
      num: { label: 'Number', group: 'Step' },
      label: { label: 'Label', group: 'Step' },
      note: { label: 'Note', group: 'Step' },
    },
  },
);
