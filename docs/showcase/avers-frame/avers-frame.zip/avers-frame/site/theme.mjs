/** Avers Frame — design tokens. */
export default defineTheme({
  name: 'avers-frame',
  color: {
    ground: '#FFFFFF',
    ink: '#101010',
    grey: '#8A8A8A',
    hairline: '#E4E4E4',
    accent: '#1F3BFF',
  },
  font: { head: 'Cormorant Garamond', body: 'Jost' },
  mode: 'literal',
});
