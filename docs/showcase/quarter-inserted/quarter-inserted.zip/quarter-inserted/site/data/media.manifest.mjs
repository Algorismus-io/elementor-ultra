/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "quarter-inserted--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'quarter-inserted--';

export default [
  { slot: `${PREFIX}arcade_floor`, file: join(MEDIA_DIR, "arcade_floor.jpg"), alt: "Rows of lit arcade cabinets on the Quarter Inserted floor" },
  { slot: `${PREFIX}bar_pour`, file: join(MEDIA_DIR, "bar_pour.jpg"), alt: "A pint being poured behind the Quarter Inserted bar" },
  { slot: `${PREFIX}pinball_hands`, file: join(MEDIA_DIR, "pinball_hands.jpg"), alt: "Hands on the flipper buttons of a pinball table" },
];
