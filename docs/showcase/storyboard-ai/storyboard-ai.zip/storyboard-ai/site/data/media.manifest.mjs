/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "storyboard-ai--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'storyboard-ai--';

export default [
  { slot: `${PREFIX}board_wall`, file: join(MEDIA_DIR, "board_wall.jpg"), alt: "A wall of pinned storyboard panels in a production office" },
  { slot: `${PREFIX}director_desk`, file: join(MEDIA_DIR, "director_desk.jpg"), alt: "A director’s desk with a marked-up script and boards" },
];
