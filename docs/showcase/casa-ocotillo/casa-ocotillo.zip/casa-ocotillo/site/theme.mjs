/** Casa Ocotillo — design tokens. Every page receives these as `theme`. */
export default defineTheme({
  name: 'casa-ocotillo',
  color: {
    ground: '#EDE3D6',
    ink: '#332A22',
    adobe: '#C0764A',
    cactus: '#5B6E52',
    shade: '#1E1A17',
    white: '#FFFFFF',
  },
  font: { head: 'Marcellus', body: 'Mulish' },
  mode: 'literal',
});
