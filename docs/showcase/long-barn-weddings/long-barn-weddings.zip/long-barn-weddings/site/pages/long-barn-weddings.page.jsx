/**
 * The Long Barn — dry-hire wedding venue.
 * Structural archetype: a TIMELINE SPINE. A hairline rail with dotted beats runs down
 * the weekend hour by hour, and the closing CTA hangs off the same rail so the page
 * reads as one continuous Friday-to-Sunday rather than a stack of blocks.
 */
import { MEDIA as media } from '../data/media.mjs';
import tokens from '../theme.mjs';

export const meta = {
  title: 'The Long Barn',
  slug: 'long-barn-weddings',
  seo: {
    title: 'The Long Barn — a dry-hire barn for the whole weekend',
    description:
      'A restored 17th century threshing barn, twelve acres and a farmhouse that sleeps 22, hired dry from Friday lunchtime until Sunday breakfast. 140 seated. No in-house catering, no commission.',
  },
};

const IMG = media.barn_interior.id;
const FARMHOUSE = media.farmhouse_morning.id;
const MEADOW = media.meadow_ceremony.id;

const RULE_ON_DARK = 'rgba(248,244,237,0.22)';
const TEXT_ON_INK = '#CFC7B8';
const TEXT_ON_MOSS = '#DCE3CC';

/* ── data ───────────────────────────────────────────────────────────────── */

const WEEKEND = [
  {
    time: 'Friday · 2pm',
    title: 'The keys, and an empty barn',
    body: 'Friday 2pm: the keys, the barn empty and swept, and eight hours to make it yours. Nobody stands over you with a schedule. The caretaker shows you the fuse board, the water, and the switch nobody can ever find, then leaves you to it.',
  },
  {
    time: 'Friday · 9pm',
    title: 'Pizza on the floor',
    body: 'Most couples eat pizza on the floor at nine and it is usually the best bit of the weekend. Half the table has driven three hours. Nobody is dressed. Somebody has already put the lights up twice.',
  },
  {
    time: 'Saturday · 1pm',
    title: 'Ceremony, inside or in the meadow',
    body: 'Saturday: ceremony inside or in the meadow, drinks in the yard, long tables the length of the barn, and a licence until 1am with amplified music until midnight.',
  },
  {
    time: 'Saturday · 3pm',
    title: 'Drinks in the yard',
    body: 'Cobbles, a low wall everyone ends up sitting on, and twelve acres for people to wander into. If the weather turns, the barn doors are eight feet wide and the whole thing moves inside in about four minutes.',
  },
  {
    time: 'Saturday · 6pm',
    title: 'Long tables, the length of the barn',
    body: 'Fourteen trestles end to end under the trusses. Your caterer serves from the yard end and the band builds at the other, so nothing has to be shifted between courses.',
  },
  {
    time: 'Saturday · midnight',
    title: 'Amplified music off, licence until one',
    body: 'The band stops at twelve and the bar runs to one. The last hour is nearly always the quiet one — in the yard, doors open, somebody making tea for eleven people.',
  },
  {
    time: 'Sunday · 9am',
    title: 'Breakfast in the farmhouse',
    body: 'Sunday: breakfast in the farmhouse, a slow clear-up, out by eleven. We do not chase you at nine with a clipboard.',
  },
  {
    time: 'Sunday · 11am',
    title: 'Out by eleven',
    body: 'Bins are ours, bottles are yours, and the field will still be there. Most people leave later than they planned and we have never once minded.',
  },
];

const INCLUDED = [
  'The barn, swept and empty',
  'The yard and the twelve acres',
  '140 chairs',
  '14 trestle tables',
  'The farmhouse, sleeping 22',
  'Parking for 70 cars',
  'A caretaker on site all weekend',
  'Heat, power, water and the prep kitchen',
];

const NOT_INCLUDED = [
  'Catering — you bring your own',
  'A bar, and anybody to run it',
  'Glassware, crockery and cutlery',
  'Linen and napkins',
  'Anything with an unenclosed flame',
  'A marquee — you will not need one',
];

const CATERERS = [
  ['Hollow & Vine', 'Long-table feasting, most of it off one fire in the yard.'],
  ["The Wheelwright's Kitchen", 'Proper British, three courses, plated, no foam.'],
  ['Saltbox', 'Mediterranean sharing plates and genuinely very good bread.'],
  ['Ferment', 'Entirely vegetarian, and the only one that has converted a father-in-law.'],
  ['Ridgeway Wood-Fired', 'Pizza on the Friday, hog on the Saturday, one van for both.'],
  ['Marsh & Daughter', 'Canapés and a wedding breakfast that actually runs to time.'],
];

const SEASONS = [
  { months: 'March to May', price: '6,400', note: 'Cold mornings, long light by seven, and the meadow at its best in the second week of May.' },
  { months: 'June to September', price: '9,800', note: 'The busy half. Saturdays in June and September go eighteen months out; August rarely does.' },
  { months: 'October to February', price: '4,900', note: 'Candles at four in the afternoon and a barn warmer than most houses. Our own favourite.' },
];

const COUPLES = [
  ['Nadia & Tom', '112 guests · June', 'A ceilidh, a curry, and a barn wedding they had been told would need a marquee. It did not.'],
  ['Ellie & Priya', '138 guests · September', 'The full length of the barn at long tables. Two caterers, two families, one lunch that ran until five.'],
  ['Sam & Jo', '94 guests · February', 'Candles down the trusses from four in the afternoon, hot toddies in the yard, everyone home by ten.'],
  ['Rosie & Will', '126 guests · May', 'A meadow ceremony that moved indoors at eleven in the morning. It rained for forty minutes and the photographs are better for it.'],
  ['Aisha & Dan', '90 guests · August', 'A Friday wedding. They saved 1,200, kept the barn until Sunday, and spent Saturday in the field with the leftovers.'],
  ['Marta & Ines', '134 guests · October', 'Three courses, a brass band, and a first dance at eleven that everybody had given up waiting for.'],
];

/* ── primitives (plain functions → inline expansion, styles allowed) ─────── */

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 700 };

/** The spine rail: a dot on the beat, a hairline running on to the next one. */
const Rail = ({ dot, line }) => (
  <div cls="spine-rail" tw="flex flex-col items-center w-[20px] shrink-0 max-md:w-[16px]">
    <div cls="spine-dot" tw="w-[9px] h-[9px] rounded-full mt-[15px] shrink-0" bg={dot || tokens.color.ink} />
    <div cls="spine-line" tw="w-[1px] flex-1 mt-[7px]" bg={line || tokens.color.rule} minh={28} />
  </div>
);

/** A ruled list line — square marker, hairline above, one line of copy. */
const Item = ({ children, marker, tone, rule }) => (
  <row
    cls="ruled-item"
    tw="flex flex-row items-start gap-4 w-full pt-3 pb-3"
    raw={`border-top: 1px solid ${rule || tokens.lit.rule};`}
  >
    <div cls="item-mark" tw="w-[6px] h-[6px] mt-[10px] shrink-0" bg={marker} />
    <text size={18} font={tokens.font.body} color={tone || tokens.color.ink} lh={1.5} tw="flex-1">
      {children}
    </text>
  </row>
);

/** The small all-caps tag that opens every band. */
const Tag = ({ children, tone }) => (
  <text size={26} font={tokens.font.head} weight={700} color={tone || tokens.color.meadow} tw="uppercase tracking-[0.12em]">
    {children}
  </text>
);

/* ── registered components (repeaters — CONTENT props only) ─────────────── */

const TimelineBeat = defineComponent(
  ({ time, title, body }) => (
    <row cls="beat" tw="flex flex-row items-stretch gap-8 w-full max-md:gap-5">
      <Rail />
      <div cls="beat-body" tw="flex flex-col gap-2 flex-1 pb-14 max-md:pb-10">
        <text size={30} font={tokens.font.head} weight={700} color={tokens.color.meadow} tw="uppercase tracking-[0.1em] leading-tight">
          {time}
        </text>
        <h3 size={44} font={tokens.font.head} weight={700} color={tokens.color.ink} lh={1.05} tw="max-md:text-[34px]">
          {title}
        </h3>
        <text size={19} font={tokens.font.body} color={tokens.color.ink} lh={1.62} maxw={620}>
          {body}
        </text>
      </div>
    </row>
  ),
  {
    title: 'Timeline beat',
    props: {
      time: { label: 'Time', group: 'Beat' },
      title: { label: 'Headline', group: 'Beat' },
      body: { label: 'Copy', group: 'Beat' },
    },
  },
);

const SeasonRow = defineComponent(
  ({ months, price, note }) => (
    <row
            tw="flex flex-row items-end gap-8 w-full pt-7 pb-7 max-md:flex-col max-md:items-start max-md:gap-3"
      raw={`border-top: 1px solid ${RULE_ON_DARK};`}
    >
      <text size={34} font={tokens.font.head} weight={700} color={tokens.color.ground} tw="uppercase tracking-[0.06em] w-[250px] shrink-0 max-md:w-full">
        {months}
      </text>
      <text size={64} font={tokens.font.head} weight={700} color={tokens.color.ground} lh={1} tw="w-[190px] shrink-0 max-md:w-full max-md:text-[52px]">
        {price}
      </text>
      <text size={17} font={tokens.font.body} color={TEXT_ON_MOSS} lh={1.6} tw="flex-1">
        {note}
      </text>
    </row>
  ),
  {
    title: 'Season price row',
    props: {
      months: { label: 'Months', group: 'Season' },
      price: { label: 'Price', group: 'Season' },
      note: { label: 'Note', group: 'Season' },
    },
  },
);

const CoupleCard = defineComponent(
  ({ names, facts, story }) => (
    <div
      cls="couple"
      tw="flex flex-col gap-3 w-full pt-6 pb-7 pl-6 pr-6"
      raw={`border-left: 1px solid ${tokens.lit.rule};`}
      hover={{ bg: '#FCFAF6', raw: `border-left: 1px solid ${tokens.lit.meadow};` }}
    >
      <text size={19} font={tokens.font.body} color={tokens.color.stone} tw="uppercase tracking-[0.1em]">
        {facts}
      </text>
      <h3 size={40} font={tokens.font.head} weight={700} color={tokens.color.ink} lh={1.05}>
        {names}
      </h3>
      <text size={18} font={tokens.font.body} color={tokens.color.ink} lh={1.6}>
        {story}
      </text>
    </div>
  ),
  {
    title: 'Couple vignette',
    props: {
      names: { label: 'Names', group: 'Couple' },
      facts: { label: 'Guests & month', group: 'Couple' },
      story: { label: 'The wedding', group: 'Couple' },
    },
  },
);

/* ── page ───────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
    {/* ── HERO — asymmetric; the weekend starts here ── */}
    <section cls="band" tw="flex flex-col w-full items-center pt-10 pb-24 pl-8 pr-8 max-md:pt-8 max-md:pb-14 max-md:pl-5 max-md:pr-5">
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px] gap-14 max-md:gap-9">
        <row
          tw="flex flex-row items-end justify-between w-full gap-6 pb-6"
          raw={`border-bottom: 1px solid ${t.lit.rule};`}
        >
          <text size={30} font={t.font.head} weight={700} color={t.color.ink} tw="uppercase tracking-[0.18em]">
            The Long Barn
          </text>
          <text size={16} font={t.font.body} color={t.color.stone} tw="uppercase tracking-[0.14em] max-md:text-[13px]">
            Dry hire · Wiltshire
          </text>
        </row>

        <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 32 }}>
          <div span={7} tw="flex flex-col gap-7 max-lg:col-span-12">
            <Tag>The whole weekend, not a slot</Tag>
            <h1 size={104} font={t.font.head} weight={700} color={t.color.ink} lh={0.94} maxw={720} tw="max-lg:text-[78px] max-md:text-[54px]">
              You get it from Friday lunchtime until Sunday breakfast.
            </h1>
            <text size={22} font={t.font.body} color={t.color.ink} lh={1.6} maxw={620} tw="max-md:text-[19px]">
              A 17th century threshing barn, twelve acres, and a farmhouse that sleeps 22, hired dry for the whole weekend. You bring the caterer, the drink and the music. We bring the building and get out of the way.
            </text>
            <row tw="flex flex-row items-center gap-7 flex-wrap pt-2">
              <text
                href="#book-a-viewing"
                cls="cta"
                size={22}
                font={t.font.body}
                color={t.color.ground}
                bg={t.color.ink}
                tw="pt-4 pb-4 pl-9 pr-9 rounded-full no-underline cursor-pointer"
                hover={{ bg: t.lit.meadow }}
              >
                Book a viewing
              </text>
              <text size={17} font={t.font.body} color={t.color.stone} lh={1.5} maxw={250}>
                Tuesday and Thursday mornings, and one Saturday a month.
              </text>
            </row>
          </div>

          <div span={5} tw="flex flex-col gap-3 max-lg:col-span-12">
            <img src={IMG} tw="w-full h-[520px] object-cover max-lg:h-[380px] max-md:h-[250px]" radius={2} />
            <text size={15} font={t.font.body} color={t.color.stone} lh={1.5} tw="uppercase tracking-[0.08em]">
              34m of oak truss, 140 down the middle
            </text>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 1. THE WEEKEND TIMELINE — the spine ── */}
    <section cls="band" tw="flex flex-col w-full items-center pt-24 pb-10 pl-8 pr-8 max-md:pt-14 max-md:pl-5 max-md:pr-5" bg={t.color.parchment}>
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px]">
        <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 28 }}>
          <div cls="band-head" span={4} tw="flex flex-col gap-5 max-lg:col-span-12">
            <Tag>Section one · the weekend</Tag>
            <h2 size={62} font={t.font.head} weight={700} color={t.color.ink} lh={1} motion={FADE} tw="max-md:text-[46px]">
              Forty-five hours, in order.
            </h2>
            <text size={18} font={t.font.body} color={t.color.stone} lh={1.6} maxw={330}>
              Friday 2pm to Sunday 11am. This is the whole thing, hour by hour, with nothing quietly left off it.
            </text>
          </div>

          <div span={8} tw="flex flex-col w-full max-lg:col-span-12">
            {WEEKEND.slice(0, 3).map((b) => (
              <TimelineBeat time={b.time} title={b.title} body={b.body} />
            ))}

            <row cls="beat" tw="flex flex-row items-stretch gap-8 w-full max-md:gap-5">
              <Rail dot={t.color.rose} />
              <div tw="flex flex-col gap-3 flex-1 pb-14 max-md:pb-10">
                <img src={MEADOW} tw="w-full h-[340px] object-cover max-md:h-[210px]" radius={2} motion={FADE} />
                <text size={15} font={t.font.body} color={t.color.stone} tw="uppercase tracking-[0.08em]">
                  The meadow — ceremony at one, if the sky allows
                </text>
              </div>
            </row>

            {WEEKEND.slice(3, 7).map((b) => (
              <TimelineBeat time={b.time} title={b.title} body={b.body} />
            ))}

            <row cls="beat" tw="flex flex-row items-stretch gap-8 w-full max-md:gap-5">
              <Rail dot={t.color.rose} />
              <div tw="flex flex-col gap-3 flex-1 pb-14 max-md:pb-10">
                <img src={FARMHOUSE} tw="w-full h-[340px] object-cover max-md:h-[210px]" radius={2} motion={FADE} />
                <text size={15} font={t.font.body} color={t.color.stone} tw="uppercase tracking-[0.08em]">
                  The farmhouse — nine bedrooms, twenty-two beds
                </text>
              </div>
            </row>

            {WEEKEND.slice(7).map((b) => (
              <TimelineBeat time={b.time} title={b.title} body={b.body} />
            ))}
          </div>
        </grid>
      </div>
    </section>

    {/* ── 2. THE BARN — dark band ── */}
    <section cls="band-dark" tw="flex flex-col w-full items-center pt-24 pb-24 pl-8 pr-8 max-md:pt-16 max-md:pb-16 max-md:pl-5 max-md:pr-5" bg={t.color.ink}>
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px] gap-12">
        <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 24 }}>
          <div cls="band-head" span={7} tw="flex flex-col gap-5 max-lg:col-span-12">
            <Tag tone={t.color.rose}>Section two · the building</Tag>
            <h2 size={62} font={t.font.head} weight={700} color={t.color.ground} lh={1} motion={FADE} tw="max-md:text-[44px]">
              Thirty-four metres of barn, and what it does in the rain.
            </h2>
          </div>
          <div cls="lede-col" span={5} tw="flex flex-col justify-end max-lg:col-span-12">
            <text size={19} font={t.font.body} color={TEXT_ON_INK} lh={1.65}>
              Barn is 34m by 11m. 140 seated at long tables, 96 with a dance floor and a band, 180 standing. Fully covered, heated, and it has never once been rained off.
            </text>
          </div>
        </grid>

        <grid cols={4} gap={1} mobile={{ gridCols: 2, gap: 1 }} bg={RULE_ON_DARK}>
          {[
            ['34 × 11', 'metres, wall to wall'],
            ['140', 'seated at long tables'],
            ['96', 'with a floor and a band'],
            ['180', 'standing, doors open'],
          ].map(([n, label]) => (
            <div cls="stat" tw="flex flex-col gap-2 pt-8 pb-8 pl-7 pr-7 max-md:pt-6 max-md:pb-6 max-md:pl-5 max-md:pr-5" bg={t.color.ink}>
              <text size={64} font={t.font.head} weight={700} color={t.color.ground} lh={0.95} tw="max-md:text-[46px]">
                {n}
              </text>
              <text size={16} font={t.font.body} color={t.color.stone} lh={1.4} tw="uppercase tracking-[0.08em]">
                {label}
              </text>
            </div>
          ))}
        </grid>

        <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 24 }}>
          <div span={6} tw="flex flex-col gap-4 max-lg:col-span-12">
            <h3 size={38} font={t.font.head} weight={700} color={t.color.ground} lh={1.05}>
              In the rain
            </h3>
            <text size={19} font={t.font.body} color={TEXT_ON_INK} lh={1.65}>
              Nothing dramatic happens. Two sets of doors close, the heaters go on, the ceremony moves under the trusses, and the light gets better. In eleven years we have moved fourteen ceremonies indoors at short notice, and not one couple has said afterwards that it spoiled the day.
            </text>
          </div>
          <div span={6} tw="flex flex-col gap-4 max-lg:col-span-12">
            <h3 size={38} font={t.font.head} weight={700} color={t.color.ground} lh={1.05}>
              The unglamorous facts
            </h3>
            <text size={19} font={t.font.body} color={TEXT_ON_INK} lh={1.65}>
              The floor is flagstone and oak, level throughout, and it takes a heel. Heating is underfloor at the yard end and three radiant panels at the other. There is a step at the west door and a ramp beside it. The nearest neighbour is 400 metres away, which is why the licence runs to one.
            </text>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 3. INCLUDED / NOT INCLUDED ── */}
    <section cls="band" tw="flex flex-col w-full items-center pt-24 pb-24 pl-8 pr-8 max-md:pt-16 max-md:pb-16 max-md:pl-5 max-md:pr-5">
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px] gap-12">
        <div tw="flex flex-col gap-5 max-w-[780px]">
          <Tag>Section three · the honest list</Tag>
          <h2 size={62} font={t.font.head} weight={700} color={t.color.ink} lh={1} motion={FADE} tw="max-md:text-[44px]">
            What is included, and what genuinely is not.
          </h2>
          <text size={19} font={t.font.body} color={t.color.ink} lh={1.65}>
            Included: the barn, the yard, twelve acres, 140 chairs, 14 trestle tables, the farmhouse, parking, and a caretaker on site all weekend. Not included: catering, bar, glassware, linen, and anything with a flame.
          </text>
        </div>

        <grid cols={12} gap={40} mobile={{ gridCols: 1, gap: 28 }}>
          <div span={6} tw="flex flex-col pt-9 pb-9 pl-9 pr-9 max-lg:col-span-12 max-md:pt-6 max-md:pb-6 max-md:pl-6 max-md:pr-6" bg="#EDF0E3" radius={2}>
            <text size={34} font={t.font.head} weight={700} color={t.color.ink} tw="uppercase tracking-[0.08em] pb-3">
              In the price
            </text>
            {INCLUDED.map((line) => (
              <Item marker={t.color.meadow} rule="#DCE0CE">{line}</Item>
            ))}
          </div>
          <div span={6} tw="flex flex-col pt-9 pb-9 pl-9 pr-9 max-lg:col-span-12 max-md:pt-6 max-md:pb-6 max-md:pl-6 max-md:pr-6" bg="#F4E9E9" radius={2}>
            <text size={34} font={t.font.head} weight={700} color={t.color.ink} tw="uppercase tracking-[0.08em] pb-3">
              Not in the price
            </text>
            {NOT_INCLUDED.map((line) => (
              <Item marker={t.color.rose} rule="#E6D6D6">{line}</Item>
            ))}
            <text size={17} font={t.font.body} color={t.color.stone} lh={1.6} tw="pt-6">
              Dry hire means dry hire. We would rather tell you in a cold February viewing than surprise you in June.
            </text>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 4. CATERERS ── */}
    <section cls="band" tw="flex flex-col w-full items-center pt-24 pb-24 pl-8 pr-8 max-md:pt-16 max-md:pb-16 max-md:pl-5 max-md:pr-5" bg={t.color.linen}>
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px] gap-12">
        <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 24 }}>
          <div cls="band-head" span={5} tw="flex flex-col gap-5 max-lg:col-span-12">
            <Tag>Section four · food</Tag>
            <h2 size={62} font={t.font.head} weight={700} color={t.color.ink} lh={1} motion={FADE} tw="max-md:text-[44px]">
              Six caterers we love. Or bring your own.
            </h2>
          </div>
          <div cls="lede-col" span={7} tw="flex flex-col justify-end max-lg:col-span-12">
            <text size={19} font={t.font.body} color={t.color.ink} lh={1.65}>
              Six caterers we love and trust, or bring your own for a £400 kitchen fee. We do not take commission from any of them and we will say so on the viewing.
            </text>
          </div>
        </grid>

        <grid cols={2} gapX={48} gapY={0} mobile={{ gridCols: 1 }}>
          {CATERERS.map(([name, line]) => (
            <row
              cls="caterer"
              tw="flex flex-row items-start gap-6 w-full pt-6 pb-6 max-md:flex-col max-md:items-start max-md:gap-2"
              raw={`border-top: 1px solid ${t.lit.rule};`}
              hover={{ bg: '#F7F2E7' }}
            >
              <text size={32} font={t.font.head} weight={700} color={t.color.ink} lh={1.1} tw="w-[220px] shrink-0 max-md:w-full">
                {name}
              </text>
              <text size={17} font={t.font.body} color={t.color.stone} lh={1.55} tw="flex-1">
                {line}
              </text>
            </row>
          ))}
        </grid>

        <div
          tw="flex flex-col gap-4 pt-9 pb-9 pl-9 pr-9 max-w-[780px] max-md:pt-6 max-md:pb-6 max-md:pl-6 max-md:pr-6"
          bg={t.color.ground}
          radius={2}
          border={[1, t.lit.rule]}
        >
          <h3 size={38} font={t.font.head} weight={700} color={t.color.ink} lh={1.05}>
            Bringing your own
          </h3>
          <text size={18} font={t.font.body} color={t.color.ink} lh={1.65}>
            The £400 covers the prep kitchen, the water, the power, the waste, and a caretaker who will find them a step ladder at seven on a Saturday morning. We ask for public liability cover and a hygiene rating of four or five. That is the entire list of conditions.
          </text>
        </div>
      </div>
    </section>

    {/* ── 5. SLEEPING 22 ── */}
    <section cls="band" tw="flex flex-col w-full items-center pt-24 pb-24 pl-8 pr-8 max-md:pt-16 max-md:pb-16 max-md:pl-5 max-md:pr-5">
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px]">
        <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 28 }}>
          <div span={5} tw="flex flex-col max-lg:col-span-12">
            <img src={FARMHOUSE} tw="w-full h-[540px] object-cover max-lg:h-[340px] max-md:h-[230px]" radius={2} motion={FADE} />
          </div>
          <div span={7} tw="flex flex-col gap-6 max-lg:col-span-12">
            <Tag>Section five · beds</Tag>
            <h2 size={58} font={t.font.head} weight={700} color={t.color.ink} lh={1} tw="max-md:text-[42px]">
              Twenty-two sleep here. Everybody else is fifteen minutes away.
            </h2>
            <text size={19} font={t.font.body} color={t.color.ink} lh={1.65}>
              Nine bedrooms across the farmhouse and the granary: one with a bath you can lie down in, four doubles, three twins, and a bunk room the children fight over. Twenty-two actual beds — no camp beds, no sofa arrangements, nobody counting the sofa.
            </text>
            <div tw="flex flex-col pt-2">
              <Item marker={t.color.meadow}>The Fleece in the village holds eight rooms for us until six weeks out.</Item>
              <Item marker={t.color.meadow}>Two bed and breakfasts within a mile, both of which will do an early breakfast.</Item>
              <Item marker={t.color.meadow}>A chain hotel twenty minutes out, for the guests who specifically want one.</Item>
              <Item marker={t.color.rose}>Taxis: book them in March, not in June. There are four firms and they all fill.</Item>
            </div>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 6. PRICE ── */}
    <section cls="band-dark" tw="flex flex-col w-full items-center pt-24 pb-24 pl-8 pr-8 max-md:pt-16 max-md:pb-16 max-md:pl-5 max-md:pr-5" bg={t.color.moss}>
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px] gap-11">
        <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 24 }}>
          <div cls="band-head" span={6} tw="flex flex-col gap-5 max-lg:col-span-12">
            <Tag tone={TEXT_ON_MOSS}>Section six · price</Tag>
            <h2 size={62} font={t.font.head} weight={700} color={t.color.ground} lh={1} motion={FADE} tw="max-md:text-[44px]">
              Price by season, and what a Friday saves you.
            </h2>
          </div>
          <div cls="lede-col" span={6} tw="flex flex-col justify-end max-lg:col-span-12">
            <text size={19} font={t.font.body} color={TEXT_ON_MOSS} lh={1.65}>
              March to May 6,400. June to September 9,800. October to February 4,900. Friday weddings are 1,200 less and nobody has ever regretted one.
            </text>
          </div>
        </grid>

        <div tw="flex flex-col w-full">
          {SEASONS.map((s) => (
            <SeasonRow months={s.months} price={s.price} note={s.note} />
          ))}
        </div>

        <grid cols={12} gap={40} mobile={{ gridCols: 1, gap: 24 }}>
          <div
            span={7}
            tw="flex flex-col gap-4 pt-8 pb-8 pl-8 pr-8 max-lg:col-span-12 max-md:pt-6 max-md:pb-6 max-md:pl-6 max-md:pr-6"
            bg="rgba(248,244,237,0.09)"
            radius={2}
          >
            <h3 size={40} font={t.font.head} weight={700} color={t.color.ground} lh={1.05}>
              A Friday is 1,200 less
            </h3>
            <text size={18} font={t.font.body} color={TEXT_ON_MOSS} lh={1.65}>
              Same barn, same forty-five hours, same Sunday breakfast — it simply starts on the Thursday afternoon instead. The guests travelling any distance were taking the Friday off anyway. Nobody has ever regretted one.
            </text>
          </div>
          <div span={5} tw="flex flex-col gap-4 justify-center max-lg:col-span-12">
            <text size={18} font={t.font.body} color={TEXT_ON_MOSS} lh={1.65}>
              Every price is the whole weekend, Friday 2pm to Sunday 11am, VAT included. No per-head charge, no corkage, and no commission on anything you book yourselves.
            </text>
            <text size={18} font={t.font.body} color={t.color.ground} lh={1.6}>
              <strong>We hold a date for seven days, free, while you think about it.</strong>
            </text>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 7. SIX COUPLES ── */}
    <section cls="band" tw="flex flex-col w-full items-center pt-24 pb-24 pl-8 pr-8 max-md:pt-16 max-md:pb-16 max-md:pl-5 max-md:pr-5">
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px] gap-12">
        <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 20 }}>
          <div cls="band-head" span={7} tw="flex flex-col gap-5 max-lg:col-span-12">
            <Tag>Section seven · six weekends</Tag>
            <h2 size={62} font={t.font.head} weight={700} color={t.color.ink} lh={1} motion={FADE} tw="max-md:text-[44px]">
              Six couples. Six very different weddings.
            </h2>
          </div>
          <div cls="lede-col" span={5} tw="flex flex-col justify-end max-lg:col-span-12">
            <text size={18} font={t.font.body} color={t.color.stone} lh={1.65}>
              Same building, same forty-five hours. This is what people have actually done with it.
            </text>
          </div>
        </grid>

        <grid cols={3} gap={32} mobile={{ gridCols: 1, gap: 20 }}>
          {COUPLES.map(([names, facts, story]) => (
            <CoupleCard names={names} facts={facts} story={story} />
          ))}
        </grid>
      </div>
    </section>

    {/* ── 8. BOOK A VIEWING — the spine's last beat ── */}
    <section
      id="book-a-viewing"
      cls="band-dark"
      tw="flex flex-col w-full items-center pt-24 pb-24 pl-8 pr-8 max-md:pt-16 max-md:pb-16 max-md:pl-5 max-md:pr-5"
      bg={t.color.ink}
    >
      <div cls="wrap" tw="flex flex-col w-full max-w-[1180px]">
        <row tw="flex flex-row items-stretch gap-8 w-full max-md:gap-5">
          <Rail dot={t.color.rose} line={RULE_ON_DARK} />

          <grid cols={12} gap={56} mobile={{ gridCols: 1, gap: 28 }} tw="flex-1">
            <div span={7} tw="flex flex-col gap-6 max-lg:col-span-12">
              <Tag tone={t.color.rose}>Section eight · come and see it</Tag>
              <h2 size={76} font={t.font.head} weight={700} color={t.color.ground} lh={0.98} tw="max-md:text-[50px]">
                Book a viewing.
              </h2>
              <text size={20} font={t.font.body} color={TEXT_ON_INK} lh={1.65} maxw={600}>
                Viewings take an hour. We walk the weekend in the order it happens — the barn empty on the Friday, the meadow, the yard, the long tables, the farmhouse, the Sunday kitchen — and we will tell you on the day whether your date is free. Bring the person who asks the awkward questions.
              </text>
              <row tw="flex flex-row items-center gap-6 flex-wrap pt-2">
                <text
                  href="mailto:viewings@thelongbarn.co.uk"
                  cls="cta"
                  size={22}
                  font={t.font.body}
                  color={t.color.ink}
                  bg={t.color.ground}
                  tw="pt-4 pb-4 pl-9 pr-9 rounded-full no-underline cursor-pointer"
                  hover={{ bg: t.lit.rose }}
                >
                  Book a viewing
                </text>
                <text href="tel:+441672500163" size={19} font={t.font.body} color={TEXT_ON_INK} tw="no-underline" hover={{ color: '#F8F4ED' }}>
                  01672 500163
                </text>
              </row>
            </div>

            <div span={5} tw="flex flex-col max-lg:col-span-12">
              <Item marker={t.color.rose} tone={TEXT_ON_INK} rule={RULE_ON_DARK}>Tuesday and Thursday, 10am and 11.30am.</Item>
              <Item marker={t.color.rose} tone={TEXT_ON_INK} rule={RULE_ON_DARK}>One Saturday a month, when the barn is empty.</Item>
              <Item marker={t.color.rose} tone={TEXT_ON_INK} rule={RULE_ON_DARK}>viewings@thelongbarn.co.uk — answered within a day.</Item>
              <Item marker={t.color.rose} tone={TEXT_ON_INK} rule={RULE_ON_DARK}>The Long Barn, Yatesbury Lane, Wiltshire SN11 8YB.</Item>
              <text size={17} font={t.font.body} color={t.color.stone} lh={1.6} tw="pt-6">
                We take one wedding a weekend and about thirty a year. If your date has gone we will say so in the first email rather than the third.
              </text>
            </div>
          </grid>
        </row>
      </div>
    </section>
  </box>
);
