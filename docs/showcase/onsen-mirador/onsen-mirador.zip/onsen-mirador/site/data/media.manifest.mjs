/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "onsen-mirador--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'onsen-mirador--';

export default [
  { slot: `${PREFIX}onsen_steam_pool`, file: join(MEDIA_DIR, "steam_pool.jpg"), alt: "Steam rising off the surface of a geothermal pool cut into basalt" },
  { slot: `${PREFIX}onsen_cold_well`, file: join(MEDIA_DIR, "cold_well.jpg"), alt: "The cold well, a small dark plunge pool at six degrees" },
  { slot: `${PREFIX}onsen_long_pool`, file: join(MEDIA_DIR, "long_pool.jpg"), alt: "The long pool, twenty-eight metres open to the sky" },
];
