export default { name: 'hana-sekigawa' };
