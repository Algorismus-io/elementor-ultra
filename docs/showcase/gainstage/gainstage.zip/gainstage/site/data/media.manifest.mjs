/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "gainstage--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'gainstage--';

export default [
  { slot: `${PREFIX}host_recording`, file: join(MEDIA_DIR, "host_recording.jpg"), alt: "Podcast host recording an episode at a microphone" },
  { slot: `${PREFIX}studio_desk`, file: join(MEDIA_DIR, "studio_desk.jpg"), alt: "Home studio desk with audio interface and headphones" },
];
