import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Backhaul — stop driving empty',
  slug: 'backhaul-freight',
  seo: {
    title: 'Backhaul — stop driving 140 empty miles home',
    description:
      'Backhaul matches empty return legs with loads going the same way. Rate shown before you tap, paid three working days after POD upload.',
  },
};

/* ── shared style constants ────────────────────────────────────────────────── */
const C = {
  ground: '#101418',
  tile: '#182029',
  ink: '#E8EDF2',
  road: '#F5A623',
  go: '#38C172',
  line: '#26313C',
};
const DIM = '#8FA0B0';
const HEAD = 'Antonio';
const BODY = 'Manrope';

const TILE = {
  bg: C.tile,
  radius: 14,
  border: [1, C.line],
  pad: 28,
  gap: 12,
  shadow: [
    [1, 0, 0, '#000000', 0],
    [24, 48, -24, 'rgba(0,0,0,0.55)', 0],
  ],
};

const RISE = { effect: 'fade', trigger: 'scrollIn', duration: 520 };

/* ── small repeaters (content props only) ──────────────────────────────────── */
const StatTile = defineComponent(
  ({ label, value, unit, body }) => (
    <box {...TILE} tw="flex flex-col justify-between hover:border-[#F5A623]" minh={230} motion={RISE}>
      <text size={12} weight={700} ls={0.14} font={BODY} color={DIM} tag="span">
        {label}
      </text>
      <box tw="flex flex-row items-end" gap={6} pad={{ t: 8 }}>
        <text tag="span" size={62} weight={700} lh={0.9} ls={-0.02} font={HEAD} color={C.road} mobile={{ size: 48 }}>
          {value}
        </text>
        <text size={15} weight={600} font={BODY} color={DIM} tag="span">
          {unit}
        </text>
      </box>
      <text size={14} lh={1.6} font={BODY} color={C.ink} pad={{ t: 8 }}>
        {body}
      </text>
    </box>
  ),
  {
    title: 'Backhaul stat tile',
    props: {
      label: { label: 'Label', group: 'Content' },
      value: { label: 'Big number', group: 'Content' },
      unit: { label: 'Unit', group: 'Content' },
      body: { label: 'Body copy', group: 'Content' },
    },
  },
);

const Step = defineComponent(
  ({ n, title, body }) => (
    <box bg={C.tile} radius={14} border={[1, C.line]} pad={24} gap={10} tw="flex flex-col hover:bg-[#1E2833]" minh={200} motion={RISE}>
      <text tag="span" size={34} weight={700} lh={1} font={HEAD} color={C.road}>
        {n}
      </text>
      <heading tag="h3" size={19} weight={600} lh={1.2} font={HEAD} color={C.ink}>
        {title}
      </heading>
      <text size={14} lh={1.65} font={BODY} color={DIM}>
        {body}
      </text>
    </box>
  ),
  {
    title: 'Backhaul step',
    props: {
      n: { label: 'Number', group: 'Content' },
      title: { label: 'Title', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
    },
  },
);

const CheckRow = defineComponent(
  ({ title, body }) => (
    <box tw="flex flex-row" gap={14} pad={{ t: 16, b: 16 }} raw="& { border-bottom: 1px solid #26313C; }">
      <box bg="rgba(56,193,114,0.14)" radius={999} w={30} h={30} tw="flex flex-col items-center justify-center" minh={30}>
        <text size={14} weight={700} font={BODY} color={C.go} tag="span">
          ✓
        </text>
      </box>
      <box tw="flex flex-col" gap={4} flex={1}>
        <heading tag="h3" size={16} weight={600} font={HEAD} color={C.ink} lh={1.25}>
          {title}
        </heading>
        <text size={14} lh={1.6} font={BODY} color={DIM}>
          {body}
        </text>
      </box>
    </box>
  ),
  {
    title: 'Backhaul check row',
    props: { title: { label: 'Title', group: 'Content' }, body: { label: 'Body', group: 'Content' } },
  },
);

const DocChip = defineComponent(
  ({ name, meta: metaLine }) => (
    <box bg={C.ground} radius={10} border={[1, C.line]} pad={18} gap={6} tw="flex flex-col hover:border-[#38C172]" minh={110}>
      <text tag="span" size={16} weight={700} ls={0.06} font={HEAD} color={C.ink}>
        {name}
      </text>
      <text size={13} lh={1.5} font={BODY} color={DIM}>
        {metaLine}
      </text>
    </box>
  ),
  {
    title: 'Backhaul document chip',
    props: { name: { label: 'Name', group: 'Content' }, meta: { label: 'Meta line', group: 'Content' } },
  },
);

const VehicleRow = defineComponent(
  ({ reg, body, status }) => (
    <box tw="flex flex-row items-center justify-between" gap={16} pad={{ t: 14, b: 14 }} raw="& { border-bottom: 1px solid #26313C; }">
      <box tw="flex flex-col" gap={3}>
        <text tag="span" size={17} weight={700} ls={0.06} font={HEAD} color={C.ink}>
          {reg}
        </text>
        <text size={13} font={BODY} color={DIM}>
          {body}
        </text>
      </box>
      <text size={12} weight={700} ls={0.08} font={BODY} color={C.go} tag="span">
        {status}
      </text>
    </box>
  ),
  {
    title: 'Backhaul vehicle row',
    props: {
      reg: { label: 'Registration', group: 'Content' },
      body: { label: 'Lane / driver', group: 'Content' },
      status: { label: 'Status', group: 'Content' },
    },
  },
);

/* ── page ──────────────────────────────────────────────────────────────────── */
const Eyebrow = ({ children, tone = C.road }) => (
  <text size={12} weight={700} ls={0.16} font={BODY} color={tone} tag="span">
    {children}
  </text>
);

const Wrap = ({ children, bg, pt = 96, pb = 96, id }) => (
  <section bg={bg} id={id} tw="flex flex-col items-center w-full" pad={{ t: pt, b: pb, l: 24, r: 24 }} mobile={{ pad: { t: 56, b: 56, l: 18, r: 18 } }}>
    <box tw="flex flex-col w-full" maxw={1180} gap={28}>
      {children}
    </box>
  </section>
);

export default () => (
  <box tw="flex flex-col w-full" bg={C.ground} pad={0}>
    {/* ── 1. Bento hero ─────────────────────────────────────────────── */}
    <section bg={C.ground} tw="flex flex-col items-center w-full" pad={{ t: 28, b: 88, l: 24, r: 24 }} mobile={{ pad: { t: 20, b: 56, l: 18, r: 18 } }}>
      <box tw="flex flex-col w-full" maxw={1180} gap={26}>
        <box tw="flex flex-row items-center justify-between w-full" gap={16} pad={{ b: 10 }} raw="& { border-bottom: 1px solid #26313C; }">
          <text tag="span" size={26} weight={700} ls={0.08} font={HEAD} color={C.ink}>
            BACKHAUL
          </text>
          <text size={12} weight={600} ls={0.1} font={BODY} color={DIM} tag="span" mobile={{ size: 10 }}>
            2,400 VEHICLES · UK &amp; IRELAND
          </text>
        </box>

        <grid cols={12} gap={16} mobile={{ gridCols: 1 }}>
          {/* hero copy tile */}
          <box span={8} {...TILE} pad={40} gap={18} tw="flex flex-col justify-center" minh={380} mobile={{ pad: 24, minh: 0 }}>
            <Eyebrow>EMPTY RUNNING, SOLVED</Eyebrow>
            <h1 size={78} weight={700} lh={0.94} ls={-0.02} font={HEAD} color={C.ink} tablet={{ size: 58 }} mobile={{ size: 40 }}>
              Stop driving 140 empty miles home.
            </h1>
            <text size={17} lh={1.65} font={BODY} color={DIM} maxw={620} mobile={{ size: 15 }}>
              Backhaul finds a paying load going the direction you are already going, on the day you are already
              going. Average empty running down 31 percent across 2,400 vehicles, and you get paid in three days.
            </text>
            <box tw="flex flex-row items-center" gap={14} pad={{ t: 10 }} wrap="wrap">
              <text
                href="#signup"
                tag="span"
                bg={C.road}
                color={C.ground}
                size={15}
                weight={700}
                font={BODY}
                radius={8}
                pad={{ t: 16, b: 16, l: 26, r: 26 }}
                tw="hover:bg-[#FFB93F]"
              >
                Sign up with your O-licence
              </text>
              <text size={13} font={BODY} color={DIM} tag="span">
                No monthly fee. No tie-in.
              </text>
            </box>
          </box>

          {/* live loads tile */}
          <box span={4} {...TILE} tw="flex flex-col justify-between" minh={380} mobile={{ minh: 0 }} motion={RISE}>
            <box tw="flex flex-row items-center" gap={8}>
              <box bg={C.go} radius={999} w={9} h={9} minh={9} />
              <Eyebrow tone={C.go}>LIVE LOADS</Eyebrow>
            </box>
            <text tag="span" size={72} weight={700} lh={0.9} ls={-0.02} font={HEAD} color={C.ink} pad={{ t: 12 }} mobile={{ size: 52 }}>
              1,847
            </text>
            <text size={14} lh={1.55} font={BODY} color={DIM}>
              posted in the last 24 hours, every one with the rate on the card.
            </text>
            <box tw="flex flex-col" gap={0} pad={{ t: 14 }}>
              <box tw="flex flex-row items-center justify-between" pad={{ t: 10, b: 10 }} raw="& { border-top: 1px solid #26313C; }">
                <text size={13} weight={600} font={BODY} color={C.ink} tag="span">DAVENTRY → CARLISLE</text>
                <text size={13} weight={700} font={BODY} color={C.road} tag="span">£2.06</text>
              </box>
              <box tw="flex flex-row items-center justify-between" pad={{ t: 10, b: 10 }} raw="& { border-top: 1px solid #26313C; }">
                <text size={13} weight={600} font={BODY} color={C.ink} tag="span">AVONMOUTH → HULL</text>
                <text size={13} weight={700} font={BODY} color={C.road} tag="span">£1.88</text>
              </box>
              <box tw="flex flex-row items-center justify-between" pad={{ t: 10, b: 10 }} raw="& { border-top: 1px solid #26313C; }">
                <text size={13} weight={600} font={BODY} color={C.ink} tag="span">DOVER → WARRINGTON</text>
                <text size={13} weight={700} font={BODY} color={C.road} tag="span">£1.97</text>
              </box>
            </box>
          </box>

          {/* stat tiles */}
          <box span={4} tw="flex flex-col" gap={0}>
            <StatTile
              label="RATE PER MILE"
              value="£1.94"
              unit="artic, accepted this week"
              body="Average accepted rate this week: £1.94 a mile for artic, £1.42 for 7.5 tonne. Every load shows the rate before you tap, not after a phone call."
            />
          </box>
          <box span={4} tw="flex flex-col" gap={0}>
            <StatTile
              label="EMPTY RUNNING"
              value="18.6%"
              unit="down from 27%"
              body="Fleet average empty running fell from 27 percent to 18.6 percent in the first six months. That is the whole product in one number."
            />
          </box>
          <box span={4} radius={14} tw="flex flex-col" minh={230} raw="& { overflow: hidden; }">
            <img src={media.truck_dusk.id} w="100%" h={230} fit="cover" radius={14} mobile={{ h: 200 }} />
          </box>
        </grid>
      </box>
    </section>

    {/* ── 2. Three-day payment ──────────────────────────────────────── */}
    <Wrap bg={C.tile}>
      <grid cols={12} gap={16} mobile={{ gridCols: 1 }}>
        <box span={5} radius={14} tw="flex flex-col" raw="& { overflow: hidden; }">
          <img src={media.loading_bay.id} w="100%" h={420} fit="cover" radius={14} tablet={{ h: 320 }} mobile={{ h: 220 }} />
        </box>
        <box span={7} tw="flex flex-col justify-center" gap={18} pad={{ l: 12 }} mobile={{ pad: { l: 0 } }}>
          <Eyebrow>PAYMENT</Eyebrow>
          <h2 size={52} weight={700} lh={1} ls={-0.02} font={HEAD} color={C.ink} tablet={{ size: 40 }} mobile={{ size: 32 }}>
            Three working days, and what it costs you.
          </h2>
          <text size={17} lh={1.65} font={BODY} color={DIM} maxw={620} mobile={{ size: 15 }}>
            Paid three working days after POD upload, for a flat 2 percent. Wait the standard 45 days and it costs
            you nothing.
          </text>
          <grid cols={2} gap={14} mobile={{ gridCols: 1 }}>
            <box bg={C.ground} radius={12} border={[1, C.line]} pad={22} gap={6} tw="flex flex-col" motion={RISE}>
              <text tag="span" size={44} weight={700} lh={1} font={HEAD} color={C.go}>
                2%
              </text>
              <text size={14} lh={1.55} font={BODY} color={DIM}>
                flat fee, paid on day three. £480 load, £9.60 to you, money in the account on Wednesday.
              </text>
            </box>
            <box bg={C.ground} radius={12} border={[1, C.line]} pad={22} gap={6} tw="flex flex-col" motion={RISE}>
              <text tag="span" size={44} weight={700} lh={1} font={HEAD} color={C.ink}>
                £0
              </text>
              <text size={14} lh={1.55} font={BODY} color={DIM}>
                if you can wait the standard 45 days. Same load, same rate, no deduction at all.
              </text>
            </box>
          </grid>
        </box>
      </grid>
    </Wrap>

    {/* ── 3. How matching works ─────────────────────────────────────── */}
    <Wrap bg={C.ground}>
      <grid cols={12} gap={16} mobile={{ gridCols: 1 }}>
        <box span={5} tw="flex flex-col" gap={14}>
          <Eyebrow>MATCHING</Eyebrow>
          <h2 size={48} weight={700} lh={1.02} ls={-0.02} font={HEAD} color={C.ink} tablet={{ size: 38 }} mobile={{ size: 32 }}>
            How it works on a return leg.
          </h2>
        </box>
        <box span={7} tw="flex flex-col justify-end" gap={0}>
          <text size={17} lh={1.65} font={BODY} color={DIM} mobile={{ size: 15 }}>
            Tell us where you tip and when you need to be home. We look at loads within 40 miles of your route and
            rank them by what you actually earn after the deviation and the fuel.
          </text>
        </box>
      </grid>
      <grid cols={4} gap={16} mobile={{ gridCols: 1 }}>
        <Step n="01" title="Tip and tell us" body="Log where you are tipping and the hour you need to be back on the yard. Twenty seconds, in the cab." />
        <Step n="02" title="We search 40 miles" body="Every posted load within a 40 mile corridor of your route home, live, with the shipper's rate already attached." />
        <Step n="03" title="Ranked on net" body="Deviation miles and fuel come off before you see the order. The top load is the one that actually pays best." />
        <Step n="04" title="Tap and run it" body="Accept on the phone. Collection window, contact and paperwork land on the load before you set off." />
      </grid>
    </Wrap>

    {/* ── 4. Rates and take ─────────────────────────────────────────── */}
    <Wrap bg={C.tile}>
      <grid cols={12} gap={16} mobile={{ gridCols: 1 }}>
        <box span={6} bg={C.ground} radius={14} border={[1, C.line]} pad={30} gap={0} tw="flex flex-col" motion={RISE}>
          <box tw="flex flex-row items-center justify-between" pad={{ b: 18 }} raw="& { border-bottom: 1px solid #26313C; }">
            <heading tag="h3" size={20} weight={700} ls={0.04} font={HEAD} color={C.ink}>
              DAVENTRY → CARLISLE
            </heading>
            <text size={12} weight={700} ls={0.08} font={BODY} color={C.go} tag="span">
              ARTIC · 233 MI
            </text>
          </box>
          <box tw="flex flex-row items-center justify-between" pad={{ t: 16, b: 16 }} raw="& { border-bottom: 1px solid #26313C; }">
            <text size={15} font={BODY} color={DIM} tag="span">Shipper pays</text>
            <text size={20} weight={700} font={BODY} color={C.ink} tag="span">£480.00</text>
          </box>
          <box tw="flex flex-row items-center justify-between" pad={{ t: 16, b: 16 }} raw="& { border-bottom: 1px solid #26313C; }">
            <text size={15} font={BODY} color={DIM} tag="span">Backhaul takes 8%</text>
            <text size={20} weight={700} font={BODY} color={C.road} tag="span">−£38.40</text>
          </box>
          <box tw="flex flex-row items-center justify-between" pad={{ t: 20 }}>
            <text size={15} weight={600} font={BODY} color={C.ink} tag="span">You get</text>
            <text tag="span" size={40} weight={700} lh={1} font={HEAD} color={C.go}>
              £441.60
            </text>
          </box>
        </box>
        <box span={6} tw="flex flex-col justify-center" gap={18} pad={{ l: 12 }} mobile={{ pad: { l: 0 } }}>
          <Eyebrow>RATES</Eyebrow>
          <h2 size={48} weight={700} lh={1.02} ls={-0.02} font={HEAD} color={C.ink} tablet={{ size: 38 }} mobile={{ size: 30 }}>
            Both numbers on the card.
          </h2>
          <text size={17} lh={1.65} font={BODY} color={DIM} mobile={{ size: 15 }}>
            The shipper pays a rate, we take 8 percent, and both numbers are on the load card. No hidden margin and
            no rate that mysteriously drops at invoice.
          </text>
          <text size={15} lh={1.6} font={BODY} color={C.ink}>
            <strong>£1.94</strong> a mile for artic, <strong>£1.42</strong> for 7.5 tonne — the accepted averages
            this week, not an asking price.
          </text>
        </box>
      </grid>
    </Wrap>

    {/* ── 5. Vetting ────────────────────────────────────────────────── */}
    <Wrap bg={C.ground}>
      <grid cols={12} gap={16} mobile={{ gridCols: 1 }}>
        <box span={5} tw="flex flex-col" gap={16}>
          <box radius={14} tw="flex flex-col" raw="& { overflow: hidden; }">
            <img src={media.driver_cab.id} w="100%" h={300} fit="cover" radius={14} mobile={{ h: 210 }} />
          </box>
          <box bg={C.tile} radius={14} border={[1, C.line]} pad={24} gap={8} tw="flex flex-col">
            <Eyebrow>VETTING</Eyebrow>
            <text size={15} lh={1.6} font={BODY} color={C.ink}>
              Every shipper is credit-checked and every carrier's O-licence, insurance and CPC are verified before
              the first load. Two missed payments and a shipper is removed, permanently.
            </text>
          </box>
        </box>
        <box span={7} tw="flex flex-col justify-center" gap={4} pad={{ l: 12 }} mobile={{ pad: { l: 0 } }}>
          <h2 size={48} weight={700} lh={1.02} ls={-0.02} font={HEAD} color={C.ink} pad={{ b: 10 }} tablet={{ size: 38 }} mobile={{ size: 30 }}>
            Who is allowed to post a load.
          </h2>
          <CheckRow title="Credit-checked shippers" body="Every account runs through a credit file before it can post. Limits are set on what they can owe at any one time." />
          <CheckRow title="O-licence verified" body="Operator licence checked against the traffic commissioner's register, with the disc number on file." />
          <CheckRow title="Insurance and CPC on file" body="Goods in transit, public liability and driver CPC, all dated and re-checked before they lapse." />
          <CheckRow title="Two strikes, permanently" body="Two missed payments and the shipper is removed. Not suspended, not warned again — removed." />
        </box>
      </grid>
    </Wrap>

    {/* ── 6. Paperwork ──────────────────────────────────────────────── */}
    <Wrap bg={C.tile}>
      <grid cols={12} gap={16} mobile={{ gridCols: 1 }}>
        <box span={7} tw="flex flex-col justify-center" gap={16}>
          <Eyebrow>PAPERWORK</Eyebrow>
          <h2 size={48} weight={700} lh={1.02} ls={-0.02} font={HEAD} color={C.ink} tablet={{ size: 38 }} mobile={{ size: 30 }}>
            The POD lives on the load, not in your cab door.
          </h2>
          <text size={17} lh={1.65} font={BODY} color={DIM} maxw={640} mobile={{ size: 15 }}>
            Photograph the POD, it is attached and timestamped. CMR, weight tickets and defect reports all live on
            the load, so the office is not chasing you at nine at night.
          </text>
        </box>
        <box span={5} bg={C.ground} radius={14} border={[1, C.line]} pad={26} gap={12} tw="flex flex-col justify-center" motion={RISE}>
          <text tag="span" size={44} weight={700} lh={1} font={HEAD} color={C.go}>
            9 sec
          </text>
          <text size={14} lh={1.6} font={BODY} color={DIM}>
            median time from photographing a POD to it being attached, timestamped and visible to the shipper's
            accounts team. The three-day clock starts on that upload.
          </text>
        </box>
      </grid>
      <grid cols={4} gap={14} mobile={{ gridCols: 1 }}>
        <DocChip name="POD" meta="Photographed, timestamped, geotagged at the tip." />
        <DocChip name="CMR" meta="Attached on international loads before collection." />
        <DocChip name="WEIGHT TICKET" meta="Scanned at the weighbridge, held against the load." />
        <DocChip name="DEFECT REPORT" meta="Filed from the walkaround, straight to the office." />
      </grid>
    </Wrap>

    {/* ── 7. Small fleets ───────────────────────────────────────────── */}
    <Wrap bg={C.ground}>
      <grid cols={12} gap={16} mobile={{ gridCols: 1 }}>
        <box span={4} tw="flex flex-col justify-center" gap={16}>
          <Eyebrow>SMALL FLEETS</Eyebrow>
          <h2 size={44} weight={700} lh={1.02} ls={-0.02} font={HEAD} color={C.ink} tablet={{ size: 36 }} mobile={{ size: 30 }}>
            Six vehicles, one account.
          </h2>
          <text size={16} lh={1.65} font={BODY} color={DIM} mobile={{ size: 15 }}>
            Add every vehicle and driver under one O-licence. Accept on behalf of a driver, see who is loaded and
            who is running empty, and take one payment run for the whole fleet on day three.
          </text>
          <box tw="flex flex-row items-end" gap={8} pad={{ t: 6 }}>
            <text tag="span" size={40} weight={700} lh={1} font={HEAD} color={C.road}>
              31%
            </text>
            <text size={14} font={BODY} color={DIM} tag="span">
              less empty running, fleet-wide
            </text>
          </box>
        </box>
        <box span={8} bg={C.tile} radius={14} border={[1, C.line]} pad={28} gap={0} tw="flex flex-col" mobile={{ pad: 20 }}>
          <box tw="flex flex-row items-center justify-between" pad={{ b: 12 }} raw="& { border-bottom: 1px solid #26313C; }">
            <text size={12} weight={700} ls={0.1} font={BODY} color={DIM} tag="span">FLEET TODAY</text>
            <text size={12} weight={700} ls={0.1} font={BODY} color={DIM} tag="span">STATUS</text>
          </box>
          <VehicleRow reg="YK71 HGV" body="Daventry → Carlisle · M. Okafor" status="LOADED" />
          <VehicleRow reg="MX20 TRK" body="Avonmouth → Hull · S. Whelan" status="MATCHED" />
          <VehicleRow reg="BD69 LDN" body="Dover → Warrington · J. Price" status="LOADED" />
          <VehicleRow reg="SC22 FLT" body="Grangemouth → Leeds · A. Barr" status="TIPPING" />
          <VehicleRow reg="PE18 RTN" body="Felixstowe → Bristol · D. Nkemelu" status="MATCHED" />
          <VehicleRow reg="LV23 BHL" body="Wakefield → Cardiff · R. Vaughan" status="LOADED" />
        </box>
      </grid>
    </Wrap>

    {/* ── 8. Sign up ────────────────────────────────────────────────── */}
    <section
      id="signup"
      bg={C.tile}
      tw="flex flex-col items-center w-full"
      pad={{ t: 104, b: 104, l: 24, r: 24 }}
      mobile={{ pad: { t: 64, b: 64, l: 18, r: 18 } }}
      raw="& { border-top: 1px solid #26313C; }"
    >
      <box tw="flex flex-col items-center w-full" maxw={780} gap={20} ta="center">
        <Eyebrow>GET STARTED</Eyebrow>
        <h2 size={62} weight={700} lh={0.98} ls={-0.02} font={HEAD} color={C.ink} ta="center" tablet={{ size: 46 }} mobile={{ size: 34 }}>
          Sign up with your O-licence.
        </h2>
        <text size={17} lh={1.65} font={BODY} color={DIM} ta="center" maxw={600} mobile={{ size: 15 }}>
          Licence number, insurance certificate and CPC. Verified inside a working day, and the first load you
          accept is on the same terms as the two thousand four hundred vehicles already running.
        </text>
        <text
          href="#signup"
          tag="span"
          bg={C.road}
          color={C.ground}
          size={16}
          weight={700}
          font={BODY}
          radius={8}
          pad={{ t: 18, b: 18, l: 32, r: 32 }}
          m={{ t: 8 }}
          tw="hover:bg-[#FFB93F]"
        >
          Sign up with your O-licence
        </text>
        <text size={13} font={BODY} color={DIM} ta="center" tag="span">
          Backhaul · 2,400 vehicles · paid three working days after POD
        </text>
      </box>
    </section>
  </box>
);
