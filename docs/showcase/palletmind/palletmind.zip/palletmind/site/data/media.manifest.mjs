/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "palletmind--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'palletmind--';

export default [
  { slot: `${PREFIX}ops_floor`, file: join(MEDIA_DIR, "ops_floor.jpg"), alt: "Operations floor of a distribution centre" },
  { slot: `${PREFIX}robot_aisle`, file: join(MEDIA_DIR, "robot_aisle.jpg"), alt: "Autonomous pallet mover in a racking aisle" },
  { slot: `${PREFIX}sensor_detail`, file: join(MEDIA_DIR, "sensor_detail.jpg"), alt: "Dual-channel safety scanner detail" },
];
