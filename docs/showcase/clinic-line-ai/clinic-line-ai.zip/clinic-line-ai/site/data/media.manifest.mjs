/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "clinic-line-ai--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'clinic-line-ai--';

export default [
  { slot: `${PREFIX}manager_portrait`, file: join(MEDIA_DIR, "manager_portrait.jpg"), alt: "Practice manager at a three-site dental group in Bristol" },
  { slot: `${PREFIX}reception`, file: join(MEDIA_DIR, "reception.jpg"), alt: "Clinic reception desk with the phone ringing" },
];
