/** Sinkstone — carbon removal registry. Design tokens. */
export default defineTheme({
  name: 'sinkstone',
  color: {
    ground: '#0B0F0D',   // page background
    ink: '#E4EDE7',      // primary text
    mineral: '#8FD6B4',  // accent / numbers / links
    warn: '#E0C060',     // voids, failures, disclosures
    line: '#1E2724',     // rules and hairlines
    muted: '#7E8F86',    // secondary copy
  },
  font: { head: 'Space Mono', body: 'IBM Plex Mono' },
  mode: 'literal',
});
