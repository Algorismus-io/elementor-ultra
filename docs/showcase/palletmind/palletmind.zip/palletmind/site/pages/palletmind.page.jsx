import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Palletmind — autonomous pallet movement, retrofitted',
  slug: 'palletmind',
  seo: {
    title: 'Palletmind | Autonomous pallet movers that retrofit into your warehouse',
    description:
      'Palletmind units navigate on existing racking and structure. No floor tape, no reflectors, no ceiling infrastructure. First unit productive in nine days.',
  },
};

/* ── dossier index ── */
const NAV = [
  ['01', 'Premise', '#premise'],
  ['02', 'Retrofit', '#retrofit'],
  ['03', 'Throughput', '#throughput'],
  ['04', 'Safety case', '#safety'],
  ['05', 'WMS integration', '#integration'],
  ['06', 'Commercial model', '#commercial'],
  ['07', 'Deployment', '#timeline'],
  ['08', 'Site walk', '#site-walk'],
];

const NavItem = defineComponent(
  ({ num = '01', label = 'Section', href = '#premise' }) => (
    <text
      href={href}
      cls="nav-item"
      tw="flex w-full py-3 text-[13px] tracking-[0.06em] no-underline border-b border-[#D5DBE0]"
      font="IBM Plex Sans"
      color="#2E3F4C"
      hover={{ color: '#0F1519', bg: '#FFD400' }}
    >
      <strong>{num}</strong>  {label}
    </text>
  ),
  { title: 'Dossier nav item', props: { num: { label: 'Number' }, label: { label: 'Label' }, href: { label: 'Anchor' } } },
);

const Stat = defineComponent(
  ({ value = '0', label = 'Metric' }) => (
    <div cls="stat" tw="flex flex-col gap-2 py-6 px-6 border-l border-[#2E3F4C]">
      <heading tag="h3" font="Michroma" color="#FFD400" tw="text-[34px] leading-none max-md:text-[26px]">
        {value}
      </heading>
      <text font="IBM Plex Sans" color="#D5DBE0" tw="text-[13px] leading-relaxed tracking-[0.04em]">
        {label}
      </text>
    </div>
  ),
  { title: 'Site stat', props: { value: { label: 'Value' }, label: { label: 'Caption' } } },
);

const WeekRow = defineComponent(
  ({ week = 'Week 1', title = 'Milestone', body = 'Detail' }) => (
    <div cls="week-row" tw="flex flex-row gap-8 py-7 border-t border-[#D5DBE0] max-md:flex-col max-md:gap-3">
      <text font="Michroma" color="#0F1519" tw="text-[13px] w-[110px] leading-relaxed">
        {week}
      </text>
      <div tw="flex flex-col gap-2 flex-1">
        <heading tag="h3" font="IBM Plex Sans" color="#0F1519" weight={600} tw="text-[19px] leading-snug">
          {title}
        </heading>
        <text font="IBM Plex Sans" color="#2E3F4C" tw="text-[15px] leading-relaxed max-w-[560px]">
          {body}
        </text>
      </div>
    </div>
  ),
  { title: 'Deployment week', props: { week: { label: 'Week' }, title: { label: 'Title' }, body: { label: 'Body' } } },
);

/* ── local section helpers (plain functions: styles vary, so no registration) ── */
const Eyebrow = ({ text: label, color = '#2E3F4C' }) => (
  <text font="Michroma" color={color} tw="text-[11px] tracking-[0.18em] leading-normal">
    {label}
  </text>
);

const Rule = ({ color = '#D5DBE0' }) => <div tw="w-full h-[1px]" bg={color} />;

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" bg={t.color.ground} font={t.font.body}>
    <grid cols="288px 1fr" gap={0} tw="w-full" mobile={{ gridCols: 1 }}>
      {/* ══ LEFT: sticky dossier nav ══ */}
      <div tw="flex flex-col border-r border-[#D5DBE0]" bg={t.color.white}>
        <div tw="sticky top-0 flex flex-col gap-8 px-8 py-10 max-md:static max-md:py-8">
          <div tw="flex flex-col gap-3">
            <heading tag="h2" font={t.font.head} color={t.color.ink} tw="text-[19px] leading-none tracking-[0.04em]">
              PALLETMIND
            </heading>
            <text font={t.font.body} color={t.color.machine} tw="text-[12px] leading-relaxed tracking-[0.08em]">
              Warehouse robotics · dossier v4.2
            </text>
          </div>

          <div tw="flex flex-col w-full">
            {NAV.map(([num, label, href]) => NavItem({ num, label, href }))}
          </div>

          <div tw="flex flex-col gap-3">
            <text
              href="#site-walk"
              font={t.font.body}
              weight={600}
              color={t.color.ink}
              tw="flex px-5 py-4 text-[14px] tracking-[0.04em] no-underline text-center justify-center"
              bg={t.color.hazard}
              hover={{ bg: '#0F1519', color: '#FFD400' }}
              shadow={[[2, 0, 0, '#0F1519'], [6, 18, -6, 'rgba(15,21,25,0.28)']]}
            >
              Arrange a site walk
            </text>
            <text font={t.font.body} color={t.color.machine} tw="text-[12px] leading-relaxed">
              Operations directors, 3PL and distribution. Ninety minutes on your floor.
            </text>
          </div>
        </div>
      </div>

      {/* ══ RIGHT: the dossier body ══ */}
      <div tw="flex flex-col w-full">
        {/* 1 — premise */}
        <section id="premise" tw="flex flex-col gap-8 px-16 py-20 max-lg:px-10 max-md:px-6 max-md:py-14" bg={t.color.ground}>
          <Eyebrow text="01 — PREMISE" />
          <h1
            font={t.font.head}
            color={t.color.ink}
            tw="text-[52px] leading-[1.08] max-w-[620px] max-lg:text-[40px] max-md:text-[28px]"
            motion={{ effect: 'fade', trigger: 'load' }}
          >
            Autonomous pallet movement in the warehouse you already have.
          </h1>
          <text font={t.font.body} color={t.color.machine} tw="text-[18px] leading-relaxed max-w-[690px] max-md:text-[15px]">
            Palletmind units navigate on existing racking and structure. No floor tape, no reflectors, no
            ceiling infrastructure, no shutting the site down. <strong>First unit productive in nine days.</strong>
          </text>
          <grid cols={3} gap={0} tw="w-full border-t border-[#D5DBE0]" mobile={{ gridCols: 1 }}>
            <div tw="flex flex-col gap-1 py-6 pr-8 border-r border-[#D5DBE0] max-md:pr-0">
              <text font={t.font.head} color={t.color.ink} tw="text-[22px] leading-none">218</text>
              <text font={t.font.body} color={t.color.machine} tw="text-[13px] leading-relaxed">pallet moves / unit / shift</text>
            </div>
            <div tw="flex flex-col gap-1 py-6 px-8 border-r border-[#D5DBE0] max-md:px-0">
              <text font={t.font.head} color={t.color.ink} tw="text-[22px] leading-none">0.9m</text>
              <text font={t.font.body} color={t.color.machine} tw="text-[13px] leading-relaxed">stop distance, 1,200kg load</text>
            </div>
            <div tw="flex flex-col gap-1 py-6 px-8 max-md:px-0">
              <text font={t.font.head} color={t.color.ink} tw="text-[22px] leading-none">9 days</text>
              <text font={t.font.body} color={t.color.machine} tw="text-[13px] leading-relaxed">survey to first productive unit</text>
            </div>
          </grid>
          <img src={media.ops_floor.id} tw="w-full h-[320px] object-cover max-md:h-[200px]" />
        </section>

        {/* 2 — retrofit */}
        <section id="retrofit" tw="flex flex-col gap-8 px-16 py-20 max-lg:px-10 max-md:px-6 max-md:py-14" bg={t.color.white}>
          <Eyebrow text="02 — RETROFIT" />
          <grid cols="1fr 1fr" gap={48} tw="w-full items-start" mobile={{ gridCols: 1, gap: 28 }}>
            <div tw="flex flex-col gap-6">
              <h2 font={t.font.head} color={t.color.ink} tw="text-[30px] leading-[1.2] max-md:text-[22px]" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
                No floor tape, no beacons, no ceiling work.
              </h2>
              <text font={t.font.body} color={t.color.machine} tw="text-[16px] leading-relaxed max-w-[540px]">
                Localisation uses the racking legs, dock doors and structural columns already in your building.
                If your layout changes on a Tuesday, the fleet has re-mapped by Wednesday morning without an engineer.
              </text>
              <div tw="flex flex-col gap-0 w-full">
                {[
                  ['Floor markings', 'None. Nothing is cut, painted or taped.'],
                  ['Reflectors and beacons', 'None. No wall furniture, no calibration drift.'],
                  ['Ceiling and power work', 'None. Charging drops into an existing 16A socket.'],
                  ['Site shutdown', 'None. Mapping runs alongside your own trucks.'],
                ].map(([k, v]) => (
                  <div tw="flex flex-row gap-6 py-4 border-t border-[#D5DBE0] max-md:flex-col max-md:gap-1">
                    <text font={t.font.body} weight={600} color={t.color.ink} tw="text-[14px] w-[190px] leading-snug">{k}</text>
                    <text font={t.font.body} color={t.color.machine} tw="text-[14px] leading-relaxed flex-1">{v}</text>
                  </div>
                ))}
              </div>
            </div>
            <img src={media.robot_aisle.id} tw="w-full h-[460px] object-cover max-md:h-[240px]" />
          </grid>
        </section>

        {/* 3 — throughput */}
        <section id="throughput" tw="flex flex-col gap-9 px-16 py-20 max-lg:px-10 max-md:px-6 max-md:py-14" bg={t.color.ink}>
          <Eyebrow text="03 — THROUGHPUT, THREE LIVE SITES" color="#FFD400" />
          <h2 font={t.font.head} color={t.color.white} tw="text-[30px] leading-[1.2] max-w-[520px] max-md:text-[22px]" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            Measured on the floor, not in a demo cell.
          </h2>
          <text font={t.font.body} color={t.color.line} tw="text-[16px] leading-relaxed max-w-[690px]">
            At a 34,000 sq m 3PL site: 218 pallet moves per unit per shift, 99.1 percent completion,
            4 human interventions per week across nine units.
          </text>
          <grid cols={4} gap={0} tw="w-full border-t border-[#2E3F4C]" mobile={{ gridCols: 2 }}>
            {[
              ['218', 'Pallet moves per unit per shift'],
              ['99.1%', 'Task completion, rolling 90 days'],
              ['4', 'Human interventions per week, nine units'],
              ['34,000', 'Square metres under fleet control'],
            ].map(([value, label]) => Stat({ value, label }))}
          </grid>
          <grid cols={3} gap={24} tw="w-full pt-2" mobile={{ gridCols: 1, gap: 16 }}>
            {[
              ['Ambient 3PL, Midlands', 'Nine units, two shifts, mixed pallet and cage.'],
              ['Chilled distribution, 2°C', 'Four units, condensation-rated sensor stack.'],
              ['Retail RDC, night shift', 'Six units running unattended between 22:00 and 06:00.'],
            ].map(([k, v]) => (
              <div tw="flex flex-col gap-2 p-6" bg="#18222A">
                <text font={t.font.body} weight={600} color={t.color.hazard} tw="text-[14px] leading-snug">{k}</text>
                <text font={t.font.body} color={t.color.line} tw="text-[14px] leading-relaxed">{v}</text>
              </div>
            ))}
          </grid>
        </section>

        {/* 4 — safety */}
        <section id="safety" tw="flex flex-col gap-8 px-16 py-20 max-lg:px-10 max-md:px-6 max-md:py-14" bg={t.color.ground}>
          <Eyebrow text="04 — SAFETY CASE" />
          <grid cols="0.9fr 1.1fr" gap={48} tw="w-full items-start" mobile={{ gridCols: 1, gap: 28 }}>
            <img src={media.sensor_detail.id} tw="w-full h-[380px] object-cover max-md:h-[220px]" />
            <div tw="flex flex-col gap-6">
              <h2 font={t.font.head} color={t.color.ink} tw="text-[30px] leading-[1.2] max-md:text-[22px]" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
                Standards, scanners and stop distances.
              </h2>
              <text font={t.font.body} color={t.color.machine} tw="text-[16px] leading-relaxed max-w-[560px]">
                ISO 3691-4 compliant, dual-channel safety scanners, 0.9m stop distance at full speed with a
                1,200kg load. Full safety case and risk assessment supplied before any trial.
              </text>
              <div tw="flex flex-col gap-0 w-full border-t border-[#D5DBE0]">
                {[
                  ['ISO 3691-4', 'Driverless industrial trucks — compliant by design, not by exemption.'],
                  ['Dual-channel scanners', 'Redundant safety-rated laser pair, cross-checked every cycle.'],
                  ['0.9m', 'Stop distance at full speed carrying 1,200kg.'],
                  ['Pre-trial documentation', 'Safety case and site risk assessment, before a unit arrives.'],
                ].map(([k, v]) => (
                  <div tw="flex flex-row gap-5 py-4 border-b border-[#D5DBE0] max-md:flex-col max-md:gap-1">
                    <text font={t.font.body} weight={600} color="#2F9E6B" tw="text-[14px] w-[170px] leading-snug tracking-[0.02em]">{k}</text>
                    <text font={t.font.body} color={t.color.machine} tw="text-[14px] leading-relaxed flex-1">{v}</text>
                  </div>
                ))}
              </div>
            </div>
          </grid>
        </section>

        {/* 5 — integration */}
        <section id="integration" tw="flex flex-col gap-8 px-16 py-20 max-lg:px-10 max-md:px-6 max-md:py-14" bg={t.color.white}>
          <Eyebrow text="05 — WMS INTEGRATION" />
          <h2 font={t.font.head} color={t.color.ink} tw="text-[30px] leading-[1.2] max-w-[560px] max-md:text-[22px]" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            It takes work from the system you already run.
          </h2>
          <text font={t.font.body} color={t.color.machine} tw="text-[16px] leading-relaxed max-w-[690px]">
            Reads task queues from SAP EWM, Manhattan, Körber and Blue Yonder via a documented REST interface.
            If your WMS is bespoke, our integration team writes the adapter and we do not charge for it.
          </text>
          <grid cols={4} gap={16} tw="w-full" mobile={{ gridCols: 2, gap: 12 }}>
            {['SAP EWM', 'Manhattan', 'Körber', 'Blue Yonder'].map((n) => (
              <div
                tw="flex flex-col justify-center px-5 py-7 border border-[#D5DBE0]"
                bg={t.color.ground}
                hover={{ bg: '#0F1519' }}
              >
                <text font={t.font.head} color={t.color.ink} tw="text-[14px] leading-snug">{n}</text>
              </div>
            ))}
          </grid>
          <grid cols="1fr 1fr" gap={40} tw="w-full pt-2 border-t border-[#D5DBE0]" mobile={{ gridCols: 1, gap: 20 }}>
            <div tw="flex flex-col gap-2 pt-6">
              <heading tag="h3" font={t.font.body} weight={600} color={t.color.ink} tw="text-[17px] leading-snug">Documented REST interface</heading>
              <text font={t.font.body} color={t.color.machine} tw="text-[15px] leading-relaxed">
                Task queue in, move confirmations out. Your integration team reads the spec once and is done.
              </text>
            </div>
            <div tw="flex flex-col gap-2 pt-6">
              <heading tag="h3" font={t.font.body} weight={600} color={t.color.ink} tw="text-[17px] leading-snug">Bespoke WMS, no charge</heading>
              <text font={t.font.body} color={t.color.machine} tw="text-[15px] leading-relaxed">
                Home-grown or heavily modified, we write the adapter ourselves and it is not a line on the quote.
              </text>
            </div>
          </grid>
        </section>

        {/* 6 — commercial */}
        <section id="commercial" tw="flex flex-col gap-8 px-16 py-20 max-lg:px-10 max-md:px-6 max-md:py-14" bg={t.color.machine}>
          <Eyebrow text="06 — COMMERCIAL MODEL" color="#FFD400" />
          <h2 font={t.font.head} color={t.color.white} tw="text-[30px] leading-[1.2] max-w-[520px] max-md:text-[22px]" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            Per move, or per unit. Both are on the table.
          </h2>
          <grid cols="1fr 1fr" gap={2} tw="w-full" mobile={{ gridCols: 1, gap: 12 }}>
            <div tw="flex flex-col gap-4 p-9 max-md:p-6" bg={t.color.ground}>
              <text font={t.font.body} color={t.color.machine} tw="text-[12px] tracking-[0.14em] leading-normal">OPERATING</text>
              <heading tag="h3" font={t.font.head} color={t.color.ink} tw="text-[34px] leading-none max-md:text-[26px]">0.34</heading>
              <text font={t.font.body} weight={600} color={t.color.ink} tw="text-[15px] leading-snug">per pallet move, no capital outlay</text>
              <text font={t.font.body} color={t.color.machine} tw="text-[14px] leading-relaxed">
                Billed on completed moves only. Service, software and spares included. Most sites start here.
              </text>
            </div>
            <div tw="flex flex-col gap-4 p-9 max-md:p-6" bg={t.color.ink}>
              <text font={t.font.body} color={t.color.hazard} tw="text-[12px] tracking-[0.14em] leading-normal">CAPITAL</text>
              <heading tag="h3" font={t.font.head} color={t.color.white} tw="text-[34px] leading-none max-md:text-[26px]">68,000</heading>
              <text font={t.font.body} weight={600} color={t.color.white} tw="text-[15px] leading-snug">per unit, outright, with a service contract</text>
              <text font={t.font.body} color={t.color.line} tw="text-[14px] leading-relaxed">
                Owned on your balance sheet. Most sites convert in year two, once the move volume is proven.
              </text>
            </div>
          </grid>
          <text font={t.font.body} color={t.color.line} tw="text-[15px] leading-relaxed max-w-[620px]">
            Per-move pricing from 0.34 per pallet move with no capital outlay, or outright purchase at 68,000 per
            unit with a service contract. Most sites start on per-move and convert in year two.
          </text>
        </section>

        {/* 7 — timeline */}
        <section id="timeline" tw="flex flex-col gap-7 px-16 py-20 max-lg:px-10 max-md:px-6 max-md:py-14" bg={t.color.ground}>
          <Eyebrow text="07 — DEPLOYMENT, WEEK BY WEEK" />
          <h2 font={t.font.head} color={t.color.ink} tw="text-[30px] leading-[1.2] max-w-[480px] max-md:text-[22px]" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            Eight weeks from survey to handover.
          </h2>
          <div tw="flex flex-col w-full">
            {[
              ['Week 1', 'Site survey and safety case', 'We walk the floor, capture the structure and produce the safety case and risk assessment for your review.'],
              ['Week 2', 'Mapping and one unit live', 'The fleet maps against racking and columns. One unit starts moving real pallets on your task queue.'],
              ['Week 4', 'Four units and WMS integration', 'Task queues read directly from your WMS. Four units running alongside your own trucks and people.'],
              ['Week 8', 'Full fleet and handover', 'Full fleet productive and handed over to your own team, with the documentation to run it.'],
            ].map(([week, title, body]) => WeekRow({ week, title, body }))}
          </div>
          <Rule />
        </section>

        {/* 8 — site walk */}
        <section id="site-walk" tw="flex flex-col gap-8 px-16 py-20 max-lg:px-10 max-md:px-6 max-md:py-14" bg={t.color.ink}>
          <grid cols="1.1fr 0.9fr" gap={48} tw="w-full items-start" mobile={{ gridCols: 1, gap: 28 }}>
            <div tw="flex flex-col gap-6">
              <Eyebrow text="08 — SITE WALK" color="#FFD400" />
              <h2 font={t.font.head} color={t.color.white} tw="text-[34px] leading-[1.15] max-w-[440px] max-md:text-[24px]">
                Arrange a site walk.
              </h2>
              <text font={t.font.body} color={t.color.line} tw="text-[16px] leading-relaxed max-w-[540px]">
                Ninety minutes on your floor with an engineer and an operations lead. You get the retrofit
                assessment, an indicative move rate and the safety case outline. No unit leaves our building
                until you have read it.
              </text>
              <text
                href="#premise"
                font={t.font.body}
                weight={600}
                color={t.color.ink}
                tw="flex px-7 py-4 text-[15px] tracking-[0.04em] no-underline w-[260px] justify-center max-md:w-full"
                bg={t.color.hazard}
                hover={{ bg: '#FFFFFF' }}
                shadow={[[3, 0, 0, '#2F9E6B'], [10, 24, -8, 'rgba(0,0,0,0.45)']]}
              >
                Arrange a site walk
              </text>
            </div>
            <div tw="flex flex-col gap-0 w-full border-t border-[#2E3F4C]">
              {[
                ['Who comes', 'One deployment engineer, one operations lead.'],
                ['What you get', 'Retrofit assessment, indicative move rate, safety case outline.'],
                ['How long', 'Ninety minutes on site, written back within five days.'],
                ['Then what', 'Week 1 survey booked, or nothing at all. Your call.'],
              ].map(([k, v]) => (
                <div tw="flex flex-col gap-1 py-5 border-b border-[#2E3F4C]">
                  <text font={t.font.body} weight={600} color={t.color.hazard} tw="text-[13px] tracking-[0.06em] leading-snug">{k}</text>
                  <text font={t.font.body} color={t.color.line} tw="text-[14px] leading-relaxed">{v}</text>
                </div>
              ))}
            </div>
          </grid>
          <text font={t.font.body} color={t.color.machine} tw="text-[12px] leading-relaxed tracking-[0.08em]">
            PALLETMIND · WAREHOUSE ROBOTICS · ISO 3691-4
          </text>
        </section>
      </div>
    </grid>
  </box>
);
