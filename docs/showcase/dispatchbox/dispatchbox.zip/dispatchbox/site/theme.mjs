/** Dispatchbox tokens — editorial index rail. */
export default defineTheme({
  name: 'dispatchbox',
  color: {
    ground: '#FBFBF9',
    ink: '#191919',
    quill: '#3B4A9E',
    highlight: '#FFE96B',
    rule: '#E0E0DA',
    grey: '#71716B',
    white: '#FFFFFF',
  },
  font: { head: 'Literata', body: 'Public Sans' },
  mode: 'literal',
});
