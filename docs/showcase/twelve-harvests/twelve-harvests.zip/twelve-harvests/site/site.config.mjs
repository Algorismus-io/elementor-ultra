export default { name: 'twelve-harvests' };
