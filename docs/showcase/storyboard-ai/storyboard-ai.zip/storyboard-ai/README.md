# Boardsmith

Panel grid used as layout — on-theme and well built.

|  |  |
|---|---|
| **Slug** | `storyboard-ai` (deploys to `/storyboard-ai/`) |
| **Archetype** | split-screen scroller |
| **Industry** | AI tool for filmmakers |
| **Page title** | Boardsmith — storyboards that stay on model |
| **Fonts** | Bricolage Grotesque, Onest — Google Fonts, imported by Elementor automatically |
| **Elements** | 137 |
| **Images** | 2 |
| **Global classes used** | 0 — built `--inline` (70 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install storyboard-ai
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
storyboard-ai/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/storyboard-ai.page.jsx         the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#141414` |
| `ink` | `#F0EFEC` |
| `paper` | `#E8E2D6` |
| `mark` | `#E2483C` |
| `grey` | `#57565A` |

Change a value, re-run `npx exjsx-kit install storyboard-ai`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/storyboard-ai.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `board_wall` | `media/board_wall.jpg` | A wall of pinned storyboard panels in a production office |
| `director_desk` | `media/director_desk.jpg` | A director’s desk with a marked-up script and boards |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
