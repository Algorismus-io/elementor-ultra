import { MEDIA as media } from '../data/media.mjs';
import { PIECES, TREES, STAGES, BANDS } from '../data/catalogue.mjs';

export const meta = {
  title: 'Wren & Ash — commissioned furniture in native hardwood',
  slug: 'wren-and-ash',
  seo: {
    title: 'Wren & Ash — furniture made from trees we can point at',
    description:
      'A two-person workshop in the Welsh borders making commissioned furniture in native oak, ash, elm and cherry. A catalogue of past commissions, with wood, dimensions and year.',
  },
};

const GROUND = '#F6F2EA';
const INK = '#241F1A';
const OAK = '#A97B4F';
const SOFT = '#6B6155';
const GREEN = '#3F5347';
const RULE = '#DED5C6';
const RULE_DARK = '#4A4038';

const fade = { effect: 'fade', trigger: 'scrollIn', duration: 700 };

/* ── repeaters (content props only — native components where Pro allows) ─────────── */

const CatalogueEntry = defineComponent(
  ({ piece = '', dim = '', wood = '', year = '' }) => (
    <col tw="border-t border-[#DED5C6] pt-5 gap-2" h="100%" justify="flex-start">
      <text cls="eyebrow" font="Karla" size={12} weight={600} ls={0.14} color={OAK} tw="uppercase">
        {year}
      </text>
      <heading tag="h3" font="EB Garamond" size={23} weight={400} lh={1.2} color={INK}>
        {piece}
      </heading>
      <text font="Karla" size={13} weight={600} color={INK} lh={1.5}>
        {dim}
      </text>
      <text font="Karla" size={14} color={SOFT} lh={1.6}>
        {wood}
      </text>
    </col>
  ),
  {
    title: 'Catalogue entry',
    props: {
      piece: { label: 'Piece', group: 'Entry' },
      dim: { label: 'Dimension', group: 'Entry' },
      wood: { label: 'Wood and provenance', group: 'Entry' },
      year: { label: 'Year', group: 'Entry' },
    },
  },
);

const TreeRow = defineComponent(
  ({ species = '', place = '', note = '', felled = '', ready = '' }) => (
    <col tw="border-t border-[#4A4038] pt-4 gap-1">
      <row tw="gap-3 items-end flex-wrap">
        <heading tag="h3" font="EB Garamond" size={22} weight={400} color={GROUND}>
          {species}
        </heading>
        <text font="Karla" size={13} weight={600} ls={0.1} color={OAK} tw="uppercase">
          {place}
        </text>
      </row>
      <text font="Karla" size={14} color="#B7ADA0" lh={1.65}>
        {note}
      </text>
      <row tw="gap-4 flex-wrap pt-1">
        <text font="Karla" size={12} ls={0.06} color="#8C8175">
          {felled}
        </text>
        <text font="Karla" size={12} ls={0.06} color="#8C8175">
          {ready}
        </text>
      </row>
    </col>
  ),
  {
    title: 'Timber rack row',
    props: {
      species: { label: 'Species', group: 'Tree' },
      place: { label: 'Place', group: 'Tree' },
      note: { label: 'Note', group: 'Tree' },
      felled: { label: 'Felled', group: 'Tree' },
      ready: { label: 'Ready', group: 'Tree' },
    },
  },
);

const PriceBand = defineComponent(
  ({ what = '', detail = '', from = '' }) => (
    <row
      tw="border-t border-[#DED5C6] py-6 gap-8 items-end justify-between max-md:flex-col max-md:gap-2"
      w="100%"
    >
      <col tw="gap-1" maxw={560}>
        <heading tag="h3" font="EB Garamond" size={26} weight={400} color={INK}>
          {what}
        </heading>
        <text font="Karla" size={14} color={SOFT} lh={1.6}>
          {detail}
        </text>
      </col>
      <text font="EB Garamond" size={30} weight={400} color={OAK} tw="whitespace-nowrap">
        {from}
      </text>
    </row>
  ),
  {
    title: 'Price band',
    props: {
      what: { label: 'Category', group: 'Band' },
      detail: { label: 'Detail', group: 'Band' },
      from: { label: 'From', group: 'Band' },
    },
  },
);

/* ── the page ────────────────────────────────────────────────────────────────────── */

export default () => (
  <box tw="flex flex-col w-full" pad={0} bg={GROUND}>

    {/* 1 — masthead: name, the sentence about the wood */}
    <section tw="w-full px-10 pt-14 pb-24 max-md:px-6 max-md:pt-10 max-md:pb-14" bg={GROUND}>
      <row tw="w-full max-w-[1240px] mx-auto justify-between items-end gap-6 pb-14 flex-wrap max-md:pb-8">
        <heading tag="h2" font="EB Garamond" size={22} weight={400} ls={0.18} color={INK} tw="uppercase">
          Wren &amp; Ash
        </heading>
        <text font="Karla" size={12} weight={600} ls={0.14} color={SOFT} tw="uppercase">
          Furniture makers · Welsh borders · est. 2014
        </text>
      </row>
      <grid
        cols="1.05fr 0.95fr"
        gap={64}
        tw="w-full max-w-[1240px] mx-auto items-center max-lg:gap-10"
        tablet={{ gridCols: 1 }}
        mobile={{ gridCols: 1, gap: 32 }}
      >
        <col tw="gap-7">
          <h1
            font="EB Garamond"
            size={72}
            weight={400}
            lh={1.04}
            ls={-0.02}
            color={INK}
            tablet={{ size: 54 }}
            mobile={{ size: 38 }}
          >
            Furniture made from trees we can point at.
          </h1>
          <text font="Karla" size={18} color={SOFT} lh={1.7} maxw={560} mobile={{ size: 16 }}>
            Two makers, one workshop in the Welsh borders, working in native oak, ash, elm and cherry
            from woodland within forty miles. Every commission is drawn, made and delivered by the
            same two people.
          </text>
          <row tw="gap-5 items-center pt-2 flex-wrap">
            <text
              href="#start"
              cls="cta"

              font="Karla"
              size={15}
              weight={600}
              ls={0.04}
              color={GROUND}
              bg={INK}
              pad={{ t: 16, r: 30, b: 16, l: 30 }}
              radius={2}
              hover={{ bg: OAK, color: INK }}
              tw="hover:bg-[#A97B4F]"
            >
              Start a commission
            </text>
            <text href="#catalogue" font="Karla" size={15} color={INK} tw="underline">
              Or read the catalogue first
            </text>
          </row>
        </col>
        <img src={media.table_room.id} w="100%" h={520} fit="cover" radius={2} tablet={{ h: 380 }} mobile={{ h: 260 }} />
      </grid>
    </section>

    {/* 2 — the catalogue proper */}
    <section id="catalogue" tw="w-full px-10 py-24 max-md:px-6 max-md:py-14" bg="#F0EADD">
      <row tw="w-full max-w-[1240px] mx-auto justify-between items-end gap-8 pb-12 flex-wrap max-md:pb-8">
        <col tw="gap-3" maxw={620}>
          <text cls="eyebrow" font="Karla" size={12} weight={600} ls={0.14} color={OAK} tw="uppercase">
            The catalogue — twenty-four pieces
          </text>
          <heading tag="h2" font="EB Garamond" size={44} weight={400} lh={1.12} color={INK} mobile={{ size: 30 }}>
            Everything we have made since 2021, with the tree it came from.
          </heading>
        </col>
        <text font="Karla" size={14} color={SOFT} lh={1.65} maxw={330}>
          Nine commissions a year, no more. Where a piece shares a tree with another, we have said so
          — a bench and a table from the one Cwmcarn oak.
        </text>
      </row>
      <grid
        cols={4}
        gap={40}
        tw="w-full max-w-[1240px] mx-auto"
        motion={fade}
        tablet={{ gridCols: 2 }}
        mobile={{ gridCols: 1, gap: 28 }}
      >
        {PIECES.map((p) => (
          <CatalogueEntry piece={p.piece} dim={p.dim} wood={p.wood} year={p.year} />
        ))}
      </grid>
    </section>

    {/* 3 — where the timber comes from, tree by tree */}
    <section tw="w-full px-10 py-24 max-md:px-6 max-md:py-14" bg={INK}>
      <grid
        cols="0.85fr 1.15fr"
        gap={72}
        tw="w-full max-w-[1240px] mx-auto items-start max-lg:gap-10"
        tablet={{ gridCols: 1 }}
        mobile={{ gridCols: 1, gap: 32 }}
      >
        <col tw="gap-6">
          <img src={media.timber_stack.id} w="100%" h={420} fit="cover" radius={2} mobile={{ h: 240 }} />
          <text font="Karla" size={15} color="#B7ADA0" lh={1.75}>
            We buy standing or wind-thrown trees, mill them ourselves, and air-dry for three years
            before anything is cut. There is a board in the rack now that will be a table in 2029.
          </text>
        </col>
        <col tw="gap-8">
          <col tw="gap-3">
            <text cls="eyebrow" font="Karla" size={12} weight={600} ls={0.14} color={OAK} tw="uppercase">
              The rack, tree by tree
            </text>
            <heading tag="h2" font="EB Garamond" size={42} weight={400} lh={1.14} color={GROUND} mobile={{ size: 30 }}>
              Six trees, and the year each one becomes furniture.
            </heading>
          </col>
          <col tw="gap-6" motion={fade}>
            {TREES.map((t) => (
              <TreeRow species={t.species} place={t.place} note={t.note} felled={t.felled} ready={t.ready} />
            ))}
          </col>
        </col>
      </grid>
    </section>

    {/* 4 — how a commission works */}
    <section tw="w-full px-10 py-24 max-md:px-6 max-md:py-14" bg={GROUND}>
      <col tw="w-full max-w-[1240px] mx-auto gap-3 pb-12 max-md:pb-8" maxw={720}>
        <text cls="eyebrow" font="Karla" size={12} weight={600} ls={0.14} color={OAK} tw="uppercase">
          How a commission works
        </text>
        <heading tag="h2" font="EB Garamond" size={44} weight={400} lh={1.12} color={INK} mobile={{ size: 30 }}>
          Four stages, and you are welcome at all of them.
        </heading>
      </col>
      <grid
        cols={4}
        gap={44}
        tw="w-full max-w-[1240px] mx-auto"
        motion={fade}
        tablet={{ gridCols: 2 }}
        mobile={{ gridCols: 1, gap: 28 }}
      >
        {STAGES.map((s) => (
          <col tw="border-t border-[#DED5C6] pt-6 gap-3">
            <text font="EB Garamond" size={40} weight={400} color={OAK} lh={1}>
              {s.n}
            </text>
            <heading tag="h3" font="EB Garamond" size={25} weight={400} lh={1.2} color={INK}>
              {s.title}
            </heading>
            <text font="Karla" size={14} color={SOFT} lh={1.7}>
              {s.body}
            </text>
          </col>
        ))}
      </grid>
    </section>

    {/* 5 — joinery detail plates */}
    <section tw="w-full px-10 py-24 max-md:px-6 max-md:py-14" bg={GREEN}>
      <row tw="w-full max-w-[1240px] mx-auto justify-between items-end gap-8 pb-12 flex-wrap max-md:pb-8">
        <heading tag="h2" font="EB Garamond" size={42} weight={400} lh={1.14} color="#EFEADF" maxw={620} mobile={{ size: 30 }}>
          Detail plates: the joints, and the room they were cut in.
        </heading>
        <text font="Karla" size={13} weight={600} ls={0.12} color="#A9BBAE" tw="uppercase">
          Plates i &amp; ii
        </text>
      </row>
      <grid
        cols={2}
        gap={40}
        tw="w-full max-w-[1240px] mx-auto"
        motion={fade}
        mobile={{ gridCols: 1, gap: 28 }}
      >
        <col tw="gap-4">
          <img src={media.joinery_macro.id} w="100%" h={460} fit="cover" radius={2} mobile={{ h: 260 }} />
          <col tw="gap-1">
            <heading tag="h3" font="EB Garamond" size={24} weight={400} color="#EFEADF">
              Plate i — through-dovetail, oak
            </heading>
            <text font="Karla" size={14} color="#A9BBAE" lh={1.7}>
              Cut by hand, sawn to the line and pared, no router jig. Finished in hardwax oil, not
              lacquer. It will mark, and you can fix it yourself with a cloth in ten minutes. That is
              the trade and we think it is the right one.
            </text>
          </col>
        </col>
        <col tw="gap-4">
          <img src={media.workshop.id} w="100%" h={460} fit="cover" radius={2} mobile={{ h: 260 }} />
          <col tw="gap-1">
            <heading tag="h3" font="EB Garamond" size={24} weight={400} color="#EFEADF">
              Plate ii — the bench room
            </heading>
            <text font="Karla" size={14} color="#A9BBAE" lh={1.7}>
              Two benches, one bandsaw, a rack of moulding planes that came with the building. Every
              piece in the catalogue above was made standing at one of these two benches.
            </text>
          </col>
        </col>
      </grid>
    </section>

    {/* 6 — prices, honestly banded */}
    <section tw="w-full px-10 py-24 max-md:px-6 max-md:py-14" bg={GROUND}>
      <grid
        cols="0.75fr 1.25fr"
        gap={64}
        tw="w-full max-w-[1240px] mx-auto items-start max-lg:gap-10"
        tablet={{ gridCols: 1 }}
        mobile={{ gridCols: 1, gap: 28 }}
      >
        <col tw="gap-3">
          <text cls="eyebrow" font="Karla" size={12} weight={600} ls={0.14} color={OAK} tw="uppercase">
            Prices, honestly banded
          </text>
          <heading tag="h2" font="EB Garamond" size={42} weight={400} lh={1.12} color={INK} mobile={{ size: 30 }}>
            Dining tables from 4,800. Chairs from 1,150 each.
          </heading>
          <text font="Karla" size={15} color={SOFT} lh={1.75}>
            Bookcases and fitted work from 6,500. Deposits are a third and are refundable until the
            timber is cut. Delivery anywhere in England and Wales is included in the price.
          </text>
        </col>
        <col tw="gap-0" motion={fade}>
          {BANDS.map((b) => (
            <PriceBand what={b.what} detail={b.detail} from={b.from} />
          ))}
        </col>
      </grid>
    </section>

    {/* 7 — the wait (the page's one centred column) */}
    <section tw="w-full px-10 py-28 max-md:px-6 max-md:py-16" bg={INK}>
      <col tw="w-full max-w-[680px] mx-auto gap-6 items-center text-center" ta="center">
        <text cls="eyebrow" font="Karla" size={12} weight={600} ls={0.14} color={OAK} tw="uppercase">
          The wait, and why it is that long
        </text>
        <heading tag="h2" font="EB Garamond" size={40} weight={400} lh={1.24} color={GROUND} ta="center" mobile={{ size: 28 }}>
          The current wait is about seven months. We will not take more than nine commissions a year,
          because ten would mean hiring someone and then it would not be our work.
        </heading>
        <text font="Karla" size={15} color="#B7ADA0" lh={1.8} ta="center">
          If that is too long, we would rather say so now than rush a piece. We will tell you the true
          date at the drawing stage and we have not missed one yet.
        </text>
      </col>
    </section>

    {/* 8 — start a conversation */}
    <section id="start" tw="w-full px-10 py-24 max-md:px-6 max-md:py-14" bg="#F0EADD">
      <grid
        cols="1.1fr 0.9fr"
        gap={64}
        tw="w-full max-w-[1240px] mx-auto items-center max-lg:gap-10"
        tablet={{ gridCols: 1 }}
        mobile={{ gridCols: 1, gap: 32 }}
      >
        <col tw="gap-5">
          <heading tag="h2" font="EB Garamond" size={52} weight={400} lh={1.08} color={INK} mobile={{ size: 34 }}>
            Start a conversation about a room.
          </heading>
          <text font="Karla" size={17} color={SOFT} lh={1.75} maxw={560}>
            Tell us the room, roughly what it has to do, and when you would like it. We will answer
            within the week, and if we are not the right workshop for it we will say who is.
          </text>
        </col>
        <col tw="gap-5 border-t border-[#DED5C6] pt-8">
          <text
            href="mailto:hello@wrenandash.co.uk"
            cls="cta"

            font="Karla"
            size={15}
            weight={600}
            ls={0.04}
            color={GROUND}
            bg={INK}
            pad={{ t: 16, r: 30, b: 16, l: 30 }}
            radius={2}
            w="hug"
            hover={{ bg: OAK, color: INK }}
            tw="hover:bg-[#A97B4F]"
          >
            Start a commission
          </text>
          <col tw="gap-1">
            <text font="Karla" size={15} color={INK} lh={1.7} href="mailto:hello@wrenandash.co.uk">
              hello@wrenandash.co.uk
            </text>
            <text font="Karla" size={15} color={SOFT} lh={1.7}>
              The workshop, Llanfihangel Crucorney, Monmouthshire
            </text>
            <text font="Karla" size={14} color={SOFT} lh={1.7}>
              Visits by arrangement, most Saturdays. Bring the dimensions of the room.
            </text>
          </col>
        </col>
      </grid>
    </section>
  </box>
);
