/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "casa-ocotillo--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'casa-ocotillo--';

export default [
  { slot: `${PREFIX}courtyard`, file: join(MEDIA_DIR, "courtyard.jpg"), alt: "The ocotillo courtyard at Casa Ocotillo in late afternoon light" },
  { slot: `${PREFIX}desert_walk`, file: join(MEDIA_DIR, "desert_walk.jpg"), alt: "A walking track through the high desert near Casa Ocotillo" },
  { slot: `${PREFIX}room_interior`, file: join(MEDIA_DIR, "room_interior.jpg"), alt: "Interior of an adobe guest room with plastered walls and linen bedding" },
  { slot: `${PREFIX}table_dinner`, file: join(MEDIA_DIR, "table_dinner.jpg"), alt: "The single nightly dinner table set for service" },
];
