/** Design tokens — The Undertow. */
export default defineTheme({
  name: 'the-undertow',
  color: {
    ground: '#F7F5F0',
    ink: '#111111',
    red: '#B3121D',
    grey: '#6F6C66',
    rule: '#D8D4CC',
    white: '#FFFFFF',
  },
  font: { head: 'Playfair Display', body: 'Spectral' },
  mode: 'literal',
});
