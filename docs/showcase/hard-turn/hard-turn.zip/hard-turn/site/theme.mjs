/** Hard Turn — brand identity agency. Tokens live here only. */
export default defineTheme({
  name: 'hard-turn',
  color: {
    ground: '#EFEFEA',
    ink: '#0A0A0A',
    shock: '#FF3B00',
    ultra: '#2B00FF',
    paper: '#FFFFFF',
  },
  font: { head: 'Syne', body: 'DM Sans' },
  mode: 'literal',
});
