# Editionable

White-cube gallery calm; edition numbers as the structure.

|  |  |
|---|---|
| **Slug** | `editionable` (deploys to `/editionable/`) |
| **Archetype** | asymmetric diagonal collage |
| **Industry** | Art platform |
| **Page title** | Editionable |
| **Fonts** | Italiana, Jost — Google Fonts, imported by Elementor automatically |
| **Elements** | 204 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (120 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install editionable
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
editionable/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/editionable.page.jsx           the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FAF7F4` |
| `ink` | `#161412` |
| `accent` | `#7B3FE4` |
| `warm` | `#E8B04B` |
| `rule` | `#DDD6CF` |

Change a value, re-run `npx exjsx-kit install editionable`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/editionable.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `artist_studio` | `media/artist_studio.jpg` | An artist at work in a daylit studio, prints drying on the wall |
| `gallery_wall` | `media/gallery_wall.jpg` | A hung gallery wall of framed editions at mixed scale |
| `print_macro` | `media/print_macro.jpg` | Macro detail of a giclée print showing paper grain and ink |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
