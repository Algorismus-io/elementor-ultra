/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "field-to-pass--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'field-to-pass--';

export default [
  { slot: `${PREFIX}grower`, file: join(MEDIA_DIR, "grower.jpg"), alt: "A grower in the field, crates of just-lifted produce beside them" },
  { slot: `${PREFIX}kitchen_prep`, file: join(MEDIA_DIR, "kitchen_prep.jpg"), alt: "Chef prepping vegetables on a restaurant pass at first light" },
  { slot: `${PREFIX}produce_strip`, file: join(MEDIA_DIR, "produce_strip.jpg"), alt: "A row of seasonal produce laid out across a bench" },
];
