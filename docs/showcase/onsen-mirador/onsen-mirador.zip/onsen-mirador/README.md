# Onsen Mirador

Steam, dark water, a serif that whispers. Best mood on the sheet.

|  |  |
|---|---|
| **Slug** | `onsen-mirador` (deploys to `/onsen-mirador/`) |
| **Archetype** | split-screen scroller |
| **Industry** | Bathhouse and spa |
| **Page title** | Onsen Mirador |
| **Fonts** | Cinzel, Cormorant Garamond — Google Fonts, imported by Elementor automatically |
| **Elements** | 171 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (73 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install onsen-mirador
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
onsen-mirador/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/onsen-mirador.page.jsx         the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#0E1416` |
| `ink` | `#E8EEEC` |
| `steam` | `#9FBDBD` |
| `cedar` | `#A0714B` |
| `stone` | `#3A4448` |

Change a value, re-run `npx exjsx-kit install onsen-mirador`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/onsen-mirador.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `onsen_steam_pool` | `media/steam_pool.jpg` | Steam rising off the surface of a geothermal pool cut into basalt |
| `onsen_cold_well` | `media/cold_well.jpg` | The cold well, a small dark plunge pool at six degrees |
| `onsen_long_pool` | `media/long_pool.jpg` | The long pool, twenty-eight metres open to the sky |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
