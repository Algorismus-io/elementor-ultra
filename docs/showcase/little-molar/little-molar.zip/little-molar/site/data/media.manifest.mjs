/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "little-molar--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'little-molar--';

export default [
  { slot: `${PREFIX}child_chair`, file: join(MEDIA_DIR, "child_chair.jpg"), alt: "A young child sitting calmly in a dental chair at Little Molar" },
  { slot: `${PREFIX}waiting_room`, file: join(MEDIA_DIR, "waiting_room.jpg"), alt: "The bright, toy-filled waiting room at Little Molar" },
];
