import { MODULES, PATCHES, CASES } from '../data/modules.mjs';
import { MEDIA } from '../data/media.mjs';

export const meta = {
  title: 'Voltcraft VX — Modular Synthesizer Hardware',
  slug: 'voltcraft-modular',
  seo: {
    title: 'Voltcraft VX — Twelve analogue Eurorack modules, every schematic published',
    description: 'Analogue Eurorack from a workshop in Tallinn. Twelve modules with HP, current draw and price on every tile, full schematics and BOM in the box, and an eleven minute calibration you do yourself.',
  },
};

const GROUND = '#0B0B0D';
const PANEL = '#17171B';
const INK = '#E7E4DC';
const KNOB = '#D8452F';
const JACK = '#C9A227';
const TRACE = '#2A6B5F';
const DIM = '#8A867D';
const LINE = '#2A2A31';

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* ── repeaters: content props only ─────────────────────────────────────── */

const ModuleTile = defineComponent(
  ({ name = 'VX-0', kind = 'Module', hp = '0HP', power = '0mA', note = '', price = '0' }) => (
    <box
      tw="flex flex-col gap-4 p-6"
      bg={PANEL}
      border={[1, LINE]}
      radius={3}
      shadow={[[0, 0, 1, '#000000', 0, 'inset'], [2, 14, -6, '#00000099']]}
      hover={{ border: [1, KNOB], bg: '#1C1C21' }}
    >
      <box tw="flex flex-row items-end justify-between gap-3 w-full">
        <heading tag="h3" size={19} weight={700} font="Orbitron" color={INK} ls={0.037}>{name}</heading>
        <text size={12} font="Space Mono" weight={700} color={JACK} ls={0.074}>{hp}</text>
      </box>
      <text size={14} font="Space Mono" color={KNOB} lh={1.4} ls={0.03}>{kind}</text>
      <box tw="w-full" h={1} bg={LINE} />
      <text size={12} font="Space Mono" color={TRACE} lh={1.6} ls={0.022}>{power}</text>
      <text size={13} font="Space Mono" color={DIM} lh={1.75}>{note}</text>
      <box tw="flex flex-row items-center justify-between gap-3 w-full" pad={{ t: 6 }}>
        <text size={22} font="Orbitron" weight={700} color={INK}>{price}</text>
        <text size={11} font="Space Mono" color={DIM} ls={0.074}>EUR · IN STOCK</text>
      </box>
    </box>
  ),
  {
    title: 'VX Catalogue Tile',
    props: {
      name: { label: 'Model', group: 'Module' },
      kind: { label: 'Type', group: 'Module' },
      hp: { label: 'Width (HP)', group: 'Specs' },
      power: { label: 'Current draw', group: 'Specs' },
      note: { label: 'Detail line', group: 'Module' },
      price: { label: 'Price (EUR)', group: 'Specs' },
    },
  },
);

const PatchCard = defineComponent(
  ({ n = '00', title = 'Patch', mods = '', body = '' }) => (
    <box tw="flex flex-col gap-3 pt-6" border={[1, 'transparent']}>
      <box tw="w-full" h={2} bg={KNOB} maxw={44} />
      <box tw="flex flex-row items-end gap-3 w-full" pad={{ t: 10 }}>
        <text size={13} font="Space Mono" weight={700} color={JACK} ls={0.074}>{n}</text>
        <heading tag="h3" size={17} weight={700} font="Orbitron" color={INK} lh={1.3}>{title}</heading>
      </box>
      <text size={12} font="Space Mono" color={TRACE} ls={0.044}>{mods}</text>
      <text size={13} font="Space Mono" color={DIM} lh={1.85}>{body}</text>
    </box>
  ),
  {
    title: 'VX Demo Patch',
    props: {
      n: { label: 'Number', group: 'Patch' },
      title: { label: 'Title', group: 'Patch' },
      mods: { label: 'Modules used', group: 'Patch' },
      body: { label: 'Description', group: 'Patch' },
    },
  },
);

/* ── small local helpers (inline expansion, styles allowed) ─────────────── */

const Eyebrow = ({ children, tone = JACK }) => (
  <text size={11} font="Space Mono" weight={700} color={tone} ls={0.178}>{children}</text>
);

const Rule = () => <box tw="w-full" h={1} bg={LINE} />;

export default () => (
  <box tw="flex flex-col w-full items-center" bg={GROUND} pad={0}>

    {/* ── 0. masthead ─────────────────────────────────────────────────── */}
    <box tw="flex flex-row items-center justify-between w-full gap-6 px-10 py-5 max-md:px-6 max-md:flex-col max-md:items-start max-md:gap-2" bg={GROUND} border={[1, LINE]}>
      <text size={15} font="Orbitron" weight={700} color={INK} ls={0.148} mobile={{ ls: 0.074, size: 14 }}>VOLTCRAFT VX</text>
      <text size={11} font="Space Mono" color={DIM} ls={0.074} tw="max-md:hidden">TALLINN · EST 2014</text>
      <text href="#range" size={11} font="Space Mono" weight={700} color={JACK} ls={0.104} hover={{ color: KNOB }}>SEE THE RANGE</text>
    </box>

    {/* ── 1. hero: asymmetric, copy left / panel photo right ──────────── */}
    <box tw="flex flex-row w-full items-stretch max-lg:flex-col" bg={GROUND}>
      <box tw="flex flex-col gap-7 justify-center px-10 py-24 max-md:px-6 max-md:py-16" w="56%" tablet={{ w: '100%' }} mobile={{ w: '100%' }}>
        <Eyebrow>ANALOGUE EURORACK · TALLINN</Eyebrow>
        <h1 size={54} weight={700} font="Orbitron" color={INK} lh={1.12} ls={-0.037} maxw={620} tablet={{ size: 42 }} mobile={{ size: 30 }}>
          Twelve modules. Every schematic published.
        </h1>
        <text size={15} font="Space Mono" color={DIM} lh={1.9} maxw={560} mobile={{ size: 13 }}>
          Analogue Eurorack from a workshop in Tallinn. Through-hole where it matters, matched transistor pairs in every VCO, and a full schematic and BOM in the box so you can fix it in twenty years.
        </text>
        <box tw="flex flex-row items-center gap-4 max-md:flex-col max-md:items-stretch" pad={{ t: 8 }}>
          <text
            href="#range"
            tw="px-8 py-4 text-center"
            size={13} font="Orbitron" weight={700} color={GROUND} bg={KNOB} radius={2} ls={0.089}
            hover={{ bg: JACK, color: GROUND }}
          >
            See the range
          </text>
          <text href="#power" tw="px-8 py-4 text-center" size={13} font="Space Mono" weight={700} color={INK} border={[1, LINE]} radius={2} ls={0.074} hover={{ border: [1, JACK], color: JACK }}>
            Power budget calculator
          </text>
        </box>
        <box tw="flex flex-row gap-10 w-full max-md:gap-6" pad={{ t: 18 }}>
          <box tw="flex flex-col gap-1">
            <text size={20} font="Orbitron" weight={700} color={JACK}>134HP</text>
            <text size={11} font="Space Mono" color={DIM} ls={0.074}>FULL RANGE WIDTH</text>
          </box>
          <box tw="flex flex-col gap-1">
            <text size={20} font="Orbitron" weight={700} color={JACK}>640mA</text>
            <text size={11} font="Space Mono" color={DIM} ls={0.074}>+12V TOTAL DRAW</text>
          </box>
          <box tw="flex flex-col gap-1">
            <text size={20} font="Orbitron" weight={700} color={JACK}>2 DAYS</text>
            <text size={11} font="Space Mono" color={DIM} ls={0.074}>SHIPS FROM ESTONIA</text>
          </box>
        </box>
      </box>
      <box tw="flex flex-col w-full" w="44%" tablet={{ w: '100%' }} mobile={{ w: '100%' }} bg={PANEL} border={[1, LINE]}>
        <img src={MEDIA.module_front.id} tw="w-full" h={480} fit="cover" tablet={{ h: 360 }} mobile={{ h: 260 }} />
        <box tw="flex flex-col gap-2 px-8 py-6 max-md:px-6">
          <text size={11} font="Space Mono" color={JACK} ls={0.119}>VX-3 DUAL VCO · 14HP</text>
          <text size={13} font="Space Mono" color={DIM} lh={1.7}>Matched transistor pair, through-zero FM, 0.2 cent drift over an hour. Four trimmers on the back, all of them documented.</text>
        </box>
      </box>
    </box>

    {/* ── 2. catalogue grid ───────────────────────────────────────────── */}
    <box id="range" tw="flex flex-col w-full gap-10 px-10 py-24 max-md:px-6 max-md:py-16" bg="#0E0E11">
      <box tw="flex flex-row items-end justify-between w-full gap-6 max-md:flex-col max-md:items-start">
        <box tw="flex flex-col gap-4" maxw={640}>
          <Eyebrow>01 — THE RANGE</Eyebrow>
          <heading tag="h2" size={34} weight={700} font="Orbitron" color={INK} lh={1.2} mobile={{ size: 24 }}>
            The catalogue, with the numbers on the tile
          </heading>
          <text size={14} font="Space Mono" color={DIM} lh={1.8}>
            HP width, current draw on both rails, and the price. Nothing hidden behind a datasheet link, because you are planning a case and you need all three at once.
          </text>
        </box>
        <text size={11} font="Space Mono" color={TRACE} ls={0.104} tw="max-md:pt-2">12 MODULES · 134HP · 640mA / 310mA</text>
      </box>
      <Rule />
      <grid cols={3} gap={20} tw="w-full" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }} motion={FADE}>
        {MODULES.map((m) => (
          <ModuleTile
            name={m.name}
            kind={m.kind}
            hp={`${m.hp}HP`}
            power={`${m.plus}mA +12V / ${m.minus}mA -12V`}
            note={m.note}
            price={String(m.price)}
          />
        ))}
      </grid>
    </box>

    {/* ── 3. signal path ──────────────────────────────────────────────── */}
    <box tw="flex flex-row w-full items-stretch max-lg:flex-col" bg={GROUND} border={[1, LINE]}>
      <box tw="flex flex-col gap-6 justify-center px-10 py-20 max-md:px-6 max-md:py-14" w="50%" tablet={{ w: '100%' }} mobile={{ w: '100%' }} bg={PANEL}>
        <Eyebrow tone={TRACE}>02 — SIGNAL PATH</Eyebrow>
        <heading tag="h2" size={30} weight={700} font="Orbitron" color={INK} lh={1.25} mobile={{ size: 23 }}>
          What is analogue, and what is not
        </heading>
        <text size={15} font="Space Mono" color={INK} lh={1.9} maxw={520} mobile={{ size: 13 }}>
          The audio path is entirely analogue. The only digital parts are the tuning helper and the preset memory, and both can be bypassed with a jumper on the back.
        </text>
        <text size={13} font="Space Mono" color={DIM} lh={1.8} maxw={520}>
          We say this plainly because the word analogue gets stretched. No DSP sits between your input jack and your output jack on any module in the range — measure it if you like, the test points are marked on the board.
        </text>
      </box>
      <box tw="flex flex-col w-full justify-center gap-5 px-10 py-20 max-md:px-6 max-md:py-14" w="50%" tablet={{ w: '100%' }} mobile={{ w: '100%' }}>
        {[
          ['ANALOGUE', 'Oscillator cores', 'Discrete, matched pair, temperature compensated', TRACE],
          ['ANALOGUE', 'Filters and VCAs', 'Transistor ladder and OTA, no lookup tables anywhere', TRACE],
          ['ANALOGUE', 'Envelopes and LFOs', 'RC timing, voltage controlled, sub-millisecond attack', TRACE],
          ['DIGITAL', 'Tuning helper', 'A microcontroller reading pitch. Jumper JP1 removes it.', JACK],
          ['DIGITAL', 'Preset memory', 'Stores knob positions only. Jumper JP2 removes it.', JACK],
        ].map(([tag, title, body, tone]) => (
          <box tw="flex flex-col gap-2 pl-5 py-3" border={[1, LINE]} radius={2} bg="#101014" hover={{ bg: '#141419' }} pad={{ l: 18, t: 14, b: 14, r: 14 }}>
            <box tw="flex flex-row items-center gap-3">
              <text size={10} font="Space Mono" weight={700} color={tone} ls={0.133}>{tag}</text>
              <heading tag="h3" size={15} weight={700} font="Orbitron" color={INK}>{title}</heading>
            </box>
            <text size={12.5} font="Space Mono" color={DIM} lh={1.7}>{body}</text>
          </box>
        ))}
      </box>
    </box>

    {/* ── 4. open schematics + repair policy ──────────────────────────── */}
    <box tw="flex flex-row w-full items-stretch max-lg:flex-col-reverse" bg="#0E0E11">
      <box tw="flex flex-col w-full" w="45%" tablet={{ w: '100%' }} mobile={{ w: '100%' }}>
        <img src={MEDIA.workshop_solder.id} tw="w-full" h={700} fit="cover" tablet={{ h: 320 }} mobile={{ h: 240 }} />
      </box>
      <box tw="flex flex-col gap-6 justify-center px-12 py-24 max-md:px-6 max-md:py-16" w="55%" tablet={{ w: '100%' }} mobile={{ w: '100%' }}>
        <Eyebrow>03 — OPEN BY DEFAULT</Eyebrow>
        <heading tag="h2" size={32} weight={700} font="Orbitron" color={INK} lh={1.2} mobile={{ size: 24 }}>
          Open schematics and the repair policy
        </heading>
        <text size={15} font="Space Mono" color={INK} lh={1.9} maxw={560} mobile={{ size: 13 }}>
          Full schematics, board files and calibration procedures are published for every module, including discontinued ones. Repair it yourself, or send it to us at cost plus postage forever.
        </text>
        <Rule />
        <box tw="flex flex-col gap-4 w-full">
          {[
            ['SCHEMATIC PDF', 'Every revision, including the two we got wrong in 2017'],
            ['GERBERS AND BOM', 'Board files and a sourced parts list with substitutions marked'],
            ['REPAIR AT COST', 'Parts plus postage, no labour charge, no expiry date'],
            ['SPARES FOREVER', 'Panels, knobs and matched transistor pairs sold individually'],
          ].map(([k, v]) => (
            <box tw="flex flex-row gap-6 w-full items-end max-md:flex-col max-md:gap-1">
              <text size={11} font="Space Mono" weight={700} color={KNOB} ls={0.104} w={180} mobile={{ w: '100%' }}>{k}</text>
              <text size={13} font="Space Mono" color={DIM} lh={1.7} flex={1}>{v}</text>
            </box>
          ))}
        </box>
      </box>
    </box>

    {/* ── 5. calibration ──────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full gap-10 px-10 py-24 max-md:px-6 max-md:py-16" bg={PANEL} border={[1, LINE]}>
      <box tw="flex flex-row items-end justify-between w-full gap-8 max-md:flex-col max-md:items-start">
        <box tw="flex flex-col gap-4" maxw={600}>
          <Eyebrow tone={KNOB}>04 — CALIBRATION</Eyebrow>
          <heading tag="h2" size={32} weight={700} font="Orbitron" color={INK} lh={1.2} mobile={{ size: 24 }}>
            Eleven minutes, at your desk
          </heading>
        </box>
        <text size={14} font="Space Mono" color={DIM} lh={1.8} maxw={480}>
          Eleven minutes with a multimeter and a tuner, four trimmers, and a printed card that walks you through it. No proprietary jig, no returning it to the factory.
        </text>
      </box>
      <grid cols={4} gap={18} tw="w-full" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }} motion={FADE}>
        {[
          ['00:00', 'Warm up', 'Power the module in the case and leave it for three minutes. Cold trimming is why people think analogue drifts.'],
          ['03:00', 'Scale, TR1', 'Play C2 and C4, adjust until the octave is exact on the tuner. Two passes, it converges.'],
          ['07:00', 'Offset, TR2', 'Set the low reference against the meter at the marked test point. One turn, rarely more.'],
          ['09:00', 'Shape, TR3 and TR4', 'Trim the triangle apex and the pulse symmetry by ear or by scope. Write the date on the card.'],
        ].map(([t, title, body]) => (
          <box tw="flex flex-col gap-3 p-6" bg={GROUND} border={[1, LINE]} radius={3} hover={{ border: [1, JACK] }}>
            <text size={12} font="Space Mono" weight={700} color={JACK} ls={0.119}>{t}</text>
            <heading tag="h3" size={16} weight={700} font="Orbitron" color={INK} lh={1.3}>{title}</heading>
            <text size={12.5} font="Space Mono" color={DIM} lh={1.8}>{body}</text>
          </box>
        ))}
      </grid>
    </box>

    {/* ── 6. demo patches ─────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full gap-10 px-10 py-24 max-md:px-6 max-md:py-16" bg={GROUND}>
      <box tw="flex flex-col gap-4" maxw={680}>
        <Eyebrow>05 — DEMO PATCHES</Eyebrow>
        <heading tag="h2" size={32} weight={700} font="Orbitron" color={INK} lh={1.2} mobile={{ size: 24 }}>
          Six patches, written out in full
        </heading>
        <text size={14} font="Space Mono" color={DIM} lh={1.8}>
          Not videos. Descriptions you can follow with cables in your hand, using modules you can see on the tiles above.
        </text>
      </box>
      <grid cols={3} gap={28} tw="w-full" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }} motion={FADE}>
        {PATCHES.map((p) => (
          <PatchCard n={p.n} title={p.title} mods={p.mods} body={p.body} />
        ))}
      </grid>
    </box>

    {/* ── 7. power budget ─────────────────────────────────────────────── */}
    <box id="power" tw="flex flex-row w-full items-stretch max-lg:flex-col" bg="#0E0E11" border={[1, LINE]}>
      <box tw="flex flex-col gap-7 justify-center px-10 py-24 max-md:px-6 max-md:py-16" w="60%" tablet={{ w: '100%' }} mobile={{ w: '100%' }}>
        <Eyebrow tone={TRACE}>06 — POWER BUDGET</Eyebrow>
        <heading tag="h2" size={32} weight={700} font="Orbitron" color={INK} lh={1.2} mobile={{ size: 24 }}>
          Will it fit your case?
        </heading>
        <text size={15} font="Space Mono" color={INK} lh={1.9} maxw={620} mobile={{ size: 13 }}>
          The whole twelve-module range draws 640mA on +12V and 310mA on -12V. Type your case into the calculator and it will tell you honestly if you are cutting it fine.
        </text>
        <box tw="flex flex-col w-full" border={[1, LINE]} radius={3} bg={PANEL}>
          <box tw="flex flex-row w-full gap-4 px-5 py-3 max-md:hidden" border={[1, LINE]}>
            <text size={10} font="Space Mono" weight={700} color={DIM} ls={0.119} flex={2}>CASE</text>
            <text size={10} font="Space Mono" weight={700} color={DIM} ls={0.119} flex={1}>SUPPLY</text>
            <text size={10} font="Space Mono" weight={700} color={DIM} ls={0.119} flex={2}>VERDICT</text>
          </box>
          {CASES.map((c) => (
            <box tw="flex flex-row w-full gap-4 px-5 py-4 items-end max-md:flex-col max-md:gap-1" border={[1, LINE]} hover={{ bg: '#1C1C21' }}>
              <text size={13} font="Space Mono" color={INK} lh={1.6} flex={2}>{c.label}</text>
              <text size={12} font="Space Mono" color={JACK} lh={1.6} flex={1}>{c.budget}</text>
              <text size={12.5} font="Space Mono" color={c.tone === 'ok' ? TRACE : KNOB} lh={1.6} flex={2}>{c.verdict}</text>
            </box>
          ))}
        </box>
        <text size={12} font="Space Mono" color={DIM} lh={1.8} maxw={620}>
          The calculator adds a twenty percent margin by default, because a supply running at its rating all evening is a supply that gets warm and starts adding hum to your VCAs.
        </text>
      </box>
      <box tw="flex flex-col w-full" w="40%" tablet={{ w: '100%' }} mobile={{ w: '100%' }}>
        <img src={MEDIA.rack_patched.id} tw="w-full h-full" h={620} fit="cover" tablet={{ h: 340 }} mobile={{ h: 240 }} />
      </box>
    </box>

    {/* ── 8. kits vs assembled ────────────────────────────────────────── */}
    <box tw="flex flex-col w-full gap-10 px-10 py-24 max-md:px-6 max-md:py-16" bg={GROUND}>
      <box tw="flex flex-col gap-4" maxw={680}>
        <Eyebrow tone={KNOB}>07 — KIT OR ASSEMBLED</Eyebrow>
        <heading tag="h2" size={32} weight={700} font="Orbitron" color={INK} lh={1.2} mobile={{ size: 24 }}>
          Which one should you buy
        </heading>
        <text size={15} font="Space Mono" color={INK} lh={1.9} mobile={{ size: 13 }}>
          Kits are 35 percent cheaper and take about four hours. Buy the kit if you have soldered before. Buy assembled if this would be your first board and you want to make music this month.
        </text>
      </box>
      <grid cols={2} gap={24} tw="w-full" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
        <box tw="flex flex-col gap-5 p-9 max-md:p-6" bg={PANEL} border={[1, LINE]} radius={3} hover={{ border: [1, JACK] }}>
          <box tw="flex flex-row items-end justify-between w-full gap-4 max-md:flex-col max-md:items-start max-md:gap-2">
            <heading tag="h3" size={22} weight={700} font="Orbitron" color={JACK}>KIT</heading>
            <text size={12} font="Space Mono" color={DIM} ls={0.074}>-35% · ~4 HOURS</text>
          </box>
          <Rule />
          {['Through-hole throughout, no pre-placed SMD to be scared of', 'Sorted and labelled parts, printed build guide, spare trimmers', 'Matched transistor pairs come pre-matched and taped in order', 'One free replacement board if you cook one, no questions'].map((s) => (
            <text size={13} font="Space Mono" color={DIM} lh={1.75}>{s}</text>
          ))}
          <text size={13} font="Space Mono" weight={700} color={INK} lh={1.7} pad={{ t: 6 }}>Buy the kit if you have soldered before.</text>
        </box>
        <box tw="flex flex-col gap-5 p-9 max-md:p-6" bg="#1A1113" border={[1, KNOB]} radius={3} hover={{ bg: '#20161A' }}>
          <box tw="flex flex-row items-end justify-between w-full gap-4 max-md:flex-col max-md:items-start max-md:gap-2">
            <heading tag="h3" size={22} weight={700} font="Orbitron" color={KNOB}>ASSEMBLED</heading>
            <text size={12} font="Space Mono" color={DIM} ls={0.074}>CALIBRATED · TESTED</text>
          </box>
          <Rule />
          {['Built, burned in for 24 hours and calibrated on our bench', 'Same schematic, same BOM, same repair policy, same trimmers', 'Ships in 2 days from Estonia with the calibration card signed', 'Two year warranty, and repair at cost after that forever'].map((s) => (
            <text size={13} font="Space Mono" color={DIM} lh={1.75}>{s}</text>
          ))}
          <text size={13} font="Space Mono" weight={700} color={INK} lh={1.7} pad={{ t: 6 }}>Buy assembled if this would be your first board.</text>
        </box>
      </grid>
    </box>

    {/* ── 9. order or find a dealer ───────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center gap-7 px-10 py-24 text-center max-md:px-6 max-md:py-16" bg={PANEL} border={[1, LINE]}>
      <Eyebrow>08 — ORDER</Eyebrow>
      <heading tag="h2" size={36} weight={700} font="Orbitron" color={INK} lh={1.2} maxw={760} ta="center" mobile={{ size: 25 }}>
        Order direct, or find a dealer
      </heading>
      <text size={15} font="Space Mono" color={DIM} lh={1.9} maxw={620} ta="center" mobile={{ size: 13 }}>
        Ships from Estonia in 2 days. Dealers in nine countries listed with stock levels updated nightly.
      </text>
      <box tw="flex flex-row items-center justify-center gap-4 max-md:flex-col max-md:items-stretch max-md:w-full" pad={{ t: 8 }}>
        <text href="#range" tw="px-9 py-4 text-center" size={13} font="Orbitron" weight={700} color={GROUND} bg={KNOB} radius={2} ls={0.089} hover={{ bg: JACK }}>
          See the range
        </text>
        <text href="#power" tw="px-9 py-4 text-center" size={13} font="Space Mono" weight={700} color={INK} border={[1, LINE]} radius={2} ls={0.074} hover={{ border: [1, JACK], color: JACK }}>
          Find a dealer
        </text>
      </box>
      <text size={11} font="Space Mono" color={TRACE} ls={0.104} ta="center" pad={{ t: 10 }}>
        VOLTCRAFT VX · TALLINN, ESTONIA · SCHEMATICS FOR EVERY MODULE, INCLUDING THE DISCONTINUED ONES
      </text>
    </box>
  </box>
);
