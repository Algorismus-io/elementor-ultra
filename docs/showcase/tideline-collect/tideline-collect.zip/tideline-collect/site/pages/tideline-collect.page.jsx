/** Tideline — single-column long-form landing page. */
import { MEDIA as M } from '../data/media.mjs';

export const meta = {
  title: 'Tideline — 14 booms, 41 tonnes, published weekly',
  slug: 'tideline-collect',
  seo: {
    title: 'Tideline — river-mouth plastic interception, published weekly',
    description:
      'Tideline runs 14 river-mouth interception booms and publishes the tonnage from every device every week, including the three that are not working.',
  },
};

/* ── data ─────────────────────────────────────────────────────────────── */

const BOOMS = [
  { code: '01', site: 'Calder Mouth', t: '0.14', d: '+6%' },
  { code: '02', site: 'Ardleigh Cut', t: '0.11', d: '+2%' },
  { code: '03', site: 'Penrose Creek', t: '0.09', d: '−4%' },
  { code: '04', site: 'Sandbar Reach', t: '0.02', d: '−71%', low: true },
  { code: '05', site: 'Mill Quay', t: '0.13', d: '+11%' },
  { code: '06', site: 'Trescoe Bight', t: '0.08', d: '−1%' },
  { code: '07', site: 'Halloway Drain', t: '0.12', d: '+9%' },
  { code: '08', site: 'Fenn Estuary', t: '0.10', d: '+3%' },
  { code: '09', site: 'Weedbank', t: '0.03', d: '−68%', low: true },
  { code: '10', site: 'Coombe Head', t: '0.07', d: '−6%' },
  { code: '11', site: 'Long Sands', t: '0.02', d: '−74%', low: true },
  { code: '12', site: 'Baxter Reach', t: '0.09', d: '+4%' },
  { code: '13', site: 'Otterhead', t: '0.08', d: '0%' },
  { code: '14', site: 'Saltings Gate', t: '0.06', d: '−9%' },
];

const MIX = [
  { label: 'Packaging film', pct: 34 },
  { label: 'Bottles and caps', pct: 22 },
  { label: 'Fishing gear', pct: 18 },
  { label: 'Unsorted fragment', pct: 15 },
  { label: 'Expanded foam', pct: 11 },
];

const SATURDAY = [
  ['08:30', 'Meet at the hard standing', 'Boots, gloves and a hot drink. Nobody is turned away for being late.'],
  ['09:15', 'Lift the boom', 'Two crew on the workboat, everyone else on the winch line and the tally sheet.'],
  ['10:30', 'Sort by hand', 'Five graded bags: film, bottles, gear, foam, fragment. This is four of the six hours.'],
  ['12:30', 'Stop for forty minutes', 'Soup from a flask. The wind does not stop, so we eat facing away from it.'],
  ['14:30', 'Weigh, log, publish', 'The number goes on the boom page before anyone drives home, good or bad.'],
];

const COSTS = [
  ['Boom hardware, moorings and repair', '128'],
  ['Workboat, fuel and crew', '76'],
  ['Sorting, haulage and processor gate fees', '84'],
  ['Monitoring, weighing and publishing', '52'],
];

/* ── components ───────────────────────────────────────────────────────── */

const BoomRow = defineComponent(
  ({ code = '01', site = 'Site', tonnes = '0.00 t', delta = '0%' }) => (
    <div cls="boom-row" tw="w-full flex flex-col">
      <div cls="boom-row-line" tw="w-full flex flex-row items-end justify-between gap-4 py-3">
        <text cls="boom-code" size={13} font="Nunito Sans" weight={700} color="#1E6B7A" w={34} ls="0.6px">
          {code}
        </text>
        <text size={16} font="Nunito Sans" weight={600} color="#132226" flex={1} mobile={{ size: 15 }}>
          {site}
        </text>
        <text size={16} font="Fraunces" weight={600} color="#132226" ta="right" w={72}>
          {tonnes}
        </text>
        <text size={14} font="Nunito Sans" weight={700} color="#4A7A4E" ta="right" w={62}>
          {delta}
        </text>
      </div>
      <box tw="w-full h-[1px]" bg="#D4E0E2" />
    </div>
  ),
  {
    title: 'Boom row (on projection)',
    props: {
      code: { label: 'Boom no.', group: 'Boom' },
      site: { label: 'Site name', group: 'Boom' },
      tonnes: { label: 'Tonnes this week', group: 'Boom' },
      delta: { label: 'Vs projection', group: 'Boom' },
    },
  },
);

const BoomRowLow = defineComponent(
  ({ code = '04', site = 'Site', tonnes = '0.00 t', delta = '−70%' }) => (
    <div cls="boom-row" tw="w-full flex flex-col">
      <div cls="boom-row-line" tw="w-full flex flex-row items-end justify-between gap-4 py-3">
        <text cls="boom-code-low" size={13} font="Nunito Sans" weight={700} color="#E2653A" w={34} ls="0.6px">
          {code}
        </text>
        <text size={16} font="Nunito Sans" weight={600} color="#132226" flex={1} mobile={{ size: 15 }}>
          {site}
        </text>
        <text size={16} font="Fraunces" weight={600} color="#E2653A" ta="right" w={72}>
          {tonnes}
        </text>
        <text size={14} font="Nunito Sans" weight={700} color="#E2653A" ta="right" w={62}>
          {delta}
        </text>
      </div>
      <box tw="w-full h-[1px]" bg="#D4E0E2" />
    </div>
  ),
  {
    title: 'Boom row (under projection)',
    props: {
      code: { label: 'Boom no.', group: 'Boom' },
      site: { label: 'Site name', group: 'Boom' },
      tonnes: { label: 'Tonnes this week', group: 'Boom' },
      delta: { label: 'Vs projection', group: 'Boom' },
    },
  },
);

const Eyebrow = ({ n, children, tone = '#1E6B7A' }) => (
  <div cls="eyebrow" tw="flex flex-row items-center gap-3">
    <text size={12} font="Nunito Sans" weight={800} color={tone} ls="1.4px">
      {n}
    </text>
    <box tw="w-6 h-[2px]" bg={tone} />
    <text size={12} font="Nunito Sans" weight={700} color={tone} ls="1.4px">
      {children}
    </text>
  </div>
);

const Bar = ({ label, pct, tone }) => (
  <div cls="mix-bar" tw="w-full flex flex-col gap-2">
    <div cls="mix-bar-head" tw="w-full flex flex-row items-end justify-between gap-4">
      <text size={16} font="Nunito Sans" weight={600} color="#132226">
        {label}
      </text>
      <text size={18} font="Fraunces" weight={600} color={tone}>
        {`${pct}%`}
      </text>
    </div>
    <box cls="mix-track" tw="w-full h-[10px] rounded-full" bg="#D4E0E2">
      <box cls="mix-fill" tw="h-[10px] rounded-full" w={`${pct * 2}%`} bg={tone} />
    </box>
  </div>
);

/* ── page ─────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>
    {/* masthead */}
    <section tw="w-full flex flex-col items-center px-6" bg={t.color.ink}>
      <div tw="w-full max-w-[900px] flex flex-row items-center justify-between gap-4 py-4">
        <text size={17} font={t.font.head} weight={600} color={t.color.white} ls={0.4}>
          Tideline
        </text>
        <text size={12} font={t.font.body} weight={600} color="#8FB6BD" ls="0.8px" mobile={{ size: 11 }}>
          Every boom reports weekly
        </text>
      </div>
    </section>

    {/* 1 — hero + live tonnage from 14 booms */}
    <section tw="w-full flex flex-col items-center px-6 pt-24 pb-16 max-md:pt-14 max-md:pb-10" bg={t.color.ground}>
      <div tw="w-full max-w-[900px] flex flex-col gap-8">
        <Eyebrow n="01">LIVE TONNAGE · WEEK 33</Eyebrow>
        <h1
          tw="w-full"
          size={62}
          weight={600}
          font={t.font.head}
          color={t.color.ink}
          lh={1.06}
          maxw={840}
          tablet={{ size: 48 }}
          mobile={{ size: 32 }}
        >
          14 booms. 41 tonnes this year. And three of them are not working.
        </h1>
        <p size={19} font={t.font.body} color="#3C5257" lh={1.7} maxw={660} mobile={{ size: 17 }}>
          Tideline intercepts plastic at river mouths before it reaches open water, because a tonne
          caught in a river is a tonne that never has to be found in an ocean. Every device reports
          its own tonnage weekly, including the bad weeks.
        </p>
        <div tw="flex flex-row items-center gap-5 flex-wrap">
          <text
            href="#give"
            size={16}
            font={t.font.body}
            weight={700}
            color={t.color.white}
            bg={t.color.sea}
            pad={{ t: 15, b: 15, l: 30, r: 30 }}
            radius={999}
            shadow={[
              [2, 6, 0, 'rgba(19,34,38,0.10)'],
              [10, 24, -6, 'rgba(30,107,122,0.35)'],
            ]}
            hover={{ bg: '#175661' }}
          >
            Fund a boom
          </text>
          <text href="#booms" size={16} font={t.font.body} weight={700} color={t.color.sea} hover={{ color: '#132226' }}>
            Read this week's numbers ↓
          </text>
        </div>
      </div>
    </section>

    {/* full-bleed river band */}
    <section tw="w-full flex flex-col items-center px-0" bg={t.color.ink}>
      <img src={M.boom_river.id} tw="w-full" h={420} fit="cover" tablet={{ h: 320 }} mobile={{ h: 230 }} />
      <div tw="w-full max-w-[900px] flex flex-row justify-between gap-6 px-6 py-4 flex-wrap max-md:flex-col max-md:gap-2">
        <text size={13} font={t.font.body} color="#8FB6BD" lh={1.6} flex={1} minh={0} mobile={{ w: '100%' }}>
          Boom 05, Mill Quay, on the ebb. The float line does the work; the skirt holds 400 mm below
          the surface so fish pass under it.
        </text>
        <text size={13} font={t.font.body} weight={700} color={t.color.white} ls="0.6px">
          1.14 t THIS WEEK
        </text>
      </div>
    </section>

    {/* the ledger */}
    <section id="booms" cls="band" tw="w-full flex flex-col items-center px-6 py-20 max-md:py-14" bg={t.color.white}>
      <div tw="w-full max-w-[900px] flex flex-col gap-8">
        <div tw="w-full flex flex-row items-end justify-between gap-6 flex-wrap">
          <h2 size={34} weight={600} font={t.font.head} color={t.color.ink} lh={1.15} maxw={520} mobile={{ size: 26 }}>
            This week, device by device
          </h2>
          <text size={14} font={t.font.body} color="#5C7276" lh={1.6} maxw={280}>
            Weighed on the hard standing, logged before anyone drives home. Updated Sunday evening.
          </text>
        </div>

        <div tw="w-full flex flex-col" motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}>
          <div tw="w-full flex flex-row items-end justify-between gap-4 pb-2">
            <text size={11} font={t.font.body} weight={700} color="#5C7276" w={34} ls="1px">
              NO
            </text>
            <text size={11} font={t.font.body} weight={700} color="#5C7276" flex={1} ls="1px">
              RIVER MOUTH
            </text>
            <text size={11} font={t.font.body} weight={700} color="#5C7276" ta="right" w={72} ls="1px">
              TONNES
            </text>
            <text size={11} font={t.font.body} weight={700} color="#5C7276" ta="right" w={62} ls="1px">
              VS PROJ
            </text>
          </div>
          <box tw="w-full h-[2px]" bg={t.color.ink} />
          {BOOMS.map((b) =>
            b.low ? (
              <BoomRowLow code={b.code} site={b.site} tonnes={`${b.t} t`} delta={b.d} />
            ) : (
              <BoomRow code={b.code} site={b.site} tonnes={`${b.t} t`} delta={b.d} />
            ),
          )}
          <div tw="w-full flex flex-row items-end justify-between gap-4 pt-3">
            <text size={13} font={t.font.body} weight={700} color={t.color.ink} flex={1} ls={0.4}>
              TOTAL, 14 DEVICES
            </text>
            <text size={20} font={t.font.head} weight={600} color={t.color.ink} ta="right" w={90}>
              1.14 t
            </text>
          </div>
        </div>
      </div>
    </section>

    {/* 2 — why river mouths */}
    <section cls="band" tw="w-full flex flex-col items-center px-6 py-20 max-md:py-14" bg={t.color.ground}>
      <div cls="column" tw="w-full max-w-[900px] flex flex-col gap-10">
        <Eyebrow n="02">WHY RIVER MOUTHS</Eyebrow>
        <div cls="split" tw="w-full flex flex-row gap-12 flex-wrap max-lg:gap-8">
          <div tw="flex flex-col gap-6" w="56%" tablet={{ w: '100%' }} mobile={{ w: '100%' }}>
            <h2 size={34} weight={600} font={t.font.head} color={t.color.ink} lh={1.18} mobile={{ size: 26 }}>
              Not the open ocean. The last narrow place before it.
            </h2>
            <p size={18} font={t.font.body} color="#3C5257" lh={1.75} mobile={{ size: 16 }}>
              Roughly 80 percent of ocean plastic arrives through rivers. Catching it at the mouth
              costs us about 340 per tonne. The same tonne recovered offshore costs between 4,000
              and 20,000. That is the entire strategy.
            </p>
            <p size={16} font={t.font.body} color="#5C7276" lh={1.75}>
              A river mouth concentrates the flow into a few hundred metres, twice a day, on a
              schedule a tide table can predict. Offshore, the same material is spread over
              thousands of square kilometres and half of it is below the surface by the time you
              arrive.
            </p>
          </div>
          <div tw="flex flex-col gap-5 flex-1" minh={0}>
            <div tw="w-full flex flex-col gap-1 p-6 rounded-2xl" bg={t.color.white} border={[1, t.color.rule]}>
              <text size={12} font={t.font.body} weight={700} color={t.color.sea} ls="1px">
                AT THE RIVER MOUTH
              </text>
              <text size={40} font={t.font.head} weight={600} color={t.color.ink} mobile={{ size: 32 }}>
                340
              </text>
              <text size={14} font={t.font.body} color="#5C7276">
                per tonne recovered, all in
              </text>
            </div>
            <div tw="w-full flex flex-col gap-1 p-6 rounded-2xl" bg={t.color.ink}>
              <text size={12} font={t.font.body} weight={700} color="#E2653A" ls="1px">
                THE SAME TONNE, OFFSHORE
              </text>
              <text size={40} font={t.font.head} weight={600} color={t.color.white} mobile={{ size: 32 }}>
                4,000–20,000
              </text>
              <text size={14} font={t.font.body} color="#8FB6BD">
                which is why we do not go out there
              </text>
            </div>
          </div>
        </div>
        <img src={M.estuary.id} tw="w-full rounded-2xl" h={300} fit="cover" mobile={{ h: 190 }} />
      </div>
    </section>

    {/* 3 — composition */}
    <section cls="band" tw="w-full flex flex-col items-center px-6 py-20 max-md:py-14" bg={t.color.white}>
      <div tw="w-full max-w-[760px] flex flex-col gap-8">
        <Eyebrow n="03">WHAT WE ACTUALLY RECOVER</Eyebrow>
        <h2 size={34} weight={600} font={t.font.head} color={t.color.ink} lh={1.18} mobile={{ size: 26 }}>
          Sorted by type, by weight, this month
        </h2>
        <p size={18} font={t.font.body} color="#3C5257" lh={1.75} mobile={{ size: 16 }}>
          This month's recovery by weight: 34 percent packaging film, 22 percent bottles and caps,
          18 percent fishing gear, 11 percent expanded foam, 15 percent unsorted fragment.
        </p>
        <div tw="w-full flex flex-col gap-6 pt-2" motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}>
          {MIX.map((m, i) => (
            <Bar label={m.label} pct={m.pct} tone={i === 0 ? '#1E6B7A' : i === 1 ? '#4A7A4E' : '#132226'} />
          ))}
        </div>
        <text size={14} font={t.font.body} color="#5C7276" lh={1.7}>
          Fragment is the category we like least. It is anything under 25 mm that cannot be
          identified at the sorting table, and it is the fraction that grows every year.
        </text>
      </div>
    </section>

    {/* 4 — the three that are failing */}
    <section cls="band" tw="w-full flex flex-col items-center px-6 py-20 max-md:py-14" bg={t.color.ink}>
      <div tw="w-full max-w-[860px] flex flex-col gap-10">
        <Eyebrow n="04" tone="#E2653A">
          THE THREE THAT ARE NOT WORKING
        </Eyebrow>
        <h2 size={36} weight={600} font={t.font.head} color={t.color.white} lh={1.15} maxw={640} mobile={{ size: 26 }}>
          Booms 4, 9 and 11 are catching less than a third of projection.
        </h2>
        <div tw="w-full flex flex-col gap-0">
          {[
            ['BOOM 04', 'Sandbar Reach', '−71%', 'The sandbar it sits behind moved. The channel now runs 60 metres east of the skirt and most of the flow misses us entirely. A survey is booked for September.'],
            ['BOOM 09', 'Weedbank', '−68%', 'Fouling with weed every eleven days. Once the mesh loads up, the boom rides high and the surface layer passes underneath. We are trialling a coarser skirt.'],
            ['BOOM 11', 'Long Sands', '−74%', 'A bad site choice, plainly. The catchment above it is mostly farmland and the plastic load was never there. We are moving it in October.'],
          ].map(([code, site, delta, why]) => (
            <div tw="w-full flex flex-col gap-3 py-7" motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}>
              <div tw="w-full flex flex-row items-end justify-between gap-4">
                <text size={13} font={t.font.body} weight={800} color="#E2653A" ls="1.2px">
                  {code}
                </text>
                <text size={20} font={t.font.head} weight={600} color={t.color.white} flex={1}>
                  {site}
                </text>
                <text size={20} font={t.font.head} weight={600} color="#E2653A" ta="right">
                  {delta}
                </text>
              </div>
              <p size={16} font={t.font.body} color="#B7CBCF" lh={1.75} maxw={680}>
                {why}
              </p>
              <box tw="w-full h-[1px] mt-4" bg="#2C4147" />
            </div>
          ))}
        </div>
        <text size={15} font={t.font.body} color="#8FB6BD" lh={1.7} maxw={620}>
          We publish these three every week alongside the eleven that work. A boom that is failing
          quietly is worse than a boom that is failing in public.
        </text>
      </div>
    </section>

    {/* 5 — downstream */}
    <section cls="band" tw="w-full flex flex-col items-center px-6 py-20 max-md:py-14" bg={t.color.ground}>
      <div cls="column" tw="w-full max-w-[900px] flex flex-col gap-10">
        <Eyebrow n="05">WHERE THE PLASTIC GOES</Eyebrow>
        <div cls="split" tw="w-full flex flex-row gap-12 flex-wrap max-lg:gap-8">
          <img
            src={M.sorting.id}
            tw="rounded-2xl"
            w="44%"
            h={340}
            fit="cover"
            tablet={{ w: '100%', h: 260 }}
            mobile={{ w: '100%', h: 200 }}
          />
          <div tw="flex flex-col gap-6 flex-1" minh={0}>
            <h2 size={32} weight={600} font={t.font.head} color={t.color.ink} lh={1.2} mobile={{ size: 26 }}>
              After we lift it, someone has to sort it by hand
            </h2>
            <p size={18} font={t.font.body} color="#3C5257" lh={1.75} mobile={{ size: 16 }}>
              Recovered plastic is sorted by hand, and 61 percent is recycled through two named
              processors. The rest goes to energy recovery. We do not pretend it all gets turned
              into sunglasses.
            </p>
            <div tw="w-full flex flex-row gap-4 flex-wrap">
              <div tw="flex flex-col gap-1 p-5 rounded-xl flex-1" bg={t.color.white} border={[1, t.color.rule]}>
                <text size={30} font={t.font.head} weight={600} color={t.color.kelp}>
                  61%
                </text>
                <text size={13} font={t.font.body} color="#5C7276" lh={1.5}>
                  recycled, two named processors
                </text>
              </div>
              <div tw="flex flex-col gap-1 p-5 rounded-xl flex-1" bg={t.color.white} border={[1, t.color.rule]}>
                <text size={30} font={t.font.head} weight={600} color={t.color.plastic}>
                  39%
                </text>
                <text size={13} font={t.font.body} color="#5C7276" lh={1.5}>
                  energy recovery, no better word for it
                </text>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    {/* 6 — volunteer Saturday */}
    <section cls="band" tw="w-full flex flex-col items-center px-6 py-20 max-md:py-14" bg={t.color.white}>
      <div tw="w-full max-w-[760px] flex flex-col gap-8">
        <Eyebrow n="06">VOLUNTEER DAYS</Eyebrow>
        <h2 size={34} weight={600} font={t.font.head} color={t.color.ink} lh={1.18} mobile={{ size: 26 }}>
          What a Saturday actually involves
        </h2>
        <p size={18} font={t.font.body} color="#3C5257" lh={1.75} mobile={{ size: 16 }}>
          A volunteer Saturday is six hours, mostly sorting on a hard standing in the wind. It is
          not glamorous, there are usually 200 nappies, and 70 percent of people come back.
        </p>
        <div tw="w-full flex flex-col gap-0 pt-2">
          {SATURDAY.map(([time, title, detail]) => (
            <div tw="w-full flex flex-row gap-6 py-5 max-md:gap-4">
              <text size={15} font={t.font.head} weight={600} color={t.color.sea} w={64}>
                {time}
              </text>
              <div tw="flex flex-col gap-1 flex-1">
                <text size={17} font={t.font.body} weight={700} color={t.color.ink}>
                  {title}
                </text>
                <text size={15} font={t.font.body} color="#5C7276" lh={1.65}>
                  {detail}
                </text>
                <box tw="w-full h-[1px] mt-5" bg={t.color.rule} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* 7 — funding */}
    <section cls="band" tw="w-full flex flex-col items-center px-6 py-20 max-md:py-14" bg={t.color.ground}>
      <div cls="column" tw="w-full max-w-[900px] flex flex-col gap-10">
        <Eyebrow n="07">FUNDING, PUBLISHED</Eyebrow>
        <div cls="split" tw="w-full flex flex-row gap-12 flex-wrap max-lg:gap-8">
          <div tw="flex flex-col gap-6" w="50%" tablet={{ w: '100%' }} mobile={{ w: '100%' }}>
            <h2 size={34} weight={600} font={t.font.head} color={t.color.ink} lh={1.18} mobile={{ size: 26 }}>
              Our cost per tonne, and where the pound goes
            </h2>
            <p size={18} font={t.font.body} color="#3C5257" lh={1.75} mobile={{ size: 16 }}>
              Our all-in cost is 340 per tonne recovered, and 71p of every pound goes into
              operations. Both numbers are updated quarterly whether they improve or not.
            </p>
            <div tw="w-full flex flex-row gap-3 flex-wrap">
              <div tw="flex flex-col gap-1 flex-1">
                <text size={40} font={t.font.head} weight={600} color={t.color.sea} mobile={{ size: 32 }}>
                  340
                </text>
                <text size={13} font={t.font.body} color="#5C7276" lh={1.5}>
                  all-in, per tonne recovered
                </text>
              </div>
              <div tw="flex flex-col gap-1 flex-1">
                <text size={40} font={t.font.head} weight={600} color={t.color.kelp} mobile={{ size: 32 }}>
                  71p
                </text>
                <text size={13} font={t.font.body} color="#5C7276" lh={1.5}>
                  of every pound into operations
                </text>
              </div>
            </div>
          </div>
          <div tw="flex flex-col gap-0 flex-1 p-7 rounded-2xl max-md:p-5" bg={t.color.white} border={[1, t.color.rule]}>
            <text size={12} font={t.font.body} weight={700} color={t.color.ink} ls="1px">
              THE 340, BROKEN DOWN
            </text>
            <box tw="w-full h-[1px] mt-3" bg={t.color.rule} />
            {COSTS.map(([label, amount]) => (
              <div tw="w-full flex flex-col">
                <div tw="w-full flex flex-row items-end justify-between gap-4 py-3">
                  <text size={15} font={t.font.body} color="#3C5257" flex={1} lh={1.5}>
                    {label}
                  </text>
                  <text size={16} font={t.font.head} weight={600} color={t.color.ink} ta="right" w={56}>
                    {amount}
                  </text>
                </div>
                <box tw="w-full h-[1px]" bg={t.color.rule} />
              </div>
            ))}
            <div tw="w-full flex flex-row items-end justify-between gap-4 pt-3">
              <text size={13} font={t.font.body} weight={700} color={t.color.ink} flex={1} ls={0.4}>
                TOTAL PER TONNE
              </text>
              <text size={20} font={t.font.head} weight={600} color={t.color.ink} ta="right" w={56}>
                340
              </text>
            </div>
          </div>
        </div>
      </div>
    </section>

    {/* 8 — give or come out on a boat (the page's one centred section) */}
    <section id="give" tw="w-full flex flex-col items-center px-6 py-24 max-md:py-16 text-center" bg={t.color.sea}>
      <div tw="w-full max-w-[720px] flex flex-col items-center gap-7 text-center">
        <text size={12} font={t.font.body} weight={700} color="#BFE0E6" ls="1.4px" ta="center">
          GIVE, OR COME OUT ON A BOAT
        </text>
        <h2
          size={42}
          weight={600}
          font={t.font.head}
          color={t.color.white}
          lh={1.15}
          ta="center"
          tablet={{ size: 34 }}
          mobile={{ size: 28 }}
        >
          A boom costs 4,100 to build and 1,900 a year to keep in the water.
        </h2>
        <p size={18} font={t.font.body} color="#DCEEF1" lh={1.7} ta="center" maxw={560} mobile={{ size: 16 }}>
          Fund a boom and you get its weekly tonnage by email, including the weeks it catches
          nothing. Or give us a Saturday and sort it yourself — bring gloves, we have the rest.
        </p>
        <div tw="flex flex-row items-center justify-center gap-4 flex-wrap pt-2">
          <text
            href="#give"
            size={16}
            font={t.font.body}
            weight={700}
            color={t.color.ink}
            bg={t.color.white}
            pad={{ t: 15, b: 15, l: 30, r: 30 }}
            radius={999}
            shadow={[
              [2, 6, 0, 'rgba(9,26,30,0.12)'],
              [12, 28, -8, 'rgba(9,26,30,0.45)'],
            ]}
            hover={{ bg: '#F2F7F8' }}
          >
            Fund a boom
          </text>
          <text
            href="#booms"
            size={16}
            font={t.font.body}
            weight={700}
            color={t.color.white}
            pad={{ t: 14, b: 14, l: 28, r: 28 }}
            radius={999}
            border={[1, '#7FBAC4']}
            hover={{ bg: '#175661' }}
          >
            Come out on a Saturday
          </text>
        </div>
      </div>
    </section>

    {/* footer */}
    <section tw="w-full flex flex-col items-center px-6" bg={t.color.ink}>
      <div tw="w-full max-w-[900px] flex flex-row items-center justify-between gap-4 py-6 flex-wrap">
        <text size={15} font={t.font.head} weight={600} color={t.color.white}>
          Tideline
        </text>
        <text size={13} font={t.font.body} color="#8FB6BD" lh={1.6}>
          Registered marine conservation charity. Tonnage published every Sunday, audited annually.
        </text>
      </div>
    </section>
  </box>
);
