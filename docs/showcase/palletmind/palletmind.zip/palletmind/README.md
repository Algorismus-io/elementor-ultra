# Palletmind

Crisp industrial B2B; correct, a little corporate.

|  |  |
|---|---|
| **Slug** | `palletmind` (deploys to `/palletmind/`) |
| **Archetype** | sidebar dossier with sticky nav |
| **Industry** | Warehouse robotics |
| **Page title** | Palletmind — autonomous pallet movement, retrofitted |
| **Fonts** | Michroma, IBM Plex Sans — Google Fonts, imported by Elementor automatically |
| **Elements** | 185 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (87 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install palletmind
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
palletmind/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/palletmind.page.jsx            the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F1F3F5` |
| `ink` | `#0F1519` |
| `machine` | `#2E3F4C` |
| `hazard` | `#FFD400` |
| `ok` | `#2F9E6B` |
| `line` | `#D5DBE0` |

Change a value, re-run `npx exjsx-kit install palletmind`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/palletmind.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `ops_floor` | `media/ops_floor.jpg` | Operations floor of a distribution centre |
| `robot_aisle` | `media/robot_aisle.jpg` | Autonomous pallet mover in a racking aisle |
| `sensor_detail` | `media/sensor_detail.jpg` | Dual-channel safety scanner detail |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
