export default { name: 'second-spring' };
