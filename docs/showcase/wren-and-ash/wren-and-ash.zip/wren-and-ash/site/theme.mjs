/** Wren & Ash — design tokens. */
export default defineTheme({
  name: 'wren-and-ash',
  color: {
    ground: '#F6F2EA',
    ink: '#241F1A',
    oak: '#A97B4F',
    inkSoft: '#6B6155',
    green: '#3F5347',
    white: '#FFFFFF',
  },
  font: { head: 'EB Garamond', body: 'Karla' },
  mode: 'literal',
});
