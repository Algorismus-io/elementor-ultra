/** Moss Hollow — the whole landing page as one soft bento grid. */
import { defineComponent } from 'elementor-jsx';
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Moss Hollow',
  seo: {
    title: 'Moss Hollow — a farming and foraging game with no timers and no ads',
    description:
      'A small farming and foraging game about a valley that keeps going whether you show up or not. £6.99 once, fully offline, no energy system, no ads, nothing to buy twice.',
  },
};

/* ── shared bits ───────────────────────────────────────────────────────────── */
const C = {
  ground: '#F3F7EC', tile: '#E4EEDA', ink: '#26331F',
  moss: '#6E9152', berry: '#A8446B', honey: '#E4A93C', white: '#FFFFFF',
};
const HEAD = 'Pacifico';
const BODY = 'Nunito';
const M1 = { span: 1 };                                  // every bento child is full width at 390
const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 600 };
const LIFT = [[0, 1, 0, 'rgba(38,51,31,0.06)'], [0, 18, -8, 'rgba(38,51,31,0.14)']];

/* ── registered components (content props only) ────────────────────────────── */
const NoTile = defineComponent(
  ({ label = 'No ads', note = 'Not one.' }) => (
    <box tw="col-span-3 flex flex-col gap-2" cls="no-tile" pad={26} bg={C.white} radius={22} shadow={LIFT}
      w="100%" mobile={M1} hover={{ bg: '#FBFDF7' }}>
      <h3 size={22} font={HEAD} color={C.ink} weight={400} lh={1.3} mobile={{ size: 20 }}>{label}</h3>
      <text size={15} font={BODY} color={C.moss} lh={1.6}>{note}</text>
    </box>
  ),
  {
    title: 'Moss Hollow No-Tile',
    props: {
      label: { label: 'Tile label', group: 'Content', default: 'No ads' },
      note: { label: 'Tile note', group: 'Content', default: 'Not one.' },
    },
  },
);

const SeasonTile = defineComponent(
  ({ season = 'Spring', days = '28 days', body = 'Mushrooms and mud.' }) => (
    <box tw="col-span-3 flex flex-col gap-3" cls="season-tile" pad={28} bg={C.white} radius={24}
      w="100%" mobile={M1} shadow={LIFT} hover={{ bg: '#FBFDF7' }}>
      <text size={13} font={BODY} weight={700} color={C.berry} ls="1.4px" raw="text-transform:uppercase;">{days}</text>
      <h3 size={28} font={HEAD} weight={400} color={C.ink} lh={1.25} mobile={{ size: 24 }}>{season}</h3>
      <text size={16} font={BODY} color={C.ink} lh={1.65}>{body}</text>
    </box>
  ),
  {
    title: 'Moss Hollow Season Tile',
    props: {
      season: { label: 'Season', group: 'Content', default: 'Spring' },
      days: { label: 'Length', group: 'Content', default: '28 days' },
      body: { label: 'What changes', group: 'Content', default: 'Mushrooms and mud.' },
    },
  },
);

/* un-registered helpers (they carry styling variants, which components cannot override) */
const Eyebrow = ({ children, color = C.moss }) => (
  <text size={13} font={BODY} weight={700} color={color} ls="1.6px" raw="text-transform:uppercase;">{children}</text>
);

const Buy = ({ label = 'Buy Moss Hollow', bg = C.ink, fg = C.white, hoverBg = C.moss }) => (
  <text href="#buy" size={17} font={BODY} weight={700} color={fg} bg={bg}
    pad={[16, 30]} radius={999} w="hug" ta="center"
    shadow={[0, 10, -4, 'rgba(38,51,31,0.28)']}
    hover={{ bg: hoverBg, color: C.white }}>{label}</text>
);

const Chip = ({ children, tint = C.tile, ink = C.ink }) => (
  <text size={15} font={BODY} weight={700} color={ink} bg={tint} cls="chip" pad={[10, 18]} radius={999} w="hug">{children}</text>
);

/* ── page ──────────────────────────────────────────────────────────────────── */
export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={C.ground}>

    {/* 1 — bento hero */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 72, b: 88, l: 24, r: 24 }} mobile={{ pad: { t: 40, b: 56, l: 16, r: 16 } }}>
      <grid cols={12} gap={16} w="100%" maxw={1180} mobile={{ gap: 12 }}>

        <box tw="col-span-7 flex flex-col gap-6 justify-center" mobile={M1} pad={{ t: 52, b: 52, l: 44, r: 44 }}
          bg={C.tile} radius={32} shadow={LIFT}>
          <Eyebrow>Moss Hollow · a small game</Eyebrow>
          <h1 size={58} font={HEAD} weight={400} color={C.ink} lh={1.15} maxw={620}
            tablet={{ size: 46 }} mobile={{ size: 34 }}>
            No timers. No ads. No shop. £6.99 once.
          </h1>
          <text size={18} font={BODY} color={C.ink} lh={1.7} maxw={560} mobile={{ size: 16 }}>
            Moss Hollow is a small farming and foraging game about a valley that keeps going whether
            you show up or not. Play for ten minutes or two hours. Nothing wilts because you were busy.
          </text>
          <Buy />
        </box>

        <box tw="col-span-5" mobile={M1} minh={420} radius={32} bgImage={media.forage.id}
          bgOpts={{ size: 'cover', position: 'center center' }}
          tablet={{ minh: 340 }} mobile={{ ...M1, minh: 240 }} shadow={LIFT} />

        <NoTile label="No ads" note="Never any. Not between days, not for a bigger barn." />
        <NoTile label="No timers" note="No energy, no waiting, no crops rotting overnight." />
        <NoTile label="No shop" note="Nothing is locked behind a second payment." />
        <NoTile label="£6.99 once" note="One price, every device you own, forever." />
      </grid>
    </section>

    {/* 2 — what ten minutes actually looks like */}
    <section tw="flex flex-col w-full items-center" bg={C.tile} pad={{ t: 88, b: 88, l: 24, r: 24 }}
      mobile={{ pad: { t: 56, b: 56, l: 16, r: 16 } }}>
      <grid cols={12} gap={20} w="100%" maxw={1180} mobile={{ gap: 12 }}>
        <box tw="col-span-5 flex flex-col gap-5 justify-center" mobile={M1} motion={FADE}>
          <Eyebrow color={C.berry}>Ten minutes a day</Eyebrow>
          <h2 size={40} font={HEAD} weight={400} color={C.ink} lh={1.2} mobile={{ size: 28 }}>
            What you actually do
          </h2>
          <text size={18} font={BODY} color={C.ink} lh={1.7} maxw={460} mobile={{ size: 16 }}>
            Forage the woods, trade with six neighbours who remember what you gave them, plant what
            the season allows, and slowly work out why the old mill stopped.
          </text>
        </box>
        <grid tw="col-span-7" cols={2} gap={14} mobile={{ ...M1, gap: 12 }}>
          <box tw="flex flex-col gap-2" cls="loop-card" pad={26} bg={C.ground} radius={22} mobile={M1}>
            <h3 size={22} font={HEAD} weight={400} color={C.ink} lh={1.3}>Forage</h3>
            <text size={15} font={BODY} color={C.ink} lh={1.6}>Baskets of chanterelles, sloes, wet bark and things you cannot identify yet.</text>
          </box>
          <box tw="flex flex-col gap-2" cls="loop-card" pad={26} bg={C.ground} radius={22} mobile={M1}>
            <h3 size={22} font={HEAD} weight={400} color={C.ink} lh={1.3}>Trade</h3>
            <text size={15} font={BODY} color={C.ink} lh={1.6}>Six neighbours, each with a long memory for kindness and for jam.</text>
          </box>
          <box tw="flex flex-col gap-2" cls="loop-card" pad={26} bg={C.ground} radius={22} mobile={M1}>
            <h3 size={22} font={HEAD} weight={400} color={C.ink} lh={1.3}>Plant</h3>
            <text size={15} font={BODY} color={C.ink} lh={1.6}>Whatever the season allows, at whatever pace suits the week you are having.</text>
          </box>
          <box tw="flex flex-col gap-2" cls="loop-card" pad={26} bg={C.ground} radius={22} mobile={M1}>
            <h3 size={22} font={HEAD} weight={400} color={C.ink} lh={1.3}>Wonder</h3>
            <text size={15} font={BODY} color={C.ink} lh={1.6}>About the old mill, which stopped a long time before you arrived.</text>
          </box>
        </grid>
      </grid>
    </section>

    {/* 3 — the seasons */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 88, b: 88, l: 24, r: 24 }}
      mobile={{ pad: { t: 56, b: 56, l: 16, r: 16 } }}>
      <grid cols={12} gap={16} w="100%" maxw={1180} mobile={{ gap: 12 }}>
        <box tw="col-span-5 flex flex-col gap-4 justify-center" mobile={M1}>
          <Eyebrow color={C.honey}>About 28 real days each</Eyebrow>
          <h2 size={40} font={HEAD} weight={400} color={C.ink} lh={1.2} mobile={{ size: 28 }}>
            The seasons, and what changes
          </h2>
          <text size={17} font={BODY} color={C.ink} lh={1.7} maxw={440} mobile={{ size: 16 }}>
            Four seasons of about 28 real days each. Spring is mushrooms and mud. Summer is the fair.
            Autumn is the best month and everyone says so. Winter is quiet and a little sad on purpose.
          </text>
        </box>
        <box tw="col-span-7" mobile={{ ...M1, minh: 200 }} minh={300} radius={28}
          bgImage={media.winter.id} bgOpts={{ size: 'cover', position: 'center center' }} shadow={LIFT} />

        <SeasonTile season="Spring" days="Season one" body="Mushrooms and mud, and a valley that smells like rain on stone." />
        <SeasonTile season="Summer" days="Season two" body="The fair. Bunting, a competition you can lose gracefully, long light." />
        <SeasonTile season="Autumn" days="Season three" body="The best month and everyone says so. Everything at once, gold everywhere." />
        <SeasonTile season="Winter" days="Season four" body="Quiet, and a little sad on purpose. The mill sits under snow and waits." />
      </grid>
    </section>

    {/* 4 — offline: dark band, off-centre */}
    <section tw="flex flex-col w-full items-center" bg={C.ink} pad={{ t: 80, b: 80, l: 24, r: 24 }}
      mobile={{ pad: { t: 52, b: 52, l: 16, r: 16 } }}>
      <grid cols={12} gap={20} w="100%" maxw={1180} mobile={{ gap: 14 }}>
        <box tw="col-span-7 flex flex-col gap-5" mobile={M1} motion={FADE}>
          <Eyebrow color={C.honey}>Offline, on a plane, in a tunnel</Eyebrow>
          <h2 size={40} font={HEAD} weight={400} color={C.white} lh={1.2} mobile={{ size: 28 }}>
            It works with the aeroplane mode on
          </h2>
          <text size={18} font={BODY} color="#DDE7D2" lh={1.75} maxw={560} mobile={{ size: 16 }}>
            Fully offline. No account, no login, no server. It works on a plane and it will still work
            in nine years when we have moved on to something else.
          </text>
        </box>
        <box tw="col-span-5 flex flex-col gap-3 justify-center" mobile={M1} pad={30} radius={26} bg="#31402A">
          <Chip tint="#3C4E33" ink={C.white}>No account</Chip>
          <Chip tint="#3C4E33" ink={C.white}>No login</Chip>
          <Chip tint="#3C4E33" ink={C.white}>No server</Chip>
          <Chip tint={C.honey} ink={C.ink}>Nothing to go down</Chip>
        </box>
      </grid>
    </section>

    {/* 5 — accessibility */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 88, b: 88, l: 24, r: 24 }}
      mobile={{ pad: { t: 56, b: 56, l: 16, r: 16 } }}>
      <grid cols={12} gap={16} w="100%" maxw={1180} mobile={{ gap: 12 }}>
        <box tw="col-span-4 flex flex-col gap-4 justify-center" mobile={M1}>
          <Eyebrow>Playable how you play</Eyebrow>
          <h2 size={38} font={HEAD} weight={400} color={C.ink} lh={1.2} mobile={{ size: 28 }}>
            Accessibility, decided early
          </h2>
          <text size={17} font={BODY} color={C.ink} lh={1.7} mobile={{ size: 16 }}>
            One-handed portrait play, full colourblind palettes, adjustable text size up to 200 percent,
            and no reflex or timing challenge anywhere in the game.
          </text>
        </box>
        <grid tw="col-span-8" cols={2} gap={14} mobile={{ ...M1, gap: 12 }}>
          <box tw="flex flex-col gap-2" cls="a11y-card" pad={26} bg={C.tile} radius={22} mobile={M1} motion={FADE}>
            <h3 size={20} font={HEAD} weight={400} color={C.ink} lh={1.3}>One hand, portrait</h3>
            <text size={15} font={BODY} color={C.ink} lh={1.6}>Every action sits inside the reach of one thumb.</text>
          </box>
          <box tw="flex flex-col gap-2" cls="a11y-card" pad={26} bg={C.tile} radius={22} mobile={M1} motion={FADE}>
            <h3 size={20} font={HEAD} weight={400} color={C.ink} lh={1.3}>Colourblind palettes</h3>
            <text size={15} font={BODY} color={C.ink} lh={1.6}>Full alternate palettes, not a filter bolted on at the end.</text>
          </box>
          <box tw="flex flex-col gap-2" cls="a11y-card" pad={26} bg={C.tile} radius={22} mobile={M1} motion={FADE}>
            <h3 size={20} font={HEAD} weight={400} color={C.ink} lh={1.3}>Text up to 200%</h3>
            <text size={15} font={BODY} color={C.ink} lh={1.6}>The interface reflows properly at every step of the scale.</text>
          </box>
          <box tw="flex flex-col gap-2" cls="a11y-card" pad={26} bg={C.tile} radius={22} mobile={M1} motion={FADE}>
            <h3 size={20} font={HEAD} weight={400} color={C.ink} lh={1.3}>No reflex tests</h3>
            <text size={15} font={BODY} color={C.ink} lh={1.6}>No timing challenge anywhere. Nothing you can be too slow for.</text>
          </box>
        </grid>
      </grid>
    </section>

    {/* 6 — the soundtrack */}
    <section tw="flex flex-col w-full items-center" bg={C.tile} pad={{ t: 88, b: 88, l: 24, r: 24 }}
      mobile={{ pad: { t: 56, b: 56, l: 16, r: 16 } }}>
      <grid cols={12} gap={20} w="100%" maxw={1180} mobile={{ gap: 14 }}>
        <box tw="col-span-6" mobile={{ ...M1, minh: 220 }} minh={380} radius={28}
          bgImage={media.valley.id} bgOpts={{ size: 'cover', position: 'center center' }} shadow={LIFT} />
        <box tw="col-span-6 flex flex-col gap-5 justify-center" mobile={{ ...M1, pad: { l: 0 } }} pad={{ l: 20 }}>
          <Eyebrow color={C.berry}>38 minutes, written by Ida Brann</Eyebrow>
          <h2 size={38} font={HEAD} weight={400} color={C.ink} lh={1.2} mobile={{ size: 28 }}>
            Piano, clarinet and field recordings
          </h2>
          <text size={18} font={BODY} color={C.ink} lh={1.75} maxw={520} mobile={{ size: 16 }}>
            38 minutes of original music for piano, clarinet and field recordings, written by Ida Brann,
            included free as a download with the game.
          </text>
          <box tw="flex flex-row gap-3 flex-wrap" w="100%">
            <Chip tint={C.ground}>Piano</Chip>
            <Chip tint={C.ground}>Clarinet</Chip>
            <Chip tint={C.ground}>Field recordings</Chip>
            <Chip tint={C.honey}>Free download</Chip>
          </box>
        </box>
      </grid>
    </section>

    {/* 7 — price, platforms, family sharing */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 88, b: 72, l: 24, r: 24 }}
      mobile={{ pad: { t: 56, b: 48, l: 16, r: 16 } }}>
      <grid cols={12} gap={16} w="100%" maxw={1180} mobile={{ gap: 12 }}>
        <box tw="col-span-4 flex flex-col gap-2 justify-center" mobile={M1} pad={36} bg={C.ink} radius={28} shadow={LIFT}>
          <text size={15} font={BODY} weight={700} color={C.honey} ls="1.4px" raw="text-transform:uppercase;">One price</text>
          <h2 size={52} font={HEAD} weight={400} color={C.white} lh={1.1} mobile={{ size: 40 }}>£6.99</h2>
          <text size={16} font={BODY} color="#DDE7D2" lh={1.6}>Paid once, at the door, and then never again.</text>
        </box>
        <box tw="col-span-4 flex flex-col gap-3 justify-center" mobile={M1} pad={32} bg={C.white} radius={28} shadow={LIFT}>
          <h3 size={26} font={HEAD} weight={400} color={C.ink} lh={1.25}>iOS and Android</h3>
          <text size={16} font={BODY} color={C.ink} lh={1.65}>
            £6.99 on iOS and Android, family sharing enabled, one purchase covers every device you own.
          </text>
        </box>
        <box tw="col-span-4 flex flex-col gap-3 justify-center" mobile={M1} pad={32} bg={C.white} radius={28} shadow={LIFT}>
          <h3 size={26} font={HEAD} weight={400} color={C.berry} lh={1.25}>Family sharing</h3>
          <text size={16} font={BODY} color={C.ink} lh={1.65}>
            There is no second thing to buy because we did not make one. No currency, no season pass, no barn upgrade.
          </text>
        </box>
      </grid>
    </section>

    {/* 8 — buy once (the page's one centred column) */}
    <section id="buy" tw="flex flex-col w-full items-center text-center" bg={C.moss}
      pad={{ t: 88, b: 96, l: 24, r: 24 }} mobile={{ pad: { t: 60, b: 64, l: 16, r: 16 } }}>
      <box tw="flex flex-col items-center gap-6" w="100%" maxw={720} ta="center" motion={FADE}>
        <h2 size={46} font={HEAD} weight={400} color={C.white} lh={1.2} ta="center" mobile={{ size: 32 }}>
          Buy once. That is the whole arrangement.
        </h2>
        <text size={18} font={BODY} color="#F1F7EA" lh={1.75} maxw={560} ta="center" mobile={{ size: 16 }}>
          £6.99, one purchase, every device you own. The valley keeps going whether you show up or not —
          and it will still be there in nine years.
        </text>
        <Buy label="Buy Moss Hollow" bg={C.ink} fg={C.white} hoverBg={C.berry} />
        <text size={14} font={BODY} color="#EAF2E0" lh={1.6} ta="center">No account · no ads · no purchases · works offline</text>
      </box>
    </section>
  </box>
);
