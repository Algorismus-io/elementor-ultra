/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "the-undertow--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'the-undertow--';

export default [
  { slot: `${PREFIX}documents`, file: join(MEDIA_DIR, "documents.jpg"), alt: "Stacked pages of disclosed documents, annotated and tagged" },
  { slot: `${PREFIX}reporter_field`, file: join(MEDIA_DIR, "reporter_field.jpg"), alt: "A reporter working in the field, notebook in hand" },
];
