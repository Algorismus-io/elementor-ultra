/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "quiet-night-cpap--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'quiet-night-cpap--';

export default [
  { slot: `${PREFIX}device_bedside`, file: join(MEDIA_DIR, "device_bedside.jpg"), alt: "Quiet Night A2 CPAP machine on a bedside table at night" },
  { slot: `${PREFIX}chamber_detail`, file: join(MEDIA_DIR, "chamber_detail.jpg"), alt: "Close detail of the Quiet Night A2 water chamber lifted from the device" },
  { slot: `${PREFIX}sleeping`, file: join(MEDIA_DIR, "sleeping.jpg"), alt: "A person asleep on their side wearing a CPAP mask" },
];
