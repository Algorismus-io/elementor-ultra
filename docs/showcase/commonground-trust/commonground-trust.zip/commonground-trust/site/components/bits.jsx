/**
 * Small shared pieces for the Common Ground Trust page.
 * Plain function components (inline expansion) wherever geometry varies per item —
 * Elementor components can only override SETTINGS, so a width-feeding prop would be a build error.
 * The genuinely content-only repeaters live in the page as defineComponent().
 */
import theme from '../theme.mjs';

const C = theme.lit;

/** A hairline. Factory, never a shared instance. */
export const Rule = ({ color = C.rule, top = 0, bottom = 0 } = {}) => (
  <div w="100%" h={1} bg={color} m={{ t: top, b: bottom }} pad={0} />
);

/** Horizontal funding / proportion meter. `pct` is 0-100. */
export const Meter = ({ pct, fill = C.grass, track = C.rule, h = 8 }) => (
  <div w="100%" h={h} bg={track} radius={h / 2} pad={0}>
    <div w={`${pct}%`} h={h} bg={fill} radius={h / 2} pad={0} />
  </div>
);

/** Map-key swatch + caption. */
export const KeySwatch = ({ label, fill, stroke, dashed = false }) => (
  <row align="center" gap={10} pad={0} w="hug">
    <div
      w={26}
      h={14}
      pad={0}
      radius={2}
      bg={fill}
      border={dashed ? [2, stroke] : [1, stroke]}
    />
    <text size={13} lh={1.3} color={C.ink} font={theme.litFont('body')} ls={0.2}>
      {label}
    </text>
  </row>
);

/** Eyebrow — the surveyor's caption used above most section headings. */
export const Eyebrow = ({ children, color = C.grass }) => (
  <text size={12} weight={700} ls="1.8px" color={color} font={theme.litFont('body')} pad={0}>
    {children}
  </text>
);
