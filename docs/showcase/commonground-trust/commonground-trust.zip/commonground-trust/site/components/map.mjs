/**
 * The watershed map — inline SVG for the <html> widget.
 * Presentation attributes only (no <style> block): the html widget's content passes through
 * WordPress sanitisation on save, and attributes survive where a style element may not.
 * Type is set with font-family attributes on Source Sans 3, which Elementor enqueues because
 * the page also names it in real style props.
 */

const GROUND = '#F3F5EF';
const INK = '#1B2A20';
const RIVER = '#2C6E8F';
const GRASS = '#6E8B3D';
const OCHRE = '#C4913C';
const RULE = '#C9D1C2';
const BODY = "'Source Sans 3', system-ui, sans-serif";

/** Held land, already in trust. */
const HELD = [
  { d: 'M104 62 L232 44 L262 152 L134 176 Z', label: 'Wenn Head', ac: '410 ac' },
  { d: 'M58 212 L172 200 L200 302 L82 322 Z', label: 'Low Fold', ac: '288 ac' },
  { d: 'M212 262 L322 250 L346 352 L232 366 Z', label: 'Cranmoor', ac: '531 ac' },
  { d: 'M382 128 L502 114 L524 200 L400 218 Z', label: 'Nine Wells', ac: '344 ac' },
  { d: 'M548 232 L662 216 L686 302 L562 318 Z', label: 'Barrowfield', ac: '402 ac' },
  { d: 'M330 392 L452 380 L470 470 L348 486 Z', label: 'Ash Carr', ac: '620 ac' },
  { d: 'M498 470 L616 456 L642 546 L514 560 Z', label: 'Thurl Ings', ac: '575 ac' },
  { d: 'M636 560 L758 546 L782 628 L662 642 Z', label: 'Wenn Mouth', ac: '498 ac' },
  { d: 'M146 380 L262 368 L284 452 L166 466 Z', label: 'Ryecroft', ac: '512 ac' },
];

/** Under offer — the three parcels in the dossier below. */
const OFFER = [
  { d: 'M252 166 L344 154 L362 242 L268 254 Z', n: '44', label: 'Marsden Bottom', ac: '63 ac' },
  { d: 'M398 226 L520 210 L542 300 L416 316 Z', n: '7', label: 'Hollin Ing', ac: '116 ac' },
  { d: 'M470 480 L548 470 L562 552 L486 562 Z', n: '51', label: 'Ash Carr Bank', ac: '38 ac' },
];

const graticule = () => {
  const out = [];
  for (let x = 80; x < 820; x += 80) out.push(`<line x1="${x}" y1="0" x2="${x}" y2="660" stroke="${RULE}" stroke-width="1" opacity="0.55"/>`);
  for (let y = 80; y < 660; y += 80) out.push(`<line x1="0" y1="${y}" x2="820" y2="${y}" stroke="${RULE}" stroke-width="1" opacity="0.55"/>`);
  return out.join('');
};

const held = () =>
  HELD.map(
    (p) => `<g><path d="${p.d}" fill="${GRASS}" fill-opacity="0.34" stroke="${GRASS}" stroke-width="1.75"/></g>`,
  ).join('');

const heldLabels = () =>
  HELD.map((p) => {
    const [x, y] = p.d.slice(1).trim().split(/[ L]+/).map(Number);
    return `<text x="${x + 12}" y="${y + 34}" font-family="${BODY}" font-size="13" fill="${INK}" fill-opacity="0.78" letter-spacing="0.2">${p.label}</text><text x="${x + 12}" y="${y + 50}" font-family="${BODY}" font-size="11.5" fill="${GRASS}" letter-spacing="0.6">${p.ac}</text>`;
  }).join('');

const offer = () =>
  OFFER.map(
    (p) => `<path d="${p.d}" fill="${OCHRE}" fill-opacity="0.16" stroke="${OCHRE}" stroke-width="2.25" stroke-dasharray="7 5"/>`,
  ).join('');

const offerLabels = () =>
  OFFER.map((p) => {
    const [x, y] = p.d.slice(1).trim().split(/[ L]+/).map(Number);
    return `<circle cx="${x + 16}" cy="${y + 22}" r="12.5" fill="${OCHRE}"/><text x="${x + 16}" y="${y + 26.5}" text-anchor="middle" font-family="${BODY}" font-size="12" font-weight="700" fill="${GROUND}">${p.n}</text><text x="${x + 34}" y="${y + 21}" font-family="${BODY}" font-size="13" font-weight="600" fill="${INK}">${p.label}</text><text x="${x + 34}" y="${y + 37}" font-family="${BODY}" font-size="11.5" fill="${OCHRE}" letter-spacing="0.6">${p.ac} · under offer</text>`;
  }).join('');

export const watershedMap = () => `
<div class="cgt-map">
<svg viewBox="0 0 820 660" width="100%" role="img" aria-label="Map of the Wenn valley showing 4,180 acres already held in trust, three parcels under offer, and 96 acres lost to development this year." xmlns="http://www.w3.org/2000/svg" style="display:block;width:100%;height:auto;background:${GROUND}">
  <defs>
    <pattern id="cgtLost" width="8" height="8" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
      <line x1="0" y1="0" x2="0" y2="8" stroke="${INK}" stroke-width="1.6" opacity="0.45"/>
    </pattern>
  </defs>

  <rect width="820" height="660" fill="${GROUND}"/>
  ${graticule()}

  <path d="M70 24 C 150 118, 84 190, 190 240 C 296 290, 332 306, 300 384 C 268 462, 384 470, 470 502 C 556 534, 640 544, 726 660" fill="none" stroke="${RIVER}" stroke-opacity="0.16" stroke-width="26" stroke-linecap="round"/>
  <path d="M70 24 C 150 118, 84 190, 190 240 C 296 290, 332 306, 300 384 C 268 462, 384 470, 470 502 C 556 534, 640 544, 726 660" fill="none" stroke="${RIVER}" stroke-width="5" stroke-linecap="round"/>
  <path d="M196 96 C 250 130, 268 168, 246 214" fill="none" stroke="${RIVER}" stroke-width="2.5" stroke-opacity="0.7"/>
  <path d="M612 402 C 556 430, 512 448, 470 502" fill="none" stroke="${RIVER}" stroke-width="2.5" stroke-opacity="0.7"/>

  ${held()}
  ${offer()}

  <path d="M688 96 L790 84 L802 172 L698 188 Z" fill="url(#cgtLost)" stroke="${INK}" stroke-width="1.5" stroke-dasharray="3 4" opacity="0.85"/>
  <text x="700" y="122" font-family="${BODY}" font-size="12.5" font-weight="700" fill="${INK}" letter-spacing="1.2">LOST 2026</text>
  <text x="700" y="140" font-family="${BODY}" font-size="11.5" fill="${INK}" fill-opacity="0.7">96 ac · outline consent</text>

  ${heldLabels()}
  ${offerLabels()}

  <text x="318" y="352" font-family="${BODY}" font-size="12" font-style="italic" fill="${RIVER}" letter-spacing="1.4">River Wenn</text>

  <g>
    <path d="M772 36 L780 62 L772 56 L764 62 Z" fill="${INK}"/>
    <text x="772" y="82" text-anchor="middle" font-family="${BODY}" font-size="11" font-weight="700" fill="${INK}" letter-spacing="1">N</text>
  </g>

  <g>
    <line x1="34" y1="618" x2="154" y2="618" stroke="${INK}" stroke-width="2"/>
    <line x1="34" y1="612" x2="34" y2="624" stroke="${INK}" stroke-width="2"/>
    <line x1="94" y1="613" x2="94" y2="623" stroke="${INK}" stroke-width="1.5"/>
    <line x1="154" y1="612" x2="154" y2="624" stroke="${INK}" stroke-width="2"/>
    <text x="34" y="640" font-family="${BODY}" font-size="11" fill="${INK}" fill-opacity="0.72">0</text>
    <text x="154" y="640" text-anchor="end" font-family="${BODY}" font-size="11" fill="${INK}" fill-opacity="0.72">2 km</text>
  </g>
  <text x="786" y="640" text-anchor="end" font-family="${BODY}" font-size="10.5" fill="${INK}" fill-opacity="0.5" letter-spacing="0.8">SURVEY SHEET SE 44 · REVISED QUARTERLY</text>
</svg>
</div>`;

/** Small parcel plan used as a dossier row thumbnail. */
export const parcelPlan = (d, seed) => `
<svg viewBox="0 0 120 120" width="100%" role="img" aria-label="Sketch plan of the parcel" xmlns="http://www.w3.org/2000/svg" style="display:block;width:100%;height:auto;background:${GROUND}">
  <rect width="120" height="120" fill="${GROUND}"/>
  <line x1="40" y1="0" x2="40" y2="120" stroke="${RULE}" stroke-width="1"/>
  <line x1="80" y1="0" x2="80" y2="120" stroke="${RULE}" stroke-width="1"/>
  <line x1="0" y1="40" x2="120" y2="40" stroke="${RULE}" stroke-width="1"/>
  <line x1="0" y1="80" x2="120" y2="80" stroke="${RULE}" stroke-width="1"/>
  <path d="${seed}" fill="none" stroke="${RIVER}" stroke-width="3" stroke-linecap="round"/>
  <path d="${d}" fill="${OCHRE}" fill-opacity="0.18" stroke="${OCHRE}" stroke-width="2" stroke-dasharray="5 4"/>
</svg>`;
