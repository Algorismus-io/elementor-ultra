# The Long Barn

Warm barn light, a script that earns its place, an honest timeline.

|  |  |
|---|---|
| **Slug** | `long-barn-weddings` (deploys to `/long-barn-weddings/`) |
| **Archetype** | timeline spine |
| **Industry** | Wedding venue |
| **Page title** | The Long Barn |
| **Fonts** | Amatic SC, Crimson Pro — Google Fonts, imported by Elementor automatically |
| **Elements** | 245 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (100 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install long-barn-weddings
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
long-barn-weddings/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/long-barn-weddings.page.jsx    the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F8F4ED` |
| `ink` | `#2E2A24` |
| `stone` | `#9E9585` |
| `meadow` | `#7B8F5A` |
| `rose` | `#C08B8B` |
| `rule` | `#E0D8CB` |

Change a value, re-run `npx exjsx-kit install long-barn-weddings`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/long-barn-weddings.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `barn_interior` | `media/barn_interior.jpg` | The Long Barn dressed for a wedding: long trestle tables running the length of a 17th century oak truss roof strung with festoon lights |
| `farmhouse_morning` | `media/farmhouse_morning.jpg` | The farmhouse at The Long Barn on a Sunday morning, where twenty-two guests sleep and breakfast is served |
| `meadow_ceremony` | `media/meadow_ceremony.jpg` | An outdoor wedding ceremony in the meadow at The Long Barn |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
