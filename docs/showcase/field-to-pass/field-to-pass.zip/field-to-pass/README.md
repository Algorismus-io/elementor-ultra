# Field to Pass

Produce warmth, grower list, good rhythm — slightly safe.

|  |  |
|---|---|
| **Slug** | `field-to-pass` (deploys to `/field-to-pass/`) |
| **Archetype** | horizontal filmstrip band |
| **Industry** | Wholesale food marketplace |
| **Page title** | Field to Pass |
| **Fonts** | Alfa Slab One, Vollkorn — Google Fonts, imported by Elementor automatically |
| **Elements** | 237 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (91 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install field-to-pass
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
field-to-pass/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/field-to-pass.page.jsx         the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F5F7F0` |
| `ink` | `#1C2418` |
| `field` | `#4E7B3A` |
| `soil` | `#7A5230` |
| `sun` | `#E5A83B` |
| `rule` | `#D2D9C7` |

Change a value, re-run `npx exjsx-kit install field-to-pass`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/field-to-pass.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `grower` | `media/grower.jpg` | A grower in the field, crates of just-lifted produce beside them |
| `kitchen_prep` | `media/kitchen_prep.jpg` | Chef prepping vegetables on a restaurant pass at first light |
| `produce_strip` | `media/produce_strip.jpg` | A row of seasonal produce laid out across a bench |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
