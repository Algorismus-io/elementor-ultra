/** Ridgeline Roof & Gutter — the whole landing page. Archetype: comparison ledger, two-column. */
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Ridgeline Roof & Gutter',
  slug: 'ridgeline-roofing',
  seo: {
    title: 'Ridgeline Roof & Gutter — fixed roof quotes in Whitcomb County',
    description:
      'Two crews, one county. A fixed price, a start date, and the name of the person on your roof. Typical 1,800 sq ft re-roof: 11,400 to 16,900 dollars, tear-off included.',
  },
};

const CTA = '#book';
const TEL = 'tel:+155501428890';
const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* The booking form. FREE Elementor has no atomic form widget (e_pro_atomic_form is inactive on
   this target), so it ships as one raw-HTML widget with inline styles — inline style attributes
   always render, unlike custom_css on an unlicensed install. Barlow is enqueued by the style
   props elsewhere on the page, so naming it here is safe. */
const FIELD =
  'width:100%;box-sizing:border-box;font-family:Barlow,sans-serif;font-size:16px;line-height:1.4;color:#151719;background:#FBFAF7;border:1px solid #D6D2CB;padding:13px 14px;outline:none;border-radius:0;';
const LABEL =
  'display:block;font-family:Barlow,sans-serif;font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#37474F;margin:0 0 7px;';
const ROW = 'margin:0 0 18px;';

const FORM_HTML = `
<form class="rl-book" action="mailto:yard@ridgelineroofgutter.com" method="post" enctype="text/plain" style="font-family:Barlow,sans-serif;">
  <p style="font-family:'Archivo Black',sans-serif;font-size:22px;line-height:1.25;color:#151719;margin:0 0 6px;">Book a walk-round</p>
  <p style="font-family:Barlow,sans-serif;font-size:15px;line-height:1.6;color:#37474F;margin:0 0 24px;">Six fields. It goes to the yard, not to a lead broker, and it is never sold on.</p>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:0 18px;">
    <div style="${ROW}">
      <label style="${LABEL}" for="rl-name">Your name</label>
      <input style="${FIELD}" id="rl-name" name="name" type="text" required placeholder="Jane Alderman">
    </div>
    <div style="${ROW}">
      <label style="${LABEL}" for="rl-phone">Phone</label>
      <input style="${FIELD}" id="rl-phone" name="phone" type="tel" required placeholder="555 0142 0000">
    </div>
  </div>

  <div style="${ROW}">
    <label style="${LABEL}" for="rl-address">Property address in Whitcomb County</label>
    <input style="${FIELD}" id="rl-address" name="address" type="text" required placeholder="14 Kestrel Road, Marlow">
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:0 18px;">
    <div style="${ROW}">
      <label style="${LABEL}" for="rl-job">What is happening</label>
      <select style="${FIELD}" id="rl-job" name="job">
        <option>Full re-roof</option>
        <option>Leak or flashing repair</option>
        <option>Storm damage, maybe a claim</option>
        <option>Gutters or guards</option>
        <option>Flat or low-slope section</option>
        <option>Not sure — please look</option>
      </select>
    </div>
    <div style="${ROW}">
      <label style="${LABEL}" for="rl-when">Start window that suits you</label>
      <select style="${FIELD}" id="rl-when" name="when">
        <option>As soon as you can (9 days out)</option>
        <option>Within the month</option>
        <option>Next quarter, planning ahead</option>
        <option>Emergency — I need a tarp today</option>
      </select>
    </div>
  </div>

  <div style="${ROW}">
    <label style="${LABEL}" for="rl-notes">Anything you have already noticed</label>
    <textarea style="${FIELD}height:104px;resize:vertical;" id="rl-notes" name="notes" rows="4" placeholder="Stain on the landing ceiling after the April storm. Granules in the front gutter."></textarea>
  </div>

  <button type="submit" style="width:100%;cursor:pointer;font-family:Barlow,sans-serif;font-size:16px;font-weight:700;color:#FFFFFF;background:#E8501B;border:0;border-radius:0;padding:18px 24px;box-shadow:3px 3px 0 0 #151719;">Get a fixed quote</button>

  <p style="font-family:Barlow,sans-serif;font-size:13px;line-height:1.6;color:#37474F;margin:16px 0 0;">Marcus or Tomas calls back inside one working day. No financing pitch, no third party, no 9pm follow-ups.</p>
</form>
<style>
  .rl-book input:focus, .rl-book select:focus, .rl-book textarea:focus { border-color: #E8501B; box-shadow: 0 0 0 2px rgba(232,80,27,.18); }
  .rl-book button:hover { background: #151719; box-shadow: 3px 3px 0 0 #E8501B; }
  @media (max-width: 767px) { .rl-book div[style*="grid-template-columns:1fr 1fr"] { grid-template-columns: 1fr; } }
</style>`;

/* ── repeaters (content props only — Elementor components cannot override styles) ────────── */

const LedgerLine = defineComponent(
  ({ item = '', amount = '' }) => {
    const t = useTheme();
    return (
      <div tw="flex flex-col w-full" gap={0}>
        <div tw="flex flex-row items-end justify-between w-full gap-5" pad={{ t: 13, b: 13 }}>
          <text size={16} font={t.font.body} color={t.color.slate} lh={1.45} w="auto">{item}</text>
          <text size={16} font={t.font.body} weight={700} color={t.color.ink} lh={1.45} ta="right" w="auto">{amount}</text>
        </div>
        <div w="100%" h={1} bg={t.color.rule} />
      </div>
    );
  },
  { title: 'Ledger Line', props: { item: { label: 'Item', group: 'Ledger' }, amount: { label: 'Amount', group: 'Ledger' } } },
);

const LedgerLineHidden = defineComponent(
  ({ item = '', amount = '' }) => {
    const t = useTheme();
    return (
      <div tw="flex flex-col w-full" gap={0}>
        <div tw="flex flex-row items-end justify-between w-full gap-5" pad={{ t: 13, b: 13 }}>
          <text size={16} font={t.font.body} color={t.color.dim} lh={1.45} w="auto">{item}</text>
          <text size={16} font={t.font.body} weight={700} color={t.color.signal} lh={1.45} ta="right" w="auto">{amount}</text>
        </div>
        <div w="100%" h={1} bg="#2E3338" />
      </div>
    );
  },
  { title: 'Ledger Line (hidden cost)', props: { item: { label: 'Item', group: 'Ledger' }, amount: { label: 'Amount', group: 'Ledger' } } },
);

const JobCard = defineComponent(
  ({ index = '', title = '', body = '', price = '', span = '' }) => {
    const t = useTheme();
    return (
      <div
        tw="flex flex-col w-full h-full gap-4"
        pad={26}
        bg={t.color.white}
        border={[1, t.color.rule]}
        shadow={[[2, 0, 0, '#EFEBE4'], [10, 24, -14, 'rgba(21, 23, 25, 0.22)']]}
        hover={{ border: [1, t.color.ink], shadow: [[2, 0, 0, '#E8501B'], [14, 30, -14, 'rgba(21, 23, 25, 0.3)']] }}
      >
        <text size={12} font={t.font.body} weight={700} ls={0.14} color={t.color.signal} lh={1}>{index}</text>
        <heading tag="h3" size={21} font={t.font.head} color={t.color.ink} lh={1.15}>{title}</heading>
        <text size={15} font={t.font.body} color={t.color.slate} lh={1.6} flex={1}>{body}</text>
        <div w="100%" h={1} bg={t.color.rule} m={{ t: 4 }} />
        <text size={19} font={t.font.head} color={t.color.ink} lh={1.25}>{price}</text>
        <text size={13} font={t.font.body} weight={600} ls={0.06} color={t.color.slate} lh={1.3}>{span}</text>
      </div>
    );
  },
  {
    title: 'Job Price Card',
    props: {
      index: { label: 'Index', group: 'Job' },
      title: { label: 'Job title', group: 'Job' },
      body: { label: 'Description', group: 'Job' },
      price: { label: 'Price range', group: 'Job' },
      span: { label: 'Timeline', group: 'Job' },
    },
  },
);

const StormStep = defineComponent(
  ({ n = '', title = '', body = '' }) => {
    const t = useTheme();
    return (
      <div tw="flex flex-row w-full gap-4 items-start">
        <text size={13} font={t.font.head} color={t.color.ink} bg={t.color.signal} lh={1} w={30} h={30} ta="center" pad={{ t: 9 }} radius={999}>{n}</text>
        <div tw="flex flex-col gap-1" flex={1}>
          <heading tag="h3" size={17} font={t.font.head} color={t.color.ground} lh={1.25}>{title}</heading>
          <text size={15} font={t.font.body} color={t.color.dim} lh={1.6}>{body}</text>
        </div>
      </div>
    );
  },
  {
    title: 'Storm Photo Step',
    props: { n: { label: 'Number', group: 'Step' }, title: { label: 'Title', group: 'Step' }, body: { label: 'Body', group: 'Step' } },
  },
);

/* ── data ─────────────────────────────────────────────────────────────────────────────────── */

const OURS = [
  ['Tear-off, all layers', 'included'],
  ['Skip hire and disposal', 'included'],
  ['Synthetic underlayment', 'included'],
  ['New step and valley flashing', 'included'],
  ['Ridge vent and boots', 'included'],
  ['Magnet sweep and cleanup', 'included'],
  ['12-year workmanship warranty', 'included'],
];

const THEIRS = [
  ['Headline price on the phone', '8,900 dollars'],
  ['Disposal fee, added on day two', '+ 780 dollars'],
  ['Flashing surcharge', '+ 640 dollars'],
  ['"Deck repair" at 14 dollars a sq ft', '+ unknown'],
  ['Broker fee inside the price', '+ 10 to 15 percent'],
  ['Crew subcontracted at 3pm the day before', 'no name'],
  ['Warranty held by the call centre', 'if they answer'],
];

const JOBS = [
  ['01', 'Full asphalt re-roof', 'Complete tear-off to the deck, rotten board replaced at cost, synthetic underlayment, architectural shingle, all new flashing. 1,800 sq ft typical.', '11,400 – 16,900 dollars', 'TWO TO THREE DAYS ON SITE'],
  ['02', 'Leak and flashing repair', 'Chimney, valley, skylight, or a nail pop that finally let go. We find it from the attic first, then fix the actual cause, not the stain.', '480 – 2,200 dollars', 'USUALLY WITHIN THE WEEK'],
  ['03', 'Seamless gutter and guards', 'Rolled on site in 5 or 6 inch aluminium, hidden hangers every 24 inches, downspouts run away from the footing. 140 ft typical.', '1,650 – 3,400 dollars', 'ONE DAY'],
  ['04', 'Low-slope and flat sections', 'Porch roofs and rear additions in fully adhered TPO, with proper edge metal and a real drainage fall. No rolled asphalt patchwork.', '9,200 – 14,800 dollars', 'TWO DAYS'],
];

const STORM = [
  ['1', 'The gutter, not the roof', 'Shingle granules pooled in the gutter trough and at the downspout outlet. Granule loss dates the hit better than anything on the roof does.'],
  ['2', 'Anything soft and metal', 'Gutters, downspouts, vents, the aluminium trim, the garage door, the grill lid. Dents in soft metal prove hail size when the shingles are ambiguous.'],
  ['3', 'The north slope', 'It weathers hardest and adjusters check it first. Shoot it from the ground with something in frame for scale — a tape, a coin, your hand.'],
  ['4', 'Time and date, before cleanup', 'Photograph before anyone picks anything up, and keep the original files. A phone photo carries the timestamp the claim will be argued over.'],
];

/* ── page ─────────────────────────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>

    {/* 1 ── phone + service area band ────────────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ink}>
      <div tw="flex flex-row w-full items-center justify-between gap-4 flex-wrap max-md:flex-col max-md:items-start max-md:gap-3" maxw={1240} pad={[14, 32]} mobile={{ pad: [16, 20] }}>
        <text size={13} font={t.font.head} color={t.color.ground} ls={0.1} lh={1.2} w="auto">RIDGELINE ROOF &amp; GUTTER</text>
        <div tw="flex flex-row items-center gap-6 flex-wrap max-md:gap-2 max-md:flex-col max-md:items-start" w="auto">
          <text
            href={TEL}
            size={14}
            font={t.font.body}
            weight={700}
            color={t.color.signal}
            lh={1.3}
            w="auto"
            hover={{ color: t.color.white }}
          >
            Call the yard direct: 555 0142 8890, 7am to 6pm
          </text>
          <text size={14} font={t.font.body} color={t.color.dim} lh={1.3} w="auto">Whitcomb County only · Yard at 2210 Kestrel Road</text>
        </div>
      </div>
    </box>

    {/* 2 ── hero: copy left, crew right ──────────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>
      <grid cols={12} gap={44} maxw={1240} w="100%" pad={[80, 32]} tablet={{ pad: [64, 32] }} mobile={{ pad: [44, 20], gap: 32 }}>

        <div span={7} tw="flex flex-col gap-6 items-start" tablet={{ span: 12 }}>
          <text size={12} font={t.font.body} weight={700} ls={0.16} color={t.color.signal} lh={1.2}>TWO CREWS · ONE COUNTY · NO BROKERS</text>
          <h1 size={62} font={t.font.head} color={t.color.ink} lh={1.02} ls={-0.02} tablet={{ size: 52 }} mobile={{ size: 34 }}>
            A roof quote with the numbers left in.
          </h1>
          <text size={18} font={t.font.body} color={t.color.slate} lh={1.65} maxw={560} mobile={{ size: 16 }}>
            We are two crews covering Whitcomb County. You get a fixed price, a start date, and the name of the person who will be on your roof. No lead brokers, no financing upsell, no mystery line items.
          </text>
          <div tw="flex flex-row items-center gap-4 flex-wrap max-md:w-full" pad={{ t: 6 }}>
            <text
              href={CTA}
              size={16}
              font={t.font.body}
              weight={700}
              color={t.color.white}
              bg={t.color.signal}
              lh={1}
              pad={[18, 30]}
              w="auto"
              shadow={[[3, 0, 0, t.color.ink]]}
              hover={{ bg: t.color.ink, shadow: [[3, 0, 0, t.color.signal]] }}
            >
              Get a fixed quote
            </text>
            <text
              href={TEL}
              size={16}
              font={t.font.body}
              weight={700}
              color={t.color.ink}
              lh={1}
              pad={[17, 24]}
              w="auto"
              border={[1, t.color.ink]}
              hover={{ bg: t.color.ink, color: t.color.ground }}
            >
              Or call 555 0142 8890
            </text>
          </div>
          <div tw="flex flex-row items-center gap-3 w-full" pad={{ t: 10 }}>
            <div w={40} h={3} bg={t.color.ink} />
            <text size={15} font={t.font.body} weight={600} color={t.color.ink} lh={1.4} flex={1}>
              Next open start date: 9 days out. Emergency tarping same day.
            </text>
          </div>
        </div>

        <div span={5} tw="flex flex-col gap-0 w-full" tablet={{ span: 12 }}>
          <img src={media.crew_working.id} w="100%" h={330} fit="cover" tablet={{ h: 300 }} mobile={{ h: 210 }} />
          <div tw="flex flex-col gap-2 w-full" pad={26} bg={t.color.ink}>
            <text size={12} font={t.font.body} weight={700} ls={0.14} color={t.color.dim} lh={1.2}>THE NUMBER PEOPLE ACTUALLY WANT</text>
            <text size={22} font={t.font.head} color={t.color.ground} lh={1.3} mobile={{ size: 19 }}>
              Typical full re-roof, 1,800 sq ft asphalt: <em>11,400 to 16,900 dollars</em> including tear-off.
            </text>
            <text size={14} font={t.font.body} color={t.color.dim} lh={1.6}>
              Your house gets its own number after we walk it. That number does not move once it is signed.
            </text>
          </div>
        </div>

      </grid>
    </box>

    {/* 3 ── the ledger ───────────────────────────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ink}>
      <div tw="flex flex-col w-full gap-10" maxw={1240} pad={[92, 32]} tablet={{ pad: [72, 32] }} mobile={{ pad: [52, 20], gap: 28 }}>

        <div tw="flex flex-row w-full items-end justify-between gap-8 flex-wrap max-md:flex-col max-md:items-start max-md:gap-4">
          <div tw="flex flex-col gap-3" maxw={620}>
            <text size={12} font={t.font.body} weight={700} ls={0.16} color={t.color.signal} lh={1.2}>THE LEDGER</text>
            <heading tag="h2" size={44} font={t.font.head} color={t.color.ground} lh={1.08} tablet={{ size: 38 }} mobile={{ size: 28 }}>
              What we charge, next to what a call-centre quote hides.
            </heading>
          </div>
          <text size={15} font={t.font.body} color={t.color.dim} lh={1.65} maxw={380}>
            Same 1,800 sq ft roof, same shingle, same county. The difference is which line items you are told about before the crew arrives.
          </text>
        </div>

        <grid cols={2} gap={0} w="100%" mobile={{ gridCols: 1, gap: 24 }}>

          <div tw="flex flex-col w-full gap-0" pad={34} bg={t.color.ground} mobile={{ pad: 22 }}>
            <div tw="flex flex-col gap-2" pad={{ b: 18 }}>
              <text size={12} font={t.font.body} weight={700} ls={0.14} color={t.color.signal} lh={1.2}>RIDGELINE — ALL IN THE NUMBER</text>
              <heading tag="h3" size={26} font={t.font.head} color={t.color.ink} lh={1.15} mobile={{ size: 21 }}>One price. One page. One crew you meet first.</heading>
            </div>
            <div w="100%" h={3} bg={t.color.ink} />
            {OURS.map(([item, amount]) => <LedgerLine item={item} amount={amount} />)}
            <div tw="flex flex-row items-end justify-between w-full gap-5" pad={{ t: 22 }}>
              <text size={16} font={t.font.head} color={t.color.ink} lh={1.3} w="auto">Fixed total, signed</text>
              <text size={26} font={t.font.head} color={t.color.signal} lh={1.15} ta="right" w="auto" mobile={{ size: 21 }}>13,650 dollars</text>
            </div>
            <text size={14} font={t.font.body} color={t.color.slate} lh={1.6} pad={{ t: 10 }}>
              Tear-off, disposal, underlayment, flashing, ridge vent, cleanup, 12-year workmanship warranty. All in the number.
            </text>
          </div>

          <div tw="flex flex-col w-full gap-0" pad={34} bg={t.color.ink2} border={[1, '#2E3338']} mobile={{ pad: 22 }}>
            <div tw="flex flex-col gap-2" pad={{ b: 18 }}>
              <text size={12} font={t.font.body} weight={700} ls={0.14} color={t.color.dim} lh={1.2}>CALL-CENTRE QUOTE — WHAT ARRIVES LATER</text>
              <heading tag="h3" size={26} font={t.font.head} color={t.color.ground} lh={1.15} mobile={{ size: 21 }}>A headline price, then five more phone calls.</heading>
            </div>
            <div w="100%" h={3} bg={t.color.signal} />
            {THEIRS.map(([item, amount]) => <LedgerLineHidden item={item} amount={amount} />)}
            <div tw="flex flex-row items-end justify-between w-full gap-5" pad={{ t: 22 }}>
              <text size={16} font={t.font.head} color={t.color.ground} lh={1.3} w="auto">Actual total, day five</text>
              <text size={26} font={t.font.head} color={t.color.signal} lh={1.15} ta="right" w="auto" mobile={{ size: 21 }}>14,900+ dollars</text>
            </div>
            <text size={14} font={t.font.body} color={t.color.dim} lh={1.6} pad={{ t: 10 }}>
              Call-centre quote: headline price, then disposal fee, then flashing surcharge, then a crew you never meet subcontracted at 3pm the day before.
            </text>
          </div>

        </grid>
      </div>
    </box>

    {/* 4 ── four jobs, with price ranges ─────────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>
      <div tw="flex flex-col w-full gap-9" maxw={1240} pad={[88, 32]} tablet={{ pad: [68, 32] }} mobile={{ pad: [52, 20], gap: 26 }}>
        <div tw="flex flex-row w-full items-end justify-between gap-8 flex-wrap max-md:flex-col max-md:items-start max-md:gap-3">
          <heading tag="h2" size={40} font={t.font.head} color={t.color.ink} lh={1.08} maxw={620} tablet={{ size: 34 }} mobile={{ size: 27 }}>
            Four jobs we do, and what they typically cost.
          </heading>
          <text size={15} font={t.font.body} color={t.color.slate} lh={1.6} maxw={360}>
            Ranges, not teasers. Where your house lands inside the range depends on pitch, layers, and deck condition — we tell you which on the walk-round.
          </text>
        </div>
        <grid cols={4} gap={20} w="100%" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }} motion={FADE}>
          {JOBS.map(([index, title, body, price, span]) => (
            <JobCard index={index} title={title} body={body} price={price} span={span} />
          ))}
        </grid>
        <div tw="flex flex-row items-center gap-4 w-full flex-wrap max-md:flex-col max-md:items-start max-md:gap-3" pad={[18, 24]} bg={t.color.white} border={[1, t.color.rule]}>
          <text size={15} font={t.font.body} color={t.color.slate} lh={1.5} flex={1}>
            Rotten decking is the one thing nobody can price from the ground. Ours is charged at cost — 68 dollars a sheet, photographed before it goes on the invoice.
          </text>
          <text href={CTA} size={15} font={t.font.body} weight={700} color={t.color.signal} lh={1.4} w="auto" hover={{ color: t.color.ink }}>
            Get your number →
          </text>
        </div>
      </div>
    </box>

    {/* 5 ── storm damage: what to photograph ─────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ink}>
      <grid cols={12} gap={48} maxw={1240} w="100%" pad={[88, 32]} tablet={{ pad: [68, 32] }} mobile={{ pad: [52, 20], gap: 30 }}>
        <div span={5} tw="flex flex-col gap-0 w-full" tablet={{ span: 12 }}>
          <img src={media.damage_detail.id} w="100%" h={380} fit="cover" tablet={{ h: 300 }} mobile={{ h: 220 }} />
          <div tw="flex flex-col gap-2" pad={[18, 20]} bg={t.color.ink2}>
            <text size={13} font={t.font.body} weight={700} ls={0.1} color={t.color.signal} lh={1.3}>GRANULE LOSS, KESTREL ROAD, LAST APRIL</text>
            <text size={14} font={t.font.body} color={t.color.dim} lh={1.6}>
              This one was approved in eleven days because the homeowner had ground photos before the cleanup crew came through.
            </text>
          </div>
        </div>
        <div span={7} tw="flex flex-col gap-7 items-start" tablet={{ span: 12 }}>
          <div tw="flex flex-col gap-3">
            <text size={12} font={t.font.body} weight={700} ls={0.16} color={t.color.signal} lh={1.2}>STORM DAMAGE</text>
            <heading tag="h2" size={40} font={t.font.head} color={t.color.ground} lh={1.08} tablet={{ size: 34 }} mobile={{ size: 27 }}>
              What to photograph before you call anyone.
            </heading>
            <text size={17} font={t.font.body} color={t.color.dim} lh={1.65} maxw={560} mobile={{ size: 15 }}>
              Before you call anyone, photograph the ground: shingle granules in the gutter, dented soft metal, and the north slope. That is what an adjuster wants.
            </text>
          </div>
          <div tw="flex flex-col gap-5 w-full">
            {STORM.map(([n, title, body]) => <StormStep n={n} title={title} body={body} />)}
          </div>
          <text size={15} font={t.font.body} weight={600} color={t.color.ground} lh={1.55} pad={[16, 20]} bg={t.color.ink2} border={[1, '#2E3338']}>
            Do not get on the roof. Nothing you can photograph up there is worth the fall, and we shoot it properly for you at no charge.
          </text>
        </div>
      </grid>
    </box>

    {/* 6 ── the two crews ────────────────────────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>
      <div tw="flex flex-col w-full gap-9" maxw={1240} pad={[88, 32]} tablet={{ pad: [68, 32] }} mobile={{ pad: [52, 20], gap: 26 }}>
        <div tw="flex flex-col gap-3" maxw={680}>
          <text size={12} font={t.font.body} weight={700} ls={0.16} color={t.color.signal} lh={1.2}>WHO TURNS UP</text>
          <heading tag="h2" size={40} font={t.font.head} color={t.color.ink} lh={1.08} tablet={{ size: 34 }} mobile={{ size: 27 }}>
            Two crews. You are told which one, by name, when you sign.
          </heading>
        </div>

        <grid cols={2} gap={24} w="100%" mobile={{ gridCols: 1 }}>

          <div tw="flex flex-col gap-5 w-full" pad={30} bg={t.color.white} border={[1, t.color.rule]} shadow={[[2, 0, 0, '#EFEBE4'], [12, 28, -16, 'rgba(21, 23, 25, 0.2)']]} mobile={{ pad: 22 }}>
            <div tw="flex flex-row items-end justify-between gap-4 w-full">
              <heading tag="h3" size={24} font={t.font.head} color={t.color.ink} lh={1.15}>Crew One — tear-offs</heading>
              <text size={13} font={t.font.body} weight={700} ls={0.08} color={t.color.signal} lh={1.3} w="auto">61 YRS COMBINED</text>
            </div>
            <div w="100%" h={2} bg={t.color.ink} />
            <div tw="flex flex-col gap-3 w-full">
              <text size={16} font={t.font.body} color={t.color.slate} lh={1.5}><strong>Marcus Deel</strong> — foreman, 24 years on the tools. Runs every tear-off and does the attic check himself.</text>
              <text size={16} font={t.font.body} color={t.color.slate} lh={1.5}><strong>Ray Ortiz</strong> — 19 years. Flashing and valleys; the reason we rarely go back to a chimney twice.</text>
              <text size={16} font={t.font.body} color={t.color.slate} lh={1.5}><strong>Dev Whitaker</strong> — 11 years. Deck repair, ridge vent, and the magnet sweep before the truck leaves.</text>
              <text size={16} font={t.font.body} color={t.color.slate} lh={1.5}><strong>Callum Reyes</strong> — 7 years. Ground, loading, and the tarp that goes on if the weather turns.</text>
            </div>
            <text size={14} font={t.font.body} color={t.color.slate} lh={1.6}>Starts at 7am, off your street by 5pm, same four faces every day of the job.</text>
          </div>

          <div tw="flex flex-col gap-5 w-full" pad={30} bg={t.color.white} border={[1, t.color.rule]} shadow={[[2, 0, 0, '#EFEBE4'], [12, 28, -16, 'rgba(21, 23, 25, 0.2)']]} mobile={{ pad: 22 }}>
            <div tw="flex flex-row items-end justify-between gap-4 w-full">
              <heading tag="h3" size={24} font={t.font.head} color={t.color.ink} lh={1.15}>Crew Two — repairs and gutter</heading>
              <text size={13} font={t.font.body} weight={700} ls={0.08} color={t.color.signal} lh={1.3} w="auto">38 YRS COMBINED</text>
            </div>
            <div w="100%" h={2} bg={t.color.ink} />
            <div tw="flex flex-col gap-3 w-full">
              <text size={16} font={t.font.body} color={t.color.slate} lh={1.5}><strong>Tomas Vance</strong> — foreman, 16 years on the tools. Leak diagnosis, low-slope TPO, and every emergency tarp.</text>
              <text size={16} font={t.font.body} color={t.color.slate} lh={1.5}><strong>Priya Nandakumar</strong> — 13 years. Runs the seamless gutter machine and sets every hanger line.</text>
              <text size={16} font={t.font.body} color={t.color.slate} lh={1.5}><strong>Owen Brackett</strong> — 9 years. Skylights, boots, and the small repairs nobody else will drive out for.</text>
            </div>
            <text size={14} font={t.font.body} color={t.color.slate} lh={1.6}>This is the crew on the phone at 6am after a storm. Tarping is same day inside the county.</text>
          </div>

        </grid>
      </div>
    </box>

    {/* 7 ── insurance claim help ─────────────────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ink2}>
      <grid cols={12} gap={44} maxw={1240} w="100%" pad={[84, 32]} tablet={{ pad: [64, 32] }} mobile={{ pad: [50, 20], gap: 28 }}>
        <div span={4} tw="flex flex-col gap-4 items-start" tablet={{ span: 12 }}>
          <text size={12} font={t.font.body} weight={700} ls={0.16} color={t.color.signal} lh={1.2}>INSURANCE</text>
          <heading tag="h2" size={38} font={t.font.head} color={t.color.ground} lh={1.08} tablet={{ size: 32 }} mobile={{ size: 26 }}>
            Claim help, plainly explained.
          </heading>
          <text size={16} font={t.font.body} color={t.color.dim} lh={1.65}>
            We are roofers, not public adjusters. We do not take a percentage of your claim and we do not ask you to sign anything over to us.
          </text>
          <text href={TEL} size={15} font={t.font.body} weight={700} color={t.color.signal} lh={1.4} hover={{ color: t.color.ground }} w="auto">
            Talk it through: 555 0142 8890
          </text>
        </div>
        <div span={8} tw="flex flex-col gap-0 w-full" tablet={{ span: 12 }}>
          <div w="100%" h={2} bg={t.color.signal} />
          <div tw="flex flex-row w-full gap-6 items-start max-md:flex-col max-md:gap-2" pad={{ t: 22, b: 22 }}>
            <text size={13} font={t.font.head} color={t.color.signal} lh={1.4} w={78}>STEP 01</text>
            <div tw="flex flex-col gap-2" flex={1}>
              <heading tag="h3" size={20} font={t.font.head} color={t.color.ground} lh={1.2}>We inspect and document, free, before you file</heading>
              <text size={15} font={t.font.body} color={t.color.dim} lh={1.65}>Photos, measurements, and a written scope in the format adjusters read. If there is no claim in it, we say so and you have lost nothing but an hour.</text>
            </div>
          </div>
          <div w="100%" h={1} bg="#343A3F" />
          <div tw="flex flex-row w-full gap-6 items-start max-md:flex-col max-md:gap-2" pad={{ t: 22, b: 22 }}>
            <text size={13} font={t.font.head} color={t.color.signal} lh={1.4} w={78}>STEP 02</text>
            <div tw="flex flex-col gap-2" flex={1}>
              <heading tag="h3" size={20} font={t.font.head} color={t.color.ground} lh={1.2}>You file it, in your name, from your account</heading>
              <text size={15} font={t.font.body} color={t.color.dim} lh={1.65}>It is your policy and your claim number. We will sit at the kitchen table while you make the call, but the claim never runs through us.</text>
            </div>
          </div>
          <div w="100%" h={1} bg="#343A3F" />
          <div tw="flex flex-row w-full gap-6 items-start max-md:flex-col max-md:gap-2" pad={{ t: 22, b: 22 }}>
            <text size={13} font={t.font.head} color={t.color.signal} lh={1.4} w={78}>STEP 03</text>
            <div tw="flex flex-col gap-2" flex={1}>
              <heading tag="h3" size={20} font={t.font.head} color={t.color.ground} lh={1.2}>We meet the adjuster on the roof</heading>
              <text size={15} font={t.font.body} color={t.color.dim} lh={1.65}>Two people looking at the same slope on the same day settles most disagreements. When the scope comes back short, we send the supplement with the photos attached.</text>
            </div>
          </div>
          <div w="100%" h={1} bg="#343A3F" />
          <div tw="flex flex-row w-full gap-6 items-start max-md:flex-col max-md:gap-2" pad={{ t: 22, b: 22 }}>
            <text size={13} font={t.font.head} color={t.color.signal} lh={1.4} w={78}>STEP 04</text>
            <div tw="flex flex-col gap-2" flex={1}>
              <heading tag="h3" size={20} font={t.font.head} color={t.color.ground} lh={1.2}>You pay the deductible, and nothing more</heading>
              <text size={15} font={t.font.body} color={t.color.dim} lh={1.65}>Anyone offering to waive or absorb your deductible is committing fraud with your name on it. We will not, and you should hang up on whoever does.</text>
            </div>
          </div>
          <div w="100%" h={2} bg={t.color.signal} />
        </div>
      </grid>
    </box>

    {/* 8 ── booking ──────────────────────────────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground} id="book">
      <grid cols={12} gap={44} maxw={1240} w="100%" pad={[88, 32]} tablet={{ pad: [68, 32] }} mobile={{ pad: [52, 20], gap: 30 }}>

        <div span={5} tw="flex flex-col gap-6 items-start" tablet={{ span: 12 }}>
          <div tw="flex flex-col gap-3">
            <text size={12} font={t.font.body} weight={700} ls={0.16} color={t.color.signal} lh={1.2}>BOOK THE WALK-ROUND</text>
            <heading tag="h2" size={40} font={t.font.head} color={t.color.ink} lh={1.08} tablet={{ size: 34 }} mobile={{ size: 27 }}>
              Get a fixed quote.
            </heading>
          </div>
          <div tw="flex flex-col gap-2 w-full" pad={22} bg={t.color.ink}>
            <text size={12} font={t.font.body} weight={700} ls={0.14} color={t.color.dim} lh={1.2}>AVAILABILITY</text>
            <text size={22} font={t.font.head} color={t.color.ground} lh={1.3} mobile={{ size: 19 }}>Next open start date: 9 days out. Emergency tarping same day.</text>
          </div>
          <div tw="flex flex-col gap-3 w-full">
            <text size={16} font={t.font.body} color={t.color.slate} lh={1.6}><strong>1.</strong> Marcus or Tomas calls you back inside one working day, from a local number.</text>
            <text size={16} font={t.font.body} color={t.color.slate} lh={1.6}><strong>2.</strong> We walk the roof and the attic, 45 minutes, no sales script and nobody sits in your kitchen for two hours.</text>
            <text size={16} font={t.font.body} color={t.color.slate} lh={1.6}><strong>3.</strong> A one-page fixed price by email the next morning, with the crew name and the start date on it.</text>
          </div>
          <text size={15} font={t.font.body} color={t.color.slate} lh={1.6}>
            Leaking right now? Do not use the form — call the yard on <strong>555 0142 8890</strong> and someone will pick up between 7am and 6pm.
          </text>
        </div>

        <div span={7} tw="flex flex-col w-full" tablet={{ span: 12 }} pad={32} bg={t.color.white} border={[1, t.color.rule]} shadow={[[3, 0, 0, t.color.rule], [18, 40, -20, 'rgba(21, 23, 25, 0.25)']]} mobile={{ pad: 20 }}>
          <html raw={FORM_HTML} />
        </div>

      </grid>
    </box>

    {/* 9 ── foot band ────────────────────────────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ink}>
      <div tw="flex flex-row w-full items-center justify-between gap-5 flex-wrap max-md:flex-col max-md:items-start max-md:gap-3" maxw={1240} pad={[30, 32]} mobile={{ pad: [26, 20] }}>
        <text size={13} font={t.font.head} color={t.color.ground} ls={0.1} lh={1.4} w="auto">RIDGELINE ROOF &amp; GUTTER · WHITCOMB COUNTY</text>
        <text size={14} font={t.font.body} color={t.color.dim} lh={1.5} w="auto">Licensed and insured · WC-ROOF-40118 · Yard at 2210 Kestrel Road, open 7am to 6pm</text>
        <text href={TEL} size={14} font={t.font.body} weight={700} color={t.color.signal} lh={1.5} w="auto" hover={{ color: t.color.white }}>555 0142 8890</text>
      </div>
    </box>

  </box>
);
