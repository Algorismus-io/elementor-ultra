import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Second Spring',
  slug: 'second-spring',
  seo: {
    title: 'Second Spring — a menopause clinic run by doctors who trained in it',
    description:
      'Forty-five minute first appointments with menopause-trained doctors, prescriptions to your door, and unlimited follow-up for £290 a year.',
  },
};

/* ── shared style constants ───────────────────────────────────────────────── */

/* Two-tone emphasis inside long-form paragraphs. One shared raw block, per CONVENTIONS §5. */
const EMPH = '& em { font-style: normal; color: #C36A63; } & strong { font-weight: 600; color: #2A2320; }';
const EMPH_LIGHT = '& em { font-style: normal; color: #E0A9A3; } & strong { font-weight: 600; color: #FBF6F1; }';

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 700 };
const FADE_SLOW = { effect: 'fade', trigger: 'scrollIn', duration: 900, delay: 120 };

/* A hairline rule that never gets reused as an instance — factory, per CONVENTIONS §4. */
const Rule = (color = 'rgba(42,35,32,0.16)') => (
  <div cls="rule" w="100%" h={1} bg={color} />
);

/* ── repeaters (content props only) ───────────────────────────────────────── */

const Symptom = defineComponent(
  ({ label = '', note = '' }) => (
    <div cls="symptom" tw="flex flex-col gap-1 w-full" pad={{ t: 14, b: 14 }} raw="border-top: 1px solid rgba(251,246,241,0.18);">
      <text size={17} weight={500} font="Figtree" color="#FBF6F1" lh={1.35}>{label}</text>
      <text size={14} font="Figtree" color="rgba(251,246,241,0.62)" lh={1.5}>{note}</text>
    </div>
  ),
  {
    title: 'Symptom line',
    props: {
      label: { label: 'Symptom', group: 'Content' },
      note: { label: 'What it is mistaken for', group: 'Content' },
    },
  },
);

const Step = defineComponent(
  ({ minute = '', title = '', body = '' }) => (
    <div cls="step" tw="flex flex-col gap-2 w-full" pad={{ l: 26, t: 4, b: 22 }} raw="border-left: 1px solid rgba(124,147,130,0.55);">
      <text size={13} weight={600} font="Figtree" color="#7C9382" ls={0.12} raw="text-transform: uppercase;">{minute}</text>
      <heading tag="h3" size={24} font="Instrument Serif" weight={400} color="#2A2320" lh={1.2}>{title}</heading>
      <text size={16} font="Figtree" color="rgba(42,35,32,0.78)" lh={1.7} maxw={520}>{body}</text>
    </div>
  ),
  {
    title: 'Appointment step',
    props: {
      minute: { label: 'Timing', group: 'Content' },
      title: { label: 'Heading', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
    },
  },
);

const Doctor = defineComponent(
  ({ name = '', role = '', creds = '', note = '' }) => (
    <div cls="doctor" tw="flex flex-col gap-2 w-full" pad={{ t: 26, b: 26 }} raw="border-top: 1px solid rgba(42,35,32,0.14);">
      <heading tag="h3" size={30} font="Instrument Serif" weight={400} color="#2A2320" lh={1.15}>{name}</heading>
      <text size={14} weight={600} font="Figtree" color="#7C9382" ls={0.1} raw="text-transform: uppercase;">{role}</text>
      <text size={16} font="Figtree" color="#4A3A38" lh={1.6} weight={500}>{creds}</text>
      <text size={16} font="Figtree" color="rgba(42,35,32,0.74)" lh={1.7} maxw={560}>{note}</text>
    </div>
  ),
  {
    title: 'Doctor',
    props: {
      name: { label: 'Name', group: 'Content' },
      role: { label: 'Role', group: 'Content' },
      creds: { label: 'Menopause qualifications', group: 'Content' },
      note: { label: 'Note', group: 'Content' },
    },
  },
);

const Account = defineComponent(
  ({ quote = '', attr = '', since = '' }) => (
    <div cls="account" tw="flex flex-col gap-5 w-full" pad={{ t: 34, b: 34 }} raw="border-top: 1px solid rgba(42,35,32,0.14);">
      <text
        size={24}
        font="Instrument Serif"
        color="#2A2320"
        lh={1.5}
        maxw={720}
        mobile={{ size: 20 }}
        raw="& em { font-style: normal; color: #C36A63; }"
      >
        {quote}
      </text>
      <div tw="flex flex-row items-center gap-3 w-full flex-wrap">
        <div w={26} h={1} bg="#C36A63" />
        <text size={15} weight={600} font="Figtree" color="#4A3A38">{attr}</text>
        <text size={14} font="Figtree" color="rgba(42,35,32,0.55)">{since}</text>
      </div>
    </div>
  ),
  {
    title: 'Patient account',
    props: {
      quote: { label: 'In her words', group: 'Content' },
      attr: { label: 'Attribution', group: 'Content' },
      since: { label: 'Context', group: 'Content' },
    },
  },
);

/* ── data ─────────────────────────────────────────────────────────────────── */

const SYMPTOMS = [
  { label: 'Joint pain', note: 'Told it was wear and tear, or the running you did in your thirties.' },
  { label: 'Ringing ears', note: 'Referred to audiology. Hearing normal. No further explanation.' },
  { label: 'Rage that arrives on a schedule', note: 'Called a personality problem, not a hormonal one.' },
  { label: 'Burning mouth', note: 'Sent to the dentist twice. Nothing found either time.' },
  { label: 'Waking at 3am with your heart going', note: 'Written up as anxiety. Offered a beta blocker.' },
  { label: 'Forgetting the word for fork', note: 'The one that frightens people most, and is spoken about least.' },
  { label: 'Skin that itches under the surface', note: 'Formication. Rarely mentioned in any leaflet.' },
  { label: 'Recurrent urinary infections', note: 'Course after course of antibiotics. No one checked oestrogen.' },
  { label: 'Frozen shoulder', note: 'Physio, six months, and no one asked about your periods.' },
  { label: 'Flooding periods you plan your week around', note: 'Common in perimenopause. Not normal to endure alone.' },
];

const STEPS = [
  {
    minute: 'Before you join',
    title: 'Your doctor has already read your history',
    body: 'You send your notes, medications and a symptom questionnaire when you book. Nobody starts the call by asking you to explain yourself from the beginning.',
  },
  {
    minute: 'Minutes 0–15',
    title: 'A full symptom score, taken seriously',
    body: 'We work through every system — sleep, mood, joints, skin, bladder, libido, memory — and score it. It becomes the baseline we measure every later change against.',
  },
  {
    minute: 'Minutes 15–30',
    title: 'Your risks, reviewed properly',
    body: 'Family history, blood pressure, migraine with aura, clotting history, breast history. We tell you what the evidence actually says about your situation, including where it is uncertain.',
  },
  {
    minute: 'Minutes 30–45',
    title: 'A written plan you can show your GP',
    body: 'Doses, route, what to expect in week two and week eight, and what would make us change course. It arrives as a PDF the same day, addressed to you and written for your GP to read.',
  },
];

const DOCTORS = [
  {
    name: 'Dr Ruth Okonjo',
    role: 'Clinical Director',
    creds: 'MBBS · MRCGP · British Menopause Society Advanced Certificate',
    note: 'Sixteen years in general practice before menopause medicine became the whole of her work. She runs our prescribing review and our complex-case clinic.',
  },
  {
    name: 'Dr Helen Marsh',
    role: 'Menopause Specialist',
    creds: 'MBChB · MRCOG · BMS Principles & Practice of Menopause Care',
    note: 'A gynaecologist by training, with a particular interest in genitourinary symptoms and in women who cannot take systemic oestrogen.',
  },
  {
    name: 'Dr Priya Anand',
    role: 'Menopause Specialist',
    creds: 'MBBS · MRCGP · BMS Advanced Certificate · Faculty of Sexual & Reproductive Healthcare',
    note: 'Works mostly with early and surgical menopause, and with women whose first symptoms began well before anybody thought to look for this.',
  },
];

const ACCOUNTS = [
  {
    quote:
      'I had been to my surgery four times in two years. On the third Second Spring appointment my doctor adjusted the dose again and I slept through the night for the first time since 2021.',
    attr: 'Anita, 51',
    since: 'Leeds · with us since 2024',
  },
  {
    quote:
      'What I remember is that she had read everything before we started. I did not have to perform being ill. She asked about my hands, and I had not even written the hands down.',
    attr: 'Frances, 47',
    since: 'Cardiff · with us since 2025',
  },
  {
    quote:
      'I went in expecting to be sold something. She told me testosterone was probably not the answer for me yet, and why. I have never had a private clinic talk me out of anything before.',
    attr: 'Denise, 55',
    since: 'Newcastle · with us since 2024',
  },
];

/* ── the page ─────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>

    {/* 1 — Opening letter. No navigation, no hero image. Column sits left of centre. */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 88, b: 104, l: 24, r: 24 }} tablet={{ pad: { t: 72, b: 84 } }} mobile={{ pad: { t: 56, b: 72, l: 20, r: 20 } }}>
      <div tw="flex flex-col w-full max-w-[1080px] gap-14">

        <div tw="flex flex-row items-end gap-4 w-full flex-wrap">
          <heading tag="h2" size={19} font="Instrument Serif" weight={400} color={t.color.ink} ls={0.02}>
            Second Spring
          </heading>
          <text size={13} font="Figtree" weight={500} color="rgba(42,35,32,0.55)" ls={0.14} raw="text-transform: uppercase;">
            Menopause clinic · by video · UK
          </text>
        </div>

        <div tw="flex flex-col gap-9 w-full max-w-[860px]">
          <h1
            size={68}
            font="Instrument Serif"
            weight={400}
            color={t.color.ink}
            lh={1.1}
            ls={-0.015}
            maxw={880}
            tablet={{ size: 52 }}
            mobile={{ size: 34, lh: 1.14 }}
            raw={EMPH}
          >
            You were told it was <em>stress</em>, or your age, or nothing at all.
          </h1>

          <text
            size={21}
            font="Figtree"
            color={t.color.deep}
            lh={1.65}
            maxw={640}
            mobile={{ size: 17 }}
            motion={FADE}
          >
            Second Spring is a menopause clinic run by doctors who trained in it specifically. Forty-five minute first appointments, prescriptions to your door, and as many follow-ups as it takes to get you right.
          </text>
        </div>

        {Rule()}

        {/* The letter proper — narrower measure than the deck above. */}
        <div tw="flex flex-col gap-6 w-full max-w-[620px]" pad={{ l: 0 }} tablet={{ pad: { l: 0 } }}>
          <text size={17} font="Figtree" color="rgba(42,35,32,0.82)" lh={1.85} motion={FADE}>
            This is not a pitch, so we will write it the way we would say it. Most women who come to us have already been to their GP two or three times. They have been offered an antidepressant, or a sleep hygiene leaflet, or a follow-up in six weeks that never quite answered anything.
          </text>
          <text size={17} font="Figtree" color="rgba(42,35,32,0.82)" lh={1.85} raw={EMPH} motion={FADE}>
            None of that is a failure of the person in front of you. A GP gets ten minutes and, until very recently, <strong>almost no menopause training at all</strong> — the average across UK medical schools was a single afternoon. We built this clinic because the appointment needs to be longer, and the doctor needs to have done the reading.
          </text>
          <text size={17} font="Figtree" color="rgba(42,35,32,0.82)" lh={1.85} motion={FADE}>
            Everything below is what you would actually get: what the first appointment covers, what we will and will not prescribe, who the doctors are, what it costs, and what happens to your records if you decide to stop. Read it in order. It was written to be read in order.
          </text>

          <div tw="flex flex-col gap-1 w-full" pad={{ t: 10 }}>
            <text size={17} font="Instrument Serif" color={t.color.ink}>Dr Ruth Okonjo</text>
            <text size={14} font="Figtree" color="rgba(42,35,32,0.6)">Clinical Director, Second Spring</text>
          </div>

          <text
            href="#book"
            size={17}
            weight={600}
            font="Figtree"
            color={t.color.rose}
            pad={{ t: 6 }}
            raw="text-decoration: underline; text-underline-offset: 6px; text-decoration-thickness: 1px;"
            hover={{ color: t.color.ink }}
          >
            Book a first appointment →
          </text>
        </div>
      </div>
    </section>

    {/* 2 — The 47 symptoms nobody connected for you. Dark full-bleed band. */}
    <section tw="flex flex-col w-full items-center" bg={t.color.deep} pad={{ t: 96, b: 104, l: 24, r: 24 }} mobile={{ pad: { t: 64, b: 72, l: 20, r: 20 } }}>
      <div tw="flex flex-col w-full max-w-[1080px] gap-12">

        <div tw="flex flex-col gap-7 w-full max-w-[760px]">
          <text size={13} weight={600} font="Figtree" color="#E0A9A3" ls={0.16} raw="text-transform: uppercase;">
            Chapter one
          </text>
          <heading
            tag="h2"
            size={46}
            font="Instrument Serif"
            weight={400}
            color="#FBF6F1"
            lh={1.15}
            tablet={{ size: 38 }}
            mobile={{ size: 29 }}
          >
            The forty-seven symptoms nobody connected for you
          </heading>
          <text
            size={22}
            font="Instrument Serif"
            color="rgba(251,246,241,0.9)"
            lh={1.65}
            maxw={720}
            mobile={{ size: 18 }}
            raw={EMPH_LIGHT}
            motion={FADE}
          >
            Joint pain. Ringing ears. Rage that arrives on a schedule. Burning mouth. Waking at 3am with your heart going. Forgetting the word for fork. <em>None of these were in the leaflet.</em>
          </text>
        </div>

        <grid cols={2} gapX={56} gapY={0} w="100%" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }} motion={FADE_SLOW}>
          {SYMPTOMS.map((s) => Symptom(s))}
        </grid>

        <text size={16} font="Figtree" color="rgba(251,246,241,0.62)" lh={1.75} maxw={620}>
          Ten of forty-seven. The full symptom score is the first thing we take, and the reason so many women say the first appointment was the first time the list made sense as one thing rather than nine unrelated complaints.
        </text>
      </div>
    </section>

    {/* 3 — What a first appointment actually covers. Image left, steps right. */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 96, b: 96, l: 24, r: 24 }} mobile={{ pad: { t: 64, b: 64, l: 20, r: 20 } }}>
      <div tw="flex flex-col w-full max-w-[1080px] gap-14">

        <div tw="flex flex-col gap-6 w-full max-w-[760px]">
          <text size={13} weight={600} font="Figtree" color={t.color.sage} ls={0.16} raw="text-transform: uppercase;">
            Chapter two
          </text>
          <heading tag="h2" size={46} font="Instrument Serif" weight={400} color={t.color.ink} lh={1.15} tablet={{ size: 38 }} mobile={{ size: 29 }}>
            What a first appointment actually covers
          </heading>
          <text size={19} font="Figtree" color={t.color.deep} lh={1.75} maxw={680} mobile={{ size: 17 }} raw={EMPH} motion={FADE}>
            Your first appointment is <strong>forty-five minutes</strong> with a doctor who has read your history before you join the call. We take a full symptom score, review your risks properly, and leave with a written plan you can show your GP.
          </text>
        </div>

        <grid cols="1fr 1.15fr" gapX={64} gapY={44} w="100%" tablet={{ gridCols: '1fr' }} mobile={{ gridCols: '1fr' }}>
          <div tw="flex flex-col gap-4 w-full">
            <img
              src={media.consult_scene.id}
              w="100%"
              h={460}
              fit="cover"
              radius={2}
              tablet={{ h: 340 }}
              mobile={{ h: 260 }}
              motion={FADE}
            />
            <text size={14} font="Figtree" color="rgba(42,35,32,0.58)" lh={1.6} maxw={380}>
              Appointments are by video, from wherever you are. No waiting room, no car park, no half-day off work.
            </text>
          </div>

          <div tw="flex flex-col gap-0 w-full">
            {STEPS.map((s) => Step(s))}
          </div>
        </grid>
      </div>
    </section>

    {/* 4 — Prescribing: what we can and cannot offer. Two facing columns on paper. */}
    <section tw="flex flex-col w-full items-center" bg={t.color.paper} pad={{ t: 96, b: 100, l: 24, r: 24 }} mobile={{ pad: { t: 64, b: 68, l: 20, r: 20 } }} raw="border-top: 1px solid rgba(42,35,32,0.1); border-bottom: 1px solid rgba(42,35,32,0.1);">
      <div tw="flex flex-col w-full max-w-[1080px] gap-12">

        <div tw="flex flex-col gap-6 w-full max-w-[760px]">
          <text size={13} weight={600} font="Figtree" color={t.color.sage} ls={0.16} raw="text-transform: uppercase;">
            Chapter three
          </text>
          <heading tag="h2" size={46} font="Instrument Serif" weight={400} color={t.color.ink} lh={1.15} tablet={{ size: 38 }} mobile={{ size: 29 }}>
            Prescribing: what we can and cannot offer
          </heading>
          <text size={19} font="Figtree" color={t.color.deep} lh={1.75} maxw={720} mobile={{ size: 17 }} raw={EMPH} motion={FADE}>
            We prescribe body-identical HRT, vaginal oestrogen, and testosterone where it is clinically appropriate. We do not sell supplements, compounded pellets, or anything with the word <em>bioidentical</em> on a private label.
          </text>
        </div>

        <grid cols={2} gapX={0} gapY={32} w="100%" mobile={{ gridCols: 1 }} motion={FADE}>
          <div tw="flex flex-col gap-5 w-full" pad={{ r: 48, t: 30 }} raw="border-top: 2px solid #7C9382;" mobile={{ pad: { r: 0, t: 26 } }}>
            <heading tag="h3" size={15} font="Figtree" weight={600} color={t.color.sage} ls={0.14} raw="text-transform: uppercase;">
              We prescribe
            </heading>
            <text size={17} font="Figtree" color="rgba(42,35,32,0.84)" lh={1.9} raw={EMPH}>
              <strong>Body-identical oestradiol</strong> — patch, gel or spray.<br />
              <strong>Micronised progesterone</strong> — capsule, or the coil if you have one.<br />
              <strong>Vaginal oestrogen</strong> — for urinary and genital symptoms, alongside systemic HRT or on its own.<br />
              <strong>Testosterone</strong> — where it is clinically appropriate, and monitored with bloods.<br />
              <strong>Non-hormonal options</strong> — for women who cannot or would rather not take oestrogen.
            </text>
          </div>

          <div tw="flex flex-col gap-5 w-full" pad={{ l: 48, t: 30 }} raw="border-top: 2px solid #C36A63;" tablet={{ pad: { l: 32 } }} mobile={{ pad: { l: 0, t: 26 } }}>
            <heading tag="h3" size={15} font="Figtree" weight={600} color={t.color.rose} ls={0.14} raw="text-transform: uppercase;">
              We do not
            </heading>
            <text size={17} font="Figtree" color="rgba(42,35,32,0.84)" lh={1.9} raw={EMPH}>
              <strong>Compounded pellets or troches</strong> — unlicensed, unmeasurable, and we will say so plainly.<br />
              <strong>Supplements</strong> — we sell none, and take no commission on any.<br />
              <strong>Private-label “bioidentical” products</strong> — the word is marketing, not pharmacology.<br />
              <strong>Blanket testosterone</strong> — not without a reason, a baseline, and a review.<br />
              <strong>Prescribing without a plan</strong> — nothing leaves this clinic without a follow-up date attached to it.
            </text>
          </div>
        </grid>

        <text size={16} font="Figtree" color="rgba(42,35,32,0.62)" lh={1.75} maxw={680}>
          Prescriptions go to a UK pharmacy and arrive at your door. If a medicine is not right for you, we would rather tell you at the first appointment than at the fourth.
        </text>
      </div>
    </section>

    {/* 5 — The doctors, with their menopause qualifications. */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 96, b: 96, l: 24, r: 24 }} mobile={{ pad: { t: 64, b: 64, l: 20, r: 20 } }}>
      <div tw="flex flex-col w-full max-w-[1080px] gap-12">

        <grid cols="1.35fr 1fr" gapX={64} gapY={40} w="100%" tablet={{ gridCols: '1fr' }} mobile={{ gridCols: '1fr' }}>
          <div tw="flex flex-col gap-6 w-full">
            <text size={13} weight={600} font="Figtree" color={t.color.sage} ls={0.16} raw="text-transform: uppercase;">
              Chapter four
            </text>
            <heading tag="h2" size={46} font="Instrument Serif" weight={400} color={t.color.ink} lh={1.15} tablet={{ size: 38 }} mobile={{ size: 29 }}>
              The doctors, and what they trained in
            </heading>
            <text size={18} font="Figtree" color={t.color.deep} lh={1.75} maxw={620} mobile={{ size: 16 }} raw={EMPH} motion={FADE}>
              Every doctor here holds a <strong>British Menopause Society</strong> qualification and sees menopause patients as the whole of their practice, not as an interest tacked onto a general list. You will see the same doctor at every follow-up unless you ask to change.
            </text>
          </div>

          <img
            src={media.portrait_calm.id}
            w="100%"
            h={380}
            fit="cover"
            radius={2}
            mobile={{ h: 280 }}
            motion={FADE}
          />
        </grid>

        <div tw="flex flex-col gap-0 w-full">
          {DOCTORS.map((d) => Doctor(d))}
        </div>
      </div>
    </section>

    {/* 6 — Cost, and what happens if you stop paying. Sage band, figure at left. */}
    <section tw="flex flex-col w-full items-center" bg="#EEF0EA" pad={{ t: 92, b: 96, l: 24, r: 24 }} mobile={{ pad: { t: 64, b: 68, l: 20, r: 20 } }}>
      <div tw="flex flex-col w-full max-w-[1080px] gap-12">

        <grid cols="0.8fr 1.2fr" gapX={64} gapY={36} w="100%" tablet={{ gridCols: '1fr' }} mobile={{ gridCols: '1fr' }}>
          <div tw="flex flex-col gap-3 w-full">
            <text size={13} weight={600} font="Figtree" color={t.color.sage} ls={0.16} raw="text-transform: uppercase;">
              Chapter five
            </text>
            <heading tag="h2" size={96} font="Instrument Serif" weight={400} color={t.color.ink} lh={1} ls={-0.03} tablet={{ size: 76 }} mobile={{ size: 60 }}>
              £290
            </heading>
            <text size={17} font="Figtree" color={t.color.deep} lh={1.6} weight={500}>
              a year — first appointment and every follow-up
            </text>
          </div>

          <div tw="flex flex-col gap-6 w-full">
            <text size={19} font="Figtree" color={t.color.deep} lh={1.8} maxw={640} mobile={{ size: 17 }} raw={EMPH} motion={FADE}>
              £290 a year covers the first appointment and every follow-up. Prescriptions are charged at cost plus £3 delivery. <strong>Stop paying and your records are still yours</strong>, sent as a PDF within 48 hours.
            </text>
            {Rule('rgba(42,35,32,0.16)')}
            <text size={16} font="Figtree" color="rgba(42,35,32,0.76)" lh={1.8} maxw={640}>
              There is no per-appointment fee, because charging by the appointment makes women ration them, and getting a dose right usually takes three or four conversations. There is no tie-in and no cancellation fee. If you leave and come back a year later, you pay the annual fee again — not a penny more for having gone.
            </text>
            <text size={16} font="Figtree" color="rgba(42,35,32,0.76)" lh={1.8} maxw={640}>
              We are not an NHS service and we do not pretend to replace one. Your GP stays your GP, which is why every plan we write is addressed to them as well as to you.
            </text>
          </div>
        </grid>
      </div>
    </section>

    {/* 7 — Three patient accounts, in their own words. */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 96, b: 96, l: 24, r: 24 }} mobile={{ pad: { t: 64, b: 64, l: 20, r: 20 } }}>
      <div tw="flex flex-col w-full max-w-[1080px] gap-10">

        <div tw="flex flex-col gap-5 w-full max-w-[720px]">
          <text size={13} weight={600} font="Figtree" color={t.color.sage} ls={0.16} raw="text-transform: uppercase;">
            Chapter six
          </text>
          <heading tag="h2" size={46} font="Instrument Serif" weight={400} color={t.color.ink} lh={1.15} tablet={{ size: 38 }} mobile={{ size: 29 }}>
            Three accounts, in their own words
          </heading>
          <text size={16} font="Figtree" color="rgba(42,35,32,0.66)" lh={1.7} maxw={560}>
            Published with permission, lightly cut for length, and otherwise exactly as they were written.
          </text>
        </div>

        <div tw="flex flex-col gap-0 w-full max-w-[840px]" motion={FADE}>
          {ACCOUNTS.map((a) => Account(a))}
        </div>
      </div>
    </section>

    {/* 8 — Book a first appointment. The one centred section on the page. */}
    <section id="book" tw="flex flex-col w-full items-center text-center" bg={t.color.deep} pad={{ t: 104, b: 112, l: 24, r: 24 }} mobile={{ pad: { t: 72, b: 80, l: 20, r: 20 } }}>
      <div tw="flex flex-col w-full max-w-[640px] items-center gap-7 text-center">
        <text size={13} weight={600} font="Figtree" color="#E0A9A3" ls={0.16} ta="center" raw="text-transform: uppercase;">
          The last part
        </text>
        <heading tag="h2" size={52} font="Instrument Serif" weight={400} color="#FBF6F1" lh={1.12} ta="center" tablet={{ size: 42 }} mobile={{ size: 32 }} motion={FADE}>
          Book a first appointment
        </heading>
        <text size={18} font="Figtree" color="rgba(251,246,241,0.8)" lh={1.75} ta="center" maxw={520} mobile={{ size: 16 }}>
          Forty-five minutes, with a doctor who has read your notes first. Usually within eight days. If we are not the right service for you, we will say so on that call and you will not be charged.
        </text>

        <text
          href="#book"
          size={17}
          weight={600}
          font="Figtree"
          color={t.color.deep}
          bg="#FBF6F1"
          pad={[18, 40]}
          radius={2}
          ta="center"
          m={{ t: 10 }}
          hover={{ bg: '#C36A63', color: '#FBF6F1' }}
        >
          Book a first appointment
        </text>

        <text size={14} font="Figtree" color="rgba(251,246,241,0.55)" lh={1.7} ta="center" maxw={480} m={{ t: 6 }}>
          £290 a year, cancel whenever you like. Second Spring is a CQC-registered private clinic; our doctors are on the GMC register.
        </text>
      </div>
    </section>

    <section tw="flex flex-col w-full items-center" pad={{ t: 40, b: 48, l: 24, r: 24 }}>
      <div tw="flex flex-row w-full max-w-[1080px] items-center justify-between gap-4 flex-wrap">
        <text size={15} font="Instrument Serif" color={t.color.ink}>Second Spring</text>
        <text size={13} font="Figtree" color="rgba(42,35,32,0.5)">
          © 2026 Second Spring Clinic Ltd · Registered in England
        </text>
      </div>
    </section>

  </box>
);
