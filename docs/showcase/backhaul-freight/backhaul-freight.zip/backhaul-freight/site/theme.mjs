/** Backhaul — freight marketplace tokens. */
export default defineTheme({
  name: 'backhaul',
  color: {
    ground: '#101418',
    tile: '#182029',
    ink: '#E8EDF2',
    road: '#F5A623',
    go: '#38C172',
    line: '#26313C',
  },
  font: { head: 'Antonio', body: 'Manrope' },
  mode: 'literal',
});
