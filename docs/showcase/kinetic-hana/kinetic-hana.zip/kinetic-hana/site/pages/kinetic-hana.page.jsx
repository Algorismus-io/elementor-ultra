/** Hana Sekigawa — motion design portfolio. Structural archetype: horizontal filmstrip band. */
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Hana Sekigawa — Motion Design',
  slug: 'kinetic-hana',
  seo: {
    title: 'Hana Sekigawa — Freelance Motion Designer, Berlin',
    description:
      'Title sequences, brand systems in motion and broadcast packages. Eleven years in, based in Berlin, available from late September. €780 a day, five-day minimum.',
  },
};

const RULE = [1, 'rgba(185, 188, 199, 0.22)'];

/* ── the eleven projects in the filmstrip band ───────────────────────────── */
const FILM = [
  { n: '01', title: 'Aomori', kind: 'Title sequence', year: '2025' },
  { n: '02', title: 'Bergwerk', kind: 'Festival idents', year: '2025' },
  { n: '03', title: 'Deutsche Welle', kind: 'Broadcast package', year: '2024' },
  { n: '04', title: 'Tonal', kind: 'Brand motion system', year: '2024' },
  { n: '05', title: 'Studio Wren', kind: 'End frames', year: '2024' },
  { n: '06', title: 'Kanso Type', kind: 'Specimen film', year: '2023' },
  { n: '07', title: 'ARD Kultur', kind: 'Package refresh', year: '2023' },
  { n: '08', title: 'Ondine', kind: 'Title sequence', year: '2023' },
  { n: '09', title: 'Vier Uhr', kind: 'Channel idents', year: '2022' },
  { n: '10', title: 'Halbwelt', kind: 'Character sequence', year: '2022' },
  { n: '11', title: 'Mira Health', kind: 'Motion spec + docs', year: '2021' },
];

const FRAME_AT = { 2: 'still_a', 6: 'still_b', 9: 'studio_desk' };

const FilmCell = ({ n = '01', title = 'Project', kind = 'Discipline', year = '2025' }) => (
    <col
      w="100%"
      h={300}
      pad={20}
      bg="#15151B"
      justify="space-between"
      border={RULE}
      hover={{ bg: '#1D1D26' }}
    >
      <text size={12} weight={700} font="Syncopate" color="#FF4D6D" ls={0.08}>
        {n}
      </text>
      <col gap={8}>
        <text size={11} font="Sen" color="#B9BCC7" ls={0.14}>
          {kind}
        </text>
        <text size={19} weight={700} font="Syncopate" color="#F4F4F6" lh={1.25} ls={-0.01}>
          {title}
        </text>
        <text size={12} font="Sen" color="#B9BCC7">
          {year}
        </text>
      </col>
    </col>
  );

const CallSheet = ({ name = 'Name', role = 'Role', note = 'Note' }) => (
    <col gap={10} pad={{ t: 26, b: 26 }} raw="border-top: 1px solid rgba(185,188,199,0.22);">
      <text size={11} font="Sen" color="#FF4D6D" ls={0.14}>
        {role}
      </text>
      <text size={20} weight={700} font="Syncopate" color="#F4F4F6" lh={1.3}>
        {name}
      </text>
      <text size={15} font="Sen" color="#B9BCC7" lh={1.65}>
        {note}
      </text>
    </col>
  );

/* ── small local helpers (inline expansion, not registered) ──────────────── */
const Eyebrow = ({ children, tone = '#FF4D6D' }) => (
  <text size={11} font="Sen" weight={700} color={tone} ls={0.16}>
    {children}
  </text>
);

const Frame = ({ slot, label }) => (
  <col
    w={332}
    h={300}
    raw="flex: 0 0 332px; min-width: 332px; scroll-snap-align: start; overflow: hidden; position: relative;"
    justify="flex-end"
    bg="#15151B"
    border={RULE}
  >
    <img src={media[slot].id} w="100%" h={300} fit="cover" raw="position: absolute; inset: 0;" />
    <text
      size={11}
      font="Sen"
      color="#F4F4F6"
      ls={0.14}
      pad={[10, 14]}
      bg="rgba(10,10,12,0.72)"
      m={{ l: 14, b: 14 }}
      raw="position: relative;"
    >
      {label}
    </text>
  </col>
);

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
    {/* ══ 1 · masthead + filmstrip band of eleven projects ══ */}
    <section tw="flex flex-col w-full gap-0" pad={0} bg={t.color.ground}>
      <row
        tw="flex flex-row w-full items-center justify-between max-md:flex-col max-md:items-start max-md:gap-3"
        pad={[20, 40]}
        raw="border-bottom: 1px solid rgba(185,188,199,0.22);"
        mobile={{ pad: [16, 20] }}
      >
        <text size={13} weight={700} font={t.font.head} color={t.color.ink} ls={0.06}>
          Hana Sekigawa
        </text>
        <row tw="flex flex-row items-center gap-6 max-md:gap-4">
          <text size={12} font={t.font.body} color={t.color.chrome} ls={0.06}>
            Berlin · Motion design
          </text>
          <text
            href="#contact"
            size={12}
            weight={700}
            font={t.font.body}
            color={t.color.ground}
            bg={t.color.signal}
            pad={[10, 18]}
            ls={0.06}
            hover={{ bg: t.color.ink }}
          >
            Check availability
          </text>
        </row>
      </row>

      <grid
        cols="minmax(0, 64fr) minmax(0, 36fr)"
        tw="w-full items-end gap-16 max-lg:gap-10 max-md:items-start max-md:gap-6"
        pad={[76, 40]}
        mobile={{ pad: [40, 20], gridCols: 1 }}
      >
        <col tw="flex flex-col gap-6">
          <Eyebrow>Freelance · Available from late September</Eyebrow>
          <h1
            size={50}
            weight={700}
            font={t.font.head}
            color={t.color.ink}
            lh={1.16}
            ls={-0.02}
            tablet={{ size: 38 }}
            mobile={{ size: 26 }}
            motion={{ effect: 'fade', trigger: 'load' }}
          >
            Motion for people who care what happens in the first 400&nbsp;milliseconds.
          </h1>
        </col>
        <col tw="flex flex-col gap-5">
          <text size={16} font={t.font.body} color={t.color.chrome} lh={1.7}>
            Freelance motion designer working on title sequences, brand systems in motion and
            broadcast packages. Based in Berlin, eleven years in, available from late September.
          </text>
          <text size={13} font={t.font.body} color={t.color.signal} ls={0.06}>
            Scroll the strip sideways →
          </text>
        </col>
      </grid>

      <row
        tw="flex flex-row w-full overflow-x-auto gap-3 justify-start items-stretch"
        pad={{ l: 40, r: 40, b: 18 }}
        wrap={false}
        raw="scroll-snap-type: x proximity; -webkit-overflow-scrolling: touch;"
        mobile={{ pad: { l: 20, r: 20, b: 14 } }}
      >
        {FILM.flatMap((f, i) => {
          const cell = (
            <col w={244} pad={0} raw="flex: 0 0 244px; min-width: 244px; scroll-snap-align: start;">
              <FilmCell n={f.n} title={f.title} kind={f.kind} year={f.year} />
            </col>
          );
          const slot = FRAME_AT[i];
          return slot
            ? [cell, <Frame slot={slot} label={`${f.title} · frame grab`} />]
            : [cell];
        })}
      </row>

      <row
        tw="flex flex-row w-full items-center justify-between gap-4"
        pad={[16, 40]}
        raw="border-top: 1px solid rgba(185,188,199,0.22);"
        mobile={{ pad: [14, 20] }}
      >
        <text size={11} font={t.font.body} color={t.color.chrome} ls={0.14}>
          Eleven selected projects · 2021—2025
        </text>
        <text size={11} font={t.font.body} color={t.color.chrome} ls={0.14}>
          Full reel below
        </text>
      </row>
    </section>

    {/* ══ 2 · the reel ══ */}
    <grid
      tag="section"
      cols="minmax(0, 52fr) minmax(0, 48fr)"
      tw="w-full gap-14 items-center max-lg:gap-10 max-md:items-start max-md:gap-8"
      pad={[92, 40]}
      bg={t.color.deep}
      mobile={{ pad: [52, 20], gridCols: 1 }}
    >
      <col tw="flex flex-col gap-6">
        <Eyebrow>The reel</Eyebrow>
        <h2 size={34} weight={700} font={t.font.head} color={t.color.ink} lh={1.25} ls={-0.02} mobile={{ size: 22 }}>
          68 seconds. No music by default.
        </h2>
        <text size={17} font={t.font.body} color={t.color.chrome} lh={1.7} maxw={520}>
          The reel runs 68 seconds and starts muted, because you are probably in an office and I am
          not going to do that to you.
        </text>
        <row tw="flex flex-row gap-8 max-md:gap-5" pad={{ t: 10 }}>
          <col gap={4}>
            <text size={26} weight={700} font={t.font.head} color={t.color.signal}>
              68s
            </text>
            <text size={12} font={t.font.body} color={t.color.chrome} ls={0.1}>
              Runtime
            </text>
          </col>
          <col gap={4}>
            <text size={26} weight={700} font={t.font.head} color={t.color.signal}>
              11
            </text>
            <text size={12} font={t.font.body} color={t.color.chrome} ls={0.1}>
              Projects cut in
            </text>
          </col>
          <col gap={4}>
            <text size={26} weight={700} font={t.font.head} color={t.color.signal}>
              4K
            </text>
            <text size={12} font={t.font.body} color={t.color.chrome} ls={0.1}>
              ProRes on request
            </text>
          </col>
        </row>
      </col>
      <col motion={{ effect: 'fade', trigger: 'scrollIn' }}>
        <img src={media.still_a.id} w="100%" h={340} fit="cover" mobile={{ h: 220 }} />
        <row
          tw="flex flex-row items-center justify-between w-full"
          pad={[12, 16]}
          bg={t.color.ground}
          border={RULE}
        >
          <text size={12} font={t.font.body} color={t.color.ink} ls={0.1}>
            REEL 2025 · MUTED
          </text>
          <text size={12} font={t.font.body} weight={700} color={t.color.signal} href="#contact" ls={0.1}>
            Ask for the link
          </text>
        </row>
      </col>
    </grid>

    {/* ══ 3 · what I do ══ */}
    <section tw="flex flex-col w-full gap-10" pad={[92, 40]} bg={t.color.ground} mobile={{ pad: [52, 20] }}>
      <row tw="flex flex-row items-end justify-between gap-6 w-full max-md:flex-col max-md:items-start max-md:gap-3">
        <h2 size={34} weight={700} font={t.font.head} color={t.color.ink} lh={1.25} ls={-0.02} mobile={{ size: 22 }}>
          What I do
        </h2>
        <text size={14} font={t.font.body} color={t.color.chrome} maxw={340} lh={1.6}>
          Titles, systems in motion, broadcast packages — and the odd character job.
        </text>
      </row>
      <grid cols={12} gap={0} mobile={{ gridCols: 1 }}>
        {[
          ['A', 'Title sequences and end frames', 'The first 400 milliseconds, then the last eight. Boards, style frames, final animation and the delivery matrix.'],
          ['B', 'Brand motion systems', 'With real documentation, not a Figma page of gifs. Timing curves, entry and exit rules, a spec your team can build against.'],
          ['C', 'Broadcast idents and package refreshes', 'Idents, bumpers, lower thirds, transitions and the full package refresh with a build kit that survives the schedule.'],
          ['D', 'Occasional character work', 'If the script deserves it. Rigged or frame-by-frame, kept short and kept honest.'],
        ].map(([k, title, body]) => (
          <col
            span={6}
            gap={12}
            pad={[34, 34]}
            raw="border-top: 1px solid rgba(185,188,199,0.22); border-right: 1px solid rgba(185,188,199,0.22);"
            hover={{ bg: t.color.deep }}
            mobile={{ pad: [24, 0] }}
          >
            <text size={12} weight={700} font={t.font.head} color={t.color.signal} ls={0.08}>
              {k}
            </text>
            <text size={21} weight={700} font={t.font.head} color={t.color.ink} lh={1.3} mobile={{ size: 17 }}>
              {title}
            </text>
            <text size={15} font={t.font.body} color={t.color.chrome} lh={1.7} maxw={420}>
              {body}
            </text>
          </col>
        ))}
      </grid>
    </section>

    {/* ══ 4 · tools and the handover ══ */}
    <grid
      tag="section"
      cols="minmax(0, 44fr) minmax(0, 56fr)"
      tw="w-full gap-14 max-lg:gap-10 max-md:gap-8"
      pad={[92, 40]}
      bg={t.color.deep}
      mobile={{ pad: [52, 20], gridCols: 1 }}
    >
      <col motion={{ effect: 'fade', trigger: 'scrollIn' }}>
        <img src={media.studio_desk.id} w="100%" h={400} fit="cover" mobile={{ h: 240 }} />
      </col>
      <col tw="flex flex-col gap-8">
        <col gap={5}>
          <Eyebrow>Tools</Eyebrow>
          <h2 size={34} weight={700} font={t.font.head} color={t.color.ink} lh={1.25} ls={-0.02} mobile={{ size: 22 }}>
            Tools, and what I hand over
          </h2>
        </col>
        <row tw="flex flex-row flex-wrap gap-3">
          {['After Effects', 'Cinema 4D + Redshift', 'Houdini, when genuinely needed'].map((tool) => (
            <text
              size={13}
              font={t.font.body}
              color={t.color.ink}
              pad={[10, 16]}
              border={RULE}
              ls={0.04}
              hover={{ color: t.color.signal }}
            >
              {tool}
            </text>
          ))}
        </row>
        <col gap={0}>
          {[
            ['01', 'Organised project files', 'Named comps, no orphan solids, no rendered-out mystery layers.'],
            ['02', 'A style frame set', 'Stills that hold up on their own, in the sizes you actually publish.'],
            ['03', 'A written motion spec', 'Durations, easings and states your dev team can build from.'],
          ].map(([n, title, body]) => (
            <row
              tw="flex flex-row gap-6 items-start w-full max-md:gap-4"
              pad={{ t: 20, b: 20 }}
              raw="border-top: 1px solid rgba(185,188,199,0.22);"
            >
              <text size={12} weight={700} font={t.font.head} color={t.color.signal} w={34}>
                {n}
              </text>
              <col gap={6} flex={1}>
                <text size={16} weight={700} font={t.font.body} color={t.color.ink}>
                  {title}
                </text>
                <text size={14} font={t.font.body} color={t.color.chrome} lh={1.65}>
                  {body}
                </text>
              </col>
            </row>
          ))}
        </col>
      </col>
    </grid>

    {/* ══ 5 · rates, availability, how I quote ══ */}
    <section tw="flex flex-col w-full gap-10" pad={[92, 40]} bg={t.color.signal} mobile={{ pad: [52, 20] }}>
      <row tw="flex flex-row items-end justify-between gap-6 w-full max-md:flex-col max-md:items-start max-md:gap-4">
        <h2 size={40} weight={700} font={t.font.head} color={t.color.ground} lh={1.15} ls={-0.02} maxw={640} mobile={{ size: 24 }}>
          €780 a day, five-day minimum.
        </h2>
        <text size={15} font={t.font.body} color="rgba(10,10,12,0.78)" maxw={300} lh={1.65}>
          Fixed-price projects from €9,000. I quote in two days and I do not do speculative
          concepts.
        </text>
      </row>
      <grid cols={3} gap={0} mobile={{ gridCols: 1 }}>
        {[
          ['Booked until', '22 September', 'Current project runs to the end of the month.'],
          ['Two weeks free', 'October', 'Best window for a six-week start.'],
          ['Q1 is open', 'Fills in November', 'If you are planning ahead, plan now.'],
        ].map(([label, big, note]) => (
          <col
            gap={10}
            pad={[30, 30]}
            raw="border-top: 1px solid rgba(10,10,12,0.35); border-right: 1px solid rgba(10,10,12,0.2);"
            mobile={{ pad: [22, 0] }}
          >
            <text size={11} weight={700} font={t.font.body} color="rgba(10,10,12,0.7)" ls={0.14}>
              {label}
            </text>
            <text size={24} weight={700} font={t.font.head} color={t.color.ground} lh={1.25} mobile={{ size: 19 }}>
              {big}
            </text>
            <text size={14} font={t.font.body} color="rgba(10,10,12,0.78)" lh={1.6}>
              {note}
            </text>
          </col>
        ))}
      </grid>
    </section>

    {/* ══ 6 · studio versus direct ══ */}
    <section tw="flex flex-col w-full gap-10" pad={[92, 40]} bg={t.color.ground} mobile={{ pad: [52, 20] }}>
      <h2 size={34} weight={700} font={t.font.head} color={t.color.ink} lh={1.25} ls={-0.02} mobile={{ size: 22 }}>
        How I work with a studio, versus direct
      </h2>
      <grid cols="minmax(0, 50fr) minmax(0, 50fr)" tw="w-full gap-6 items-stretch" mobile={{ gridCols: 1 }}>
        <col
          tw="flex flex-col gap-5"
          pad={[38, 34]}
          bg={t.color.deep}
          border={RULE}
          mobile={{ pad: [26, 22] }}
        >
          <Eyebrow tone="#B9BCC7">With a studio</Eyebrow>
          <text size={22} weight={700} font={t.font.head} color={t.color.ink} lh={1.3} mobile={{ size: 18 }}>
            I slot in as a designer and animator, and take direction.
          </text>
          <text size={15} font={t.font.body} color={t.color.chrome} lh={1.7}>
            Your creative director leads, I deliver inside your pipeline and your naming
            conventions. No client-facing noise from me unless you want me in the room.
          </text>
        </col>
        <col
          tw="flex flex-col gap-5"
          pad={[38, 34]}
          bg={t.color.deep}
          raw="border: 1px solid rgba(255,77,109,0.55);"
          mobile={{ pad: [26, 22] }}
        >
          <Eyebrow>Direct with a brand</Eyebrow>
          <text size={22} weight={700} font={t.font.head} color={t.color.ink} lh={1.3} mobile={{ size: 18 }}>
            One strategy conversation before I open After Effects.
          </text>
          <text size={15} font={t.font.body} color={t.color.chrome} lh={1.7}>
            I insist on it, and it is included. It is ninety minutes that saves a fortnight of
            animating the wrong idea beautifully.
          </text>
        </col>
      </grid>
    </section>

    {/* ══ 7 · three clients who will take your call ══ */}
    <grid
      tag="section"
      cols="minmax(0, 34fr) minmax(0, 66fr)"
      tw="w-full gap-14 max-lg:gap-10 max-md:gap-8"
      pad={[92, 40]}
      bg={t.color.deep}
      mobile={{ pad: [52, 20], gridCols: 1 }}
    >
      <col tw="flex flex-col gap-5">
        <Eyebrow>References</Eyebrow>
        <h2 size={30} weight={700} font={t.font.head} color={t.color.ink} lh={1.25} ls={-0.02} mobile={{ size: 21 }}>
          Three clients who will take your call
        </h2>
        <text size={15} font={t.font.body} color={t.color.chrome} lh={1.7}>
          Ask me and I will send numbers, not a testimonial carousel. All three have hired me twice.
        </text>
      </col>
      <col tw="flex flex-col">
        <CallSheet
          name="Marlene Vogt"
          role="Executive producer · Studio Wren, Berlin"
          note="Two title sequences and an end-frame system, both shipped inside a broadcast schedule."
        />
        <CallSheet
          name="Ilya Beker"
          role="Creative director · Deutsche Welle brand"
          note="A package refresh across four channels, handed over with the spec his team still builds from."
        />
        <CallSheet
          name="Sofia Renner"
          role="Head of brand · Tonal"
          note="Direct client. One strategy conversation, then a motion system their product team ships weekly."
        />
      </col>
    </grid>

    {/* ══ 8 · get in touch ══ */}
    <grid
      tag="section"
      id="contact"
      cols="minmax(0, 58fr) minmax(0, 42fr)"
      tw="w-full gap-12 items-end max-md:items-start max-md:gap-8"
      pad={[96, 40]}
      bg={t.color.ground}
      mobile={{ pad: [56, 20], gridCols: 1 }}
    >
      <col tw="flex flex-col gap-6">
        <Eyebrow>Get in touch</Eyebrow>
        <h2
          size={36}
          weight={700}
          font={t.font.head}
          color={t.color.ink}
          lh={1.2}
          ls={-0.02}
          mobile={{ size: 22 }}
          motion={{ effect: 'fade', trigger: 'scrollIn' }}
        >
          Tell me the dates and the deliverable. You get a quote in two days.
        </h2>
        <text
          href="mailto:hana@sekigawa.motion"
          size={17}
          weight={700}
          font={t.font.body}
          color={t.color.ground}
          bg={t.color.signal}
          pad={[16, 26]}
          ls={0.04}
          w="hug"
          hover={{ bg: t.color.ink }}
        >
          Check availability
        </text>
      </col>
      <col tw="flex flex-col gap-4">
        {[
          ['Email', 'hana@sekigawa.motion'],
          ['Studio', 'Berlin, CET — replies same day'],
          ['Next free', 'October, two weeks'],
        ].map(([k, v]) => (
          <row
            tw="flex flex-row items-end justify-between gap-4 w-full"
            pad={{ b: 12 }}
            raw="border-bottom: 1px solid rgba(185,188,199,0.22);"
          >
            <text size={12} font={t.font.body} color={t.color.chrome} ls={0.12}>
              {k}
            </text>
            <text size={15} font={t.font.body} color={t.color.ink}>
              {v}
            </text>
          </row>
        ))}
      </col>
    </grid>

    <row
      tw="flex flex-row w-full items-center justify-between gap-4 max-md:flex-col max-md:items-start max-md:gap-2"
      pad={[22, 40]}
      bg={t.color.deep}
      mobile={{ pad: [20, 20] }}
    >
      <text size={11} font={t.font.body} color={t.color.chrome} ls={0.12}>
        Hana Sekigawa · Motion design · Berlin
      </text>
      <text size={11} font={t.font.body} color={t.color.chrome} ls={0.12}>
        €780/day · Fixed price from €9,000
      </text>
    </row>
  </box>
);
