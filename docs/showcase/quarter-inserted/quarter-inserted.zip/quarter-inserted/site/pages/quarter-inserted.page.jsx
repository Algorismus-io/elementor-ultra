/** Quarter Inserted — full-bleed colour blocks with hard seams. One block per thing you would ask about. */
import { decades, cabinetCount, pinball, taps, pizzas, hours, rules } from '../data/floor.mjs';
import { MEDIA as img } from '../data/media.mjs';

export const meta = {
  title: 'Quarter Inserted',
  slug: 'quarter-inserted',
  seo: {
    title: 'Quarter Inserted — 44 arcade cabinets, all free play',
    description:
      'An arcade bar with 44 properly restored cabinets, all on free play, eight taps, six pizzas and no cocktail menu. Walk in. Over 21 after 8pm.',
  },
};

const C = {
  ground: '#12061F',
  ink: '#F5F0FF',
  magenta: '#FF00A8',
  cyan: '#00E5FF',
  amber: '#FFC400',
  deep: '#2A0B45',
};

const fadeIn = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* ── seam: the hard line between two colour blocks ─────────────────────────── */
const Seam = ({ color = C.ground, h = 10 }) => <div w="100%" h={h} bg={color} minh={h} />;

/* ── kicker: 01 / THE FLOOR ────────────────────────────────────────────────── */
const Kicker = ({ n, label, color }) => (
  <div cls="kicker" w="100%" dir="row" gap={12} align="center" wrap>
    <text tag="span" cls="kicker-num" font="Chivo" size={13} weight={700} ls="2px" color={color}>{n}</text>
    <div cls="kicker-rule" w={28} h={2} bg={color} minh={2} />
    <text tag="span" cls="kicker-label" font="Chivo" size={13} weight={700} ls="2px" color={color}>{label}</text>
  </div>
);

/* ── shell: every block is full-bleed, square-cornered, hard-edged ─────────── */
const Block = ({ bg, children, pad = [88, 40], mobilePad = [56, 20], id }) => (
  <section id={id} w="100%" bg={bg} pad={pad} tablet={{ pad: [72, 32] }} mobile={{ pad: mobilePad }}>
    <div w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} dir="column" gap={0}>
      {children}
    </div>
  </section>
);

/* ── registered components (content props only) ────────────────────────────── */
const TapRow = defineComponent(
  ({ n = '01', name = 'Tap', note = '', abv = '' }) => (
    <div
      w="100%"
      dir="row"
      gap={18}
      align="start"
      pad={{ t: 18, b: 18, l: 18, r: 18 }}
      bg="#0B0416"
      hover={{ bg: '#1B0730' }}
      mobile={{ pad: { t: 14, b: 14, l: 14, r: 14 }, gap: 12 }}
    >
      <text tag="span" font="Chivo" size={13} weight={700} color={C.cyan} ls="1px" w={30}>{n}</text>
      <div dir="column" gap={4} flex={1}>
        <text font="Chivo" size={19} weight={700} color={C.ink} lh={1.2} mobile={{ size: 17 }}>{name}</text>
        <text font="Chivo" size={14} weight={400} color="#B9A9CE" lh={1.5}>{note}</text>
      </div>
      <text tag="span" font="Chivo" size={14} weight={700} color={C.amber} ta="right" w={62}>{abv}</text>
    </div>
  ),
  {
    title: 'QI Tap Row',
    props: {
      n: { label: 'Number', group: 'Tap' },
      name: { label: 'Beer', group: 'Tap' },
      note: { label: 'Note', group: 'Tap' },
      abv: { label: 'ABV', group: 'Tap' },
    },
  },
);

const PizzaCard = defineComponent(
  ({ n = '01', name = 'Pizza', desc = '' }) => (
    <div
      w="100%"
      dir="column"
      gap={10}
      pad={[26, 24]}
      bg={C.ground}
      h="100%"
      hover={{ bg: C.deep }}
      mobile={{ pad: [22, 18] }}
    >
      <text tag="span" font="Chivo" size={12} weight={700} ls="2px" color={C.magenta}>{n}</text>
      <text font="Chivo" size={22} weight={800} color={C.ink} lh={1.15} mobile={{ size: 19 }}>{name}</text>
      <text font="Chivo" size={15} weight={400} color="#C7B8DB" lh={1.55}>{desc}</text>
    </div>
  ),
  {
    title: 'QI Pizza Card',
    props: {
      n: { label: 'Number', group: 'Pizza' },
      name: { label: 'Name', group: 'Pizza' },
      desc: { label: 'Description', group: 'Pizza' },
    },
  },
);

const Photo = (slot, extra = {}) =>
  img[slot].id
    ? <img src={img[slot].id} w="100%" h="100%" fit="cover" {...extra} />
    : <img src={img[slot].url} alt={img[slot].alt} w="100%" h="100%" fit="cover" {...extra} />;

export default () => (
  <box w="100%" dir="column" gap={0} pad={0} bg={C.ground}>

    {/* ── 1. NEON BLOCK ─────────────────────────────────────────────────────── */}
    <section w="100%" bg={C.magenta} pad={[0, 0]}>
      <div w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} dir="row" gap={0} wrap align="stretch">
        <div
          w="58%"
          dir="column"
          gap={26}
          pad={{ t: 84, b: 84, l: 40, r: 48 }}
          tablet={{ w: '100%', pad: { t: 64, b: 56, l: 32, r: 32 } }}
          mobile={{ w: '100%', pad: { t: 48, b: 44, l: 20, r: 20 }, gap: 20 }}
        >
          <Kicker n="01" label="ARCADE BAR — OPEN LATE" color={C.ground} />
          <h1
            font="Monoton"
            size={62}
            weight={400}
            color={C.ground}
            lh={1.18}
            tablet={{ size: 48 }}
            mobile={{ size: 27 }}
          >
            44 Cabinets. All Free Play. No Queue For Change.
          </h1>
          <text font="Chivo" size={19} weight={400} color="#2A0B45" lh={1.6} maxw={620} mobile={{ size: 16 }}>
            A bar with a properly restored arcade attached, not an arcade with a bar bolted on. Every
            cabinet is on free play from the moment you walk in. You pay for drinks and that is it.
          </text>
          <div dir="row" gap={14} wrap align="center">
            <text
              href="#floor"
              tag="span"
              font="Chivo"
              size={16}
              weight={800}
              ls="1px"
              color={C.ink}
              bg={C.ground}
              pad={[17, 30]}
              hover={{ bg: C.cyan, color: C.ground }}
            >
              See what is on the floor
            </text>
            <text
              href="#find-us"
              tag="span"
              font="Chivo"
              size={16}
              weight={800}
              ls="1px"
              color={C.ground}
              pad={[15, 26]}
              border={[2, C.ground]}
              hover={{ bg: C.ground, color: C.ink }}
            >
              Where we are
            </text>
          </div>
        </div>

        <div
          w="42%"
          dir="column"
          gap={0}
          bg={C.ground}
          tablet={{ w: '100%' }}
          mobile={{ w: '100%' }}
        >
          <div w="100%" h={228} tablet={{ h: 260 }} mobile={{ h: 190 }}>
            {Photo('arcade_floor')}
          </div>
          <div w="100%" dir="column" gap={0} pad={{ t: 26, b: 30, l: 30, r: 30 }} mobile={{ pad: { t: 22, b: 24, l: 20, r: 20 } }}>
            <text font="Chivo" size={12} weight={700} ls="2px" color={C.cyan} pad={{ b: 14 }}>OPENING HOURS</text>
            {hours.map((h) => (
              <div
                cls="hours-row"
                w="100%"
                dir="row"
                justify="space-between"
                gap={14}
                pad={{ t: 10, b: 10 }}
                border={[0, C.deep]}
                raw="& { border-bottom: 1px solid #3A1A5C; }"
              >
                <text font="Chivo" size={15} weight={400} color={C.ink}>{h.day}</text>
                <text font="Chivo" size={15} weight={700} color={C.amber} ta="right">{h.time}</text>
              </div>
            ))}
            <text font="Chivo" size={13} weight={400} color="#B9A9CE" lh={1.5} pad={{ t: 16 }}>
              Free play the whole time we are open. No tokens, no change machine, no jar of quarters
              by the door.
            </text>
          </div>
        </div>
      </div>
    </section>

    <Seam color={C.cyan} h={10} />

    {/* ── 2. THE FLOOR — 44 CABINETS BY DECADE ──────────────────────────────── */}
    <Block bg={C.ground} id="floor">
      <div w="100%" dir="row" gap={32} wrap align="end" justify="space-between" pad={{ b: 34 }}>
        <div dir="column" gap={16} maxw={620}>
          <Kicker n="02" label="THE FLOOR" color={C.cyan} />
          <h2 font="Monoton" size={46} weight={400} color={C.ink} lh={1.2} tablet={{ size: 38 }} mobile={{ size: 28 }} motion={fadeIn}>
            The Floor
          </h2>
          <text font="Chivo" size={17} weight={400} color="#C7B8DB" lh={1.65} mobile={{ size: 15 }}>
            Original boards where we could get them, faithful reproductions where we could not, and we
            say which is which on the marquee. Six pinball tables, all levelled weekly by someone who
            cares far too much.
          </text>
        </div>
        <div dir="column" gap={0} align="end" mobile={{ align: 'start' }}>
          <text font="Monoton" size={84} weight={400} color={C.magenta} lh={1} mobile={{ size: 60 }}>{String(cabinetCount)}</text>
          <text font="Chivo" size={13} weight={700} ls="2px" color={C.ink}>CABINETS, ALL FREE PLAY</text>
        </div>
      </div>

      <grid cols={4} gap={0} w="100%" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
        {decades.map((d, i) => (
          <div
            cls="decade-col"
            w="100%"
            h="100%"
            dir="column"
            gap={14}
            pad={[26, 24]}
            bg={i % 2 === 0 ? C.deep : '#1C0733'}
            mobile={{ pad: [22, 18] }}
          >
            <div dir="column" gap={4}>
              <h3 font="Chivo" size={20} weight={800} color={C.amber} lh={1.2}>{d.label}</h3>
              <text font="Chivo" size={12} weight={700} ls="1px" color={C.cyan}>{`${d.range} · ${d.cabinets.length} MACHINES`}</text>
            </div>
            <div dir="column" gap={7}>
              {d.cabinets.map((name) => (
                <text cls="cabinet-name" font="Chivo" size={15} weight={400} color={C.ink} lh={1.4}>{name}</text>
              ))}
            </div>
          </div>
        ))}
      </grid>

      <div w="100%" dir="row" gap={26} wrap align="center" bg={C.amber} pad={[24, 26]} m={{ t: 10 }} mobile={{ pad: [20, 18], gap: 16 }}>
        <text font="Chivo" size={13} weight={700} ls="2px" color={C.ground} w={190} mobile={{ w: '100%' }}>SIX PINBALL TABLES</text>
        <div dir="row" gap={18} wrap flex={1}>
          {pinball.map((p) => (
            <text cls="pinball-name" font="Chivo" size={16} weight={700} color={C.ground} lh={1.4}>{p}</text>
          ))}
        </div>
      </div>
    </Block>

    <Seam color={C.magenta} h={10} />

    {/* ── 3. DRINKS ─────────────────────────────────────────────────────────── */}
    <section w="100%" bg={C.cyan} pad={[0, 0]} id="drinks">
      <div w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} dir="row" gap={0} wrap align="stretch">
        <div
          w="40%"
          dir="column"
          gap={22}
          pad={{ t: 80, b: 80, l: 40, r: 44 }}
          tablet={{ w: '100%', pad: { t: 64, b: 40, l: 32, r: 32 } }}
          mobile={{ w: '100%', pad: { t: 48, b: 32, l: 20, r: 20 }, gap: 18 }}
        >
          <Kicker n="03" label="THE BAR" color={C.ground} />
          <h2 font="Monoton" size={44} weight={400} color={C.ground} lh={1.2} tablet={{ size: 36 }} mobile={{ size: 27 }} motion={fadeIn}>
            On Tap
          </h2>
          <text font="Chivo" size={17} weight={400} color="#0A2A31" lh={1.65} mobile={{ size: 15 }}>
            Eight taps, four of them local, two lagers that are actually good, and no cocktail menu. We
            would rather pour you a decent pint in ninety seconds than a negroni in six minutes.
          </text>
          <div w="100%" h={200} tablet={{ h: 240 }} mobile={{ h: 180 }}>
            {Photo('bar_pour')}
          </div>
          <text font="Chivo" size={14} weight={700} color={C.ground} lh={1.5}>
            Wine is red, white or orange. Soft drinks are proper ones. There is a coffee machine and
            somebody knows how to use it.
          </text>
        </div>
        <div w="60%" dir="column" gap={2} bg={C.ground} pad={{ t: 40, b: 40, l: 40, r: 40 }} tablet={{ w: '100%', pad: { t: 32, b: 32, l: 32, r: 32 } }} mobile={{ w: '100%', pad: { t: 24, b: 28, l: 16, r: 16 } }}>
          {taps.map((t) => <TapRow n={t.n} name={t.name} note={t.note} abv={t.abv} />)}
        </div>
      </div>
    </section>

    <Seam color={C.ground} h={10} />

    {/* ── 4. TOURNAMENTS ────────────────────────────────────────────────────── */}
    <Block bg={C.amber} id="tournaments">
      <div w="100%" dir="column" gap={16} maxw={760} pad={{ b: 36 }}>
        <Kicker n="04" label="TUESDAY AND THURSDAY" color={C.ground} />
        <h2 font="Monoton" size={46} weight={400} color={C.ground} lh={1.2} tablet={{ size: 38 }} mobile={{ size: 28 }} motion={fadeIn}>
          Tournaments
        </h2>
        <text font="Chivo" size={18} weight={400} color="#3A2400" lh={1.65} mobile={{ size: 15 }}>
          Tuesday is pinball, Thursday is fighting games, and the leaderboard resets on the first of
          every month. Winner gets their initials on the wall for a year and a bar tab.
        </text>
      </div>

      <div w="100%" dir="row" gap={0} wrap align="stretch">
        <div w="50%" dir="column" gap={10} pad={[30, 30]} bg={C.ground} tablet={{ w: '100%' }} mobile={{ w: '100%', pad: [24, 20] }}>
          <text font="Chivo" size={12} weight={700} ls="2px" color={C.cyan}>TUESDAY · 7PM</text>
          <h3 font="Chivo" size={26} weight={800} color={C.ink} lh={1.15} mobile={{ size: 22 }}>Pinball Ladder</h3>
          <text font="Chivo" size={15} weight={400} color="#C7B8DB" lh={1.6}>
            Three games, best two of three, on whichever tables come out of the hat at seven. Sign up at
            the bar from six. Free to enter, capped at thirty-two players.
          </text>
        </div>
        <div w="50%" dir="column" gap={10} pad={[30, 30]} bg={C.deep} tablet={{ w: '100%' }} mobile={{ w: '100%', pad: [24, 20] }}>
          <text font="Chivo" size={12} weight={700} ls="2px" color={C.magenta}>THURSDAY · 7PM</text>
          <h3 font="Chivo" size={26} weight={800} color={C.ink} lh={1.15} mobile={{ size: 22 }}>Fighting Games</h3>
          <text font="Chivo" size={15} weight={400} color="#C7B8DB" lh={1.6}>
            Double elimination on the cabinet, not on a console. Game rotates monthly between Super
            Turbo, KOF ’98 and Accent Core. Sticks are Japanese and they are looked after.
          </text>
        </div>
      </div>

      <div w="100%" dir="row" gap={0} wrap align="stretch" m={{ t: 10 }}>
        <div w="55%" dir="column" gap={14} pad={[30, 30]} bg={C.ink} tablet={{ w: '100%' }} mobile={{ w: '100%', pad: [24, 20] }}>
          <text font="Chivo" size={12} weight={700} ls="2px" color={C.magenta}>LEADERBOARD RULES</text>
          <div dir="column" gap={9}>
            <text cls="leaderboard-rule" font="Chivo" size={15} weight={400} color={C.ground} lh={1.55}>
              <strong>One.</strong> Scores only count if a member of staff sees the screen before it is cleared.
            </text>
            <text cls="leaderboard-rule" font="Chivo" size={15} weight={400} color={C.ground} lh={1.55}>
              <strong>Two.</strong> Three initials, no more, and we reserve the right to refuse the funny ones.
            </text>
            <text cls="leaderboard-rule" font="Chivo" size={15} weight={400} color={C.ground} lh={1.55}>
              <strong>Three.</strong> Everything resets at open on the first of the month. Nothing carries over.
            </text>
            <text cls="leaderboard-rule" font="Chivo" size={15} weight={400} color={C.ground} lh={1.55}>
              <strong>Four.</strong> The month’s top score on each tournament machine goes on the wall for a year, plus a fifty pound tab.
            </text>
            <text cls="leaderboard-rule" font="Chivo" size={15} weight={400} color={C.ground} lh={1.55}>
              <strong>Five.</strong> Ties are settled on the machine, that night, in one game. No sharing the wall.
            </text>
          </div>
        </div>
        <div w="45%" minh={260} tablet={{ w: '100%', minh: 240 }} mobile={{ w: '100%', minh: 200 }}>
          {Photo('pinball_hands')}
        </div>
      </div>
    </Block>

    <Seam color={C.cyan} h={10} />

    {/* ── 5. PRIVATE HIRE ───────────────────────────────────────────────────── */}
    <section w="100%" bg={C.deep} pad={[0, 0]} id="hire">
      <div w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} dir="row" gap={0} wrap align="stretch">
        <div
          w="55%"
          dir="column"
          gap={22}
          pad={{ t: 84, b: 84, l: 40, r: 48 }}
          tablet={{ w: '100%', pad: { t: 64, b: 56, l: 32, r: 32 } }}
          mobile={{ w: '100%', pad: { t: 48, b: 44, l: 20, r: 20 }, gap: 18 }}
        >
          <Kicker n="05" label="PRIVATE HIRE" color={C.cyan} />
          <h2 font="Monoton" size={44} weight={400} color={C.ink} lh={1.2} tablet={{ size: 36 }} mobile={{ size: 26 }} motion={fadeIn}>
            The Whole Floor
          </h2>
          <text font="Chivo" size={18} weight={400} color="#D8CBE9" lh={1.65} mobile={{ size: 15 }}>
            Whole floor hire for up to 120 people, Sunday to Wednesday, from 900 including a welcome
            round. All 44 cabinets and all six tables stay on free play, which is the entire point.
          </text>
          <div w="100%" dir="row" gap={0} wrap>
            <div cls="hire-stat" w="33.33%" dir="column" gap={4} pad={{ t: 18, b: 18, r: 18 }} mobile={{ w: '100%', pad: { t: 12, b: 12 } }}>
              <text cls="hire-stat-num" font="Monoton" size={34} weight={400} color={C.amber} lh={1.1}>120</text>
              <text cls="hire-stat-label" font="Chivo" size={13} weight={700} ls="1px" color={C.ink}>PEOPLE, STANDING</text>
            </div>
            <div cls="hire-stat" w="33.33%" dir="column" gap={4} pad={{ t: 18, b: 18, r: 18 }} mobile={{ w: '100%', pad: { t: 12, b: 12 } }}>
              <text cls="hire-stat-num" font="Monoton" size={34} weight={400} color={C.amber} lh={1.1}>900</text>
              <text cls="hire-stat-label" font="Chivo" size={13} weight={700} ls="1px" color={C.ink}>FROM, WELCOME ROUND IN</text>
            </div>
            <div cls="hire-stat" w="33.33%" dir="column" gap={4} pad={{ t: 18, b: 18, r: 18 }} mobile={{ w: '100%', pad: { t: 12, b: 12 } }}>
              <text cls="hire-stat-num" font="Monoton" size={34} weight={400} color={C.amber} lh={1.1}>Sun</text>
              <text cls="hire-stat-label" font="Chivo" size={13} weight={700} ls="1px" color={C.ink}>TO WEDNESDAY</text>
            </div>
          </div>
          <text
            href="mailto:hire@quarterinserted.co.uk"
            tag="span"
            font="Chivo"
            size={16}
            weight={800}
            ls="1px"
            color={C.ground}
            bg={C.cyan}
            pad={[16, 28]}
            w="hug"
            hover={{ bg: C.amber }}
          >
            hire@quarterinserted.co.uk
          </text>
          <text font="Chivo" size={14} weight={400} color="#B9A9CE" lh={1.55}>
            Pizza for the room is quoted per head. Thursday and the weekend stay open to everybody —
            we are not shutting the floor on a Friday, sorry.
          </text>
        </div>
        <div w="45%" minh={420} bg={C.ground} tablet={{ w: '100%', minh: 300 }} mobile={{ w: '100%', minh: 220 }}>
          {Photo('arcade_floor')}
        </div>
      </div>
    </section>

    <Seam color={C.amber} h={10} />

    {/* ── 6. FOOD ───────────────────────────────────────────────────────────── */}
    <Block bg={C.magenta} id="food">
      <div w="100%" dir="row" gap={32} wrap align="end" justify="space-between" pad={{ b: 32 }}>
        <div dir="column" gap={16} maxw={700}>
          <Kicker n="06" label="ONE OVEN, UNTIL 11PM" color={C.ground} />
          <h2 font="Monoton" size={46} weight={400} color={C.ground} lh={1.2} tablet={{ size: 38 }} mobile={{ size: 28 }} motion={fadeIn}>
            The Oven
          </h2>
          <text font="Chivo" size={18} weight={400} color="#2A0B45" lh={1.65} mobile={{ size: 15 }}>
            One oven, six pizzas, until 11pm. The one with the fennel sausage is the correct order and
            the staff will tell you so.
          </text>
        </div>
        <text font="Chivo" size={13} weight={700} ls="2px" color={C.ground} maxw={220} lh={1.6}>
          NO STARTERS. NO PUDDINGS. NO CHIPS. THERE IS ONE OVEN AND IT IS BUSY.
        </text>
      </div>

      <grid cols={3} gap={2} w="100%" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
        {pizzas.map((p) => <PizzaCard n={p.n} name={p.name} desc={p.desc} />)}
      </grid>
    </Block>

    <Seam color={C.cyan} h={10} />

    {/* ── 7. HOUSE RULES ────────────────────────────────────────────────────── */}
    <Block bg={C.ground} id="rules">
      <div w="100%" dir="column" gap={16} maxw={760} pad={{ b: 34 }}>
        <Kicker n="07" label="HOUSE RULES" color={C.magenta} />
        <h2 font="Monoton" size={46} weight={400} color={C.ink} lh={1.2} tablet={{ size: 38 }} mobile={{ size: 28 }} motion={fadeIn}>
          House Rules
        </h2>
        <text font="Chivo" size={18} weight={400} color="#C7B8DB" lh={1.65} mobile={{ size: 15 }}>
          Over 21 after 8pm. No drinks on the cabinets, and we do mean it. Be decent to whoever is on
          the machine you want. That is the whole list, and it is not negotiable.
        </text>
      </div>

      <div w="100%" dir="column" gap={0}>
        {rules.map((r, i) => (
          <div
            cls="rule-row"
            w="100%"
            dir="row"
            gap={28}
            wrap
            align="start"
            pad={[28, 30]}
            bg={i % 2 === 0 ? C.deep : '#1C0733'}
            mobile={{ pad: [22, 18], gap: 10 }}
          >
            <text font="Monoton" size={30} weight={400} color={C.cyan} lh={1} w={72} mobile={{ size: 24, w: '100%' }}>{r.n}</text>
            <div dir="column" gap={8} flex={1} maxw={860}>
              <h3 font="Chivo" size={22} weight={800} color={C.amber} lh={1.2} mobile={{ size: 19 }}>{r.title}</h3>
              <text font="Chivo" size={16} weight={400} color={C.ink} lh={1.6} mobile={{ size: 15 }}>{r.body}</text>
            </div>
          </div>
        ))}
      </div>
    </Block>

    <Seam color={C.magenta} h={10} />

    {/* ── 8. FIND US ────────────────────────────────────────────────────────── */}
    <section w="100%" bg={C.cyan} pad={[0, 0]} id="find-us">
      <div w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} dir="row" gap={0} wrap align="stretch">
        <div
          w="50%"
          dir="column"
          gap={20}
          pad={{ t: 80, b: 80, l: 40, r: 44 }}
          tablet={{ w: '100%', pad: { t: 60, b: 48, l: 32, r: 32 } }}
          mobile={{ w: '100%', pad: { t: 48, b: 40, l: 20, r: 20 }, gap: 16 }}
        >
          <Kicker n="08" label="FIND US" color={C.ground} />
          <h2 font="Monoton" size={44} weight={400} color={C.ground} lh={1.2} tablet={{ size: 36 }} mobile={{ size: 26 }}>
            Walk In
          </h2>
          <text font="Chivo" size={18} weight={400} color="#0A2A31" lh={1.65} mobile={{ size: 15 }}>
            No bookings for the main floor, ever. If we are full there is a queue and it moves. Come
            early on a Friday or come late on a Tuesday and have the place to yourself.
          </text>
          <div dir="column" gap={2}>
            <text font="Chivo" size={20} weight={800} color={C.ground} lh={1.4}>Quarter Inserted</text>
            <text cls="address-line" font="Chivo" size={17} weight={400} color="#0A2A31" lh={1.5}>Unit 4, The Old Print Works</text>
            <text cls="address-line" font="Chivo" size={17} weight={400} color="#0A2A31" lh={1.5}>112 Gasworks Lane</text>
            <text cls="address-line" font="Chivo" size={17} weight={400} color="#0A2A31" lh={1.5}>Manchester M4 6JR</text>
          </div>
          <text
            href="tel:+441610000044"
            tag="span"
            font="Chivo"
            size={16}
            weight={800}
            ls="1px"
            color={C.cyan}
            bg={C.ground}
            pad={[16, 28]}
            w="hug"
            hover={{ bg: C.magenta, color: C.ink }}
          >
            0161 000 0044
          </text>
        </div>

        <div
          w="50%"
          dir="column"
          gap={0}
          bg={C.ground}
          pad={{ t: 60, b: 60, l: 40, r: 40 }}
          tablet={{ w: '100%', pad: { t: 44, b: 48, l: 32, r: 32 } }}
          mobile={{ w: '100%', pad: { t: 36, b: 40, l: 20, r: 20 } }}
        >
          <text font="Chivo" size={12} weight={700} ls="2px" color={C.amber} pad={{ b: 16 }}>WHEN WE ARE OPEN</text>
          {hours.map((h) => (
            <div
              cls="hours-row"
              w="100%"
              dir="row"
              justify="space-between"
              gap={14}
              pad={{ t: 12, b: 12 }}
              raw="& { border-bottom: 1px solid #3A1A5C; }"
            >
              <text font="Chivo" size={16} weight={400} color={C.ink}>{h.day}</text>
              <text font="Chivo" size={16} weight={700} color={C.cyan} ta="right">{h.time}</text>
            </div>
          ))}
          <text font="Chivo" size={15} weight={400} color="#C7B8DB" lh={1.6} pad={{ t: 20 }}>
            Two minutes from the tram, five from the station, and there is a bike rack in the yard.
            Kitchen stops at 11pm sharp. Over 21 after 8pm, so bring ID.
          </text>
          <text font="Monoton" size={26} weight={400} color={C.magenta} lh={1.3} pad={{ t: 24 }} mobile={{ size: 20 }}>
            Quarter Inserted
          </text>
        </div>
      </div>
    </section>

    <Seam color={C.magenta} h={10} />
  </box>
);
