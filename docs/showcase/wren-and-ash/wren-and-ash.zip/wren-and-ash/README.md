# Wren & Ash

Furniture catalogue in warm neutrals; the joint detail plates are a lovely touch.

|  |  |
|---|---|
| **Slug** | `wren-and-ash` (deploys to `/wren-and-ash/`) |
| **Archetype** | catalogue grid |
| **Industry** | Maker portfolio |
| **Page title** | Wren & Ash — commissioned furniture in native hardwood |
| **Fonts** | EB Garamond, Karla — Google Fonts, imported by Elementor automatically |
| **Elements** | 126 |
| **Images** | 4 |
| **Global classes used** | 0 — built `--inline` (60 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install wren-and-ash
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
wren-and-ash/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/wren-and-ash.page.jsx          the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F6F2EA` |
| `ink` | `#241F1A` |
| `oak` | `#A97B4F` |
| `ink_soft` | `#6B6155` |
| `green` | `#3F5347` |

Change a value, re-run `npx exjsx-kit install wren-and-ash`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/wren-and-ash.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `joinery_macro` | `media/joinery_macro.jpg` | Close view of a hand-cut dovetail joint in oak |
| `table_room` | `media/table_room.jpg` | A solid oak refectory table in a plain room |
| `timber_stack` | `media/timber_stack.jpg` | Air-drying boards stacked in stick in the timber rack |
| `workshop` | `media/workshop.jpg` | The two-person workshop in the Welsh borders |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
