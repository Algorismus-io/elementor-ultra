import { MEDIA as media } from '../data/media.mjs';
import { P } from '../data/palette.mjs';

export const meta = {
  title: 'Quiet Night A2',
  slug: 'quiet-night-cpap',
  seo: {
    title: 'Quiet Night A2 — the CPAP measured against the one you gave up on',
    description:
      '24.1 dBA at the pillow, three cushion sizes in the box, tap water in the chamber. The spec comparison against the two machines you already tried, measured under ISO 80601-2-70.',
  },
};

const HEAD = 'Lexend';
const BODY = 'Figtree';

/* ── the comparison table ─────────────────────────────────────────────────── */

const COL = { label: '34%', val: '22%' };
const CELL = { t: 15, b: 15, l: 18, r: 12 };
const CELL_M = { t: 10, b: 10, l: 10, r: 7 };

/** One measured row of the spec sheet. Content props only — styling is fixed by the definition. */
const SpecRow = ({ label, a2, m1, m2 }) => (
    <row
      w="100%"
      tw="flex flex-row items-stretch"
      cls="spec-row"
      raw="border-bottom: 1px solid #DCE7EF;"
    >
      <box w={COL.label} pad={CELL} mobile={{ pad: CELL_M }}>
        <text font={BODY} size={14} lh={1.4} color={P.ink} mobile={{ size: 11 }}>
          {label}
        </text>
      </box>
      <box w={COL.val} pad={CELL} mobile={{ pad: CELL_M }} bg="#FFFFFF">
        <text font={BODY} size={15} weight={600} lh={1.35} color={P.ok} mobile={{ size: 11 }}>
          {a2}
        </text>
      </box>
      <box w={COL.val} pad={CELL} mobile={{ pad: CELL_M }}>
        <text font={BODY} size={14} lh={1.35} color="#5A6B7A" mobile={{ size: 11 }}>
          {m1}
        </text>
      </box>
      <box w={COL.val} pad={CELL} mobile={{ pad: CELL_M }}>
        <text font={BODY} size={14} lh={1.35} color="#5A6B7A" mobile={{ size: 11 }}>
          {m2}
        </text>
      </box>
    </row>
  );

const SPECS = [
  { label: 'Noise at the pillow, 30 cm', a2: '24.1 dBA', m1: '26.6 dBA', m2: '28.9 dBA' },
  { label: 'Cushion sizes in the box', a2: 'Three', m1: 'One', m2: 'One' },
  { label: 'Frame adjusts without tools', a2: 'Yes', m1: 'No', m2: 'No' },
  { label: 'Water the chamber takes', a2: 'Tap', m1: 'Distilled advised', m2: 'Distilled required' },
  { label: 'Time to refit the chamber', a2: '11 seconds', m1: '38 seconds', m2: '52 seconds' },
  { label: 'Chamber is dishwasher safe', a2: 'Yes', m1: 'No', m2: 'No' },
  { label: 'Data leaves the device', a2: 'Only if you send it', m1: 'On by default', m2: 'On by default' },
  { label: 'Compliance report you can export', a2: 'One tap, PDF', m1: 'Clinic portal only', m2: 'Clinic portal only' },
  { label: 'Trial you can return', a2: '30 nights', m1: '14 days, retailer', m2: 'None' },
];

/* ── small parts ──────────────────────────────────────────────────────────── */

const Band = ({ id, bg, pad, children }) => (
  <box id={id} w="100%" bg={bg} pad={pad} tw="flex flex-col items-center">
    <box w="100%" maxw={1180} tw="flex flex-col">
      {children}
    </box>
  </box>
);

const Eyebrow = ({ children, color }) => (
  <text font={BODY} size={12} weight={600} ls={0.12} color={color}>
    {children}
  </text>
);

const NoiseBar = ({ name, value, pct, tone, dim }) => (
  <grid w="100%" cols="minmax(0, 30fr) minmax(0, 50fr) minmax(0, 20fr)" tw="items-center gap-4"
        mobile={{ gap: 10, gridCols: 'minmax(0, 30fr) minmax(0, 50fr) minmax(0, 20fr)' }}>
    <box>
      <text font={BODY} size={14} color={dim ? '#5A6B7A' : P.ink} weight={dim ? 400 : 600} mobile={{ size: 12 }}>
        {name}
      </text>
    </box>
    <box w="100%" h={10} radius={5} bg="#E3EBF2" tw="flex flex-row">
      <box w={pct} h={10} radius={5} bg={tone} />
    </box>
    <box>
      <text font={HEAD} size={15} weight={600} color={dim ? '#5A6B7A' : P.ink} ta="right" mobile={{ size: 12 }}>
        {value}
      </text>
    </box>
  </grid>
);

const Fact = ({ k, v, bg, kc, vc }) => (
  <box bg={bg} radius={10} pad={20} tw="flex flex-col gap-2">
    <text font={HEAD} size={17} weight={600} color={kc}>
      {k}
    </text>
    <text font={BODY} size={14} lh={1.55} color={vc}>
      {v}
    </text>
  </box>
);

const DefRow = ({ term, children }) => (
  <row w="100%" tw="flex flex-row gap-8 max-md:flex-col max-md:gap-2" raw="border-top: 1px solid #DCE7EF;" cls="def-row" pad={{ t: 26, b: 26 }}>
    <box w="260px" tw="max-md:w-full">
      <h3 font={HEAD} size={18} weight={600} color={P.ink} mobile={{ size: 16 }}>
        {term}
      </h3>
    </box>
    <box tw="flex flex-col gap-3" flex={1}>
      {children}
    </box>
  </row>
);

const Badge = ({ children }) => (
  <box radius={999} pad={{ t: 9, b: 9, l: 16, r: 16 }} border={[1, '#3B5468']} bg="#22364799">
    <text font={BODY} size={13} weight={600} color={P.soft}>
      {children}
    </text>
  </box>
);

const Cta = ({ href, children }) => (
  <text
    href={href}
    font={BODY}
    size={16}
    weight={600}
    color="#FFFFFF"
    bg={P.ok}
    radius={8}
    pad={{ t: 15, b: 15, l: 28, r: 28 }}
    ta="center"
    tw="hover:bg-[#35896A]"
    shadow={[[6, 18, -6, '#0E2E2333'], [1, 2, 0, '#0000001A']]}
  >
    {children}
  </text>
);

/* ── page ─────────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
    {/* 1 — hero: the spec sheet IS the hero */}
    <Band id="compare" bg={t.color.night} pad={{ t: 72, b: 88, l: 24, r: 24 }}>
      {/* gap-aware columns: %-widths on a gapped flex row overflow (Elementor rejects the save);
          the same proportions as grid fr tracks subtract the gap first. */}
      <grid cols="minmax(0, 58fr) minmax(0, 42fr)" tw="gap-16 max-lg:gap-8" w="100%" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
        <box tw="flex flex-col gap-5">
          <Eyebrow color={t.color.calm}>CPAP · MODEL A2 · FDA 510(k) CLEARED</Eyebrow>
          <h1
            font={HEAD}
            size={54}
            weight={600}
            lh={1.08}
            ls={-0.02}
            color={t.color.white}
            tablet={{ size: 44 }}
            mobile={{ size: 31 }}
          >
            Quiet Night A2 versus the machine you gave up on
          </h1>
        </box>
        <box tw="flex flex-col gap-6 justify-end">
          <text font={BODY} size={17} lh={1.62} color={t.color.soft} mobile={{ size: 15 }}>
            Two thirds of people stop using CPAP within a year. We rebuilt the machine around the
            three reasons they give: it is loud, the mask hurts, and the tank is a chore. Here is the
            comparison, measured, not claimed.
          </text>
          <row tw="flex flex-row gap-4 items-center max-md:flex-col max-md:items-stretch">
            <Cta href="#trial">Start a 30-night trial</Cta>
            <text
              href="#noise"
              font={BODY}
              size={15}
              weight={600}
              color={t.color.soft}
              pad={{ t: 15, b: 15, l: 4, r: 4 }}
              tw="hover:text-[#7FB2D9]"
              ta="center"
            >
              Read the measurement method
            </text>
          </row>
        </box>
      </grid>

      {/* the table */}
      <box
        w="100%"
        bg={t.color.ground}
        radius={14}
        m={{ t: 52 }}
        shadow={[[24, 60, -20, '#00000059'], [2, 6, 0, '#0000002E']]}
        tw="flex flex-col overflow-hidden"
        motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}
      >
        {/* header row */}
        <row w="100%" tw="flex flex-row items-stretch" bg="#E8EFF5" raw="border-bottom: 2px solid #C3D4E2;" cls="spec-head">
          <box w={COL.label} pad={{ t: 16, b: 14, l: 18, r: 12 }} mobile={{ pad: CELL_M }}>
            <text font={BODY} size={12} weight={600} ls={0.1} color="#5A6B7A" mobile={{ size: 10 }}>
              MEASURED
            </text>
          </box>
          <box w={COL.val} pad={{ t: 16, b: 14, l: 18, r: 12 }} mobile={{ pad: CELL_M }} bg="#FFFFFF" tw="flex flex-col gap-1">
            <text font={HEAD} size={15} weight={600} color={t.color.ink} lh={1.25} mobile={{ size: 11 }}>
              Quiet Night A2
            </text>
            <text font={BODY} size={12} color={t.color.ok} weight={600} mobile={{ size: 10 }}>
              2026
            </text>
          </box>
          <box w={COL.val} pad={{ t: 16, b: 14, l: 18, r: 12 }} mobile={{ pad: CELL_M }} tw="flex flex-col gap-1">
            <text font={HEAD} size={15} weight={600} color="#5A6B7A" lh={1.25} mobile={{ size: 11 }}>
              Machine A
            </text>
            <text font={BODY} size={12} color="#7C8B99" mobile={{ size: 10 }}>
              2022
            </text>
          </box>
          <box w={COL.val} pad={{ t: 16, b: 14, l: 18, r: 12 }} mobile={{ pad: CELL_M }} tw="flex flex-col gap-1">
            <text font={HEAD} size={15} weight={600} color="#5A6B7A" lh={1.25} mobile={{ size: 11 }}>
              Machine B
            </text>
            <text font={BODY} size={12} color="#7C8B99" mobile={{ size: 10 }}>
              2021
            </text>
          </box>
        </row>

        {SPECS.map((s) => (
          <SpecRow label={s.label} a2={s.a2} m1={s.m1} m2={s.m2} />
        ))}

        <box pad={{ t: 18, b: 20, l: 18, r: 18 }} bg="#EDF2F7">
          <text font={BODY} size={13} lh={1.6} color="#5A6B7A" mobile={{ size: 12 }}>
            Machines A and B are the two best-selling units in the US and UK. All three were measured
            in the same lab, on the same day, at 10 cmH2O with the humidifier on and standard tubing.
            They are named, with serial numbers, in the methodology PDF.
          </text>
        </box>
      </box>
    </Band>

    {/* 2 — noise */}
    <Band id="noise" bg={t.color.ground} pad={{ t: 104, b: 104, l: 24, r: 24 }}>
      {/* gap-aware columns: %-widths on a gapped flex row overflow (Elementor rejects the save);
          the same proportions as grid fr tracks subtract the gap first. */}
      <grid cols="minmax(0, 55fr) minmax(0, 45fr)" tw="gap-16 items-center max-lg:gap-10" w="100%" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
        <box tw="flex flex-col gap-7">
          <Eyebrow color={t.color.calm}>01 — NOISE</Eyebrow>
          <h2
            font={HEAD}
            size={40}
            weight={600}
            lh={1.12}
            ls={-0.015}
            color={t.color.ink}
            mobile={{ size: 27 }}
            motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}
          >
            Twenty-four decibels, taken at the pillow
          </h2>
          <row tw="flex flex-row items-end gap-3">
            <text font={HEAD} size={78} weight={600} lh={1} ls={-0.03} color={t.color.ink} mobile={{ size: 54 }}>
              24.1
            </text>
            <text font={BODY} size={20} weight={600} color={t.color.ok} pad={{ b: 12 }} mobile={{ size: 16 }}>
              dBA
            </text>
          </row>
          <text font={BODY} size={17} lh={1.62} color="#3C4C5A" mobile={{ size: 15 }}>
            24.1 dBA measured at 30cm from the pillow at 10 cmH2O, per ISO 80601-2-70. The two market
            leaders measure 26.6 and 28.9 under the same method in our lab.
          </text>

          <box tw="flex flex-col gap-4" w="100%" pad={{ t: 8 }}>
            <NoiseBar name="Quiet Night A2" value="24.1" pct="41%" tone={t.color.ok} />
            <NoiseBar name="Machine A" value="26.6" pct="66%" tone="#94A9B9" dim />
            <NoiseBar name="Machine B" value="28.9" pct="89%" tone="#94A9B9" dim />
          </box>

          <text font={BODY} size={14} lh={1.65} color="#5A6B7A" maxw={540}>
            <strong>Method.</strong> Anechoic room, sensor at head height 30cm from where an ear
            would be, averaged over ten minutes of steady therapy. Decibels are logarithmic: at
            28.9 the machine is roughly twice as loud to the person beside you as it is at 24.1.
          </text>
        </box>

        <box tw="flex flex-col">
          <img
            src={media.device_bedside.id}
            w="100%"
            radius={14}
            shadow={[[18, 44, -18, '#16212B40']]}
          />
          <text font={BODY} size={13} lh={1.55} color="#5A6B7A" pad={{ t: 14 }}>
            The A2 on a bedside table. No fan whine, no exhaust note at the back of the case — the
            blower sits on a decoupled mount and the outlet is baffled.
          </text>
        </box>
      </grid>
    </Band>

    {/* 3 — mask */}
    <Band id="mask" bg={t.color.soft} pad={{ t: 96, b: 96, l: 24, r: 24 }}>
      {/* gap-aware columns: %-widths on a gapped flex row overflow (Elementor rejects the save);
          the same proportions as grid fr tracks subtract the gap first. */}
      <grid cols="minmax(0, 42fr) minmax(0, 58fr)" tw="gap-16 items-center max-lg:gap-10" w="100%" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
        <box>
          <img src={media.sleeping.id} w="100%" radius={14} shadow={[[16, 40, -16, '#16212B33']]} />
        </box>
        <box tw="flex flex-col gap-7">
          <Eyebrow color="#2C6491">02 — THE MASK</Eyebrow>
          <h2
            font={HEAD}
            size={40}
            weight={600}
            lh={1.12}
            ls={-0.015}
            color={t.color.ink}
            mobile={{ size: 27 }}
            motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}
          >
            The mask problem is usually a sizing problem
          </h2>
          <text font={BODY} size={17} lh={1.62} color="#3C4C5A" mobile={{ size: 15 }}>
            Ships with three cushion sizes and a frame that adjusts without tools. Most people are
            wearing the wrong size and nobody ever checked.
          </text>
          <grid cols={3} gap={14} w="100%" mobile={{ gridCols: 1 }} tablet={{ gridCols: 3 }}>
            <Fact k="Small" v="38 mm cushion. Narrow bridge, shallow nasal profile." bg="#FFFFFF" kc={t.color.ink} vc="#5A6B7A" />
            <Fact k="Medium" v="42 mm cushion. Fits most adults; the one you were given." bg="#FFFFFF" kc={t.color.ink} vc="#5A6B7A" />
            <Fact k="Large" v="46 mm cushion. Wider bridge, deeper seal, less strap force." bg="#FFFFFF" kc={t.color.ink} vc="#5A6B7A" />
          </grid>
          <text font={BODY} size={14} lh={1.65} color="#48596A">
            All three are in the box, so you can change size at 3am without ordering anything. The
            frame tightens by hand — no clips to lose, no tool in a drawer. If none of them seal, we
            send a full-face frame at no charge inside the trial.
          </text>
        </box>
      </grid>
    </Band>

    {/* 4 — humidifier */}
    <Band id="water" bg={t.color.night} pad={{ t: 100, b: 100, l: 24, r: 24 }}>
      {/* gap-aware columns: %-widths on a gapped flex row overflow (Elementor rejects the save);
          the same proportions as grid fr tracks subtract the gap first. */}
      <grid cols="minmax(0, 56fr) minmax(0, 44fr)" tw="gap-16 items-center max-lg:gap-10" w="100%" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
        <box tw="flex flex-col gap-7">
          <Eyebrow color={t.color.calm}>03 — WATER</Eyebrow>
          <h2
            font={HEAD}
            size={40}
            weight={600}
            lh={1.12}
            ls={-0.015}
            color={t.color.white}
            mobile={{ size: 27 }}
            motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}
          >
            Tap water is fine. There is no subscription.
          </h2>
          <text font={BODY} size={17} lh={1.62} color={t.color.soft} mobile={{ size: 15 }}>
            Tap water is fine. The chamber is dishwasher safe and takes eleven seconds to refit.
            There is no distilled water subscription and there never will be.
          </text>
          <grid cols={3} gap={14} w="100%" mobile={{ gridCols: 1 }}>
            <Fact k="11 seconds" v="Chamber out, filled, back in. Timed with one hand, half asleep." bg="#22364B" kc={t.color.white} vc={t.color.soft} />
            <Fact k="Top rack" v="Dishwasher safe. No descaling ritual, no vinegar soak on Sundays." bg="#22364B" kc={t.color.white} vc={t.color.soft} />
            <Fact k="Any tap" v="A scale-tolerant plate and a replaceable seal, £9, once a year." bg="#22364B" kc={t.color.white} vc={t.color.soft} />
          </grid>
        </box>
        <box>
          <img src={media.chamber_detail.id} w="100%" radius={14} shadow={[[20, 50, -18, '#00000066']]} />
        </box>
      </grid>
    </Band>

    {/* 5 — data */}
    <Band id="data" bg={t.color.ground} pad={{ t: 100, b: 100, l: 24, r: 24 }}>
      <box tw="flex flex-col gap-10" w="100%">
        {/* gap-aware columns: %-widths on a gapped flex row overflow (Elementor rejects the save);
          the same proportions as grid fr tracks subtract the gap first. */}
        <grid cols="minmax(0, 48fr) minmax(0, 52fr)" tw="gap-16 items-start max-lg:gap-6" w="100%" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
          <box tw="flex flex-col gap-5">
            <Eyebrow color={t.color.calm}>04 — YOUR DATA</Eyebrow>
            <h2
              font={HEAD}
              size={40}
              weight={600}
              lh={1.12}
              ls={-0.015}
              color={t.color.ink}
              mobile={{ size: 27 }}
              motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}
            >
              What it records, and who can see it
            </h2>
          </box>
          <box>
            <text font={BODY} size={17} lh={1.62} color="#3C4C5A" mobile={{ size: 15 }}>
              Your data stays on the device and your phone unless you send it. You can export a
              compliance report for your clinic in one tap and delete everything in two.
            </text>
          </box>
        </grid>

        <grid cols={4} gap={14} w="100%" mobile={{ gridCols: 1 }} tablet={{ gridCols: 2 }}>
          <Fact k="Recorded" v="AHI, leak rate, delivered pressure, mask-on hours, per night, on the device." bg="#FFFFFF" kc={t.color.ink} vc="#5A6B7A" />
          <Fact k="Stored" v="On the machine and, if you pair it, on your phone. Nowhere else by default." bg="#FFFFFF" kc={t.color.ink} vc="#5A6B7A" />
          <Fact k="Exported" v="One tap makes a dated PDF your clinic accepts for compliance. You choose the range." bg="#FFFFFF" kc={t.color.ink} vc="#5A6B7A" />
          <Fact k="Deleted" v="Two taps wipes the device and the phone. We hold no copy to delete." bg="#FFFFFF" kc={t.color.ink} vc="#5A6B7A" />
        </grid>

        <box bg="#E8EFF5" radius={12} pad={24} border={[1, '#CDDDE9']}>
          <text font={BODY} size={14} lh={1.65} color="#3C4C5A">
            <strong>No insurer feed.</strong> Some machines report usage to a supplier or insurer
            automatically, and people find out when a claim is refused. The A2 has no such channel.
            If your insurer needs proof of use, you send them the PDF.
          </text>
        </box>
      </box>
    </Band>

    {/* 6 — access */}
    <Band id="access" bg={t.color.white} pad={{ t: 96, b: 96, l: 24, r: 24 }}>
      <box tw="flex flex-col gap-8" w="100%">
        <box tw="flex flex-col gap-4" maxw={620}>
          <Eyebrow color={t.color.calm}>05 — GETTING ONE</Eyebrow>
          <h2 font={HEAD} size={40} weight={600} lh={1.12} ls={-0.015} color={t.color.ink} mobile={{ size: 27 }}>
            Prescription, insurance and sending it back
          </h2>
        </box>
        <box tw="flex flex-col" w="100%">
          <DefRow term="Prescription">
            <text font={BODY} size={16} lh={1.65} color="#3C4C5A" mobile={{ size: 15 }}>
              Required. Upload it at checkout, or give us your clinic and we will request it. We do
              not ship a machine without one, including on the trial.
            </text>
          </DefRow>
          <DefRow term="Insurance">
            <text font={BODY} size={16} lh={1.65} color="#3C4C5A" mobile={{ size: 15 }}>
              We are not in-network anywhere. You pay us directly and we issue an itemised invoice
              with HCPCS codes E0601 and A7038 so you can claim it back. Most US plans reimburse a
              rental equivalent rather than a purchase — ask for the code list before you order.
            </text>
          </DefRow>
          <DefRow term="Returns">
            <text font={BODY} size={16} lh={1.65} color="#3C4C5A" mobile={{ size: 15 }}>
              Sleep on it for 30 nights. Send it back for any reason and we refund it including the
              shipping, and you keep the masks.
            </text>
          </DefRow>
          <DefRow term="Servicing">
            <text font={BODY} size={16} lh={1.65} color="#3C4C5A" mobile={{ size: 15 }}>
              Three-year warranty on the blower, two on everything else. Filters, seals and cushions
              are stocked as ordinary parts you can buy one at a time.
            </text>
          </DefRow>
        </box>
      </box>
    </Band>

    {/* 7 — evidence */}
    <Band id="evidence" bg={t.color.night} pad={{ t: 96, b: 96, l: 24, r: 24 }}>
      {/* gap-aware columns: %-widths on a gapped flex row overflow (Elementor rejects the save);
          the same proportions as grid fr tracks subtract the gap first. */}
      <grid cols="minmax(0, 46fr) minmax(0, 54fr)" tw="gap-16 items-start max-lg:gap-8" w="100%" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
        <box tw="flex flex-col gap-5">
          <Eyebrow color={t.color.calm}>06 — EVIDENCE</Eyebrow>
          <h2
            font={HEAD}
            size={38}
            weight={600}
            lh={1.14}
            ls={-0.015}
            color={t.color.white}
            mobile={{ size: 26 }}
            motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}
          >
            Clinical evidence and regulatory clearances
          </h2>
          <row tw="flex flex-row gap-3 flex-wrap">
            <Badge>FDA 510(k) cleared</Badge>
            <Badge>UKCA marked</Badge>
            <Badge>ISO 80601-2-70</Badge>
            <Badge>Prescription required</Badge>
          </row>
        </box>
        <box tw="flex flex-col gap-6">
          <text font={BODY} size={17} lh={1.62} color={t.color.soft} mobile={{ size: 15 }}>
            FDA 510(k) cleared and UKCA marked. Prescription required. Full clinical summary and the
            comparison methodology are downloadable in one PDF.
          </text>
          <text font={BODY} size={15} lh={1.65} color="#9FB4C6">
            The summary covers a 212-participant adherence study run over six months against the
            participants' own previous machines, the acoustic test protocol with raw sound-pressure
            traces, and the chamber's microbiological testing on non-distilled water. It also lists
            what we did not test, which is the part worth reading.
          </text>
          <text
            href="/wp-content/uploads/quiet-night-a2-clinical-summary.pdf"
            font={BODY}
            size={16}
            weight={600}
            color={t.color.white}
            pad={{ t: 14, b: 14, l: 22, r: 22 }}
            radius={8}
            border={[1, '#4B6478']}
            tw="hover:bg-[#22364B]"
            w="hug"
          >
            Download the clinical summary and methodology (PDF)
          </text>
        </box>
      </grid>
    </Band>

    {/* 8 — trial */}
    <Band id="trial" bg={t.color.ground} pad={{ t: 100, b: 112, l: 24, r: 24 }}>
      {/* gap-aware columns: %-widths on a gapped flex row overflow (Elementor rejects the save);
          the same proportions as grid fr tracks subtract the gap first. */}
      <grid cols="minmax(0, 55fr) minmax(0, 45fr)" tw="gap-16 items-center max-lg:gap-10" w="100%" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
        <box tw="flex flex-col gap-6">
          <Eyebrow color={t.color.calm}>07 — THE TRIAL</Eyebrow>
          <h2 font={HEAD} size={44} weight={600} lh={1.1} ls={-0.02} color={t.color.ink} mobile={{ size: 29 }}>
            Sleep on it for thirty nights
          </h2>
          <text font={BODY} size={18} lh={1.6} color="#3C4C5A" mobile={{ size: 16 }}>
            Sleep on it for 30 nights. Send it back for any reason and we refund it including the
            shipping, and you keep the masks.
          </text>
          <row tw="flex flex-row gap-4 items-center max-md:flex-col max-md:items-stretch">
            <Cta href="/order/">Start a 30-night trial</Cta>
            <text
              href="#compare"
              font={BODY}
              size={15}
              weight={600}
              color={t.color.calm}
              pad={{ t: 15, b: 15, l: 4, r: 4 }}
              tw="hover:text-[#2C6491]"
              ta="center"
            >
              Back to the comparison
            </text>
          </row>
          <text font={BODY} size={13} lh={1.6} color="#5A6B7A">
            Prescription required before dispatch. Ships in two working days in the UK and US.
          </text>
        </box>

        <box
          bg={t.color.white}
          radius={14}
          pad={30}
          border={[1, '#D5E2EC']}
          shadow={[[14, 38, -14, '#16212B26']]}
          tw="flex flex-col gap-4"
        >
          <text font={HEAD} size={17} weight={600} color={t.color.ink}>
            In the box
          </text>
          <box tw="flex flex-col gap-3">
            <text font={BODY} size={15} lh={1.55} color="#3C4C5A" raw="border-top: 1px solid #E4EDF3; padding-top: 12px;" cls="box-line">
              The A2 machine, humidifier chamber fitted
            </text>
            <text font={BODY} size={15} lh={1.55} color="#3C4C5A" raw="border-top: 1px solid #E4EDF3; padding-top: 12px;" cls="box-line">
              Three cushion sizes and a tool-free frame
            </text>
            <text font={BODY} size={15} lh={1.55} color="#3C4C5A" raw="border-top: 1px solid #E4EDF3; padding-top: 12px;" cls="box-line">
              Heated tubing, spare filter, travel case
            </text>
            <text font={BODY} size={15} lh={1.55} color="#3C4C5A" raw="border-top: 1px solid #E4EDF3; padding-top: 12px;" cls="box-line">
              A one-page setup card, not a manual
            </text>
          </box>
          <text font={BODY} size={13} lh={1.6} color="#5A6B7A" pad={{ t: 6 }}>
            Return shipping is prepaid and in the box from day one. You do not have to ask us for it.
          </text>
        </box>
      </grid>
    </Band>
  </box>
);
