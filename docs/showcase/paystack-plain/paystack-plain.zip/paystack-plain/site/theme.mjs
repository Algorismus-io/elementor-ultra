/** Plainroll design tokens — flat-fee UK payroll, ledger aesthetic. */
export default defineTheme({
  name: 'plainroll',
  color: {
    ground: '#FAFAF8',
    ink: '#121212',
    ours: '#0F6E5A',
    theirs: '#9A9A9A',
    flag: '#D64545',
    rule: '#E2E2DE',
    white: '#FFFFFF',
  },
  font: { head: 'Familjen Grotesk', body: 'Inter' },
  radius: { sm: 4, md: 8, lg: 14 },
  mode: 'literal',
});
