export default { name: 'iron-ledger' };
