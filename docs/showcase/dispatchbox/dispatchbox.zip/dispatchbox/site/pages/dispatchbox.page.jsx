/** Dispatchbox — editorial index rail. */

export const meta = {
  title: 'Dispatchbox',
  slug: 'dispatchbox',
  template: 'elementor_canvas',
  seo: {
    title: 'Dispatchbox — six promises, and the mechanism behind each one',
    description:
      'A newsletter platform with flat pricing, no growth network, no emails sent to your list that you did not write, and an export that actually restores somewhere else.',
  },
};

/* Palette mirrors theme.mjs — components below are registered at module scope and
   cannot take style props, so the literals live here. */
const C = {
  ground: '#FBFBF9',
  ink: '#191919',
  quill: '#3B4A9E',
  highlight: '#FFE96B',
  rule: '#E0E0DA',
  grey: '#71716B',
  white: '#FFFFFF',
  quillTint: '#F0F1F8',
};
const F = { head: 'Literata', body: 'Public Sans' };

const SECTION = { t: 112, b: 112, l: 32, r: 32 };
const SECTION_M = { t: 60, b: 60, l: 20, r: 20 };

/* ── repeaters (content props only) ───────────────────────────────── */

const PromiseRow = defineComponent(
  ({ numeral = 'I', title = '', body = '' }) => (
    <grid
      cols={12}
      gapX={40}
      gapY={12}
      cls="promise-row"
      w="100%"
      pad={{ t: 34, b: 34 }}
      raw="border-top: 1px solid #E0E0DA;"
      mobile={{ pad: { t: 24, b: 24 }, gapY: 8 }}
    >
      <heading
        tag="h3"
        span={2}
        size={30}
        weight={400}
        font={F.head}
        color={C.quill}
        lh={1}
        ls={0.02}
        mobile={{ span: 1, size: 22 }}
      >
        {numeral}
      </heading>
      <heading
        tag="h4"
        span={4}
        size={21}
        weight={500}
        font={F.head}
        color={C.ink}
        lh={1.3}
        mobile={{ span: 1, size: 19 }}
      >
        {title}
      </heading>
      <text span={6} size={16} font={F.body} color={C.grey} lh={1.7} mobile={{ span: 1, size: 15 }}>
        {body}
      </text>
    </grid>
  ),
  {
    title: 'Promise Row',
    props: {
      numeral: { label: 'Numeral', group: 'Content' },
      title: { label: 'Title', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
    },
  },
);

const FileRow = defineComponent(
  ({ name = '', detail = '' }) => (
    <grid
      cols={12}
      gapX={32}
      gapY={6}
      cls="file-row"
      w="100%"
      pad={{ t: 16, b: 16 }}
      raw="border-top: 1px solid rgba(224,224,218,0.18);"
    >
      <text
        span={5}
        cls="file-path"
        size={15}
        color={C.highlight}
        lh={1.5}
        tw="font-mono"
        mobile={{ span: 1, size: 14 }}
      >
        {name}
      </text>
      <text span={7} size={15} font={F.body} color="#A9A9A2" lh={1.6} mobile={{ span: 1, size: 14 }}>
        {detail}
      </text>
    </grid>
  ),
  {
    title: 'Export File Row',
    props: {
      name: { label: 'Path', group: 'Content' },
      detail: { label: 'Detail', group: 'Content' },
    },
  },
);

const MigrationCard = defineComponent(
  ({ platform = '', minutes = '', note = '' }) => (
    <box
      span={4}
      cls="migration-card"
      tw="flex flex-col"
      gap={14}
      pad={30}
      bg={C.white}
      border={[1, C.rule]}
      raw="border-radius: 2px;"
    
      mobile={{ span: 1 }}>
      <heading tag="h3" size={22} weight={500} font={F.head} color={C.ink} lh={1.25}>
        {platform}
      </heading>
      <text size={40} weight={400} font={F.head} color={C.quill} lh={1}>
        {minutes}
      </text>
      <text size={15} font={F.body} color={C.grey} lh={1.65}>
        {note}
      </text>
    </box>
  ),
  {
    title: 'Migration Card',
    props: {
      platform: { label: 'Platform', group: 'Content' },
      minutes: { label: 'Elapsed', group: 'Content' },
      note: { label: 'Note', group: 'Content' },
    },
  },
);

/* ── data ─────────────────────────────────────────────────────────── */

const INDEX = [
  { n: '01', label: 'Six promises', href: '#promises' },
  { n: '02', label: 'The export file, byte by byte', href: '#export' },
  { n: '03', label: 'No recommendation network', href: '#network' },
  { n: '04', label: 'Deliverability and your domain', href: '#deliverability' },
  { n: '05', label: 'Paid subscriptions, and the take rate', href: '#take-rate' },
  { n: '06', label: 'Migration from the big three', href: '#migration' },
  { n: '07', label: 'What we are bad at', href: '#bad-at' },
  { n: '08', label: 'Move your list', href: '#move' },
];

const PROMISES = [
  {
    numeral: 'I.',
    title: 'We never email your subscribers.',
    body: 'Not a digest, not a recommendation, not a we-noticed-you-have-not-opened. There is no code path that sends from your list except when you press send.',
  },
  {
    numeral: 'II.',
    title: 'Your export is a single zip.',
    body: 'Subscribers with signup date and source, every post as Markdown with its images, and your paid subscriber records with Stripe IDs intact. Download it any time without asking.',
  },
  {
    numeral: 'III.',
    title: 'Flat price.',
    body: '£19 a month up to 25,000 subscribers, £49 above that. We do not take a percentage of your paid subscriptions and we never will.',
  },
  {
    numeral: 'IV.',
    title: 'No recommendation network.',
    body: 'We do not run one, we do not sell placement in one, and no widget under your posts points a reader at a writer who paid to be there.',
  },
  {
    numeral: 'V.',
    title: 'Your domain, your reputation.',
    body: 'Every send is authenticated to a domain you own. If you leave, the address your readers already trust leaves with you, warmed and intact.',
  },
  {
    numeral: 'VI.',
    title: 'Ninety days of notice, in writing.',
    body: 'Any change to price or policy reaches you three months early, written by a person, with the old terms honoured until the day it lands.',
  },
];

const FILES = [
  { name: 'subscribers.csv', detail: '14,208 rows · email, name, signup_date, source, status, tags' },
  { name: 'posts/*.md', detail: '412 files · Markdown with front matter, footnotes and links preserved' },
  { name: 'posts/images/', detail: '1,904 files · original resolution, referenced by relative path' },
  { name: 'paid.csv', detail: '1,106 rows · stripe_customer_id, stripe_subscription_id, price, member_since' },
  { name: 'drafts/', detail: 'everything unpublished, same Markdown as the posts directory' },
  { name: 'manifest.json', detail: 'per-file checksums, schema version, export timestamp, row counts' },
];

const MIGRATIONS = [
  {
    platform: 'Substack',
    minutes: '11 min',
    note: 'Posts, subscribers, comments and paid tiers, with Stripe billing continuing on the same cards.',
  },
  {
    platform: 'beehiiv',
    minutes: '9 min',
    note: 'Segments and signup sources map across as tags. Automations are listed, not silently recreated.',
  },
  {
    platform: 'Mailchimp',
    minutes: '14 min',
    note: 'Campaign archive becomes posts. Merge fields become subscriber fields you can still read.',
  },
];

/* ── shared bits ──────────────────────────────────────────────────── */

const Eyebrow = ({ children, tone = C.grey }) => (
  <text size={12} weight={600} font={F.body} color={tone} ls={0.16} tw="uppercase">
    {children}
  </text>
);

const IndexLine = ({ n, label, href }) => (
  <box
    tag="div"
    cls="index-line"
    tw="flex flex-row items-end"
    gap={16}
    w="100%"
    pad={{ t: 11, b: 11 }}
    raw="border-top: 1px solid #E0E0DA;"
  >
    <text size={12} weight={600} font={F.body} color={C.quill} ls={0.1} w={28}>
      {n}
    </text>
    <text
      href={href}
      size={15}
      font={F.body}
      color={C.ink}
      lh={1.4}
      tw="no-underline hover:text-[#3B4A9E]"
    >
      {label}
    </text>
  </box>
);

/* ── page ─────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>

    {/* masthead ─ rule under a wordmark line */}
    <box tw="flex flex-col w-full items-center" pad={0} grad={[180, '#F4F4EF', C.ground]}>
      <box
        tw="flex flex-row items-center justify-between w-full"
        maxw={1160}
        gap={16}
        pad={{ t: 22, b: 22, l: 32, r: 32 }}
        raw="border-bottom: 1px solid #E0E0DA;"
        mobile={{ pad: { t: 16, b: 16, l: 20, r: 20 } }}
      >
        <text size={15} weight={700} font={F.head} color={C.ink} ls={0.14} tw="uppercase">
          Dispatchbox
        </text>
        <text size={12} weight={500} font={F.body} color={C.grey} ls={0.1} tw="uppercase">
          Newsletter publishing
        </text>
      </box>

      <grid
        cols={12}
        gapX={56}
        gapY={44}
        w="100%"
        maxw={1160}
        pad={{ t: 96, b: 104, l: 32, r: 32 }}
        mobile={{ pad: { t: 52, b: 56, l: 20, r: 20 }, gapY: 36 }}
      >
        <box span={7} tw="flex flex-col items-start" gap={26}
      mobile={{ span: 1 }}>
          <Eyebrow>Est. 2026 · Flat fee · Leave whenever</Eyebrow>
          <heading
            tag="h1"
            w="100%"
            size={68}
            weight={400}
            font={F.head}
            color={C.ink}
            lh={1.06}
            ls={-0.02}
            tablet={{ size: 52 }}
            mobile={{ size: 34 }}
          >
            Six promises, and the mechanism behind each one.
          </heading>
          <text
            size={18}
            font={F.body}
            color={C.grey}
            lh={1.7}
            maxw={560}
            mobile={{ size: 16 }}
          >
            Dispatchbox is a newsletter platform for writers who have been burned. Flat pricing, no
            growth network, no emails sent to your list that you did not write, and an export that
            actually restores somewhere else.
          </text>
          <box tw="flex flex-row items-center flex-wrap" gap={16} pad={{ t: 8 }}>
            <text
              href="#move"
              size={16}
              weight={600}
              font={F.body}
              color={C.ground}
              bg={C.ink}
              pad={{ t: 15, b: 15, l: 28, r: 28 }}
              tw="no-underline hover:bg-[#3B4A9E]"
            >
              Move your list
            </text>
            <text
              href="#export"
              size={15}
              font={F.body}
              color={C.ink}
              pad={{ t: 15, b: 15 }}
              tw="underline underline-offset-4 hover:text-[#3B4A9E]"
            >
              Read the export file first
            </text>
          </box>
        </box>

        {/* the index rail */}
        <box
          span={5}
          tw="flex flex-col"
          gap={0}
          pad={{ l: 32 }}
          raw="border-left: 1px solid #E0E0DA;"
          mobile={{ span: 1, pad: { l: 18, t: 4 } }}
          motion={{ effect: 'fade', trigger: 'scrollIn', duration: 700 }}
        >
          <text
            size={12}
            weight={600}
            font={F.body}
            color={C.grey}
            ls={0.16}
            tw="uppercase"
            pad={{ b: 14 }}
          >
            Index
          </text>
          {INDEX.map((it) => (
            <IndexLine n={it.n} label={it.label} href={it.href} />
          ))}
        </box>
      </grid>
    </box>

    {/* 01 ─ six promises */}
    <box
      id="promises"
      tw="flex flex-col w-full items-center"
      bg={C.ground}
      pad={SECTION}
      mobile={{ pad: SECTION_M }}
    >
      <box tw="flex flex-col w-full" maxw={1160} gap={0}>
        <grid cols={12} gapX={40} gapY={16} w="100%" pad={{ b: 40 }} mobile={{ pad: { b: 24 } }}>
          <box span={2} tw="flex flex-col"
      mobile={{ span: 1 }}>
            <Eyebrow tone={C.quill}>01</Eyebrow>
          </box>
          <box span={10} tw="flex flex-col" gap={16}
      mobile={{ span: 1 }}>
            <heading
              tag="h2"
              size={40}
              weight={400}
              font={F.head}
              color={C.ink}
              lh={1.15}
              maxw={720}
              mobile={{ size: 27 }}
            >
              The promises, indexed. Each one is a mechanism, not a sentiment.
            </heading>
            <text size={16} font={F.body} color={C.grey} lh={1.7} maxw={640} mobile={{ size: 15 }}>
              A promise you cannot verify is marketing. Every line below names the thing that would
              have to be built for us to break it, and it is not built.
            </text>
          </box>
        </grid>

        <box tw="flex flex-col w-full" gap={0} raw="border-bottom: 1px solid #E0E0DA;">
          {PROMISES.map((p) => (
            <PromiseRow numeral={p.numeral} title={p.title} body={p.body} />
          ))}
        </box>
      </box>
    </box>

    {/* 02 ─ the export file */}
    <box
      id="export"
      tw="flex flex-col w-full items-center"
      bg={C.ink}
      pad={SECTION}
      mobile={{ pad: SECTION_M }}
    >
      <grid
        cols={12}
        gapX={56}
        gapY={40}
        w="100%"
        maxw={1160}
        mobile={{ gapY: 28 }}
      >
        <box span={5} tw="flex flex-col items-start" gap={20}
      mobile={{ span: 1 }}>
          <Eyebrow tone={C.highlight}>02 · The export file</Eyebrow>
          <heading
            tag="h2"
            size={38}
            weight={400}
            font={F.head}
            color={C.ground}
            lh={1.15}
            mobile={{ size: 26 }}
          >
            One zip. Here is what is inside it, byte by byte.
          </heading>
          <text size={16} font={F.body} color="#A9A9A2" lh={1.75} mobile={{ size: 15 }}>
            No ticket, no waiting queue, no partial CSV with the paid records mysteriously missing.
            The button sits in your settings and works at three in the morning.
          </text>
          <text size={14} color={C.highlight} lh={1.7} tw="font-mono">
            dispatchbox-export-2026-08-13.zip · 214 MB
          </text>
        </box>

        <box
          span={7}
          tw="flex flex-col"
          gap={0}
          pad={{ t: 8, b: 8 }}
          raw="border-bottom: 1px solid rgba(224,224,218,0.18);"
          motion={{ effect: 'fade', trigger: 'scrollIn', duration: 700 }}
        
      mobile={{ span: 1 }}>
          {FILES.map((f) => (
            <FileRow name={f.name} detail={f.detail} />
          ))}
          <text size={14} font={F.body} color={C.grey} lh={1.7} pad={{ t: 18 }}>
            Checksums so you can prove the file is whole. Schema documented at the same URL for as
            long as we exist.
          </text>
        </box>
      </grid>
    </box>

    {/* 03 ─ no network */}
    <box
      id="network"
      tw="flex flex-col w-full items-center"
      bg={C.highlight}
      pad={SECTION}
      mobile={{ pad: SECTION_M }}
    >
      <box tw="flex flex-col w-full" maxw={1160} gap={44} mobile={{ gap: 28 }}>
        <box tw="flex flex-col" gap={18} maxw={760}>
          <Eyebrow tone={C.ink}>03 · No recommendation network</Eyebrow>
          <heading
            tag="h2"
            size={42}
            weight={400}
            font={F.head}
            color={C.ink}
            lh={1.12}
            mobile={{ size: 27 }}
          >
            Your list is not inventory for someone else's growth.
          </heading>
        </box>

        <grid cols={12} gapX={48} gapY={32} w="100%">
          <box
            span={6}
            tw="flex flex-col"
            gap={14}
            pad={{ t: 26, l: 26, r: 26, b: 26 }}
            raw="border: 1px solid rgba(25,25,25,0.22);"
          
      mobile={{ span: 1 }}>
            <text size={12} weight={600} font={F.body} color={C.ink} ls={0.14} tw="uppercase">
              What a growth network does
            </text>
            <text size={16} font={F.body} color={C.ink} lh={1.75} mobile={{ size: 15 }}>
              A subscriber who trusted you gets shown three other writers at the moment of signup.
              Your open rate becomes a currency someone else spends. When the network changes its
              ranking, your subscriber growth changes and nobody tells you why.
            </text>
          </box>
          <box
            span={6}
            tw="flex flex-col"
            gap={14}
            pad={{ t: 26, l: 26, r: 26, b: 26 }}
            bg={C.ink}
          
      mobile={{ span: 1 }}>
            <text size={12} weight={600} font={F.body} color={C.highlight} ls={0.14} tw="uppercase">
              What Dispatchbox does
            </text>
            <text size={16} font={F.body} color={C.ground} lh={1.75} mobile={{ size: 15 }}>
              Nothing. There is no cross-promotion surface, no paid placement, no onboarding step
              that offers your reader a list of alternatives. We have no product that would let us
              do it, and building one would be a rewrite of the sending layer.
            </text>
          </box>
        </grid>
      </box>
    </box>

    {/* 04 ─ deliverability */}
    <box
      id="deliverability"
      tw="flex flex-col w-full items-center"
      bg={C.ground}
      pad={SECTION}
      mobile={{ pad: SECTION_M }}
    >
      <grid cols={12} gapX={56} gapY={40} w="100%" maxw={1160}>
        <box span={7} tw="flex flex-col items-start" gap={20}
      mobile={{ span: 1 }}>
          <Eyebrow tone={C.quill}>04 · Deliverability</Eyebrow>
          <heading
            tag="h2"
            size={38}
            weight={400}
            font={F.head}
            color={C.ink}
            lh={1.15}
            mobile={{ size: 26 }}
          >
            Our IP policy, in the plainest words we have.
          </heading>
          <text size={17} font={F.body} color={C.grey} lh={1.75} maxw={620} mobile={{ size: 15 }}>
            Your newsletter sends from your own authenticated domain on a pool shared only with
            writers of similar volume and complaint rate. We publish our pool complaint rates
            monthly.
          </text>
          <text size={16} font={F.body} color={C.grey} lh={1.75} maxw={620} mobile={{ size: 15 }}>
            SPF, DKIM and DMARC are set up during import and checked before your first send. A list
            with a bad month is moved to its own pool rather than allowed to sit next to yours, and
            we will tell you if that list is you.
          </text>
        </box>

        <box
          span={5}
          tw="flex flex-col"
          gap={0}
          pad={26}
          bg={C.quillTint}
          raw="border-left: 3px solid #3B4A9E;"
          motion={{ effect: 'fade', trigger: 'scrollIn', duration: 700 }}
        
      mobile={{ span: 1 }}>
          <text size={12} weight={600} font={F.body} color={C.quill} ls={0.14} tw="uppercase" pad={{ b: 16 }}>
            Pool report · July 2026
          </text>
          <box tw="flex flex-row items-end justify-between" gap={12} pad={{ t: 12, b: 12 }} raw="border-top: 1px solid rgba(59,74,158,0.2);">
            <text size={15} font={F.body} color={C.ink} lh={1.5}>Complaint rate</text>
            <text size={22} font={F.head} color={C.quill} lh={1.2}>0.021%</text>
          </box>
          <box tw="flex flex-row items-end justify-between" gap={12} pad={{ t: 12, b: 12 }} raw="border-top: 1px solid rgba(59,74,158,0.2);">
            <text size={15} font={F.body} color={C.ink} lh={1.5}>Inbox placement</text>
            <text size={22} font={F.head} color={C.quill} lh={1.2}>98.4%</text>
          </box>
          <box tw="flex flex-row items-end justify-between" gap={12} pad={{ t: 12, b: 12 }} raw="border-top: 1px solid rgba(59,74,158,0.2);">
            <text size={15} font={F.body} color={C.ink} lh={1.5}>Bounce rate</text>
            <text size={22} font={F.head} color={C.quill} lh={1.2}>0.34%</text>
          </box>
          <box tw="flex flex-row items-end justify-between" gap={12} pad={{ t: 12, b: 12 }} raw="border-top: 1px solid rgba(59,74,158,0.2);">
            <text size={15} font={F.body} color={C.ink} lh={1.5}>Pools in operation</text>
            <text size={22} font={F.head} color={C.quill} lh={1.2}>14</text>
          </box>
          <text size={13} font={F.body} color={C.grey} lh={1.6} pad={{ t: 16 }}>
            Published on the first working day of every month, including the months it looks bad.
          </text>
        </box>
      </grid>
    </box>

    {/* 05 ─ take rate */}
    <box
      id="take-rate"
      tw="flex flex-col w-full items-center"
      bg={C.white}
      pad={SECTION}
      mobile={{ pad: SECTION_M }}
      raw="border-top: 1px solid #E0E0DA; border-bottom: 1px solid #E0E0DA;"
    >
      <grid cols={12} gapX={56} gapY={36} w="100%" maxw={1160}>
        <box span={5} tw="flex flex-col justify-center" gap={10} pad={36} bg={C.highlight}
      mobile={{ span: 1 }}>
          <text
            size={112}
            weight={400}
            font={F.head}
            color={C.ink}
            lh={0.92}
            ls={-0.03}
            tablet={{ size: 88 }}
            mobile={{ size: 68 }}
          >
            0%
          </text>
          <text size={16} weight={600} font={F.body} color={C.ink} lh={1.5}>
            of your paid subscriptions, taken by us
          </text>
        </box>

        <box span={7} tw="flex flex-col items-start" gap={18}
      mobile={{ span: 1 }}>
          <Eyebrow tone={C.quill}>05 · Paid subscriptions</Eyebrow>
          <heading
            tag="h2"
            size={38}
            weight={400}
            font={F.head}
            color={C.ink}
            lh={1.15}
            mobile={{ size: 26 }}
          >
            The actual take rate, and the bill it replaces.
          </heading>
          <text size={16} font={F.body} color={C.grey} lh={1.75} maxw={600} mobile={{ size: 15 }}>
            Payments run through your own Stripe account. Your subscribers' cards, your payout
            schedule, your customer records. Stripe takes its usual fee and we take none of it.
          </text>
          <box tw="flex flex-col w-full" gap={0} maxw={620}>
            <box tw="flex flex-row items-end justify-between" gap={16} pad={{ t: 14, b: 14 }} raw="border-top: 1px solid #E0E0DA;">
              <text size={16} font={F.body} color={C.ink} lh={1.5}>Up to 25,000 subscribers</text>
              <text size={20} font={F.head} color={C.ink} lh={1.3}>£19 / month</text>
            </box>
            <box tw="flex flex-row items-end justify-between" gap={16} pad={{ t: 14, b: 14 }} raw="border-top: 1px solid #E0E0DA;">
              <text size={16} font={F.body} color={C.ink} lh={1.5}>Above 25,000 subscribers</text>
              <text size={20} font={F.head} color={C.ink} lh={1.3}>£49 / month</text>
            </box>
            <box tw="flex flex-row items-end justify-between" gap={16} pad={{ t: 14, b: 14 }} raw="border-top: 1px solid #E0E0DA; border-bottom: 1px solid #E0E0DA;">
              <text size={16} font={F.body} color={C.grey} lh={1.5}>Percentage of revenue, at any tier</text>
              <text size={20} font={F.head} color={C.quill} lh={1.3}>None</text>
            </box>
          </box>
          <text size={15} font={F.body} color={C.grey} lh={1.7} maxw={600}>
            A writer billing £4,000 a month in subscriptions pays us £49. On a ten percent platform
            that same writer pays £400, every month, forever, for the same sending.
          </text>
        </box>
      </grid>
    </box>

    {/* 06 ─ migration */}
    <box
      id="migration"
      tw="flex flex-col w-full items-center"
      bg={C.ground}
      pad={SECTION}
      mobile={{ pad: SECTION_M }}
    >
      <box tw="flex flex-col w-full" maxw={1160} gap={40} mobile={{ gap: 26 }}>
        <grid cols={12} gapX={48} gapY={18} w="100%">
          <box span={6} tw="flex flex-col" gap={18}
      mobile={{ span: 1 }}>
            <Eyebrow tone={C.quill}>06 · Migration</Eyebrow>
            <heading
              tag="h2"
              size={38}
              weight={400}
              font={F.head}
              color={C.ink}
              lh={1.15}
              mobile={{ size: 26 }}
            >
              Eleven minutes, and a dry run you can read first.
            </heading>
          </box>
          <box span={6} tw="flex flex-col justify-end" gap={12}
      mobile={{ span: 1 }}>
            <text size={16} font={F.body} color={C.grey} lh={1.75} mobile={{ size: 15 }}>
              Import from the three big platforms in about eleven minutes, including paid
              subscribers and their Stripe billing, with a dry run you can inspect before anything
              moves. Nothing sends, nothing charges, nothing is deleted anywhere else.
            </text>
          </box>
        </grid>

        <grid cols={12} gapX={24} gapY={24} w="100%">
          {MIGRATIONS.map((m) => (
            <MigrationCard platform={m.platform} minutes={m.minutes} note={m.note} />
          ))}
        </grid>
      </box>
    </box>

    {/* 07 ─ what we are bad at */}
    <box
      id="bad-at"
      tw="flex flex-col w-full items-center"
      grad={[180, C.ground, '#F1F1EC']}
      pad={SECTION}
      mobile={{ pad: SECTION_M }}
    >
      <grid cols={12} gapX={56} gapY={32} w="100%" maxw={1160}>
        <box span={4} tw="flex flex-col" gap={16}
      mobile={{ span: 1 }}>
          <Eyebrow tone={C.quill}>07 · What we are bad at</Eyebrow>
          <heading
            tag="h2"
            size={36}
            weight={400}
            font={F.head}
            color={C.ink}
            lh={1.15}
            mobile={{ size: 25 }}
          >
            The list of things we will disappoint you about.
          </heading>
        </box>
        <box
          span={8}
          tw="flex flex-col"
          gap={22}
          pad={34}
          raw="border: 2px solid #191919;"
          motion={{ effect: 'fade', trigger: 'scrollIn', duration: 700 }}
        
      mobile={{ span: 1 }}>
          <text size={20} font={F.head} color={C.ink} lh={1.55} mobile={{ size: 17 }}>
            We are bad at: landing page design, native video, and anything resembling a CRM. If you
            need a funnel, we are the wrong tool and we would rather tell you now.
          </text>
          <text size={16} font={F.body} color={C.grey} lh={1.75} mobile={{ size: 15 }}>
            There is no lead scoring, no drip sequence builder, no behavioural trigger that emails a
            reader because of something they did not do. Several of those are on the list of things
            we will not build, which is the same list as promise I.
          </text>
        </box>
      </grid>
    </box>

    {/* 08 ─ move your list */}
    <box
      id="move"
      tw="flex flex-col w-full items-center"
      grad={[160, C.ink, '#232A4A']}
      pad={{ t: 116, b: 96, l: 32, r: 32 }}
      mobile={{ pad: { t: 64, b: 56, l: 20, r: 20 } }}
    >
      <box tw="flex flex-col w-full" maxw={1160} gap={34} mobile={{ gap: 24 }}>
        <grid cols={12} gapX={56} gapY={28} w="100%">
          <box span={7} tw="flex flex-col items-start" gap={22}
      mobile={{ span: 1 }}>
            <Eyebrow tone={C.highlight}>08 · Move your list</Eyebrow>
            <heading
              tag="h2"
              size={52}
              weight={400}
              font={F.head}
              color={C.ground}
              lh={1.08}
              ls={-0.02}
              tablet={{ size: 42 }}
              mobile={{ size: 30 }}
            >
              Bring it over. Leave with all of it whenever you like.
            </heading>
            <text
              href="#promises"
              size={16}
              weight={600}
              font={F.body}
              color={C.ink}
              bg={C.highlight}
              pad={{ t: 16, b: 16, l: 30, r: 30 }}
              tw="no-underline hover:bg-[#FBFBF9]"
            >
              Move your list
            </text>
          </box>
          <box span={5} tw="flex flex-col justify-end" gap={14}
      mobile={{ span: 1 }}>
            <text size={16} font={F.body} color="#B9B9B2" lh={1.75} mobile={{ size: 15 }}>
              Import runs as a dry run first. The export button is live from the first minute of the
              trial, before you have paid us anything, because a promise you can only test on the
              way out is not a promise.
            </text>
            <text size={14} font={F.body} color={C.grey} lh={1.7}>
              £19 a month · 14 day trial · no percentage, ever
            </text>
          </box>
        </grid>

        <box
          tw="flex flex-row items-center justify-between flex-wrap"
          gap={14}
          w="100%"
          pad={{ t: 26 }}
          raw="border-top: 1px solid rgba(224,224,218,0.18);"
        >
          <text size={13} weight={700} font={F.head} color={C.ground} ls={0.14} tw="uppercase">
            Dispatchbox
          </text>
          <text size={13} font={F.body} color={C.grey} lh={1.6}>
            Six promises, and the mechanism behind each one.
          </text>
        </box>
      </box>
    </box>
  </box>
);
