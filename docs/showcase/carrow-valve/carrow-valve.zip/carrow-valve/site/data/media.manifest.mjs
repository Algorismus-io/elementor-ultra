/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "carrow-valve--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'carrow-valve--';

export default [
  { slot: `${PREFIX}forge_floor`, file: join(MEDIA_DIR, "forge_floor.jpg"), alt: "Forge floor at the Carrow Valve Works in Sheffield" },
  { slot: `${PREFIX}test_bay`, file: join(MEDIA_DIR, "test_bay.jpg"), alt: "Hydrostatic test bay with a valve under witnessed test" },
  { slot: `${PREFIX}valve_machined`, file: join(MEDIA_DIR, "valve_machined.jpg"), alt: "Machined forged valve body on the inspection bench" },
];
