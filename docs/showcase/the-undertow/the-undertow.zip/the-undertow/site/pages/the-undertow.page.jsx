/** The Undertow — editorial index rail. */
import { MEDIA } from '../data/media.mjs';

export const meta = {
  title: 'The Undertow',
  slug: 'the-undertow',
  seo: {
    title: 'The Undertow — six investigations a year, funded by members',
    description:
      'The Undertow publishes six long investigations a year, funded entirely by 11,400 members. No advertising, no proprietor, no sponsored anything.',
  },
};

/* ── data ─────────────────────────────────────────────────────────────── */

const INDEX = [
  ['14.03.26', 'THE QUOTA THAT WASN’T', 'Fisheries', 'Elena Mbeki', '11 months'],
  ['22.01.26', 'NINETEEN DOORS', 'Housing', 'Ravi Sandhu', '13 months'],
  ['03.11.25', 'THE LONG WARD', 'Health', 'Nora Faulkner', '9 months'],
  ['18.08.25', 'PAPER RIVERS', 'Environment', 'Tomas Beck', '14 months'],
  ['09.06.25', 'WHAT THE INSPECTOR SAW', 'Care homes', 'Nora Faulkner', '10 months'],
  ['27.03.25', 'A SMALL FIRE IN BOOTLE', 'Fire safety', 'Ravi Sandhu', '12 months'],
  ['11.12.24', 'THE SUBCONTRACTED BORDER', 'Immigration', 'Yusuf Adeyemi', '15 months'],
  ['02.09.24', 'THIRTY-ONE ACCOUNTS', 'Finance', 'Elena Mbeki', '12 months'],
  ['20.05.24', 'THE GRAVEL LICENCE', 'Planning', 'Tomas Beck', '8 months'],
  ['08.02.24', 'NOBODY’S PENSION', 'Labour', 'Yusuf Adeyemi', '16 months'],
  ['15.10.23', 'THE SILENT REGISTER', 'Policing', 'Nora Faulkner', '11 months'],
  ['30.06.23', 'COLD WATER, WARM WORDS', 'Utilities', 'Ravi Sandhu', '10 months'],
];

const COSTS = [
  ['Reporter time, nine to fourteen months', '£34,000', 'One reporter, sometimes two, off everything else.'],
  ['Legal review, pre-publication', '£22,000', 'Read line by line before anyone else sees a word.'],
  ['Documents, FOI and court fees', '£6,400', '240 pages on the current piece. We paid for all of them.'],
  ['Travel, fixers and lodging', '£5,200', 'Eleven families do not live in one place.'],
  ['Fact-checking, independent second pass', '£4,800', 'A checker who did not write it and is paid to disagree.'],
  ['Translation and transcription', '£2,600', 'Ninety hours of tape, typed by humans.'],
];

const OWNS = [
  ['The Undertow Trust', 'Holds the title. A locked purpose clause: it cannot be sold, merged or floated.'],
  ['11,400 members', 'One vote each. Nobody gets two, including the editor.'],
  ['The reporters', 'Copyright reverts to them after five years. Always has.'],
];

const NOT_OWNS = [
  ['No advertiser', 'We have never sold a page, a slot or a newsletter line.'],
  ['No proprietor', 'There is no owner to ring on a Sunday night.'],
  ['No venture fund', 'No growth round, so no growth reason to publish faster.'],
  ['No party, no state', 'We take nothing from either, and we publish what we are offered.'],
];

const LETTERS = [
  [
    'I disagreed with almost everything in the fisheries piece and I renewed anyway, because you printed the reply from the man you accused, in full, on the same page.',
    'R.H., Aberdeen',
    'Renewed February 2026',
  ],
  [
    'I read the housing piece on a Tuesday and by Friday my landlord had a letter from the council. I do not think those two things are related. I have decided to believe they are.',
    'M.O., Salford',
    'Member since 2023',
  ],
  [
    'Cancel my membership. Then, twelve days later, put it back. I was wrong about the pension piece. You were slower than I wanted and righter than I expected.',
    'J.T., Belfast',
    'Both emails printed, unedited',
  ],
];

const TIERS = [
  ['REDUCED', '£3', 'a month', 'Students and anyone out of work. We do not ask for proof and we never will.', ['The full archive, six years deep', 'Every document set we can legally publish', 'The monthly reporting note'], false],
  ['MEMBER', '£8', 'a month, or £80 a year', 'The rate that pays for the work. 11,400 people are on it.', ['Everything in Reduced', 'The costings ledger for every piece', 'Reporters’ open calls, four a year', 'Print edition of each investigation'], true],
  ['PATRON', '£25', 'a month', 'Funds one investigation’s legal review each year. That is the line that kills stories.', ['Everything in Member', 'Named in the annual ledger, if you want it', 'The unpublished-story list, twice a year'], false],
];

/* ── shared bits ──────────────────────────────────────────────────────── */

const Rule = ({ theme: t, c }) => <div w="100%" h={1} bg={c || t.color.rule} />;

const Eyebrow = ({ theme: t, children, c }) => (
  <text tag="span" size={11} weight={600} ls="2.4px" font={t.font.body} color={c || t.color.red} w="100%">
    {children}
  </text>
);

/* ── registered repeaters (content props only) ────────────────────────── */

const IndexRow = defineComponent(
  ({ date, title, desk, byline, span }) => (
    <box w="100%" pad={0} bg="transparent">
      <div w="100%" h={1} bg="#D8D4CC" />
      <grid
        cols="94px 1fr 150px"
        gap={16}
        w="100%"
        pad={{ t: 18, b: 18 }}
        align="flex-end"
        mobile={{ gridCols: 1, gap: 6, pad: { t: 14, b: 14 } }}
        hover={{ bg: '#EFEBE3' }}
      >
        <text size={12} weight={600} ls="1.2px" font="Spectral" color="#6F6C66" w="100%">
          {date}
        </text>
        <div tw="flex flex-col gap-1" w="100%" pad={0} bg="transparent">
          <heading tag="h3" size={22} weight={500} lh={1.25} font="Playfair Display" color="#111111" w="100%" mobile={{ size: 19 }}>
            {title}
          </heading>
          <text size={13} lh={1.5} font="Spectral" color="#6F6C66" w="100%">
            {byline}
          </text>
        </div>
        <div tw="flex flex-col gap-1" w="100%" pad={0} bg="transparent" ta="right" mobile={{ ta: 'left' }}>
          <text size={11} weight={600} ls="1.6px" font="Spectral" color="#B3121D" w="100%" ta="right" mobile={{ ta: 'left' }}>
            {desk}
          </text>
          <text size={12} font="Spectral" color="#6F6C66" w="100%" ta="right" mobile={{ ta: 'left' }}>
            {span}
          </text>
        </div>
      </grid>
    </box>
  ),
  {
    title: 'Undertow Index Row',
    props: {
      date: { label: 'Date', group: 'Entry' },
      title: { label: 'Headline', group: 'Entry' },
      desk: { label: 'Desk', group: 'Meta' },
      byline: { label: 'Byline', group: 'Meta' },
      span: { label: 'Reporting span', group: 'Meta' },
    },
  },
);

const CostRow = defineComponent(
  ({ item, amount, note }) => (
    <box w="100%" pad={0} bg="transparent">
      <div w="100%" h={1} bg="#333029" />
      <grid cols="1fr 120px" gap={16} w="100%" pad={{ t: 16, b: 16 }} align="flex-end" mobile={{ gridCols: 1, gap: 4 }}>
        <div tw="flex flex-col gap-1" w="100%" pad={0} bg="transparent">
          <text size={16} lh={1.4} font="Spectral" color="#F7F5F0" w="100%">
            {item}
          </text>
          <text size={13} lh={1.5} font="Spectral" color="#9C9890" w="100%">
            {note}
          </text>
        </div>
        <text size={19} weight={600} font="Playfair Display" color="#F7F5F0" w="100%" ta="right" mobile={{ ta: 'left', size: 17 }}>
          {amount}
        </text>
      </grid>
    </box>
  ),
  {
    title: 'Undertow Cost Row',
    props: {
      item: { label: 'Line item', group: 'Cost' },
      amount: { label: 'Amount', group: 'Cost' },
      note: { label: 'Note', group: 'Cost' },
    },
  },
);

const Letter = defineComponent(
  ({ body, signature, meta: metaLine }) => (
    <div tw="flex flex-col gap-5" w="100%" h="100%" pad={{ t: 28, r: 26, b: 28, l: 26 }} bg="#F7F5F0" border={[1, '#D8D4CC']}>
      <text size={30} weight={700} lh={1} font="Playfair Display" color="#B3121D" w="hug">
        “
      </text>
      <text size={17} lh={1.7} font="Spectral" color="#111111" w="100%" flex={1}>
        {body}
      </text>
      <div w="100%" h={1} bg="#D8D4CC" />
      <div tw="flex flex-col gap-1" w="100%" pad={0} bg="transparent">
        <text size={13} weight={600} ls="0.8px" font="Spectral" color="#111111" w="100%">
          {signature}
        </text>
        <text size={12} font="Spectral" color="#6F6C66" w="100%">
          {metaLine}
        </text>
      </div>
    </div>
  ),
  {
    title: 'Undertow Reader Letter',
    props: {
      body: { label: 'Letter', group: 'Letter' },
      signature: { label: 'Signature', group: 'Attribution' },
      meta: { label: 'Note', group: 'Attribution' },
    },
  },
);

/* ── page ─────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => {
  const Wrap = ({ children, ...p }) => (
    <div tw="flex flex-col w-full" maxw={1100} m={{ l: 'auto', r: 'auto' }} pad={0} bg="transparent" {...p}>
      {children}
    </div>
  );

  return (
    <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>
      {/* ── 1. Masthead + current investigation ───────────────────────── */}
      <section w="100%" pad={0} bg={t.color.ground} tw="flex flex-col">
        <div w="100%" pad={{ t: 20, r: 32, b: 20, l: 32 }} bg={t.color.ink} tw="flex flex-col" mobile={{ pad: { t: 16, r: 20, b: 16, l: 20 } }}>
          <Wrap>
            <grid cols="1fr auto" gap={20} w="100%" align="center" mobile={{ gridCols: 1, gap: 8 }}>
              <text size={13} weight={600} ls="3.6px" font={t.font.body} color={t.color.ground} w="100%">
                THE UNDERTOW
              </text>
              <text size={12} ls="0.6px" font={t.font.body} color="#9C9890" w="100%" ta="right" mobile={{ ta: 'left' }}>
                Issue 34 · Six investigations a year · Member-funded since 2020
              </text>
            </grid>
          </Wrap>
        </div>

        <div w="100%" pad={{ t: 88, r: 32, b: 0, l: 32 }} tw="flex flex-col" bg="transparent" mobile={{ pad: { t: 48, r: 20, b: 0, l: 20 } }}>
          <Wrap>
            <grid cols="1.15fr 0.85fr" gap={64} w="100%" mobile={{ gridCols: 1, gap: 40 }} tablet={{ gap: 40 }}>
              <div tw="flex flex-col gap-7" w="100%" pad={0} bg="transparent" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
                <Eyebrow theme={t}>INVESTIGATIVE MAGAZINE · EST. 2020</Eyebrow>
                <h1 size={72} weight={500} lh={1.04} ls="-1.2px" font={t.font.head} color={t.color.ink} w="100%" tablet={{ size: 54 }} mobile={{ size: 38, lh: 1.08 }}>
                  Six stories a year. Each one took a year.
                </h1>
                <text size={19} lh={1.7} font={t.font.body} color={t.color.grey} w="100%" maxw={560} mobile={{ size: 17 }}>
                  The Undertow is funded by 11,400 members and nobody else. No advertising, no proprietor, no sponsored anything. We publish when the reporting is done, which is sometimes fourteen months late.
                </text>
                <div tw="flex flex-row gap-4 items-center" w="100%" pad={{ t: 8 }} bg="transparent" wrap="wrap">
                  <text
                    tag="span"
                    href="#membership"
                    size={15}
                    weight={600}
                    ls="0.6px"
                    font={t.font.body}
                    color={t.color.ground}
                    bg={t.color.red}
                    pad={{ t: 16, r: 34, b: 16, l: 34 }}
                    w="hug"
                    ta="center"
                    hover={{ bg: t.color.ink }}
                  >
                    Become a member
                  </text>
                  <text tag="span" href="#index" size={15} weight={500} font={t.font.body} color={t.color.ink} pad={{ t: 16, r: 8, b: 16, l: 8 }} w="hug" hover={{ color: t.color.red }}>
                    Read the index
                  </text>
                </div>
              </div>

              <div tw="flex flex-col gap-0" w="100%" pad={0} bg="transparent">
                <img src={MEDIA.documents.id} w="100%" h={300} fit="cover" tablet={{ h: 240 }} mobile={{ h: 210 }} />
                <div tw="flex flex-col gap-4" w="100%" pad={{ t: 26, r: 26, b: 26, l: 26 }} bg={t.color.ink}>
                  <Eyebrow theme={t} c="#E8A2A7">PUBLISHED THURSDAY · CURRENT</Eyebrow>
                  <heading tag="h2" size={27} weight={500} lh={1.22} font={t.font.head} color={t.color.ground} w="100%" mobile={{ size: 23 }}>
                    The Dry County
                  </heading>
                  <text size={15} lh={1.65} font={t.font.body} color="#B9B5AD" w="100%">
                    How a water utility sold the same aquifer twice, and the eleven families who noticed. Eight months of reporting, 240 pages of documents, published Thursday.
                  </text>
                  <div w="100%" h={1} bg="#333029" />
                  <grid cols={3} gap={12} w="100%">
                    <div tw="flex flex-col gap-1" w="100%" pad={0} bg="transparent">
                      <text size={20} weight={600} font={t.font.head} color={t.color.ground} w="100%">8</text>
                      <text size={11} ls="0.8px" font={t.font.body} color="#8F8B83" w="100%">MONTHS</text>
                    </div>
                    <div tw="flex flex-col gap-1" w="100%" pad={0} bg="transparent">
                      <text size={20} weight={600} font={t.font.head} color={t.color.ground} w="100%">240</text>
                      <text size={11} ls="0.8px" font={t.font.body} color="#8F8B83" w="100%">DOCUMENTS</text>
                    </div>
                    <div tw="flex flex-col gap-1" w="100%" pad={0} bg="transparent">
                      <text size={20} weight={600} font={t.font.head} color={t.color.ground} w="100%">11</text>
                      <text size={11} ls="0.8px" font={t.font.body} color="#8F8B83" w="100%">FAMILIES</text>
                    </div>
                  </grid>
                </div>
              </div>
            </grid>
          </Wrap>
        </div>
      </section>

      {/* ── 2. Index of the last twelve pieces ────────────────────────── */}
      <section id="index" w="100%" pad={{ t: 96, r: 32, b: 96, l: 32 }} bg={t.color.ground} tw="flex flex-col" mobile={{ pad: { t: 56, r: 20, b: 56, l: 20 } }}>
        <Wrap>
          <grid cols="0.42fr 1fr" gap={56} w="100%" mobile={{ gridCols: 1, gap: 28 }} tablet={{ gap: 32 }}>
            <div tw="flex flex-col gap-4" w="100%" pad={0} bg="transparent">
              <Eyebrow theme={t}>THE INDEX</Eyebrow>
              <heading tag="h2" size={40} weight={500} lh={1.14} ls="-0.6px" font={t.font.head} color={t.color.ink} w="100%" mobile={{ size: 30 }}>
                The last twelve pieces
              </heading>
              <text size={16} lh={1.7} font={t.font.body} color={t.color.grey} w="100%">
                Two years of work, in order. Every one of them is still online, with its documents, its costings and its corrections attached.
              </text>
            </div>

            <div tw="flex flex-col" w="100%" pad={0} bg="transparent" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              {INDEX.map(([date, title, desk, byline, span]) => (
                <IndexRow date={date} title={title} desk={desk} byline={`By ${byline}`} span={span} />
              ))}
              <Rule theme={t} c={t.color.ink} />
              <text size={13} ls="0.6px" font={t.font.body} color={t.color.grey} w="100%" pad={{ t: 16 }}>
                Members read the full archive, six years deep, including the pieces that were killed by legal and the notes explaining why.
              </text>
            </div>
          </grid>
        </Wrap>
      </section>

      {/* ── 3. What a year-long investigation costs ───────────────────── */}
      <section w="100%" pad={{ t: 96, r: 32, b: 96, l: 32 }} bg={t.color.ink} tw="flex flex-col" mobile={{ pad: { t: 56, r: 20, b: 56, l: 20 } }}>
        <Wrap>
          <grid cols="0.85fr 1.15fr" gap={56} w="100%" mobile={{ gridCols: 1, gap: 36 }} tablet={{ gap: 36 }}>
            <div tw="flex flex-col gap-6" w="100%" pad={0} bg="transparent">
              <Eyebrow theme={t} c="#E8A2A7">THE COSTINGS</Eyebrow>
              <heading tag="h2" size={40} weight={500} lh={1.14} ls="-0.6px" font={t.font.head} color={t.color.ground} w="100%" mobile={{ size: 30 }}>
                What a year of reporting actually costs
              </heading>
              <text size={17} lh={1.7} font={t.font.body} color="#B9B5AD" w="100%">
                A full investigation costs us between 60,000 and 90,000. Roughly a third of that is legal review. We publish that breakdown for every piece.
              </text>
              <img src={MEDIA.reporter_field.id} w="100%" h={260} fit="cover" mobile={{ h: 200 }} />
            </div>

            <div tw="flex flex-col" w="100%" pad={0} bg="transparent" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              {COSTS.map(([item, amount, note]) => (
                <CostRow item={item} amount={amount} note={note} />
              ))}
              <Rule theme={t} c={t.color.red} />
              <grid cols="1fr 120px" gap={16} w="100%" pad={{ t: 18 }} align="flex-end" mobile={{ gridCols: 1, gap: 4 }}>
                <text size={15} weight={600} ls="1.4px" font={t.font.body} color={t.color.ground} w="100%">
                  TYPICAL TOTAL, ONE INVESTIGATION
                </text>
                <text size={26} weight={600} font={t.font.head} color={t.color.red} w="100%" ta="right" mobile={{ ta: 'left' }}>
                  £75,000
                </text>
              </grid>
              <text size={13} lh={1.6} font={t.font.body} color="#8F8B83" w="100%" pad={{ t: 12 }}>
                Six pieces a year. 11,400 members. The arithmetic is not comfortable, which is why we print it.
              </text>
            </div>
          </grid>
        </Wrap>
      </section>

      {/* ── 4. Corrections ────────────────────────────────────────────── */}
      <section w="100%" pad={{ t: 72, r: 32, b: 72, l: 32 }} bg={t.color.ground} tw="flex flex-col" mobile={{ pad: { t: 48, r: 20, b: 48, l: 20 } }}>
        <Wrap>
          <div tw="flex flex-row" w="100%" pad={0} bg="#EFEBE3" mobile={{ dir: 'column' }}>
            <div w={6} h="auto" bg={t.color.red} mobile={{ w: '100%', h: 6 }} pad={0} />
            <grid cols="1fr auto" gap={40} w="100%" pad={{ t: 40, r: 40, b: 40, l: 40 }} align="center" mobile={{ gridCols: 1, gap: 24, pad: { t: 28, r: 22, b: 28, l: 22 } }}>
              <div tw="flex flex-col gap-4" w="100%" pad={0} bg="transparent">
                <Eyebrow theme={t}>CORRECTIONS · 23 SINCE 2020</Eyebrow>
                <heading tag="h2" size={32} weight={500} lh={1.2} font={t.font.head} color={t.color.ink} w="100%" mobile={{ size: 25 }}>
                  Everything we got wrong is still here
                </heading>
                <text size={17} lh={1.7} font={t.font.body} color={t.color.grey} w="100%" maxw={640}>
                  We have issued 23 corrections in six years and every one is still on the site with the original text struck through, not deleted.
                </text>
              </div>
              <text
                tag="span"
                href="#corrections-ledger"
                size={15}
                weight={600}
                ls="0.6px"
                font={t.font.body}
                color={t.color.ink}
                bg="transparent"
                border={[1, t.color.ink]}
                pad={{ t: 15, r: 30, b: 15, l: 30 }}
                w="hug"
                ta="center"
                hover={{ bg: t.color.ink, color: t.color.ground }}
              >
                Read the corrections page
              </text>
            </grid>
          </div>
        </Wrap>
      </section>

      {/* ── 5. Who owns us and who does not ───────────────────────────── */}
      <section id="corrections-ledger" w="100%" pad={{ t: 80, r: 32, b: 96, l: 32 }} bg={t.color.ground} tw="flex flex-col" mobile={{ pad: { t: 48, r: 20, b: 56, l: 20 } }}>
        <Wrap>
          <div tw="flex flex-col gap-4" w="100%" pad={{ b: 44 }} bg="transparent" maxw={720} mobile={{ pad: { b: 30 } }}>
            <Eyebrow theme={t}>OWNERSHIP</Eyebrow>
            <heading tag="h2" size={40} weight={500} lh={1.14} ls="-0.6px" font={t.font.head} color={t.color.ink} w="100%" mobile={{ size: 30 }}>
              Who owns us, and who does not
            </heading>
            <text size={17} lh={1.7} font={t.font.body} color={t.color.grey} w="100%">
              The Undertow is owned by a trust with a locked purpose clause. It cannot be sold, and no member owns more than one vote.
            </text>
          </div>

          <grid cols={2} gap={0} w="100%" mobile={{ gridCols: 1 }}>
            <div tw="flex flex-col gap-0" w="100%" pad={{ t: 0, r: 44, b: 0, l: 0 }} bg="transparent" border={[1, t.color.rule]} mobile={{ pad: { t: 0, r: 0, b: 0, l: 0 } }}>
              <div tw="flex flex-col gap-2" w="100%" pad={{ t: 26, r: 26, b: 22, l: 26 }} bg="transparent">
                <text size={12} weight={600} ls="2.2px" font={t.font.body} color={t.color.ink} w="100%">
                  WHO OWNS US
                </text>
              </div>
              {OWNS.map(([label, body]) => (
                <div tw="flex flex-col gap-2" w="100%" pad={{ t: 22, r: 26, b: 22, l: 26 }} bg="transparent">
                  <div w="100%" h={1} bg={t.color.rule} m={{ b: 14 }} />
                  <heading tag="h3" size={21} weight={500} lh={1.3} font={t.font.head} color={t.color.ink} w="100%">
                    {label}
                  </heading>
                  <text size={15} lh={1.65} font={t.font.body} color={t.color.grey} w="100%">
                    {body}
                  </text>
                </div>
              ))}
            </div>

            <div tw="flex flex-col gap-0" w="100%" pad={0} bg={t.color.ink}>
              <div tw="flex flex-col gap-2" w="100%" pad={{ t: 26, r: 26, b: 22, l: 26 }} bg="transparent">
                <text size={12} weight={600} ls="2.2px" font={t.font.body} color="#E8A2A7" w="100%">
                  WHO DOES NOT
                </text>
              </div>
              {NOT_OWNS.map(([label, body]) => (
                <div tw="flex flex-col gap-2" w="100%" pad={{ t: 22, r: 26, b: 22, l: 26 }} bg="transparent">
                  <div w="100%" h={1} bg="#333029" m={{ b: 14 }} />
                  <heading tag="h3" size={21} weight={500} lh={1.3} font={t.font.head} color={t.color.ground} w="100%">
                    {label}
                  </heading>
                  <text size={15} lh={1.65} font={t.font.body} color="#9C9890" w="100%">
                    {body}
                  </text>
                </div>
              ))}
            </div>
          </grid>
        </Wrap>
      </section>

      {/* ── 6. Three reader letters, unedited ─────────────────────────── */}
      <section w="100%" pad={{ t: 88, r: 32, b: 88, l: 32 }} bg={t.color.white} tw="flex flex-col" mobile={{ pad: { t: 52, r: 20, b: 52, l: 20 } }}>
        <Wrap>
          <grid cols="1fr auto" gap={32} w="100%" pad={{ b: 40 }} align="end" mobile={{ gridCols: 1, gap: 12, pad: { b: 28 } }}>
            <div tw="flex flex-col gap-4" w="100%" pad={0} bg="transparent">
              <Eyebrow theme={t}>LETTERS</Eyebrow>
              <heading tag="h2" size={40} weight={500} lh={1.14} ls="-0.6px" font={t.font.head} color={t.color.ink} w="100%" mobile={{ size: 30 }}>
                Three readers, unedited
              </heading>
            </div>
            <text size={14} lh={1.6} font={t.font.body} color={t.color.grey} w="100%" maxw={300} ta="right" mobile={{ ta: 'left', maxw: 520 }}>
              Printed as received, including the punctuation and the parts that sting.
            </text>
          </grid>
          <Rule theme={t} c={t.color.ink} />
          <grid cols={3} gap={24} w="100%" pad={{ t: 40 }} tablet={{ gridCols: 1 }} mobile={{ gridCols: 1, gap: 18, pad: { t: 28 } }} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            {LETTERS.map(([body, signature, note]) => (
              <Letter body={body} signature={signature} meta={note} />
            ))}
          </grid>
        </Wrap>
      </section>

      {/* ── 7. Membership tiers ───────────────────────────────────────── */}
      <section id="membership" w="100%" pad={{ t: 96, r: 32, b: 96, l: 32 }} bg={t.color.ground} tw="flex flex-col" mobile={{ pad: { t: 56, r: 20, b: 56, l: 20 } }}>
        <Wrap>
          <div tw="flex flex-col gap-4" w="100%" pad={{ b: 44 }} bg="transparent" maxw={700} mobile={{ pad: { b: 30 } }}>
            <Eyebrow theme={t}>MEMBERSHIP</Eyebrow>
            <heading tag="h2" size={40} weight={500} lh={1.14} ls="-0.6px" font={t.font.head} color={t.color.ink} w="100%" mobile={{ size: 30 }}>
              £8 a month, or £80 a year
            </heading>
            <text size={17} lh={1.7} font={t.font.body} color={t.color.grey} w="100%">
              Students and anyone out of work pay £3 and we do not ask for proof. Membership is the only ask on this page, because it is the only income we have.
            </text>
          </div>

          <grid cols={3} gap={0} w="100%" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
            {TIERS.map(([name, price, cadence, blurb, perks, featured]) => (
              <div
                tw="flex flex-col gap-5"
                w="100%"
                h="100%"
                pad={{ t: 34, r: 30, b: 34, l: 30 }}
                bg={featured ? t.color.ink : 'transparent'}
                border={[1, featured ? t.color.ink : t.color.rule]}
              >
                <text size={12} weight={600} ls="2.4px" font={t.font.body} color={featured ? '#E8A2A7' : t.color.red} w="100%">
                  {name}
                </text>
                <div tw="flex flex-row gap-2 items-end" w="100%" pad={0} bg="transparent" wrap="wrap">
                  <text tag="span" size={46} weight={500} lh={1} font={t.font.head} color={featured ? t.color.ground : t.color.ink} w="hug" mobile={{ size: 38 }}>
                    {price}
                  </text>
                  <text tag="span" size={14} font={t.font.body} color={featured ? '#9C9890' : t.color.grey} w="hug">
                    {cadence}
                  </text>
                </div>
                <text size={15} lh={1.65} font={t.font.body} color={featured ? '#B9B5AD' : t.color.grey} w="100%">
                  {blurb}
                </text>
                <div w="100%" h={1} bg={featured ? '#333029' : t.color.rule} />
                <div tw="flex flex-col gap-3" w="100%" pad={0} bg="transparent" flex={1}>
                  {perks.map((perk) => (
                    <grid cols="14px 1fr" gap={10} w="100%" align="start">
                      <text size={14} lh={1.6} font={t.font.body} color={t.color.red} w="100%">
                        —
                      </text>
                      <text size={14} lh={1.6} font={t.font.body} color={featured ? '#D6D2CA' : t.color.ink} w="100%">
                        {perk}
                      </text>
                    </grid>
                  ))}
                </div>
                <text
                  tag="span"
                  href="#join"
                  size={14}
                  weight={600}
                  ls="0.6px"
                  font={t.font.body}
                  color={featured ? t.color.ink : t.color.ground}
                  bg={featured ? t.color.ground : t.color.ink}
                  pad={{ t: 14, r: 26, b: 14, l: 26 }}
                  w="100%"
                  ta="center"
                  hover={{ bg: t.color.red, color: t.color.ground }}
                >
                  Become a member
                </text>
              </div>
            ))}
          </grid>
        </Wrap>
      </section>

      {/* ── 8. Sign up and read the archive ───────────────────────────── */}
      <section id="join" w="100%" pad={{ t: 104, r: 32, b: 104, l: 32 }} bg={t.color.ink} tw="flex flex-col items-center" mobile={{ pad: { t: 64, r: 20, b: 64, l: 20 } }}>
        <div tw="flex flex-col items-center gap-7" w="100%" maxw={720} pad={0} bg="transparent" ta="center" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
          <Eyebrow theme={t} c="#E8A2A7">JOIN 11,400 MEMBERS</Eyebrow>
          <heading tag="h2" size={52} weight={500} lh={1.1} ls="-0.8px" font={t.font.head} color={t.color.ground} w="100%" ta="center" tablet={{ size: 42 }} mobile={{ size: 32 }}>
            Sign up and read the archive
          </heading>
          <text size={18} lh={1.7} font={t.font.body} color="#B9B5AD" w="100%" ta="center" maxw={560} mobile={{ size: 16 }}>
            Six years of investigations, every document set we can legally publish, and the costings for all of it. Cancel in one click, from the same page you joined on.
          </text>
          <div tw="flex flex-row gap-4 items-center justify-center" w="100%" pad={{ t: 8 }} bg="transparent" wrap="wrap">
            <text
              tag="span"
              href="#membership"
              size={15}
              weight={600}
              ls="0.6px"
              font={t.font.body}
              color={t.color.ground}
              bg={t.color.red}
              pad={{ t: 17, r: 38, b: 17, l: 38 }}
              w="hug"
              ta="center"
              hover={{ bg: t.color.ground, color: t.color.ink }}
            >
              Become a member
            </text>
            <text tag="span" href="#index" size={15} weight={500} font={t.font.body} color={t.color.ground} pad={{ t: 17, r: 8, b: 17, l: 8 }} w="hug" hover={{ color: '#E8A2A7' }}>
              Browse the index first
            </text>
          </div>
          <div w={120} h={1} bg="#333029" m={{ t: 12 }} />
          <text size={13} lh={1.7} font={t.font.body} color="#8F8B83" w="100%" ta="center">
            The Undertow · Owned by a trust with a locked purpose clause · No advertising, no proprietor, no sponsored anything
          </text>
        </div>
      </section>
    </box>
  );
};
