/** Toolbelt — trades apprenticeship platform. Dossier palette. */
export default defineTheme({
  name: 'toolbelt',
  color: {
    ground: '#16181C',   // page background
    panel: '#1F2229',    // raised dossier panels
    ink: '#F1F2F4',      // display + body text
    steel: '#8B939C',    // secondary copy, rules
    spark: '#FFB020',    // primary accent, CTAs
    go: '#41C97D',       // positive numbers
    line: '#2C3039',     // hairline rules
  },
  font: { head: 'Teko', body: 'Barlow' },
  radius: { sm: 2, md: 4, lg: 6 },
  mode: 'literal',
});
