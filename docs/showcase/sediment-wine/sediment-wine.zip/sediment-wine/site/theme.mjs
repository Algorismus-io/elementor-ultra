/** Sediment — natural wine club tokens. */
export default defineTheme({
  name: 'sediment',
  color: {
    ground: '#FDF6EF',
    ink: '#2A1A1F',
    wine: '#7B1E3A',
    orange: '#D97A34',
    verdant: '#5C7A4A',
    cream: '#F5E6D6',
    white: '#FFFFFF',
  },
  font: { head: 'Petrona', body: 'Lora' },
  mode: 'literal',
});
