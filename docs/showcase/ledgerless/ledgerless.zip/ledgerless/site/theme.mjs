/** Ledgerless — fintech for freelancers. Oversized type as layout. */
export default defineTheme({
  name: 'ledgerless',
  color: {
    ground: '#0D0C0F',
    ink: '#FAF7F2',
    money: '#B6FF6B',
    warn: '#FF8A3D',
    muted: '#6A6772',
  },
  font: { head: 'Bricolage Grotesque', body: 'Public Sans' },
  mode: 'literal',
});
