/** Week 33 filmstrip — fourteen things at their best. */
export const FILM = [
  { name: 'Crown Prince squash', farm: 'Hollow Lane Market Garden', dist: '38 km', note: 'Cured three weeks. Cuts dry, roasts sweet.' },
  { name: 'Gariguette strawberries', farm: 'Ryeburn Fruit', dist: '44 km', note: 'The last picking of the year. Thursday ends it.' },
  { name: 'Sea kale', farm: 'Coast Rows', dist: '88 km', note: 'Blanched under pots, cut Tuesday at dawn.' },
  { name: 'Three-week mutton', farm: 'Blackthorn Hill', dist: '72 km', note: 'Hung 21 days. Saddle, shoulder, whole sides.' },
  { name: 'Goat curd', farm: 'Sallow Dairy', dist: '29 km', note: 'Set Monday. Will not last past Thursday.' },
  { name: 'Cavolo nero', farm: 'Ninepence Farm', dist: '51 km', note: 'First frost has been through it. Sweeter for it.' },
  { name: 'Green cobnuts', farm: 'Marsh End', dist: '63 km', note: 'Milky, still in the husk. Two weeks at most.' },
  { name: 'Borlotti beans', farm: 'Whitewell Holding', dist: '47 km', note: 'Podding weight. Shell them the day they land.' },
  { name: 'Damsons', farm: 'Old Vicarage Orchard', dist: '66 km', note: 'Picked over twice. Then it is jam and nothing else.' },
  { name: 'Cold-smoked trout', farm: 'Aln Smokehouse', dist: '81 km', note: 'Oak, fourteen hours. Sides or sliced to order.' },
  { name: 'Salad burnet and chervil', farm: 'Fen Cutting', dist: '34 km', note: 'Cut the night before, boxed damp.' },
  { name: 'Chanterelles', farm: 'Gorse Wood', dist: '74 km', note: 'Foraged Sunday and Wednesday only. Nothing between.' },
  { name: 'Raw milk butter', farm: 'Sallow Dairy', dist: '29 km', note: 'Churned Tuesday, cultured eighteen hours.' },
  { name: 'Ox cheek', farm: 'Blackthorn Hill', dist: '72 km', note: 'Whole, trimmed, six to a box. Braising weather.' },
];

/** A sample of the 46 producers, with distance from the city. */
export const GROWERS = [
  { farm: 'Hollow Lane Market Garden', dist: '38 km', detail: 'Squash, roots, brassicas. Two cuts a week.' },
  { farm: 'Sallow Dairy', dist: '29 km', detail: 'Goat curd, raw milk butter, cultured cream.' },
  { farm: 'Blackthorn Hill', dist: '72 km', detail: 'Mutton and hogget, hung on the farm.' },
  { farm: 'Ryeburn Fruit', dist: '44 km', detail: 'Strawberries, currants, late plums.' },
  { farm: 'Coast Rows', dist: '88 km', detail: 'Sea kale, samphire, coastal herbs.' },
  { farm: 'Aln Smokehouse', dist: '81 km', detail: 'Oak-smoked trout, eel, cured butter.' },
  { farm: 'Ninepence Farm', dist: '51 km', detail: 'Leaf and stem crops, field-grown, no polytunnels.' },
  { farm: 'Fen Cutting', dist: '34 km', detail: 'Soft herbs and salad, cut to order.' },
];

/** The three ways an order reaches the growers. */
export const ORDER_ROUTES = [
  { no: '01', label: 'On the web', body: 'The full list, updated as growers cut. Reorder last week in two clicks, edit until 9pm.' },
  { no: '02', label: 'On WhatsApp', body: 'Send a photo of your list or a voice note. It comes back typed for you to confirm before cut-off.' },
  { no: '03', label: 'On the phone', body: 'Ring the desk between 7am and 9pm and a person picks up. They know what is good this week.' },
];
