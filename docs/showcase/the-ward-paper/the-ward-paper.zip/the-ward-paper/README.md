# The Ward

Genuine newspaper craft — masthead, rules, column rhythm, reporter beats.

|  |  |
|---|---|
| **Slug** | `the-ward-paper` (deploys to `/the-ward-paper/`) |
| **Archetype** | single-column long-form |
| **Industry** | Local news cooperative |
| **Page title** | The Ward |
| **Fonts** | Playfair Display, Source Serif 4 — Google Fonts, imported by Elementor automatically |
| **Elements** | 135 |
| **Images** | 2 |
| **Global classes used** | 0 — built `--inline` (86 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install the-ward-paper
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
the-ward-paper/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/the-ward-paper.page.jsx        the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FFFDFA` |
| `ink` | `#141414` |
| `press` | `#8C2B2B` |
| `civic` | `#2A4E7A` |
| `rule` | `#DEDAD3` |
| `grey` | `#6B6B67` |

Change a value, re-run `npx exjsx-kit install the-ward-paper`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/the-ward-paper.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `ward-council-chamber` | `media/council_chamber.jpg` | The empty public gallery and press bench of a city council chamber |
| `ward-reporter-street` | `media/reporter_street.jpg` | A reporter working on a city street outside the civic buildings |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
