/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "kilnhouse--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'kilnhouse--';

export default [
  { slot: `${PREFIX}catalogue_still`, file: join(MEDIA_DIR, "catalogue_still.jpg"), alt: "Six stoneware shapes laid out on a linen cloth" },
  { slot: `${PREFIX}glaze_macro`, file: join(MEDIA_DIR, "glaze_macro.jpg"), alt: "Macro detail of a flame-fired glaze surface" },
  { slot: `${PREFIX}kiln_firing`, file: join(MEDIA_DIR, "kiln_firing.jpg"), alt: "Stoneware being fired in the Coimbra kiln" },
  { slot: `${PREFIX}kitchen_use`, file: join(MEDIA_DIR, "kitchen_use.jpg"), alt: "Kilnhouse braiser in use on a home kitchen hob" },
];
