/** Common Ground Trust — design tokens. */
export default defineTheme({
  name: 'commonground',
  color: {
    ground: '#F3F5EF',
    ink: '#1B2A20',
    river: '#2C6E8F',
    grass: '#6E8B3D',
    ochre: '#C4913C',
    rule: '#C9D1C2',
    paper: '#FFFFFF',
  },
  font: { head: 'Newsreader', body: 'Source Sans 3' },
  mode: 'literal',
});
