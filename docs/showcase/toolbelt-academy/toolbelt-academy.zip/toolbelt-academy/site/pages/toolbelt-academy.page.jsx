/** Toolbelt — the dossier. Sticky trade-selector sidebar left, hard numbers right. */
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Toolbelt — paid trades apprenticeships',
  slug: 'toolbelt-academy',
  seo: {
    title: 'Toolbelt — Earning at 18. Qualified at 22. No debt at any point.',
    description:
      'Toolbelt matches you with a paid apprenticeship in electrical, plumbing, HVAC or welding. On a wage from week one, training paid for, no loan. 412 employers hiring across 9 regions.',
    ogImage: media.apprentice_site.url,
  },
};

/* ── data ───────────────────────────────────────────────────────────────── */

const TRADES = [
  {
    no: '01', name: 'Electrical', pay: '£42k',
    work: 'Mostly domestic and commercial installation, some fault finding. You will be on your knees in lofts for two years and running your own board by year four.',
    qualify: '4 years to NVQ3 + AM2', top: '£38,000 – £46,000', entry: 'Competitive — apply early',
  },
  {
    no: '02', name: 'Plumbing & heating', pay: '£40k',
    work: 'Domestic heating, bathrooms and commercial pipework. Emergency callouts pay a premium, and once you are out on your own around year six that rate is yours.',
    qualify: '3 to 4 years to NVQ3', top: '£34,000 – £44,000', entry: 'Steady intake all year',
  },
  {
    no: '03', name: 'HVAC & refrigeration', pay: '£44k',
    work: 'Air conditioning, refrigeration and heat pumps. The newest of the four and the fastest growing. F-Gas certification is the ticket, and every new building needs one of you.',
    qualify: '4 years + F-Gas', top: '£36,000 – £48,000', entry: 'Easiest to get started',
  },
  {
    no: '04', name: 'Welding & fabrication', pay: '£46k',
    work: 'Fabrication, pipework and structural. Hardest to get into, best paid at the top, and coded welders can name their rate offshore and in petrochem.',
    qualify: '3 years + coding tickets', top: '£38,000 – £70,000 coded', entry: 'Hardest — test before offer',
  },
];

const YEARS = [
  { y: 'Year 1', a: '£16,800', aw: '37%', g: 'Studying', gw: '3%', gn: 'debt +£16,000' },
  { y: 'Year 2', a: '£20,100', aw: '44%', g: 'Studying', gw: '3%', gn: 'debt +£16,000' },
  { y: 'Year 3', a: '£24,400', aw: '53%', g: 'Studying', gw: '3%', gn: 'debt +£16,000' },
  { y: 'Year 4', a: '£29,600', aw: '64%', g: '£24,000', gw: '52%', gn: 'first graduate role' },
  { y: 'Year 5', a: '£42,000', aw: '91%', g: '£28,900', gw: '63%', gn: 'median path' },
];

const ENTRY = [
  { no: '01', h: 'Maths and English at grade 4', t: 'Most employers want the two of them. A few will take a functional skills pass instead, and a handful will put you through it in year one if the rest of you is right.' },
  { no: '02', h: 'A driving licence by year two', t: 'Not on day one. Vans go out at 7:30 and a mate who can drive one is worth more than a mate who cannot, so employers expect you to be working on it.' },
  { no: '03', h: 'Someone who turns up at 7:20 for a 7:30 start', t: 'That last one is genuinely the main filter. More apprenticeships end over timekeeping than over ability, and every employer we place with says the same thing unprompted.' },
  { no: '04', h: 'No GCSEs at all? Still worth applying', t: 'Sixty-one of our employers run their own entry test and ignore the paperwork entirely. We flag those on your matches so you are not applying into a wall.' },
];

const REGIONS = [
  { r: 'North West', n: '61' }, { r: 'West Midlands', n: '58' }, { r: 'Yorkshire & Humber', n: '49' },
  { r: 'South East', n: '47' }, { r: 'London', n: '44' }, { r: 'South West', n: '41' },
  { r: 'East of England', n: '39' }, { r: 'Scotland', n: '38' }, { r: 'Wales', n: '35' },
];

const PARENTS = [
  { q: 'Is it a real qualification?', a: 'Yes it is a real qualification. An NVQ Level 3 with AM2 is the same standard the person who wired your house holds, it is regulated, and it is recognised by every employer in the sector.' },
  { q: 'Can they go to university later?', a: 'Yes they can go to university later and many do. A Level 3 carries UCAS points, and the ones who go tend to go at 24 with savings, a trade to fall back on and a much clearer idea of why.' },
  { q: 'Is the trade disappearing?', a: 'No, the trade is not disappearing. There are 11,000 unfilled electrical vacancies right now, and a heat pump is not a thing you install from an office in another country.' },
  { q: 'What if they pick the wrong one?', a: 'The first two years overlap more than you would think. Moving between trades before the end of year two is common, costs nothing, and we handle the rematch rather than leaving them to it.' },
];

const NAV = [
  { no: '01', label: 'The offer', href: '#offer' },
  { no: '02', label: 'Earnings curve', href: '#earnings' },
  { no: '03', label: 'Four trades', href: '#trades' },
  { no: '04', label: 'What it costs', href: '#cost' },
  { no: '05', label: 'Entry requirements', href: '#entry' },
  { no: '06', label: 'Employers hiring', href: '#employers' },
  { no: '07', label: 'For parents', href: '#parents' },
  { no: '08', label: 'Apply', href: '#apply' },
];

/* ── shared bits ────────────────────────────────────────────────────────── */

const C = {
  ground: '#16181C', panel: '#1F2229', ink: '#F1F2F4',
  steel: '#8B939C', spark: '#FFB020', go: '#41C97D', line: '#2C3039',
};
const HEAD = 'Teko';
const BODY = 'Barlow';

const Rule = (p = {}) => <div tw="w-full h-[1px]" bg={C.line} {...p} />;

const Eyebrow = ({ children, color = C.spark }) => (
  <text font={BODY} size={12} weight={700} ls={0.18} color={color} tw="uppercase">
    {children}
  </text>
);

const Cta = ({ label = 'Find an apprenticeship', href = '#apply' }) => (
  <text
    href={href} font={HEAD} size={24} weight={600} ls={0.04} color={C.ground} bg={C.spark}
    tw="uppercase px-7 py-2 rounded-[3px] w-fit no-underline text-center"
    hover={{ bg: '#FFC85C' }}
  >
    {label}
  </text>
);

/* ── registered repeaters (content props only) ──────────────────────────── */

const TradeCard = defineComponent(
  ({ no = '01', name = 'Trade', work = '', qualify = '', top = '', entry = '' }) => (
    <box tw="flex flex-col gap-4 p-7 rounded-[4px] border-l-4 h-full" bg={C.panel}
      raw={`border-left: 4px solid ${C.spark};`}>
      <box tw="flex flex-row items-end gap-3">
        <text font={HEAD} size={22} weight={500} color={C.spark}>{no}</text>
        <heading tag="h3" font={HEAD} size={38} weight={500} ls={0.01} color={C.ink} lh={1}>{name}</heading>
      </box>
      <text font={BODY} size={16} lh={1.6} color={C.steel}>{work}</text>
      <div tw="w-full h-[1px] mt-1" bg={C.line} />
      <box tw="flex flex-col gap-2">
        <box tw="flex flex-row justify-between gap-4">
          <text font={BODY} size={13} weight={600} ls={0.08} color={C.steel} tw="uppercase">Time to qualify</text>
          <text font={BODY} size={14} weight={600} color={C.ink} ta="right">{qualify}</text>
        </box>
        <box tw="flex flex-row justify-between gap-4">
          <text font={BODY} size={13} weight={600} ls={0.08} color={C.steel} tw="uppercase">Qualified pay</text>
          <text font={BODY} size={14} weight={600} color={C.go} ta="right">{top}</text>
        </box>
        <box tw="flex flex-row justify-between gap-4">
          <text font={BODY} size={13} weight={600} ls={0.08} color={C.steel} tw="uppercase">Getting in</text>
          <text font={BODY} size={14} weight={600} color={C.ink} ta="right">{entry}</text>
        </box>
      </box>
    </box>
  ),
  {
    title: 'Trade card',
    props: {
      no: { label: 'Number', group: 'Trade' },
      name: { label: 'Trade name', group: 'Trade' },
      work: { label: 'What the work is like', group: 'Trade' },
      qualify: { label: 'Time to qualify', group: 'Facts' },
      top: { label: 'Qualified pay', group: 'Facts' },
      entry: { label: 'Getting in', group: 'Facts' },
    },
  },
);

const QaRow = defineComponent(
  ({ q = '', a = '' }) => (
    <box tw="flex flex-col gap-2 py-5 border-t" raw={`border-top: 1px solid ${C.line};`}>
      <heading tag="h3" font={HEAD} size={28} weight={500} color={C.ink} lh={1.1}>{q}</heading>
      <text font={BODY} size={16} lh={1.65} color={C.steel}>{a}</text>
    </box>
  ),
  { title: 'Parent question', props: { q: { label: 'Question', group: 'Q&A' }, a: { label: 'Answer', group: 'Q&A' } } },
);

/* ── sidebar ────────────────────────────────────────────────────────────── */

const Sidebar = () => (
  <box tw="flex flex-col gap-6 p-8 sticky top-0 max-md:static" bg={C.ground}
    raw={`border-right: 1px solid ${C.line}; align-self: start;`}
    mobile={{ pos: 'static' }}>
    <box tw="flex flex-col gap-1">
      <text font={HEAD} size={34} weight={600} ls={0.06} color={C.ink} tw="uppercase" lh={1}>Toolbelt</text>
      <text font={BODY} size={11} weight={600} ls={0.16} color={C.steel} tw="uppercase">Apprenticeship dossier</text>
    </box>

    <Rule />

    <box tw="flex flex-col gap-3">
      <Eyebrow>Choose a trade</Eyebrow>
      <box tw="flex flex-col gap-[2px]">
        {TRADES.map((t) => (
          <text
            href="#trades" font={BODY} size={15} weight={600} color={C.ink}
            tw="flex flex-row justify-between gap-3 px-3 py-2 rounded-[3px] no-underline"
            raw={`& em { font-style: normal; color: ${C.spark}; font-weight: 700; }`}
            hover={{ bg: C.panel, color: C.spark }}
          >
            {t.name} <em>{t.pay}</em>
          </text>
        ))}
      </box>
    </box>

    <Rule />

    <box tw="flex flex-col gap-3">
      <Eyebrow color={C.steel}>Contents</Eyebrow>
      <box tw="flex flex-col gap-[6px]">
        {NAV.map((n) => (
          <text
            href={n.href} font={BODY} size={14} weight={500} color={C.steel} tw="no-underline"
            raw={`& strong { color: ${C.spark}; font-weight: 700; margin-right: 8px; }`}
            hover={{ color: C.ink }}
          >
            <strong>{n.no}</strong>{n.label}
          </text>
        ))}
      </box>
    </box>

    <Rule />

    <box tw="flex flex-col gap-3">
      <Cta />
      <text font={BODY} size={12} lh={1.5} color={C.steel}>412 employers hiring across 9 regions this quarter. Six minutes to apply.</text>
    </box>
  </box>
);

/* ── page ───────────────────────────────────────────────────────────────── */

export default () => (
  <box tw="flex flex-col w-full" bg={C.ground} pad={0}>

    {/* masthead strip */}
    <box tw="flex flex-row items-center justify-between gap-4 px-8 py-3 w-full max-md:px-5"
      bg={C.panel} raw={`border-bottom: 1px solid ${C.line};`}>
      <text font={BODY} size={12} weight={700} ls={0.16} color={C.spark} tw="uppercase">Dossier · 2026 intake</text>
      <text font={BODY} size={12} weight={600} ls={0.08} color={C.steel} tw="uppercase max-md:hidden">
        Electrical · Plumbing · HVAC · Welding
      </text>
    </box>

    {/* the dossier: sticky sidebar + content column */}
    <grid cols="304px 1fr" gap={0} tw="w-full" tablet={{ gridCols: '244px 1fr' }} mobile={{ gridCols: 1 }}>

      <Sidebar />

      <box tw="flex flex-col w-full min-w-0">

        {/* 01 — the offer */}
        <section id="offer" tw="flex flex-col gap-6 px-12 pt-16 pb-14 w-full max-md:px-5 max-md:pt-10">
          <Eyebrow>01 — The offer</Eyebrow>
          <h1 font={HEAD} size={86} weight={600} ls={-0.01} lh={0.92} color={C.ink} maxw={880}
            tw="max-lg:text-[64px] max-md:text-[44px]"
            raw={`& em { font-style: normal; color: ${C.spark}; }`}
            motion={{ effect: 'fade', trigger: 'load', duration: 500 }}>
            Earning at 18. Qualified at 22. <em>No debt at any point.</em>
          </h1>
          <text font={BODY} size={19} lh={1.65} color={C.steel} maxw={720} tw="max-md:text-[16px]">
            Toolbelt matches you with a paid apprenticeship in electrical, plumbing, HVAC or welding. You are on a wage from week one, your training is paid for, and you finish with a qualification that nobody can offshore.
          </text>
          <box tw="flex flex-row items-center gap-4 flex-wrap">
            <Cta />
            <text href="#parents" font={BODY} size={15} weight={600} color={C.ink} tw="underline py-2"
              hover={{ color: C.spark }}>
              Reading this for your kid? Start at section 07
            </text>
          </box>
        </section>

        <box tw="flex flex-row w-full max-md:flex-col">
          <img src={media.apprentice_site.id} tw="w-full h-[340px] object-cover max-md:h-[220px]" />
        </box>

        {/* headline numbers strip */}
        <grid cols={4} gap={0} tw="w-full" mobile={{ gridCols: 2 }}
          raw={`border-bottom: 1px solid ${C.line};`}>
          {[
            { k: 'Year 1 wage', v: '£16,800' },
            { k: 'Year 3 wage', v: '£24,400' },
            { k: 'Year 5 qualified', v: '£38k–46k' },
            { k: 'Student debt', v: '£0' },
          ].map((s, i) => (
            <box tw="flex flex-col gap-1 px-6 py-6 max-md:px-5" bg={C.ground}
              raw={`border-right: 1px solid ${C.line};`}>
              <text font={BODY} size={11} weight={700} ls={0.14} color={C.steel} tw="uppercase">{s.k}</text>
              <text font={HEAD} size={46} weight={600} lh={1} color={i === 3 ? C.go : C.ink}
                tw="max-md:text-[34px]">{s.v}</text>
            </box>
          ))}
        </grid>

        {/* 02 — earnings curve */}
        <section id="earnings" tw="flex flex-col gap-7 px-12 py-16 w-full max-md:px-5 max-md:py-12" bg={C.panel}>
          <box tw="flex flex-col gap-4" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            <Eyebrow>02 — Earnings curve</Eyebrow>
            <heading tag="h2" font={HEAD} size={56} weight={600} lh={1} color={C.ink} tw="max-md:text-[36px]">
              Apprentice versus graduate, year by year
            </heading>
            <text font={BODY} size={17} lh={1.7} color={C.steel} maxw={760}>
              Year 1: £16,800. Year 3: £24,400. Year 5 qualified: £38,000 to £46,000. A graduate on the median path is at £28,900 in year five with £48,000 of debt behind them.
            </text>
          </box>

          <box tw="flex flex-col gap-0 w-full">
            <grid cols="88px 1fr 1fr" gap={16} tw="w-full pb-3" mobile={{ gridCols: '64px 1fr 1fr' }}
              raw={`border-bottom: 1px solid ${C.line};`}>
              <text font={BODY} size={11} weight={700} ls={0.14} color={C.steel} tw="uppercase">Year</text>
              <text font={BODY} size={11} weight={700} ls={0.14} color={C.spark} tw="uppercase">Apprentice</text>
              <text font={BODY} size={11} weight={700} ls={0.14} color={C.steel} tw="uppercase">Graduate</text>
            </grid>

            {YEARS.map((r) => (
              <grid cols="88px 1fr 1fr" gap={16} tw="w-full py-4 items-center" mobile={{ gridCols: '64px 1fr 1fr' }}
                raw={`border-bottom: 1px solid ${C.line};`}>
                <text font={HEAD} size={26} weight={500} lh={1} color={C.ink}>{r.y}</text>
                <box tw="flex flex-col gap-2">
                  <div tw="h-[10px] rounded-[2px]" bg={C.spark} w={r.aw} />
                  <text font={BODY} size={15} weight={700} color={C.ink}>{r.a}</text>
                </box>
                <box tw="flex flex-col gap-2">
                  <div tw="h-[10px] rounded-[2px]" bg={C.steel} w={r.gw} />
                  <text font={BODY} size={15} weight={600} color={C.steel}>
                    {r.g} <em>· {r.gn}</em>
                  </text>
                </box>
              </grid>
            ))}
          </box>

          <grid cols={2} gap={20} tw="w-full" mobile={{ gridCols: 1 }}>
            <box tw="flex flex-col gap-2 p-6 rounded-[4px]" bg={C.ground} raw={`border-left: 4px solid ${C.go};`}>
              <text font={BODY} size={11} weight={700} ls={0.14} color={C.steel} tw="uppercase">Apprentice, five years in</text>
              <text font={HEAD} size={52} weight={600} lh={1} color={C.go} tw="max-md:text-[38px]">+£132,900</text>
              <text font={BODY} size={15} lh={1.6} color={C.steel}>Earned, banked, nothing owed. Tools provided, training paid for by the employer and the government.</text>
            </box>
            <box tw="flex flex-col gap-2 p-6 rounded-[4px]" bg={C.ground} raw={`border-left: 4px solid ${C.steel};`}>
              <text font={BODY} size={11} weight={700} ls={0.14} color={C.steel} tw="uppercase">Graduate, five years in</text>
              <text font={HEAD} size={52} weight={600} lh={1} color={C.ink} tw="max-md:text-[38px]">+£4,900</text>
              <text font={BODY} size={15} lh={1.6} color={C.steel}>£52,900 earned across years four and five, less £48,000 of debt still behind them and repaying at 9p in the pound.</text>
            </box>
          </grid>
        </section>

        {/* 03 — four trades */}
        <section id="trades" tw="flex flex-col gap-7 px-12 py-16 w-full max-md:px-5 max-md:py-12">
          <box tw="flex flex-col gap-4" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            <Eyebrow>03 — The four trades</Eyebrow>
            <heading tag="h2" font={HEAD} size={56} weight={600} lh={1} color={C.ink} tw="max-md:text-[36px]">
              What the work is actually like
            </heading>
            <text font={BODY} size={17} lh={1.7} color={C.steel} maxw={760}>
              Not the brochure version. Four trades, what you will physically be doing in year one, and what the ceiling looks like once you are qualified.
            </text>
          </box>
          <grid cols={2} gap={20} tw="w-full" mobile={{ gridCols: 1 }}>
            {TRADES.map((t) => (
              <TradeCard no={t.no} name={t.name} work={t.work} qualify={t.qualify} top={t.top} entry={t.entry} />
            ))}
          </grid>
        </section>

        {/* 04 — what it costs */}
        <section id="cost" tw="w-full" bg={C.panel}>
          <grid cols="1fr 1fr" gap={0} tw="w-full" mobile={{ gridCols: 1 }}>
            <box tw="flex flex-col gap-5 px-12 py-16 max-md:px-5 max-md:py-12">
              <Eyebrow>04 — What it costs you</Eyebrow>
              <text font={HEAD} size={140} weight={600} lh={0.85} color={C.spark} tw="max-lg:text-[110px] max-md:text-[84px]">£0</text>
              <heading tag="h2" font={HEAD} size={44} weight={500} lh={1.05} color={C.ink} tw="max-md:text-[30px]">
                It costs you nothing
              </heading>
              <text font={BODY} size={17} lh={1.7} color={C.steel} maxw={520}>
                The employer and the government fund the training. You do not pay fees, you do not take a loan, and your tools are usually provided in year one.
              </text>
              <box tw="flex flex-col gap-0 mt-2">
                {[
                  ['Course fees', '£0 — funded'],
                  ['Student loan', '£0 — none taken'],
                  ['Tools, year one', 'Usually provided'],
                  ['Your wage, week one', '£323 per week'],
                ].map((row) => (
                  <box tw="flex flex-row justify-between gap-4 py-3" raw={`border-bottom: 1px solid ${C.line};`}>
                    <text font={BODY} size={15} color={C.steel}>{row[0]}</text>
                    <text font={BODY} size={15} weight={700} color={C.ink} ta="right">{row[1]}</text>
                  </box>
                ))}
              </box>
            </box>
            <img src={media.toolbox.id} tw="w-full h-full object-cover max-md:h-[260px]" />
          </grid>
        </section>

        {/* 05 — entry requirements */}
        <section id="entry" tw="flex flex-col gap-7 px-12 py-16 w-full max-md:px-5 max-md:py-12">
          <box tw="flex flex-col gap-4" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            <Eyebrow>05 — Entry requirements</Eyebrow>
            <heading tag="h2" font={HEAD} size={56} weight={600} lh={1} color={C.ink} tw="max-md:text-[36px]">
              Honestly stated
            </heading>
            <text font={BODY} size={17} lh={1.7} color={C.steel} maxw={760}>
              Most employers want Maths and English at grade 4, a driving licence by year two, and someone who turns up at 7:20 for a 7:30 start. That last one is genuinely the main filter.
            </text>
          </box>
          <grid cols={2} gap={0} tw="w-full" mobile={{ gridCols: 1 }}>
            {ENTRY.map((e) => (
              <box tw="flex flex-row gap-5 px-7 py-7 max-md:px-0" bg={C.ground}
                raw={`border-top: 1px solid ${C.line};`}>
                <text font={HEAD} size={30} weight={600} lh={1} color={C.spark}>{e.no}</text>
                <box tw="flex flex-col gap-2 min-w-0">
                  <heading tag="h3" font={HEAD} size={30} weight={500} lh={1.05} color={C.ink}>{e.h}</heading>
                  <text font={BODY} size={15} lh={1.65} color={C.steel}>{e.t}</text>
                </box>
              </box>
            ))}
          </grid>
        </section>

        {/* 06 — employers hiring */}
        <section id="employers" tw="flex flex-col gap-7 px-12 py-16 w-full max-md:px-5 max-md:py-12" bg={C.panel}>
          <box tw="flex flex-row items-end justify-between gap-6 flex-wrap">
            <box tw="flex flex-col gap-4">
              <Eyebrow>06 — Employers hiring now</Eyebrow>
              <heading tag="h2" font={HEAD} size={56} weight={600} lh={1} color={C.ink} tw="max-md:text-[36px]">
                412 employers, 9 regions, this quarter
              </heading>
            </box>
            <text font={BODY} size={16} lh={1.65} color={C.steel} maxw={380}>
              Applications take about six minutes and go to a person, not a portal.
            </text>
          </box>
          <grid cols={3} gap={12} tw="w-full" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
            {REGIONS.map((r) => (
              <box tw="flex flex-row items-end justify-between gap-4 px-5 py-5 rounded-[3px]" bg={C.ground}
                hover={{ bg: '#262A33' }}>
                <box tw="flex flex-col gap-1 min-w-0">
                  <text font={BODY} size={16} weight={600} color={C.ink}>{r.r}</text>
                  <text font={BODY} size={12} weight={600} ls={0.1} color={C.steel} tw="uppercase">Hiring now</text>
                </box>
                <text font={HEAD} size={40} weight={600} lh={1} color={C.spark}>{r.n}</text>
              </box>
            ))}
          </grid>
        </section>

        {/* 07 — for parents */}
        <section id="parents" tw="w-full">
          <grid cols="1fr 1fr" gap={0} tw="w-full" mobile={{ gridCols: 1 }}>
            <img src={media.welding_sparks.id} tw="w-full h-full object-cover max-md:h-[240px]" />
            <box tw="flex flex-col gap-5 px-12 py-16 max-md:px-5 max-md:py-12">
              <Eyebrow>07 — For parents</Eyebrow>
              <heading tag="h2" font={HEAD} size={52} weight={600} lh={1} color={C.ink} tw="max-md:text-[34px]">
                The questions you are about to ask
              </heading>
              <box tw="flex flex-col gap-0">
                {PARENTS.map((p) => <QaRow q={p.q} a={p.a} />)}
              </box>
            </box>
          </grid>
        </section>

        {/* 08 — apply (the one centred section) */}
        <section id="apply" tw="flex flex-col items-center gap-6 px-12 py-20 w-full text-center max-md:px-5 max-md:py-14"
          bg={C.panel} raw={`border-top: 4px solid ${C.spark};`}>
          <Eyebrow>08 — Apply</Eyebrow>
          <heading tag="h2" font={HEAD} size={72} weight={600} lh={0.95} color={C.ink} maxw={760} ta="center"
            tw="max-md:text-[42px]" motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            Apply in six minutes
          </heading>
          <text font={BODY} size={18} lh={1.7} color={C.steel} maxw={620} ta="center">
            Pick a trade, tell us your postcode and what you have got, and we send you to the employers actually hiring near you. It goes to a person, not a portal.
          </text>
          <grid cols={3} gap={16} tw="w-full max-w-[760px] mt-2" mobile={{ gridCols: 1 }}>
            {[
              ['1', 'Pick a trade', 'Or tell us you are undecided — half of applicants are.'],
              ['2', 'Two minutes of details', 'Postcode, age, grades if you have them.'],
              ['3', 'Matched in 48 hours', 'Named employers, real vacancies, your inbox.'],
            ].map((s) => (
              <box tw="flex flex-col items-center gap-2 px-5 py-6 rounded-[3px] text-center" bg={C.ground}>
                <text font={HEAD} size={34} weight={600} lh={1} color={C.spark}>{s[0]}</text>
                <text font={BODY} size={16} weight={700} color={C.ink} ta="center">{s[1]}</text>
                <text font={BODY} size={14} lh={1.55} color={C.steel} ta="center">{s[2]}</text>
              </box>
            ))}
          </grid>
          <Cta />
          <text font={BODY} size={13} color={C.steel} ta="center">
            412 employers hiring across 9 regions this quarter. No fees, ever.
          </text>
        </section>

        {/* footer */}
        <box tw="flex flex-row items-center justify-between gap-4 px-12 py-6 w-full max-md:px-5 max-md:flex-col max-md:items-start"
          raw={`border-top: 1px solid ${C.line};`}>
          <text font={HEAD} size={24} weight={600} ls={0.06} color={C.ink} tw="uppercase">Toolbelt</text>
          <text font={BODY} size={12} color={C.steel}>
            Paid apprenticeships in electrical, plumbing, HVAC and welding.
          </text>
        </box>

      </box>
    </grid>
  </box>
);
