# Sediment

Deep burgundy, tilted labels, an editorial hand throughout.

|  |  |
|---|---|
| **Slug** | `sediment-wine` (deploys to `/sediment-wine/`) |
| **Archetype** | overlapping stacked cards |
| **Industry** | Natural wine club |
| **Page title** | Sediment — natural wine club |
| **Fonts** | Petrona, Lora — Google Fonts, imported by Elementor automatically |
| **Elements** | 141 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (82 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install sediment-wine
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
sediment-wine/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/sediment-wine.page.jsx         the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FDF6EF` |
| `ink` | `#2A1A1F` |
| `wine` | `#7B1E3A` |
| `orange` | `#D97A34` |
| `verdant` | `#5C7A4A` |
| `cream` | `#F5E6D6` |

Change a value, re-run `npx exjsx-kit install sediment-wine`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/sediment-wine.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `bottles_table` | `media/bottles_table.jpg` | Six natural wine bottles standing on a scuffed wooden table |
| `pour` | `media/pour.jpg` | Cloudy red wine being poured into a tumbler |
| `vineyard` | `media/vineyard.jpg` | A small hillside vineyard in late summer |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
