# Hana Sekigawa

Motion-studio dark with magenta light trails — looks like a real reel site.

|  |  |
|---|---|
| **Slug** | `kinetic-hana` (deploys to `/kinetic-hana/`) |
| **Archetype** | horizontal filmstrip band |
| **Industry** | Motion design portfolio |
| **Page title** | Hana Sekigawa — Motion Design |
| **Fonts** | Syncopate, Sen — Google Fonts, imported by Elementor automatically |
| **Elements** | 238 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (87 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install kinetic-hana
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
kinetic-hana/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/kinetic-hana.page.jsx          the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#0A0A0C` |
| `ink` | `#F4F4F6` |
| `signal` | `#FF4D6D` |
| `chrome` | `#B9BCC7` |
| `deep` | `#15151B` |

Change a value, re-run `npx exjsx-kit install kinetic-hana`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/kinetic-hana.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `still_a` | `media/still_frame_a.jpg` | Still frame from a title sequence by Hana Sekigawa |
| `still_b` | `media/still_frame_b.jpg` | Still frame from a broadcast package by Hana Sekigawa |
| `studio_desk` | `media/studio_desk.jpg` | Hana Sekigawa studio desk with After Effects timeline on screen |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
