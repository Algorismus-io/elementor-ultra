/** Onsen Mirador — geothermal bathhouse. */
export default defineTheme({
  name: 'onsen-mirador',
  color: {
    ground: '#0E1416',
    ink: '#E8EEEC',
    steam: '#9FBDBD',
    cedar: '#A0714B',
    stone: '#3A4448',
  },
  font: { head: 'Cinzel', body: 'Cormorant Garamond' },
  mode: 'literal',
});
