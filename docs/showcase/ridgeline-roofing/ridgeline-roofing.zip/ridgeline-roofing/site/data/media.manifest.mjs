/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "ridgeline-roofing--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'ridgeline-roofing--';

export default [
  { slot: `${PREFIX}crew_working`, file: join(MEDIA_DIR, "crew_working.jpg"), alt: "A Ridgeline crew working on a residential asphalt roof" },
  { slot: `${PREFIX}damage_detail`, file: join(MEDIA_DIR, "damage_detail.jpg"), alt: "Close detail of storm-damaged shingles with granule loss" },
];
