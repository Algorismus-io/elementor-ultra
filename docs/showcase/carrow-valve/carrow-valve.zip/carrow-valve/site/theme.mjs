/** Carrow Valve Works — design tokens. */
export default defineTheme({
  name: 'carrow',
  color: {
    ground: '#F2F3F4',
    ink: '#1A1D20',
    steel: '#5B676E',
    safety: '#C8102E',
    band: '#DDE1E4',
    white: '#FFFFFF',
  },
  font: { head: 'Oswald', body: 'Roboto Mono' },
  mode: 'literal',
});
