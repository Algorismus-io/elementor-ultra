/** Spoke & Van — mobile bicycle repair. Design tokens. */
export default defineTheme({
  name: 'spoke-and-van',
  color: {
    ground: '#111811', // page base — night workshop
    ink: '#F2F7EF',    // primary text on dark
    hi: '#C6FF3D',     // hi-vis lime — slots, prices, CTA
    van: '#F26B21',    // van orange — warnings, rescue
    panel: '#1C2620',  // raised surface
  },
  font: { head: 'Bebas Neue', body: 'Cabin' },
  mode: 'literal',
});
