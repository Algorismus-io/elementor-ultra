import { P } from './data/palette.mjs';

/** Design tokens — Quiet Night A2. */
export default defineTheme({
  name: 'quiet-night',
  color: {
    ground: P.ground, // page background
    ink: P.ink,       // display + body text
    calm: P.calm,     // links, accents
    night: P.night,   // dark bands
    soft: P.soft,     // rules, tints, dark-band body copy
    ok: P.ok,         // the column that wins
    white: P.white,
  },
  font: { head: 'Lexend', body: 'Figtree' },
  mode: 'literal',
});
