/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "anvil-field-t9--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'anvil-field-t9--';

export default [
  { slot: `${PREFIX}device_field`, file: join(MEDIA_DIR, "device_field.jpg"), alt: "Anvil T9 rugged field laptop open on a survey tripod case" },
  { slot: `${PREFIX}hot_swap`, file: join(MEDIA_DIR, "hot_swap.jpg"), alt: "Gloved hands swapping a hot-swap battery on the Anvil T9" },
  { slot: `${PREFIX}deployment`, file: join(MEDIA_DIR, "deployment.jpg"), alt: "Field crew using the Anvil T9 on a utilities deployment" },
];
