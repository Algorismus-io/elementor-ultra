/** The one place the brand hexes live — read by theme.mjs and by module-scope components. */
export const P = {
  ground: '#F4F7FA',
  ink: '#16212B',
  calm: '#3E7CB1',
  night: '#1B2A38',
  soft: '#DCE7EF',
  ok: '#3FA37E',
  white: '#FFFFFF',
};
export default P;
