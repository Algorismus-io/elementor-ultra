/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "commonground-trust--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'commonground-trust--';

export default [
  { slot: `${PREFIX}curlew`, file: join(MEDIA_DIR, "curlew.jpg"), alt: "A curlew standing in wet meadow grass on the Wenn floodplain" },
  { slot: `${PREFIX}meadow_wide`, file: join(MEDIA_DIR, "meadow_wide.jpg"), alt: "Wide view of unploughed floodplain meadow along the river Wenn" },
  { slot: `${PREFIX}volunteer_survey`, file: join(MEDIA_DIR, "volunteer_survey.jpg"), alt: "Volunteers carrying out a bank survey along the river" },
];
