/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "hutbook-alpine--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'hutbook-alpine--';

export default [
  { slot: `${PREFIX}dorm`, file: join(MEDIA_DIR, "dorm.jpg"), alt: "Bunks made up in a shared alpine hut dormitory" },
  { slot: `${PREFIX}hut_dusk`, file: join(MEDIA_DIR, "hut_dusk.jpg"), alt: "A mountain hut lit from inside at dusk below the ridge" },
  { slot: `${PREFIX}traverse_walkers`, file: join(MEDIA_DIR, "traverse_walkers.jpg"), alt: "Walkers crossing a high alpine traverse in single file" },
];
