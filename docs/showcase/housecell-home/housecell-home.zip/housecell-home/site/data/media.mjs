/**
 * media.mjs — the ONE media-wiring convention for every page in this kit.
 *
 * `exjsx media site/data/media.manifest.mjs site/data/media-map.json` sideloads the files in
 * ../../media/ into the target WordPress and writes media-map.json (slot -> attachment id).
 * This module is the only thing pages import; ids are never hardcoded in a page.
 *
 * Manifest slots are namespaced "housecell-home--<slot>" so installing several kit pages on ONE
 * WordPress cannot make two pages fight over the same `exjsx-<slot>` attachment. The prefix is
 * stripped here, so page code addresses plain slots.
 *
 *   MEDIA   slot   -> { type, id, url, alt }   (the raw map, de-namespaced)
 *   IMG     slot   -> attachment id            (also keyed by the camelCase alias of each slot)
 *   img(s)  -> attachment id, or null before the media step has run
 *   alt(s)  -> alt text
 *   srcAlt(s) -> alt text ONLY for url-src images (an id-src image takes alt from the attachment)
 *   has(s)  -> boolean
 */
import raw from './media-map.json' with { type: 'json' };

const PREFIX = 'housecell-home--';
const camel = (s) => s.replace(/[_-]+(.)/g, (_, c) => c.toUpperCase());

export const MEDIA = Object.fromEntries(
  Object.entries(raw).map(([k, v]) => [k.startsWith(PREFIX) ? k.slice(PREFIX.length) : k, v]),
);
export const IMG = Object.fromEntries(
  Object.entries(MEDIA).flatMap(([k, v]) => [[k, v.id ?? null], [camel(k), v.id ?? null]]),
);
export const img = (slot) => IMG[slot] ?? null;
export const alt = (slot) => MEDIA[slot]?.alt ?? '';
export const srcAlt = (slot) => (MEDIA[slot]?.id ? undefined : MEDIA[slot]?.alt || '');
export const has = (slot) => IMG[slot] != null;
export default IMG;
