/** Safe Passage — single-column long-form landing page. */
import { defineComponent } from 'elementor-jsx';
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Safe Passage',
  slug: 'safe-passage-law',
  seo: {
    title: 'Safe Passage — free legal representation for unaccompanied minors',
    description:
      'Safe Passage represents unaccompanied minors through asylum appeals, for free, and trains solicitors to take these cases. Represented appeals succeed in 63% of cases; unrepresented, 11%.',
  },
};

const INK = '#1A1A1A';
const DEEP = '#153A5B';
const AMBER = '#D98324';
const LINE = '#DCDCDC';
const WASH = '#F4F2EE';
const GROUND = '#FFFFFF';
const HEAD = 'Libre Baskerville';
const BODY = 'Assistant';

const fadeUp = { effect: 'fade', trigger: 'scrollIn', duration: 700 };

/* ── repeaters (content props only) ───────────────────────────────── */

const MoneyLine = defineComponent(
  ({ amount = '£46', what = 'Covers something.' }) => (
    <div tw="flex flex-col w-full gap-0" pad={0}>
      <box h={1} w="100%" bg={LINE} pad={0} />
      <grid cols={12} gap={16} w="100%" pad={{ t: 22, b: 22 }}>
        <div span={3} pad={0} mobile={{ props: {} }}>
          <heading tag="h3" size={30} weight={400} font={HEAD} color={DEEP} lh={1.2} mobile={{ size: 24 }}>
            {amount}
          </heading>
        </div>
        <div span={9} pad={0}>
          <text size={17} font={BODY} color={INK} lh={1.65}>
            {what}
          </text>
        </div>
      </grid>
    </div>
  ),
  {
    title: 'Money line',
    props: { amount: { label: 'Amount', group: 'Content' }, what: { label: 'What it buys', group: 'Content' } },
  },
);

const GovRow = defineComponent(
  ({ label = 'Label', body = 'Body copy.' }) => (
    <div tw="flex flex-col w-full" pad={0}>
      <box h={1} w="100%" bg={LINE} pad={0} />
      <grid cols={12} gap={16} w="100%" pad={{ t: 24, b: 24 }}>
        <div span={4} pad={0}>
          <text size={13} weight={700} ls={0.12} font={BODY} color={AMBER}>
            {label}
          </text>
        </div>
        <div span={8} pad={0}>
          <text size={17} font={BODY} color={INK} lh={1.7}>
            {body}
          </text>
        </div>
      </grid>
    </div>
  ),
  {
    title: 'Governance row',
    props: { label: { label: 'Label', group: 'Content' }, body: { label: 'Body', group: 'Content' } },
  },
);

/* ── page ─────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={GROUND}>

    {/* 1 — help now bar */}
    <section tw="flex w-full justify-center px-6 py-6 max-md:px-5 max-md:py-6" bg={DEEP} pad={{ t: 26, b: 26, l: 24, r: 24 }}>
      <div tw="flex flex-row w-full max-w-[1040px] gap-6 items-start max-md:flex-col max-md:gap-3" pad={0}>
        <text size={13} weight={700} ls={0.12} font={BODY} color={AMBER} w="hug" tw="max-md:w-full">
          NEED A LAWYER TODAY?
        </text>
        <text size={16} font={BODY} color="#FFFFFF" lh={1.6} maxw={720}>
          Need a lawyer? Call <strong>0800 555 0119</strong>, 9am to 7pm, interpreters available in 31 languages.
          We will not ask your immigration status before we help you.
        </text>
        <text
          href="tel:08005550119"
          size={16}
          weight={700}
          font={BODY}
          color={DEEP}
          bg="#FFFFFF"
          pad={{ t: 10, b: 10, l: 18, r: 18 }}
          w="hug"
          hover={{ bg: AMBER, color: '#FFFFFF' }}
        >
          Call now
        </text>
      </div>
    </section>

    {/* 2 — the situation */}
    <section tw="flex flex-col w-full items-start max-w-[1040px] px-6 pt-24 pb-20 max-md:px-5 max-md:pt-14 max-md:pb-12">
      <div tw="flex flex-col gap-7 max-w-[760px]" pad={0}>
        <box h={3} w={72} bg={AMBER} pad={0} />
        <h1 size={54} weight={400} font={HEAD} color={INK} lh={1.18} tablet={{ size: 44 }} mobile={{ size: 31 }}>
          A child with a lawyer wins. A child without one usually does not.
        </h1>
        <text size={21} font={BODY} color={DEEP} lh={1.6} maxw={700} mobile={{ size: 18 }}>
          Safe Passage represents unaccompanied minors through asylum appeals, for free, and trains solicitors to
          take these cases in their own firms. Last year we held 214 cases and trained 96 lawyers.
        </text>
        <div tw="flex flex-row gap-4 items-center max-md:flex-col max-md:items-start" pad={{ t: 4 }}>
          <text
            href="#give"
            size={17}
            weight={700}
            font={BODY}
            color="#FFFFFF"
            bg={DEEP}
            pad={{ t: 14, b: 14, l: 26, r: 26 }}
            w="hug"
            hover={{ bg: AMBER }}
          >
            Give monthly
          </text>
          <text href="#lawyers" size={17} weight={600} font={BODY} color={DEEP} w="hug" hover={{ color: AMBER }}>
            Train with us as a solicitor →
          </text>
        </div>
      </div>
    </section>

    {/* 2b — four paragraphs */}
    <section tw="flex flex-col w-full items-start max-w-[1040px] px-6 pb-20 max-md:px-5 max-md:pb-12">
      <div tw="flex flex-col gap-5 max-w-[680px]" pad={0} motion={fadeUp}>
        <text size={18} font={BODY} color={INK} lh={1.8}>
          A child who arrives here alone is asked to explain, in a second language, to an official who has never met
          them, why they are afraid to go home. They are asked for dates. They are asked for documents that were
          burned, confiscated or never issued. Most of them are between fourteen and seventeen.
        </text>
        <text size={18} font={BODY} color={INK} lh={1.8}>
          Legal aid for these appeals has been cut, then cut again, and the firms that still do the work are
          concentrated in two or three cities. A child placed in dispersal accommodation two hundred miles from the
          nearest immigration solicitor is, for practical purposes, unrepresented.
        </text>
        <text size={18} font={BODY} color={INK} lh={1.8}>
          The tribunal does not lower its evidential bar for a sixteen-year-old. It cannot. What changes is whether
          anyone gathers the country evidence, orders the age assessment challenge, finds the border record, prepares
          the child for cross-examination, and turns up on the day.
        </text>
        <text size={18} font={BODY} color={INK} lh={1.8}>
          That is the whole of our work: put a competent lawyer beside every child who is appealing, and make it
          ordinary for high street firms to take one of these cases a year.
        </text>
      </div>
    </section>

    {/* 2c — three numbers */}
    <section tw="flex flex-col w-full items-start max-w-[1040px] px-6 pb-24 max-md:px-5 max-md:pb-14">
      <grid cols={3} gap={32} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
        <div tw="flex flex-col gap-3" pad={0}>
          <box h={3} w={44} bg={AMBER} pad={0} />
          <heading tag="h2" size={58} weight={400} font={HEAD} color={DEEP} lh={1.05} mobile={{ size: 44 }}>
            214
          </heading>
          <text size={16} font={BODY} color={INK} lh={1.6}>
            appeals held last year, each one with a named solicitor on the file from first interview to
            determination.
          </text>
        </div>
        <div tw="flex flex-col gap-3" pad={0}>
          <box h={3} w={44} bg={AMBER} pad={0} />
          <heading tag="h2" size={58} weight={400} font={HEAD} color={DEEP} lh={1.05} mobile={{ size: 44 }}>
            96
          </heading>
          <text size={16} font={BODY} color={INK} lh={1.6}>
            solicitors trained to run an asylum appeal for a child inside their own firm, unpaid, with our
            supervision.
          </text>
        </div>
        <div tw="flex flex-col gap-3" pad={0}>
          <box h={3} w={44} bg={AMBER} pad={0} />
          <heading tag="h2" size={58} weight={400} font={HEAD} color={DEEP} lh={1.05} mobile={{ size: 44 }}>
            31
          </heading>
          <text size={16} font={BODY} color={INK} lh={1.6}>
            languages our helpline covers, because a child should not have to borrow a stranger's words to ask for
            help.
          </text>
        </div>
      </grid>
    </section>

    {/* 3 — what representation changes */}
    <section tw="flex w-full justify-center px-6 py-24 max-md:px-5 max-md:py-14" bg={WASH}>
      <div tw="flex flex-col w-full max-w-[1040px] gap-10" pad={0}>
        <div tw="flex flex-col gap-5 max-w-[720px]" pad={0}>
          <text size={13} weight={700} ls={0.12} font={BODY} color={AMBER}>
            WHAT REPRESENTATION CHANGES
          </text>
          <heading tag="h2" size={38} weight={400} font={HEAD} color={INK} lh={1.25} mobile={{ size: 27 }}>
            Represented appeals succeeded in 63 percent of our cases last year.
          </heading>
          <text size={18} font={BODY} color={INK} lh={1.8}>
            Unrepresented appeals in the same tribunals succeeded in 11 percent. That gap is the entire reason this
            organisation exists.
          </text>
        </div>

        <grid cols={2} gap={40} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
          <div tw="flex flex-col gap-3" pad={0} motion={fadeUp}>
            <text size={15} weight={700} font={BODY} color={DEEP}>
              With a lawyer
            </text>
            <box h={40} w="100%" bg={DEEP} pad={0} radius={2} />
            <heading tag="h3" size={34} weight={400} font={HEAD} color={DEEP} mobile={{ size: 28 }}>
              63%
            </heading>
          </div>
          <div tw="flex flex-col gap-3" pad={0} motion={fadeUp}>
            <text size={15} weight={700} font={BODY} color={INK}>
              Without a lawyer
            </text>
            <box h={40} w="17%" bg="#B9C4CE" pad={0} radius={2} />
            <heading tag="h3" size={34} weight={400} font={HEAD} color={INK} mobile={{ size: 28 }}>
              11%
            </heading>
          </div>
        </grid>

        <text size={15} font={BODY} color="#4A4A4A" lh={1.7} maxw={720}>
          Source: our own case files and published First-tier Tribunal outcome statistics for the same hearing
          centres, 2025. We count a success as asylum, humanitarian protection or leave to remain granted on appeal.
        </text>
      </div>
    </section>

    {/* 4 — one case */}
    <section tw="flex flex-col w-full items-center" pad={0} bg={DEEP}>
      <img src={media.corridor.id} w="100%" h={360} fit="cover" tablet={{ h: 280 }} mobile={{ h: 200 }} />
      <div tw="flex w-full justify-center px-6 py-24 max-md:px-5 max-md:py-14">
        <div tw="flex flex-col w-full max-w-[1040px] gap-6" pad={0}>
          <text size={13} weight={700} ls={0.12} font={BODY} color={AMBER}>
            ONE CASE, TOLD WITH PERMISSION
          </text>
          <heading
            tag="h2"
            size={30}
            weight={400}
            font={HEAD}
            color="#FFFFFF"
            lh={1.5}
            maxw={820}
            tablet={{ size: 26 }}
            mobile={{ size: 21 }}
          >
            S arrived at sixteen with a phone and a phone number. The first refusal letter said his account lacked
            credibility because he could not name the month he left.
          </heading>
          <text size={18} font={BODY} color="#D7E1EA" lh={1.8} maxw={700}>
            His lawyer found the border record that proved it. He is now studying engineering and has asked us to
            keep telling this.
          </text>
          <box h={1} w={120} bg={AMBER} pad={0} m={{ t: 8 }} />
          <text size={15} font={BODY} color="#A9BBCB" lh={1.7} maxw={700}>
            Names and identifying details are changed unless a client asks us to keep them. S read this page before
            it was published.
          </text>
        </div>
      </div>
    </section>

    {/* 5 — for lawyers */}
    <section id="lawyers" tw="flex w-full justify-center px-6 py-24 max-md:px-5 max-md:py-14" bg={GROUND}>
      <grid cols={12} gap={48} w="100%" maxw={1040} mobile={{ gridCols: 1, gap: 28 }}>
        <div span={7} tw="flex flex-col gap-5" pad={0}>
          <text size={13} weight={700} ls={0.12} font={BODY} color={AMBER}>
            FOR LAWYERS
          </text>
          <heading tag="h2" size={38} weight={400} font={HEAD} color={INK} lh={1.25} mobile={{ size: 27 }}>
            The pro bono training route
          </heading>
          <text size={18} font={BODY} color={INK} lh={1.8}>
            We run a two-day training four times a year. Take one case, get a supervising solicitor on speed dial,
            and we handle the file management. 96 lawyers did this last year and 88 of them took a second case.
          </text>
          <text size={17} font={BODY} color="#4A4A4A" lh={1.75}>
            You do not need immigration experience. You need two days, a practising certificate, and roughly forty
            hours across the following year. We provide the precedents, the country evidence library, the expert
            list and a supervising solicitor who has run several hundred of these.
          </text>
          <text
            href="mailto:training@safepassage.org.uk"
            size={17}
            weight={700}
            font={BODY}
            color="#FFFFFF"
            bg={DEEP}
            pad={{ t: 14, b: 14, l: 26, r: 26 }}
            w="hug"
            m={{ t: 8 }}
            hover={{ bg: AMBER }}
          >
            Ask about the next training
          </text>
        </div>
        <div span={5} tw="flex flex-col gap-4" pad={0}>
          <img src={media.hands_documents.id} w="100%" h={300} fit="cover" mobile={{ h: 220 }} />
          <text size={15} font={BODY} color="#4A4A4A" lh={1.7}>
            Four trainings a year, in London, Manchester, Birmingham and online. The next one takes forty
            participants.
          </text>
        </div>
      </grid>
    </section>

    {/* 6 — where donations go */}
    <section tw="flex w-full justify-center px-6 py-24 max-md:px-5 max-md:py-14" bg={WASH}>
      <div tw="flex flex-col w-full max-w-[860px] gap-6" pad={0}>
        <text size={13} weight={700} ls={0.12} font={BODY} color={AMBER}>
          WHERE DONATIONS GO
        </text>
        <heading tag="h2" size={38} weight={400} font={HEAD} color={INK} lh={1.25} mobile={{ size: 27 }}>
          Line by line
        </heading>
        <text size={18} font={BODY} color={INK} lh={1.8} maxw={680} m={{ b: 8 }}>
          These are real unit costs from last year's accounts, not illustrative rounding. A monthly gift is worth
          more to us than the same amount once, because it lets us commit to a case before we know what it will
          need.
        </text>
        <div tw="flex flex-col w-full" pad={0}>
          <MoneyLine amount="£46" what="Covers an interpreter for a full appeal hearing." />
          <MoneyLine amount="£180" what="Covers a country expert report." />
          <MoneyLine amount="£2,400" what="Covers a case from first interview to determination." />
          <MoneyLine
            amount="86p"
            what="Of every pound goes to casework, the helpline and training. The rest is audit, insurance and the two people who keep the accounts straight."
          />
        </div>
      </div>
    </section>

    {/* 7 — governance and red lines */}
    <section tw="flex w-full justify-center px-6 py-24 max-md:px-5 max-md:py-14" bg={GROUND}>
      <div tw="flex flex-col w-full max-w-[860px] gap-6" pad={0}>
        <heading tag="h2" size={38} weight={400} font={HEAD} color={INK} lh={1.25} mobile={{ size: 27 }}>
          Governance, funding and our red lines
        </heading>
        <div tw="flex flex-col w-full" pad={0}>
          <GovRow
            label="RED LINES"
            body="We take no money from the Home Office, no money from detention or removal contractors, and we publish every funder over £5,000."
          />
          <GovRow
            label="GOVERNANCE"
            body="A board of nine trustees, three of whom arrived in this country as unaccompanied minors. Board minutes and the conflicts register are published twice a year."
          />
          <GovRow
            label="FUNDING SOURCES"
            body="61 percent individual donors, 24 percent trusts and foundations, 15 percent law firm partnerships. No statutory funding of any kind."
          />
          <GovRow
            label="SAFEGUARDING"
            body="Every caseworker and volunteer solicitor is DBS checked and trained in working with separated children. Complaints go to a trustee, not to staff."
          />
          <box h={1} w="100%" bg={LINE} pad={0} />
        </div>
      </div>
    </section>

    {/* 8 — give monthly */}
    <section id="give" tw="flex w-full justify-center px-6 py-24 max-md:px-5 max-md:py-16" bg={DEEP}>
      <div tw="flex flex-col w-full max-w-[860px] gap-6 items-start" pad={0}>
        <box h={3} w={72} bg={AMBER} pad={0} />
        <heading tag="h2" size={44} weight={400} font={HEAD} color="#FFFFFF" lh={1.2} mobile={{ size: 30 }}>
          Give monthly
        </heading>
        <text size={19} font={BODY} color="#D7E1EA" lh={1.7} maxw={680}>
          £20 a month keeps an interpreter in the room for five hearings a year. Cancel any time, in one email, with
          no follow-up call.
        </text>
        <div tw="flex flex-row gap-3 items-center max-md:flex-col max-md:items-start" pad={{ t: 8 }}>
          <text
            href="/donate/"
            size={17}
            weight={700}
            font={BODY}
            color={DEEP}
            bg={AMBER}
            pad={{ t: 15, b: 15, l: 28, r: 28 }}
            w="hug"
            hover={{ bg: '#FFFFFF' }}
          >
            £20 a month
          </text>
          <text
            href="/donate/"
            size={17}
            weight={700}
            font={BODY}
            color="#FFFFFF"
            border={[1, '#5C7C99']}
            pad={{ t: 15, b: 15, l: 28, r: 28 }}
            w="hug"
            hover={{ bg: '#1E4B72' }}
          >
            £46 a month
          </text>
          <text
            href="/donate/"
            size={17}
            weight={700}
            font={BODY}
            color="#FFFFFF"
            border={[1, '#5C7C99']}
            pad={{ t: 15, b: 15, l: 28, r: 28 }}
            w="hug"
            hover={{ bg: '#1E4B72' }}
          >
            Another amount
          </text>
        </div>
        <text size={15} font={BODY} color="#A9BBCB" lh={1.7} maxw={680} m={{ t: 8 }}>
          Safe Passage is a registered charity. Gift Aid adds 25p to every pound if you pay UK tax. If you need a
          lawyer rather than a way to give, call <strong>0800 555 0119</strong>.
        </text>
      </div>
    </section>

  </box>
);
