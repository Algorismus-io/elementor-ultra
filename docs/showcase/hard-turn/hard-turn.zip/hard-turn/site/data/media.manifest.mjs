/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "hard-turn--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'hard-turn--';

export default [
  { slot: `${PREFIX}print_detail`, file: join(MEDIA_DIR, "print_detail.jpg"), alt: "Close detail of a printed identity system" },
  { slot: `${PREFIX}studio_wall`, file: join(MEDIA_DIR, "studio_wall.jpg"), alt: "Studio wall pinned with work in progress" },
  { slot: `${PREFIX}team_working`, file: join(MEDIA_DIR, "team_working.jpg"), alt: "The Hard Turn team working through a rebrand" },
];
