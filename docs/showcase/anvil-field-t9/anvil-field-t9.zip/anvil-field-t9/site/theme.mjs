/** Anvil Field T9 — rugged computing hardware tokens. */
export default defineTheme({
  name: 'anvil-field-t9',
  color: {
    ground: '#101314',
    panel: '#191D1F',
    ink: '#DDE3E4',
    hazard: '#FFB000',
    line: '#2C3335',
    green: '#5FD08A',
    muted: '#8B9698',
  },
  font: { head: 'Saira Condensed', body: 'IBM Plex Sans' },
  mode: 'literal',
});
