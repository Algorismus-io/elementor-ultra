/** Loud Quarry — poster-wall tokens. */
export default defineTheme({
  name: 'loud-quarry',
  color: {
    ground: '#101014',
    ink: '#F2F0EA',
    acid: '#D9FF00',
    hot: '#FF1F5A',
    cool: '#00B7FF',
  },
  font: { head: 'Bungee', body: 'Space Grotesk' },
  mode: 'literal',
});
