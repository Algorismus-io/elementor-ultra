/** Housecell design tokens — home energy hardware, dark bento. */
export default defineTheme({
  name: 'housecell',
  color: {
    ground: '#0E1712',   // page background
    tile: '#152119',     // bento tile
    ink: '#E9F2EC',      // primary text
    charge: '#5BE38A',   // charge / savings accent
    grid: '#F2B138',     // grid / tariff accent
    line: '#24352B',     // hairline borders
    dim: '#9BB3A4',      // secondary text
  },
  font: { head: 'Big Shoulders Display', body: 'Archivo' },
  mode: 'literal',
});
