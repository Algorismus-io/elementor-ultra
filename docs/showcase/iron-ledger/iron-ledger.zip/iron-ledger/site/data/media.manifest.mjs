/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "iron-ledger--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'iron-ledger--';

export default [
  { slot: `${PREFIX}battle_map`, file: join(MEDIA_DIR, "battle_map.jpg"), alt: "Campaign map of the retreat, roads and river crossings marked in chalk" },
  { slot: `${PREFIX}camp_night`, file: join(MEDIA_DIR, "camp_night.jpg"), alt: "The column camped at night, wagons drawn up around low fires" },
  { slot: `${PREFIX}ledger_still`, file: join(MEDIA_DIR, "ledger_still.jpg"), alt: "The supply ledger open on a field desk, grain columns tallied by hand" },
];
