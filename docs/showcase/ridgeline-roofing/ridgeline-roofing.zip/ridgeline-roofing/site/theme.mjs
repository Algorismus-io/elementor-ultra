/** Ridgeline Roof & Gutter — design tokens. */
export default defineTheme({
  name: 'ridgeline',
  color: {
    ground: '#FBFAF7',   // page background
    ink: '#151719',      // display text / dark bands
    ink2: '#1E2225',     // raised surface on dark bands
    slate: '#37474F',    // secondary body copy
    signal: '#E8501B',   // price, CTA, emphasis
    rule: '#D6D2CB',     // hairlines, borders
    dim: '#9AA3A8',      // body copy on dark
    white: '#FFFFFF',
  },
  font: { head: 'Archivo Black', body: 'Barlow' },
  mode: 'literal',
});
