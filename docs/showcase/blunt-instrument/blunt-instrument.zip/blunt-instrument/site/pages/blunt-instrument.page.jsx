import { defineComponent } from 'elementor-jsx';

/** Blunt Instrument — oversized type as layout. */
export const meta = {
  title: 'Blunt Instrument',
  slug: 'blunt-instrument',
  seo: {
    title: 'Blunt Instrument — paid acquisition on a flat fee',
    description:
      'Blunt Instrument runs paid acquisition for eleven DTC brands on a flat monthly fee of £11,500. No percentage of spend, published results including the accounts we lost, two months notice either way.',
  },
};

/* palette — literals here so registered components render without theme context */
const GROUND = '#000000';
const INK = '#FFFFFF';
const YELL = '#FFE600';
const BLOOD = '#FF2D2D';
const GREY = '#666666';
const HEAD = 'Unbounded';
const BODY = 'Plus Jakarta Sans';

const RULE_TOP = 'border-top:1px solid #262626;';
const BREAK = 'overflow-wrap:anywhere; word-break:break-word;';
const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* ── results board rows: content-only props, two registered variants (kept / lost) ── */

const KeptRow = defineComponent(
  ({ brand = '', shape = '', mer = '', spend = '', note = '' }) => (
    <grid
      cols={12}
      gap={16}
      w="100%"
      pad={{ t: 26, b: 26 }}
      raw={RULE_TOP}
      mobile={{ gridCols: 1, gap: 6, pad: { t: 18, b: 18 } }}
    >
      <text span={4} font={HEAD} size={26} weight={600} color={INK} lh={1.1} mobile={{ size: 20, span: 12 }}>
        {brand}
      </text>
      <text span={2} font={BODY} size={13} weight={600} ls="1px" color={GREY} tw="uppercase" mobile={{ span: 12 }}>
        {shape}
      </text>
      <text span={2} font={HEAD} size={26} weight={600} color={YELL} mobile={{ size: 20, span: 12 }}>
        {mer}
      </text>
      <text span={2} font={BODY} size={15} color={INK} mobile={{ span: 12 }}>
        {spend}
      </text>
      <text span={2} font={BODY} size={14} color={GREY} lh={1.45} mobile={{ span: 12 }}>
        {note}
      </text>
    </grid>
  ),
  {
    title: 'Result row — kept',
    props: {
      brand: { label: 'Brand', group: 'Row' },
      shape: { label: 'Category', group: 'Row' },
      mer: { label: 'MER', group: 'Row' },
      spend: { label: 'Spend', group: 'Row' },
      note: { label: 'Note', group: 'Row' },
    },
  },
);

const LostRow = defineComponent(
  ({ brand = '', shape = '', mer = '', spend = '', note = '' }) => (
    <grid
      cols={12}
      gap={16}
      w="100%"
      pad={{ t: 26, b: 26 }}
      raw={RULE_TOP}
      mobile={{ gridCols: 1, gap: 6, pad: { t: 18, b: 18 } }}
    >
      <text span={4} font={HEAD} size={26} weight={600} color={BLOOD} lh={1.1} mobile={{ size: 20, span: 12 }}>
        {brand}
      </text>
      <text span={2} font={BODY} size={13} weight={600} ls="1px" color={GREY} tw="uppercase" mobile={{ span: 12 }}>
        {shape}
      </text>
      <text span={2} font={HEAD} size={26} weight={600} color={BLOOD} mobile={{ size: 20, span: 12 }}>
        {mer}
      </text>
      <text span={2} font={BODY} size={15} color={GREY} mobile={{ span: 12 }}>
        {spend}
      </text>
      <text span={2} font={BODY} size={14} color={INK} lh={1.45} mobile={{ span: 12 }}>
        {note}
      </text>
    </grid>
  ),
  {
    title: 'Result row — lost',
    props: {
      brand: { label: 'Brand', group: 'Row' },
      shape: { label: 'Category', group: 'Row' },
      mer: { label: 'MER', group: 'Row' },
      spend: { label: 'Spend', group: 'Row' },
      note: { label: 'Note', group: 'Row' },
    },
  },
);

/* ── the page ── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>

    {/* 1 ─ statement wall */}
    <section
      w="100%"
      pad={{ t: 40, b: 96, l: 32, r: 32 }}
      gap={0}
      bg={t.color.ground}
      mobile={{ pad: { t: 28, b: 56, l: 18, r: 18 } }}
    >
      <row w="100%" justify="space-between" align="center" gap={16} wrap="wrap" pad={{ b: 24 }} raw="border-bottom:1px solid #262626;" mobile={{ dir: 'column', align: 'flex-start', gap: 8 }}>
        <text font={HEAD} size={14} weight={700} ls="1px" color={t.color.ink} tw="uppercase">
          Blunt Instrument
        </text>
        <text font={BODY} size={12} weight={600} ls="2px" color={t.color.grey} tw="uppercase" mobile={{ size: 10 }}>
          Paid acquisition · Eleven DTC brands
        </text>
      </row>

      <h1
        tw="text-[20vw] leading-[0.80] tracking-[-0.045em] uppercase"
        font={HEAD}
        weight={800}
        color={t.color.ink}
        pad={{ t: 40 }}
        raw={BREAK + ' & em { color:#FFE600; font-style:normal; } & strong { color:#FF2D2D; font-weight:800; }'}
      >
        We do <strong>not</strong> take a <em>percentage</em> of your ad spend.
      </h1>

      <grid cols={12} gap={40} w="100%" pad={{ t: 56 }} mobile={{ gap: 28, pad: { t: 32 } }}>
        <text span={7} font={BODY} size={22} lh={1.5} color={t.color.ink} mobile={{ size: 17, span: 12 }}>
          Blunt Instrument runs paid acquisition for eleven DTC brands on a flat monthly fee. When your spend goes up we
          earn the same, which is the only way this relationship stays honest.
        </text>
        <box span={5} gap={16} align="flex-start" mobile={{ span: 12 }}>
          <text
            href="#book"
            font={HEAD}
            size={17}
            weight={700}
            color={t.color.ground}
            bg={t.color.yell}
            pad={{ t: 20, b: 20, l: 30, r: 30 }}
            tw="uppercase"
            hover={{ bg: t.color.blood, color: t.color.ink }}
          >
            Book a teardown call
          </text>
          <text font={BODY} size={14} lh={1.5} color={t.color.grey}>
            Forty minutes. We open your account, say what is wrong, and you keep the notes whether or not you hire us.
          </text>
        </box>
      </grid>
    </section>

    {/* 2 ─ the flat fee */}
    <section
      w="100%"
      pad={{ t: 96, b: 96, l: 32, r: 32 }}
      gap={0}
      bg={t.color.yell}
      mobile={{ pad: { t: 56, b: 56, l: 18, r: 18 } }}
    >
      <text font={BODY} size={13} weight={700} ls="2px" color={t.color.ground} tw="uppercase">
        01 — The fee
      </text>
      <h2
        tw="text-[17vw] leading-[0.82] tracking-[-0.05em]"
        raw={BREAK}
        font={HEAD}
        weight={800}
        color={t.color.ground}
        pad={{ t: 12 }}
        motion={FADE}
      >
        £11,500
      </h2>
      <text
        font={HEAD}
        size={38}
        weight={700}
        lh={1.05}
        color={t.color.ground}
        tw="uppercase"
        pad={{ b: 44 }}
        mobile={{ size: 22 }}
      >
        a month, flat, all channels, all creative
      </text>

      <grid cols={12} gap={40} w="100%" pad={{ t: 44 }} raw="border-top:2px solid #000000;" mobile={{ gap: 24 }}>
        <text span={6} font={BODY} size={21} lh={1.5} color={t.color.ground} mobile={{ size: 17, span: 12 }}>
          That is the number whether you spend 40k or 400k, and we will tell you when to spend less.
        </text>
        <box span={6} gap={22} mobile={{ span: 12 }}>
          <h3 font={HEAD} size={22} weight={700} lh={1.2} color={t.color.ground} tw="uppercase" mobile={{ size: 18 }}>
            Why percentage of spend corrupts
          </h3>
          <text font={BODY} size={17} lh={1.55} color={t.color.ground}>
            An agency on 10% of spend has one lever it will always pull: more spend. It will not tell you the third
            channel is buying customers you already had. It will not cap a campaign that is printing volume at a payback
            you cannot finance. We have watched it happen from the inside, twice.
          </text>
          <text font={BODY} size={17} lh={1.55} color={t.color.ground}>
            On a flat fee the only way we grow is by keeping you, so we argue with you about efficiency instead of
            selling you scale you did not ask for.
          </text>
        </box>
      </grid>
    </section>

    {/* 3 ─ results board */}
    <section
      w="100%"
      pad={{ t: 104, b: 104, l: 32, r: 32 }}
      gap={0}
      bg={t.color.ground}
      mobile={{ pad: { t: 60, b: 60, l: 18, r: 18 } }}
    >
      <text font={BODY} size={13} weight={700} ls="2px" color={t.color.grey} tw="uppercase">
        02 — The board
      </text>
      <h2
        tw="text-[9vw] leading-[0.9] tracking-[-0.04em] uppercase"
        raw={BREAK}
        font={HEAD}
        weight={800}
        color={t.color.ink}
        pad={{ t: 12, b: 40 }}
      >
        Results, <em>including</em> the three we lost
      </h2>

      <grid cols={12} gap={40} w="100%" pad={{ b: 56 }} mobile={{ gap: 22 }}>
        <text span={6} font={BODY} size={19} lh={1.55} color={t.color.ink} mobile={{ size: 16, span: 12 }}>
          Best twelve months: a supplement brand from 2.1 to 3.4 blended MER on 4x the spend.
        </text>
        <text span={6} font={BODY} size={19} lh={1.55} color={t.color.blood} mobile={{ size: 16, span: 12 }}>
          Worst: a furniture brand we could not move past 1.6, where we resigned the account in month five and refunded
          month four.
        </text>
      </grid>

      <box w="100%" gap={0} motion={FADE}>
        <KeptRow brand="Supplements" shape="Subscription" mer="2.1 → 3.4" spend="4x spend" note="Held for 26 months, still running." />
        <KeptRow brand="Skincare" shape="DTC + Amazon" mer="1.9 → 2.8" spend="2.2x spend" note="Cut two channels in week three." />
        <KeptRow brand="Outdoor apparel" shape="Seasonal" mer="2.4 → 3.1" spend="3x spend" note="Creative volume did all of it." />
        <LostRow brand="Furniture" shape="High AOV" mer="1.6 → 1.6" spend="Flat" note="Resigned month five. Refunded month four." />
        <LostRow brand="Pet nutrition" shape="Subscription" mer="2.7 → 2.2" spend="1.4x spend" note="They left for a shop on 12% of spend." />
        <LostRow brand="Men's basics" shape="Low AOV" mer="1.4 → 1.5" spend="Flat" note="A 34% return rate we were never going to fix with ads." />
      </box>
      <text font={BODY} size={14} lh={1.5} color={t.color.grey} pad={{ t: 26 }} raw={RULE_TOP}>
        Blended MER, first month against best rolling twelve. Every account we have ever run is on this board.
      </text>
    </section>

    {/* 4 ─ how we run an account */}
    <section
      w="100%"
      pad={{ t: 104, b: 104, l: 32, r: 32 }}
      gap={0}
      grad={[180, '#000000', '#141414']}
      mobile={{ pad: { t: 60, b: 60, l: 18, r: 18 } }}
    >
      <text font={BODY} size={13} weight={700} ls="2px" color={t.color.grey} tw="uppercase" pad={{ b: 44 }}>
        03 — The week
      </text>

      <grid cols={12} gap={32} w="100%" pad={{ t: 34, b: 34 }} raw={RULE_TOP} mobile={{ gap: 10 }}>
        <heading
          tag="h3"
          span={5}
          tw="text-[7vw] leading-[0.9] tracking-[-0.04em] uppercase"
          raw={BREAK}
          font={HEAD}
          weight={800}
          color={t.color.yell}
          mobile={{ span: 12 }}
        >
          Monday
        </heading>
        <text span={7} font={BODY} size={22} lh={1.5} color={t.color.ink} mobile={{ size: 17, span: 12 }}>
          We look at cohort payback, not ROAS. Platform numbers are a claim, not a fact, and thirty day payback is the
          only figure your bank agrees with.
        </text>
      </grid>

      <grid cols={12} gap={32} w="100%" pad={{ t: 34, b: 34 }} raw={RULE_TOP} mobile={{ gap: 10 }}>
        <heading
          tag="h3"
          span={5}
          tw="text-[7vw] leading-[0.9] tracking-[-0.04em] uppercase"
          raw={BREAK}
          font={HEAD}
          weight={800}
          color={t.color.ink}
          mobile={{ span: 12 }}
        >
          Wednesday
        </heading>
        <text span={7} font={BODY} size={22} lh={1.5} color={t.color.ink} mobile={{ size: 17, span: 12 }}>
          We ship three new creative concepts. Not three edits of the same concept. Three arguments for why someone
          should buy the thing.
        </text>
      </grid>

      <grid cols={12} gap={32} w="100%" pad={{ t: 34, b: 34 }} raw={RULE_TOP} mobile={{ gap: 10 }}>
        <heading
          tag="h3"
          span={5}
          tw="text-[7vw] leading-[0.9] tracking-[-0.04em] uppercase"
          raw={BREAK}
          font={HEAD}
          weight={800}
          color={t.color.blood}
          mobile={{ span: 12 }}
        >
          Friday
        </heading>
        <text span={7} font={BODY} size={22} lh={1.5} color={t.color.ink} mobile={{ size: 17, span: 12 }}>
          We kill whatever is below threshold, including things we made and liked. You get one page on what died and
          what replaced it, and nobody schedules a call about it.
        </text>
      </grid>
    </section>

    {/* 5 ─ creative */}
    <section
      w="100%"
      pad={{ t: 104, b: 104, l: 32, r: 32 }}
      gap={0}
      bg={t.color.blood}
      mobile={{ pad: { t: 60, b: 60, l: 18, r: 18 } }}
    >
      <text font={BODY} size={13} weight={700} ls="2px" color={t.color.ground} tw="uppercase">
        04 — Creative
      </text>
      <h2
        tw="text-[10vw] leading-[0.86] tracking-[-0.045em] uppercase"
        raw={BREAK}
        font={HEAD}
        weight={800}
        color={t.color.ground}
        pad={{ t: 12, b: 44 }}
        motion={FADE}
      >
        We shoot it. We do not brief it out.
      </h2>

      <grid cols={12} gap={40} w="100%" pad={{ t: 44 }} raw="border-top:2px solid #000000;" mobile={{ gap: 24 }}>
        <text span={7} font={BODY} size={21} lh={1.5} color={t.color.ground} mobile={{ size: 17, span: 12 }}>
          We have a studio and two editors. We shoot your product ourselves, weekly, because the bottleneck is never
          targeting and has not been since 2021.
        </text>
        <box span={5} gap={18} mobile={{ span: 12 }}>
          <text font={HEAD} size={54} weight={800} lh={1} color={t.color.ink} mobile={{ size: 38 }}>
            12–20
          </text>
          <text font={BODY} size={16} lh={1.5} color={t.color.ground}>
            new assets a week per account, cut for the placement they run in, not resized after the fact.
          </text>
        </box>
      </grid>
    </section>

    {/* 6 ─ who this is wrong for */}
    <section
      w="100%"
      pad={{ t: 104, b: 104, l: 32, r: 32 }}
      gap={0}
      bg={t.color.ground}
      mobile={{ pad: { t: 60, b: 60, l: 18, r: 18 } }}
    >
      <text font={BODY} size={13} weight={700} ls="2px" color={t.color.grey} tw="uppercase">
        05 — Fit
      </text>
      <h2
        tw="text-[12vw] leading-[0.86] tracking-[-0.045em] uppercase"
        raw={BREAK}
        font={HEAD}
        weight={800}
        color={t.color.blood}
        pad={{ t: 12, b: 48 }}
      >
        Wrong for you if
      </h2>

      <grid cols={12} gap={40} w="100%" mobile={{ gap: 28 }}>
        <box span={4} gap={14} pad={{ t: 26 }} raw="border-top:3px solid #FF2D2D;" mobile={{ span: 12 }}>
          <text font={HEAD} size={30} weight={800} color={t.color.ink} mobile={{ size: 24 }}>
            Under 30k
          </text>
          <text font={BODY} size={17} lh={1.55} color={t.color.grey}>
            a month in spend. The fee eats too much of the account and we would be taking your money.
          </text>
        </box>
        <box span={4} gap={14} pad={{ t: 26 }} raw="border-top:3px solid #FF2D2D;" mobile={{ span: 12 }}>
          <text font={HEAD} size={30} weight={800} color={t.color.ink} mobile={{ size: 24 }}>
            Agency of record
          </text>
          <text font={BODY} size={17} lh={1.55} color={t.color.grey}>
            theatre. Quarterly offsites, a named strategist who never opens the account, a brand platform.
          </text>
        </box>
        <box span={4} gap={14} pad={{ t: 26 }} raw="border-top:3px solid #FF2D2D;" mobile={{ span: 12 }}>
          <text font={HEAD} size={30} weight={800} color={t.color.ink} mobile={{ size: 24 }}>
            40 slide decks
          </text>
          <text font={BODY} size={17} lh={1.55} color={t.color.grey}>
            for your board every month. We send a one-page memo and a loom.
          </text>
        </box>
      </grid>
    </section>

    {/* 7 ─ the exit clause */}
    <section
      w="100%"
      pad={{ t: 104, b: 104, l: 32, r: 32 }}
      gap={0}
      bg={t.color.ink}
      mobile={{ pad: { t: 60, b: 60, l: 18, r: 18 } }}
    >
      <text font={BODY} size={13} weight={700} ls="2px" color={GREY} tw="uppercase">
        06 — The exit
      </text>
      <h2
        tw="text-[16vw] leading-[0.82] tracking-[-0.05em] uppercase"
        font={HEAD}
        weight={800}
        color={t.color.ground}
        pad={{ t: 12 }}
        raw={BREAK + ' & em { background:#FFE600; font-style:normal; }'}
      >
        <em>Two months</em> either way
      </h2>
      <grid cols={12} gap={40} w="100%" pad={{ t: 48 }} raw="border-top:2px solid #000000;" mobile={{ gap: 22 }}>
        <text span={7} font={BODY} size={22} lh={1.5} color={t.color.ground} mobile={{ size: 17, span: 12 }}>
          Two months notice either way, and we hand over every account, pixel, creative file and audience without a call
          about it.
        </text>
        <text span={5} font={BODY} size={16} lh={1.55} color={GREY} mobile={{ span: 12 }}>
          No retention meeting, no win-back offer, no clause that makes the ad account ours. Everything was built in
          your business manager from day one because it was always yours.
        </text>
      </grid>
    </section>

    {/* 8 ─ book a teardown call (the page's single centred section) */}
    <section
      id="book"
      w="100%"
      pad={{ t: 120, b: 120, l: 32, r: 32 }}
      gap={26}
      align="center"
      ta="center"
      bg={t.color.ground}
      mobile={{ pad: { t: 70, b: 70, l: 18, r: 18 } }}
    >
      <text font={BODY} size={13} weight={700} ls="2px" color={t.color.grey} tw="uppercase">
        07 — Next
      </text>
      <h2
        tw="text-[10vw] leading-[0.86] tracking-[-0.045em] uppercase"
        raw={BREAK}
        font={HEAD}
        weight={800}
        color={t.color.yell}
        ta="center"
        motion={FADE}
      >
        Book a teardown call
      </h2>
      <text font={BODY} size={21} lh={1.5} color={t.color.ink} maxw={720} ta="center" mobile={{ size: 17 }}>
        Send us the account and forty minutes. We will tell you what we would change in week one, what we would kill,
        and whether £11,500 a month is worth it for a business your size. Sometimes the answer is no.
      </text>
      <text
        href="mailto:teardown@bluntinstrument.co"
        font={HEAD}
        size={19}
        weight={700}
        color={t.color.ground}
        bg={t.color.yell}
        pad={{ t: 22, b: 22, l: 38, r: 38 }}
        tw="uppercase"
        raw={BREAK}
        hover={{ bg: t.color.blood, color: t.color.ink }}
        mobile={{ size: 13, pad: { t: 18, b: 18, l: 16, r: 16 } }}
      >
        teardown@bluntinstrument.co
      </text>
      <text font={BODY} size={13} ls="1px" color={t.color.grey} tw="uppercase" ta="center">
        Blunt Instrument · Flat fee · No percentage of spend
      </text>
    </section>
  </box>
);
