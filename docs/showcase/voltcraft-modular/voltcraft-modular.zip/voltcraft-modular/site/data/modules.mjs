/** The twelve-module range. +12V sums to 640mA, -12V to 310mA. */
export const MODULES = [
  { name: 'VX-1', kind: 'Quad Attenuverter', hp: 8, plus: 22, minus: 18, note: 'DC-coupled, unity gain at centre detent, four channels normalled down', price: 119 },
  { name: 'VX-2', kind: 'Noise & Sample', hp: 6, plus: 24, minus: 14, note: 'Transistor avalanche noise, white and pink outputs, clocked S&H', price: 129 },
  { name: 'VX-3', kind: 'Dual VCO', hp: 14, plus: 78, minus: 32, note: 'Through-zero FM, matched pair, 0.2 cent drift over an hour', price: 289 },
  { name: 'VX-4', kind: 'Ladder VCF', hp: 10, plus: 46, minus: 40, note: 'Four-pole transistor ladder, self-oscillating, gain compensation trim', price: 219 },
  { name: 'VX-5', kind: 'State Variable VCF', hp: 12, plus: 52, minus: 44, note: 'Simultaneous LP, HP, BP and notch, 1V/oct tracking to five octaves', price: 239 },
  { name: 'VX-6', kind: 'Dual ADSR', hp: 10, plus: 38, minus: 20, note: 'Two envelopes, 0.8ms to 24s, end-of-cycle gate on both channels', price: 169 },
  { name: 'VX-7', kind: 'Function Generator', hp: 8, plus: 44, minus: 26, note: 'Slew, LFO and AD in one, cycles into audio at 6kHz, voltage controlled', price: 189 },
  { name: 'VX-8', kind: 'Stereo VCA', hp: 8, plus: 40, minus: 34, note: 'Linear and exponential response, discrete output stage, 1dB channel match', price: 159 },
  { name: 'VX-9', kind: 'Analogue Delay', hp: 16, plus: 92, minus: 38, note: 'Two BBD lines, 18ms to 640ms, companding with a defeatable clock filter', price: 329 },
  { name: 'VX-10', kind: 'Spring Reverb', hp: 12, plus: 74, minus: 22, note: 'Three-spring tank, dwell and tone controls, tank socket on the rear', price: 249 },
  { name: 'VX-11', kind: 'Sequencer 8', hp: 20, plus: 86, minus: 12, note: 'Eight steps, two rows, analogue gate bus and a hand-wired step switch', price: 279 },
  { name: 'VX-12', kind: 'Output & Cue', hp: 10, plus: 44, minus: 10, note: 'Balanced outs on the rear, cue bus, and a headphone amp that drives 32 ohm', price: 179 },
];

export const PATCHES = [
  { n: '01', title: 'Through-zero drone', mods: 'VX-3 · VX-5 · VX-10', body: 'Both VCO cores at 55Hz, one modulating the other through zero, into the state variable filter in notch and out to the spring tank at full dwell. Sits still for twenty minutes and never repeats.' },
  { n: '02', title: 'Ladder kick', mods: 'VX-4 · VX-6 · VX-8', body: 'Self-oscillate the ladder, pitch it with a fast decay envelope, and shape the tail on the exponential VCA. Tune the resonance trimmer for the body you want.' },
  { n: '03', title: 'Clocked sample chatter', mods: 'VX-2 · VX-11 · VX-3', body: 'Sample and hold on white noise, clocked from the sequencer gate bus, into the second VCO exponential input. Attenuvert it down until it is pitch and not noise.' },
  { n: '04', title: 'Two-hand generative', mods: 'VX-7 · VX-1 · VX-5', body: 'Two function generators cycling at unrelated rates, cross-patched through the attenuverter to each other, sweeping the filter cutoff from both directions at once.' },
  { n: '05', title: 'BBD feedback bed', mods: 'VX-9 · VX-8 · VX-12', body: 'Delay output back into its own input past unity, VCA in the loop to keep it from running away, cue bus so you can hear it building before it hits the mix.' },
  { n: '06', title: 'West coast bass', mods: 'VX-3 · VX-7 · VX-8', body: 'Single VCO into the function generator used as a lowpass gate substitute, struck by the sequencer gates. Short strikes, long strikes, one knob between them.' },
];

export const CASES = [
  { label: '84HP skiff, 1.4A supply', hp: '84HP', budget: '1400 / 1200mA', verdict: 'Six modules comfortably', tone: 'ok' },
  { label: '104HP two-row, 2A supply', hp: '104HP', budget: '2000 / 1500mA', verdict: 'The full range, headroom to spare', tone: 'ok' },
  { label: '84HP with a 1A brick', hp: '84HP', budget: '1000 / 500mA', verdict: 'Cutting it fine past nine modules', tone: 'watch' },
  { label: '62HP portable, 0.6A supply', hp: '62HP', budget: '600 / 300mA', verdict: 'Four modules, and skip the delay', tone: 'watch' },
];
