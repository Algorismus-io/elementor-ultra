/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "toolbelt-academy--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'toolbelt-academy--';

export default [
  { slot: `${PREFIX}apprentice_site`, file: join(MEDIA_DIR, "apprentice_site.jpg"), alt: "Apprentice electrician working on a live construction site" },
  { slot: `${PREFIX}toolbox`, file: join(MEDIA_DIR, "toolbox.jpg"), alt: "Open toolbox with hand tools laid out" },
  { slot: `${PREFIX}welding_sparks`, file: join(MEDIA_DIR, "welding_sparks.jpg"), alt: "Welder striking an arc, sparks flying" },
];
