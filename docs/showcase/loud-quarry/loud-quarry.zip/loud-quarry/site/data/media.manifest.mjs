/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "loud-quarry--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'loud-quarry--';

export default [
  { slot: `${PREFIX}camp_morning`, file: join(MEDIA_DIR, "camp_morning.jpg"), alt: "Tents in the quarry campsite at first light" },
  { slot: `${PREFIX}crowd_close`, file: join(MEDIA_DIR, "crowd_close.jpg"), alt: "Crowd pressed to the barrier at the front of a stage" },
  { slot: `${PREFIX}quarry_night`, file: join(MEDIA_DIR, "quarry_night.jpg"), alt: "Floodlit granite quarry walls at night" },
];
