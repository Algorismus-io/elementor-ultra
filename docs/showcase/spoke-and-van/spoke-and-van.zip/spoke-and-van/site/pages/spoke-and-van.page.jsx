/** Spoke & Van — mobile bicycle repair. Map-first geographic landing page. */
import { defineComponent } from 'elementor-jsx';
import { img as pic, srcAlt as picAlt, has as hasPic } from '../data/media.mjs';

export const meta = {
  title: 'Spoke & Van — mobile bike repair at your kerb',
  slug: 'spoke-and-van',
  seo: {
    title: 'Spoke & Van — mobile bike repair across seven city zones',
    description:
      'A fully equipped bike workshop in a van. Book a two-hour window, leave the bike locked outside your office or flat, and get a text when it is done.',
  },
};

/* ── data ─────────────────────────────────────────────────────────────── */

const ZONES = [
  { code: 'Z1', name: 'Old Town',    slots: '3 slots left today', when: 'Daily · 07:00–19:00', span: 5, live: true },
  { code: 'Z2', name: 'Riverside',   slots: '2 slots left today', when: 'Daily · 07:00–19:00', span: 4, live: true },
  { code: 'Z3', name: 'Gasworks',    slots: '4 slots left today', when: 'Daily · 07:00–19:00', span: 3, live: true },
  { code: 'Z4', name: 'Northgate',   slots: '1 slot left today',  when: 'Daily · 07:00–19:00', span: 5, live: true },
  { code: 'Z5', name: 'Elmfield',    slots: 'Next: Thu 08:00',    when: 'Tuesday and Thursday', span: 3, live: false },
  { code: 'Z6', name: 'Harbour Row', slots: 'Next: Tue 13:00',    when: 'Tuesday and Thursday', span: 4, live: false },
  { code: 'Z7', name: 'Longbank',    slots: 'Saturday · 2 left',  when: 'Saturday mornings, books out by Wednesday', span: 12, live: false },
];

const PRICES = [
  { job: 'Puncture',                 price: '18', note: 'Tube included, 20 minutes at the kerb' },
  { job: 'Full service',             price: '79', note: 'Drivetrain, brakes, gears, bearings, safety check' },
  { job: 'Brake bleed',              price: '45', note: 'Per end' },
  { job: 'Gear index and cable',     price: '32', note: 'Inner cable and outer where needed' },
  { job: 'Wheel true',               price: '25', note: 'Per wheel, on the truing stand in the van' },
  { job: 'Chain and cassette',       price: '68', note: 'Fitted, from — plus parts' },
];

const STOCK = ['Tubes in six sizes', 'Pads for every common caliper', 'Chains', 'Cables, inner and outer', 'Bearings and cups', 'Truing stand'];

const LIMITS = [
  { job: 'Bottom bracket press-fit', why: 'Needs the press and a bench that does not move' },
  { job: 'Frame alignment',          why: 'Needs the alignment table' },
  { job: 'E-bike motor teardown',    why: 'Needs the diagnostic rig and a clean bench' },
];

const TAPS = [
  { n: '01', head: 'Pick your zone',     body: 'Seven zones, each with its own days. The map shows what is left today before you type anything.' },
  { n: '02', head: 'Pick a two-hour window', body: 'Tell us the bike, and what it is doing. A photo helps if something is bent.' },
  { n: '03', head: 'Lock it and go back to work', body: 'Leave it outside. We text you when it is done and take payment on the link.' },
];

const FLEET_FACTS = [
  { k: 'From', v: '6 bikes' },
  { k: 'Visits', v: 'One a month' },
  { k: 'Records', v: 'Everything logged' },
  { k: 'Billing', v: 'Invoiced quarterly' },
];

/* ── page ─────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => {
  const C = t.color;
  const line = '#2C3A2F';
  const dim = '#9DAE9B';
  const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

  /* repeaters — content props only (Elementor components cannot override styles) */

  /* visual variants are separate registered components — a component prop may never feed styles */
  const zoneTile = (accent, badge) =>
    ({ code = 'Z1', name = 'Zone', slots = '', when = '' }) => (
      <box
        cls="zone-tile"
        tw="flex flex-col gap-2 w-full hover:border-[#C6FF3D]"
        pad={{ t: 16, r: 16, b: 16, l: 16 }}
        radius={8}
        bg={C.ground}
        border={[1, line]}
        minh={124}
      >
        <box tw="flex flex-row items-center justify-between w-full" gap={10}>
          <text size={13} font={t.font.body} weight={700} color={accent} tw="tracking-[0.16em] uppercase">
            {code}
          </text>
          <text size={11} font={t.font.body} color={accent} tw="tracking-[0.14em] uppercase">
            {badge}
          </text>
        </box>
        <heading tag="h3" size={30} font={t.font.head} color={C.ink} lh={1} tw="tracking-[0.02em]">
          {name}
        </heading>
        <text size={15} font={t.font.body} weight={700} color={C.ink} lh={1.3}>
          {slots}
        </text>
        <text size={12.5} font={t.font.body} color={dim} lh={1.4}>
          {when}
        </text>
      </box>
    );

  const ZONE_PROPS = {
    code: { label: 'Zone code', group: 'Zone' },
    name: { label: 'Zone name', group: 'Zone' },
    slots: { label: 'Slots line', group: 'Availability' },
    when: { label: 'Days line', group: 'Availability' },
  };
  const ZoneTileLive = defineComponent(zoneTile(C.hi, 'Van out now'), { title: 'Zone tile — van out now', props: ZONE_PROPS });
  const ZoneTileScheduled = defineComponent(zoneTile(C.van, 'Scheduled'), { title: 'Zone tile — scheduled', props: ZONE_PROPS });

  const PriceRow = defineComponent(
    ({ job = 'Job', price = '0', note = '' }) => (
      <box cls="price-row" tw="flex flex-col gap-1 w-full" pad={{ t: 18, b: 18 }} border={[1, line]}>
        <box tw="flex flex-row items-center justify-between w-full" gap={16}>
          <heading tag="h3" size={30} font={t.font.head} color={C.ink} lh={1} tw="tracking-[0.02em]">
            {job}
          </heading>
          <text size={30} font={t.font.head} color={C.hi} lh={1} tw="tracking-[0.02em]">
            {price}
          </text>
        </box>
        <text size={13.5} font={t.font.body} color={dim} lh={1.45}>
          {note}
        </text>
      </box>
    ),
    {
      title: 'Price row',
      props: {
        job: { label: 'Job', group: 'Price' },
        price: { label: 'Price', group: 'Price' },
        note: { label: 'Note', group: 'Price' },
      },
    },
  );

  const Eyebrow = ({ children, color }) => (
    <text size={12} font={t.font.body} weight={700} color={color || C.hi} tw="tracking-[0.22em] uppercase">
      {children}
    </text>
  );

  /* photo slot — the real image once sideloaded, a tinted plate that holds the layout until then */
  const Photo = ({ slot, h, mobileH, radius = 0, motion }) =>
    hasPic(slot) ? (
      <img src={pic(slot)} alt={picAlt(slot)} w="100%" h={h} fit="cover" radius={radius} mobile={{ h: mobileH }} motion={motion} />
    ) : (
      <box
        w="100%"
        h={h}
        radius={radius}
        bg={C.panel}
        mobile={{ h: mobileH }}
        motion={motion}
        raw="background-image: repeating-linear-gradient(135deg, rgba(242,247,239,.05) 0 12px, transparent 12px 24px);"
      />
    );

  const Chip = ({ children }) => (
    <text
      size={13}
      font={t.font.body}
      color={C.ink}
      pad={{ t: 8, r: 14, b: 8, l: 14 }}
      radius={999}
      border={[1, line]}
      tw="hover:border-[#C6FF3D]"
    >
      {children}
    </text>
  );

  return (
    <box tw="flex flex-col w-full items-center" pad={0} bg={C.ground}>
      {/* ── 1. Coverage map + today's remaining slots ───────────────────── */}
      <section tw="flex flex-col w-full items-center" pad={{ t: 28, r: 24, b: 96, l: 24 }} bg={C.ground}>
        <box tw="flex flex-row items-center justify-between w-full" maxw={1240} gap={16} pad={{ t: 0, b: 44 }}>
          <Eyebrow>Spoke &amp; Van · Mobile bike workshop</Eyebrow>
          <text size={12} font={t.font.body} color={dim} tw="tracking-[0.14em] uppercase max-md:hidden">
            Seven zones · Mon to Sat
          </text>
        </box>

        <grid cols="1fr 1.15fr" gap={56} w="100%" maxw={1240} mobile={{ gridCols: 1, gap: 40 }} tablet={{ gridCols: 1, gap: 44 }}>
          <box tw="flex flex-col items-start gap-7 w-full">
            <h1
              size={92}
              font={t.font.head}
              color={C.ink}
              lh={0.9}
              w="100%"
              tw="tracking-[0.01em]"
              tablet={{ size: 72 }}
              mobile={{ size: 46 }}
            >
              We bring the workshop to your kerb.
            </h1>
            <text size={17.5} font={t.font.body} color={dim} lh={1.65} maxw={520} mobile={{ size: 16 }}>
              A fully equipped bike workshop in a van, covering seven zones across the city. Book a two-hour window,
              leave the bike locked outside, and get a text when it is done.
            </text>
            <box tw="flex flex-row items-center gap-4 w-full" wrap>
              <text
                href="#book"
                size={15}
                font={t.font.body}
                weight={700}
                color={C.ground}
                bg={C.hi}
                pad={{ t: 16, r: 30, b: 16, l: 30 }}
                radius={4}
                tw="tracking-[0.12em] uppercase hover:bg-[#F26B21]"
              >
                Find a slot near you
              </text>
              <text href="#prices" size={14} font={t.font.body} color={C.ink} tw="tracking-[0.1em] uppercase hover:text-[#C6FF3D]">
                See the price list
              </text>
            </box>
            <box tw="flex flex-col gap-2 w-full" pad={{ t: 12 }} border={[1, line]} radius={0}>
              <box tw="flex flex-col gap-2 w-full" pad={{ t: 14 }}>
                <Eyebrow color={C.van}>Coverage</Eyebrow>
                <text size={14.5} font={t.font.body} color={dim} lh={1.6} maxw={480}>
                  Zones 1 to 4 daily. Zones 5 and 6 Tuesday and Thursday. Zone 7 Saturday mornings only, and it books
                  out by Wednesday.
                </text>
              </box>
            </box>
          </box>

          {/* the map */}
          <box tw="flex flex-col w-full gap-4" pad={16} radius={12} bg={C.panel} border={[1, line]} motion={FADE}>
            <box tw="flex flex-row items-center justify-between w-full" gap={12} pad={{ t: 4, r: 4, b: 4, l: 4 }}>
              <heading tag="h2" size={12} font={t.font.body} weight={700} color={C.ink} lh={1.4} tw="tracking-[0.18em] uppercase">
                Coverage map · today
              </heading>
              <text size={12} font={t.font.body} color={C.hi} tw="tracking-[0.14em] uppercase">
                10 slots left
              </text>
            </box>

            <box
              tw="flex flex-col w-full"
              pad={10}
              radius={8}
              raw="background-image: linear-gradient(rgba(242,247,239,.05) 1px, transparent 1px), linear-gradient(90deg, rgba(242,247,239,.05) 1px, transparent 1px); background-size: 34px 34px;"
            >
              <grid cols={12} gap={10} w="100%" mobile={{ gridCols: 1, gap: 10 }}>
                {ZONES.map((z) => (
                  <box span={z.span} mobile={{ span: 1 }} tablet={{ span: z.span }} tw="flex flex-col w-full">
                    {z.live
                      ? ZoneTileLive({ code: z.code, name: z.name, slots: z.slots, when: z.when })
                      : ZoneTileScheduled({ code: z.code, name: z.name, slots: z.slots, when: z.when })}
                  </box>
                ))}
              </grid>
            </box>

            <box tw="flex flex-row items-center gap-5 w-full" wrap pad={{ t: 4, r: 4, b: 4, l: 4 }}>
              <text size={12} font={t.font.body} color={C.hi} tw="tracking-[0.12em] uppercase">
                Lime · van out now
              </text>
              <text size={12} font={t.font.body} color={C.van} tw="tracking-[0.12em] uppercase">
                Orange · scheduled days
              </text>
            </box>
          </box>
        </grid>
      </section>

      {/* orange kerb rule */}
      <box w="100%" h={6} bg={C.van} />

      {/* ── 2. Price list ──────────────────────────────────────────────── */}
      <section id="prices" tw="flex flex-col w-full items-center" pad={{ t: 88, r: 24, b: 88, l: 24 }} bg={C.ground}>
        <grid cols="0.55fr 1.45fr" gap={56} w="100%" maxw={1240} mobile={{ gridCols: 1, gap: 28 }} tablet={{ gridCols: 1, gap: 32 }}>
          <box tw="flex flex-col gap-4 w-full items-start">
            <Eyebrow>Price list</Eyebrow>
            <heading tag="h2" size={58} font={t.font.head} color={C.ink} lh={0.95} tw="tracking-[0.01em]" mobile={{ size: 40 }}>
              Flat prices, read in ten seconds.
            </heading>
            <text size={15} font={t.font.body} color={dim} lh={1.6} maxw={340}>
              No call-out fee inside your zone. Parts at cost plus fitting. We tell you before we spend your money.
            </text>
          </box>

          <grid cols={2} gap={0} gapX={48} w="100%" mobile={{ gridCols: 1 }} motion={FADE}>
            {PRICES.map((p) => (
              <box tw="flex flex-col w-full">
                <PriceRow job={p.job} price={p.price} note={p.note} />
              </box>
            ))}
          </grid>
        </grid>
      </section>

      {/* ── 3. What we carry on the van ────────────────────────────────── */}
      <section tw="flex flex-col w-full items-center" pad={{ t: 88, r: 24, b: 88, l: 24 }} bg={C.panel}>
        <grid cols="1.05fr 1fr" gap={56} w="100%" maxw={1240} mobile={{ gridCols: 1, gap: 36 }} tablet={{ gridCols: 1, gap: 40 }}>
          <Photo slot="van_open" h={420} mobileH={260} radius={12} motion={FADE} />
          <box tw="flex flex-col gap-6 w-full items-start justify-center">
            <Eyebrow>On board</Eyebrow>
            <heading tag="h2" size={58} font={t.font.head} color={C.ink} lh={0.95} tw="tracking-[0.01em]" mobile={{ size: 40 }}>
              What we carry on the van.
            </heading>
            <text size={17} font={t.font.body} color={dim} lh={1.65} maxw={520}>
              The van carries tubes in six sizes, pads for every common caliper, chains, cables, bearings, and a truing
              stand. If we do not have your part we can usually get it same day.
            </text>
            <box tw="flex flex-row gap-3 w-full" wrap>
              {STOCK.map((s) => (
                <Chip>{s}</Chip>
              ))}
            </box>
          </box>
        </grid>
      </section>

      {/* ── 4. What we cannot do kerbside ──────────────────────────────── */}
      <section tw="flex flex-col w-full items-center" pad={{ t: 80, r: 24, b: 80, l: 24 }} bg={C.ground}>
        <box tw="flex flex-col w-full" maxw={1240} pad={{ l: 28 }} raw={`border-left: 6px solid ${C.van};`}>
          <grid cols="1fr 1fr" gap={48} w="100%" mobile={{ gridCols: 1, gap: 28 }} tablet={{ gridCols: 1, gap: 32 }}>
            <box tw="flex flex-col gap-4 w-full items-start">
              <Eyebrow color={C.van}>Honest limits</Eyebrow>
              <heading tag="h2" size={54} font={t.font.head} color={C.ink} lh={0.95} tw="tracking-[0.01em]" mobile={{ size: 38 }}>
                What we cannot do kerbside.
              </heading>
              <text size={16.5} font={t.font.body} color={dim} lh={1.65} maxw={500}>
                We cannot do bottom bracket press-fit work, frame alignment, or full e-bike motor teardowns at the kerb.
                Those go to the unit and come back in two days.
              </text>
            </box>
            <box tw="flex flex-col gap-0 w-full justify-center">
              {LIMITS.map((l) => (
                <box tw="flex flex-row items-start gap-4 w-full" pad={{ t: 16, b: 16 }} border={[1, line]}>
                  <text size={13} font={t.font.body} weight={700} color={C.van} tw="tracking-[0.1em] uppercase" w={28}>
                    →
                  </text>
                  <box tw="flex flex-col gap-1 w-full">
                    <heading tag="h3" size={26} font={t.font.head} color={C.ink} lh={1.05} tw="tracking-[0.02em]">
                      {l.job}
                    </heading>
                    <text size={14} font={t.font.body} color={dim} lh={1.5}>
                      {l.why} · to the unit, back in two days
                    </text>
                  </box>
                </box>
              ))}
            </box>
          </grid>
        </box>
      </section>

      {/* ── 5. Booking in three taps ───────────────────────────────────── */}
      <section tw="flex flex-col w-full items-center" pad={{ t: 88, r: 24, b: 88, l: 24 }} bg={C.panel}>
        <box tw="flex flex-row items-end justify-between w-full" maxw={1240} gap={24} pad={{ b: 44 }} wrap>
          <box tw="flex flex-col gap-3 items-start">
            <Eyebrow>Booking</Eyebrow>
            <heading tag="h2" size={58} font={t.font.head} color={C.ink} lh={0.95} tw="tracking-[0.01em]" mobile={{ size: 40 }}>
              Booking in three taps.
            </heading>
          </box>
          <text size={14.5} font={t.font.body} color={dim} lh={1.6} maxw={380}>
            No account, no app. The whole thing takes about forty seconds on a phone.
          </text>
        </box>
        <grid cols={3} gap={24} w="100%" maxw={1240} mobile={{ gridCols: 1 }} tablet={{ gridCols: 1 }} motion={FADE}>
          {TAPS.map((s) => (
            <box tw="flex flex-col gap-4 w-full hover:border-[#C6FF3D]" pad={26} radius={10} bg={C.ground} border={[1, line]}>
              <text size={54} font={t.font.head} color={C.hi} lh={0.9} tw="tracking-[0.02em]">
                {s.n}
              </text>
              <heading tag="h3" size={30} font={t.font.head} color={C.ink} lh={1.05} tw="tracking-[0.02em]">
                {s.head}
              </heading>
              <text size={15} font={t.font.body} color={dim} lh={1.6}>
                {s.body}
              </text>
            </box>
          ))}
        </grid>
      </section>

      {/* ── 6. Fleet and office contracts ──────────────────────────────── */}
      <section tw="flex flex-col w-full items-center" pad={{ t: 88, r: 24, b: 88, l: 24 }} bg={C.ground}>
        <grid cols="1.2fr 1fr" gap={56} w="100%" maxw={1240} mobile={{ gridCols: 1, gap: 32 }} tablet={{ gridCols: 1, gap: 36 }}>
          <box tw="flex flex-col gap-5 w-full items-start justify-center">
            <Eyebrow>Fleet</Eyebrow>
            <heading tag="h2" size={58} font={t.font.head} color={C.ink} lh={0.95} tw="tracking-[0.01em]" mobile={{ size: 40 }}>
              Fleet and office contracts.
            </heading>
            <text size={17} font={t.font.body} color={dim} lh={1.65} maxw={540}>
              Office and courier fleet contracts from six bikes: one visit a month, everything logged, invoiced
              quarterly.
            </text>
            <text href="#book" size={14} font={t.font.body} weight={700} color={C.hi} tw="tracking-[0.12em] uppercase hover:text-[#F26B21]">
              Ask about a contract
            </text>
          </box>
          <grid cols={2} gap={1} w="100%" mobile={{ gridCols: 2 }} bg={line} radius={10}>
            {FLEET_FACTS.map((f) => (
              <box tw="flex flex-col gap-2 w-full justify-center" pad={26} bg={C.panel} minh={132}>
                <text size={12} font={t.font.body} color={dim} tw="tracking-[0.18em] uppercase">
                  {f.k}
                </text>
                <text size={34} font={t.font.head} color={C.ink} lh={1} tw="tracking-[0.02em]">
                  {f.v}
                </text>
              </box>
            ))}
          </grid>
        </grid>
      </section>

      {/* ── 7. Same-day rescue for a puncture ──────────────────────────── */}
      <section tw="flex flex-col w-full items-center" pad={0} bg={C.van}>
        <grid cols="1fr 1fr" gap={0} w="100%" mobile={{ gridCols: 1 }} tablet={{ gridCols: 1 }}>
          <Photo slot="hands_repair" h={460} mobileH={280} />
          <box tw="flex flex-col gap-6 w-full items-start justify-center" pad={{ t: 72, r: 48, b: 72, l: 48 }} mobile={{ pad: { t: 48, r: 24, b: 48, l: 24 } }}>
            <Eyebrow color={C.ground}>Rescue</Eyebrow>
            <heading tag="h2" size={58} font={t.font.head} color={C.ground} lh={0.94} tw="tracking-[0.01em]" mobile={{ size: 38 }}>
              Stranded with a puncture?
            </heading>
            <text size={17.5} font={t.font.body} color={C.ground} lh={1.6} maxw={460} weight={600}>
              Stranded with a puncture inside zones 1 to 4? We aim to be there in 45 minutes for 34, including the tube.
            </text>
            <box tw="flex flex-row gap-8 w-full" wrap>
              <box tw="flex flex-col gap-1">
                <text size={46} font={t.font.head} color={C.ground} lh={1} tw="tracking-[0.02em]">
                  45 min
                </text>
                <text size={12.5} font={t.font.body} color={C.ground} tw="tracking-[0.16em] uppercase">
                  Target arrival
                </text>
              </box>
              <box tw="flex flex-col gap-1">
                <text size={46} font={t.font.head} color={C.ground} lh={1} tw="tracking-[0.02em]">
                  34
                </text>
                <text size={12.5} font={t.font.body} color={C.ground} tw="tracking-[0.16em] uppercase">
                  Tube included
                </text>
              </box>
            </box>
            <text
              href="#book"
              size={15}
              font={t.font.body}
              weight={700}
              color={C.hi}
              bg={C.ground}
              pad={{ t: 16, r: 30, b: 16, l: 30 }}
              radius={4}
              tw="tracking-[0.12em] uppercase hover:text-[#F26B21]"
            >
              Call the van out
            </text>
          </box>
        </grid>
      </section>

      {/* ── 8. Book a slot ─────────────────────────────────────────────── */}
      <section id="book" tw="flex flex-col w-full items-center text-center gap-6" pad={{ t: 96, r: 24, b: 96, l: 24 }} bg={C.hi}>
        <Eyebrow color={C.ground}>Book a slot</Eyebrow>
        <heading tag="h2" size={76} font={t.font.head} color={C.ground} lh={0.92} maxw={860} ta="center" tw="tracking-[0.01em]" mobile={{ size: 44 }}>
          Find a slot near you.
        </heading>
        <text size={17.5} font={t.font.body} color={C.ground} lh={1.6} maxw={560} ta="center">
          Pick your zone and a two-hour window. Leave the bike locked outside, and get a text when it is done.
        </text>
        <text
          href="#prices"
          size={15}
          font={t.font.body}
          weight={700}
          color={C.hi}
          bg={C.ground}
          pad={{ t: 18, r: 36, b: 18, l: 36 }}
          radius={4}
          tw="tracking-[0.12em] uppercase hover:text-[#F26B21]"
        >
          Find a slot near you
        </text>
        <text size={13} font={t.font.body} color={C.ground} tw="tracking-[0.12em] uppercase">
          Spoke &amp; Van · Seven zones · Mon to Sat
        </text>
      </section>
    </box>
  );
};
