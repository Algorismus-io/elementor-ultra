/**
 * The Ward — a reader-owned local newspaper for one city.
 * Structure: single-column long-form. A letter set in newsprint, read top to bottom,
 * with the membership ask held back until the last section.
 */
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'The Ward',
  slug: 'the-ward-paper',
  seo: {
    title: 'The Ward — a reader-owned newspaper for one city',
    description:
      'Four reporters, every council meeting, every planning committee, every magistrates list. Owned by 3,900 members, one vote each, and nobody else.',
  },
};

const IMG = {
  chamber: media['ward-council-chamber'].id,
  reporter: media['ward-reporter-street'].id,
};

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 600 };

/* ── repeaters (content props only — Elementor components cannot override styles) ── */

const Reporter = defineComponent(
  ({ name = 'Name', beat = 'Beat', line = 'What they do.' }) => (
    <box tw="flex flex-col w-full gap-3">
      <box h={2} w="100%" bg="#141414" />
      <text size={12} ls="2px" weight={700} font="Source Serif 4" color="#8C2B2B" pad={{ t: 14 }}>
        {beat}
      </text>
      <heading tag="h3" size={30} lh={1.15} weight={500} font="Playfair Display" color="#141414">
        {name}
      </heading>
      <text size={17} lh={1.62} font="Source Serif 4" color="#6B6B67">
        {line}
      </text>
    </box>
  ),
  {
    title: 'Ward Reporter',
    props: {
      name: { label: 'Name', group: 'Reporter' },
      beat: { label: 'Beat', group: 'Reporter' },
      line: { label: 'What they cover', group: 'Reporter' },
    },
  },
);

const Format = defineComponent(
  ({ index = '01', name = 'Format', line = 'Description.' }) => (
    <box tw="flex flex-col w-full gap-3">
      <box h={1} w="100%" bg="#DEDAD3" />
      <text size={12} ls="2px" weight={700} font="Source Serif 4" color="#2A4E7A" pad={{ t: 16 }}>
        {index}
      </text>
      <heading tag="h3" size={26} lh={1.2} weight={500} font="Playfair Display" color="#141414">
        {name}
      </heading>
      <text size={16} lh={1.6} font="Source Serif 4" color="#6B6B67">
        {line}
      </text>
    </box>
  ),
  {
    title: 'Ward Format',
    props: {
      index: { label: 'Number', group: 'Format' },
      name: { label: 'Name', group: 'Format' },
      line: { label: 'Description', group: 'Format' },
    },
  },
);

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>

    {/* ── 1 · Editor's letter — no images above the fold ───────────────────────── */}
    <section
      tw="flex flex-col w-full items-center"
      bg={t.color.ground}
      pad={{ t: 30, b: 104, l: 24, r: 24 }}
      tablet={{ pad: { t: 26, b: 80, l: 24, r: 24 } }}
      mobile={{ pad: { t: 20, b: 64, l: 18, r: 18 } }}
    >
      <box tw="flex flex-col w-full" maxw={1060}>

        <box tw="flex flex-row w-full items-center justify-between gap-4" pad={{ b: 12 }} mobile={{ gap: 8 }}>
          <text size={13} weight={700} ls="3px" font={t.font.body} color={t.color.press} mobile={{ size: 11, ls: "2px" }}>
            THE WARD
          </text>
          <text size={11} ls="1.6px" font={t.font.body} color={t.color.grey} ta="right" mobile={{ size: 9.5, ls: "1px" }}>
            READER-OWNED · NO PROPRIETOR
          </text>
        </box>
        <box h={3} w="100%" bg={t.color.ink} />
        <box h={1} w="100%" bg={t.color.ink} m={{ t: 4 }} />

        <box tw="flex flex-col w-full" pad={{ t: 56 }} gap={26} mobile={{ pad: { t: 36 }, gap: 20 }}>
          <text size={12} ls="2.4px" weight={700} font={t.font.body} color={t.color.press} mobile={{ size: 11, ls: "1.8px" }}>
            A LETTER FROM THE EDITOR
          </text>
          <h1
            size={68}
            lh={1.04}
            weight={500}
            font={t.font.head}
            color={t.color.ink}
            maxw={920}
            tablet={{ size: 52 }}
            mobile={{ size: 33, lh: 1.12 }}
          >
            Nobody has sat in that council chamber for six years. We do now.
          </h1>
          <text
            size={21}
            lh={1.58}
            font={t.font.body}
            color={t.color.ink}
            maxw={680}
            tablet={{ size: 19 }}
            mobile={{ size: 17, lh: 1.55 }}
          >
            The Ward is a reader-owned newspaper covering one city. Four reporters, every council
            meeting, every planning committee, every magistrates list. Owned by 3,900 members, one
            vote each, and nobody else.
          </text>
          <text
            size={18}
            lh={1.72}
            font={t.font.body}
            color={t.color.grey}
            maxw={660}
            mobile={{ size: 16 }}
          >
            You are reading this because the paper that used to cover your street stopped. Not
            suddenly — it thinned, then it went regional, then it went. What replaced it was a
            website with the same twelve stories as every other town. So a few hundred of us put in
            six pounds a month and hired reporters back. There is no owner to sell us, and no
            algorithm to please. There is a chamber, a court, a planning list, and four people whose
            job is to be in the room.
          </text>

          <box tw="flex flex-row w-full items-center gap-4" pad={{ t: 6 }}>
            <box h={1} w={64} bg={t.color.press} />
            <text size={14} ls="0.6px" font={t.font.body} color={t.color.ink} weight={600} mobile={{ size: 13 }}>
              Dee Kavanagh, Editor
            </text>
          </box>
        </box>

        <grid
          cols={3}
          gap={0}
          w="100%"
          pad={{ t: 64 }}
          mobile={{ gridCols: 1, pad: { t: 44 } }}
          motion={FADE}
        >
          <box tw="flex flex-col gap-2" pad={{ t: 20, r: 24 }} mobile={{ pad: { t: 18, r: 0, b: 18 } }}>
            <box h={1} w="100%" bg={t.color.rule} m={{ b: 14 }} />
            <heading tag="h2" size={44} lh={1} weight={500} font={t.font.head} color={t.color.ink} mobile={{ size: 34 }}>
              3,900
            </heading>
            <text size={14} ls="1.2px" font={t.font.body} color={t.color.grey}>
              MEMBER OWNERS, ONE VOTE EACH
            </text>
          </box>
          <box tw="flex flex-col gap-2" pad={{ t: 20, r: 24, l: 24 }} mobile={{ pad: { t: 18, r: 0, l: 0, b: 18 } }}>
            <box h={1} w="100%" bg={t.color.rule} m={{ b: 14 }} />
            <heading tag="h2" size={44} lh={1} weight={500} font={t.font.head} color={t.color.ink} mobile={{ size: 34 }}>
              Four
            </heading>
            <text size={14} ls="1.2px" font={t.font.body} color={t.color.grey}>
              REPORTERS, ALL ON ONE CITY
            </text>
          </box>
          <box tw="flex flex-col gap-2" pad={{ t: 20, l: 24 }} mobile={{ pad: { t: 18, l: 0 } }}>
            <box h={1} w="100%" bg={t.color.rule} m={{ b: 14 }} />
            <heading tag="h2" size={44} lh={1} weight={500} font={t.font.head} color={t.color.press} mobile={{ size: 34 }}>
              None
            </heading>
            <text size={14} ls="1.2px" font={t.font.body} color={t.color.grey}>
              SHAREHOLDERS, DONORS WITH VIEWS
            </text>
          </box>
        </grid>
      </box>
    </section>

    {/* ── 2 · What we cover every single week, without fail ─────────────────────── */}
    <section
      tw="flex flex-col w-full items-center"
      bg="#F7F3EC"
      pad={{ t: 96, b: 96, l: 24, r: 24 }}
      mobile={{ pad: { t: 60, b: 60, l: 18, r: 18 } }}
    >
      <box tw="flex flex-col w-full" maxw={1060} gap={40} mobile={{ gap: 30 }}>
        <box tw="flex flex-col w-full gap-5" maxw={780}>
          <text size={12} ls="2.4px" weight={700} font={t.font.body} color={t.color.press}>
            01 — THE BEAT
          </text>
          <heading
            tag="h2"
            size={46}
            lh={1.12}
            weight={500}
            font={t.font.head}
            color={t.color.ink}
            tablet={{ size: 38 }}
            mobile={{ size: 28, lh: 1.18 }}
          >
            What we cover every single week, without fail
          </heading>
          <text size={19} lh={1.66} font={t.font.body} color={t.color.ink} maxw={720} mobile={{ size: 16.5 }}>
            Every week without exception: the full council and every committee, the planning list
            with what it means for your street, the magistrates and crown court lists, and a schools
            page that is not press releases.
          </text>
        </box>

        <grid cols={2} gap={0} gapX={48} w="100%" mobile={{ gridCols: 1, gapX: 0 }} motion={FADE}>
          {[
            ['Council and committees', 'Full council, cabinet, scrutiny, licensing, audit. We publish who voted which way and what it cost, the same week it happened — not a fortnight later from the minutes.'],
            ['The planning list', 'Every application, translated. Not "outline consent, mixed use" but: this is the corner of your road, this is how tall, this is the deadline to object.'],
            ['Magistrates and crown', 'The lists, attended in person. Names, charges, outcomes, and the cases nobody sends a press release about because there is nobody left to send it to.'],
            ['Schools and health', 'Admissions, inspections, closures, the trust board that meets at 9am on a Tuesday. Reported from the meeting, not from the statement issued after it.'],
          ].map(([h, body], i) => (
            <box tw="flex flex-col w-full gap-3" pad={{ t: 26, b: 26 }} mobile={{ pad: { t: 20, b: 20 } }}>
              <box h={2} w="100%" bg={t.color.ink} m={{ b: 12 }} />
              <heading tag="h3" size={24} lh={1.2} weight={500} font={t.font.head} color={t.color.ink} mobile={{ size: 21 }}>
                {h}
              </heading>
              <text size={16.5} lh={1.66} font={t.font.body} color={t.color.grey} mobile={{ size: 15.5 }}>
                {body}
              </text>
            </box>
          ))}
        </grid>
      </box>
    </section>

    {/* ── 3 · The four reporters and their beats ────────────────────────────────── */}
    <section
      tw="flex flex-col w-full items-center"
      bg={t.color.ground}
      pad={{ t: 92, b: 100, l: 24, r: 24 }}
      mobile={{ pad: { t: 58, b: 62, l: 18, r: 18 } }}
    >
      <box tw="flex flex-col w-full" maxw={1060} gap={44} mobile={{ gap: 30 }}>
        <box tw="flex flex-col w-full gap-5" maxw={760}>
          <text size={12} ls="2.4px" weight={700} font={t.font.body} color={t.color.press}>
            02 — THE NEWSROOM
          </text>
          <heading
            tag="h2"
            size={46}
            lh={1.12}
            weight={500}
            font={t.font.head}
            color={t.color.ink}
            tablet={{ size: 38 }}
            mobile={{ size: 28, lh: 1.18 }}
          >
            The four reporters and their beats
          </heading>
          <text size={18} lh={1.68} font={t.font.body} color={t.color.grey} maxw={700} mobile={{ size: 16 }}>
            Dee covers the council and has read every budget line since 2019. Sam does courts.
            Fenella does planning and housing. Ade does schools, health and everything that happens
            at 4pm on a Friday.
          </text>
        </box>

        <box tw="flex flex-col w-full gap-3">
          <img src={IMG.reporter} w="100%" h={340} fit="cover" tablet={{ h: 280 }} mobile={{ h: 190 }} motion={FADE} />
          <text size={13} lh={1.5} font={t.font.body} color={t.color.grey} ta="left">
            Fenella outside the civic offices, waiting on a planning officer who said ten minutes an
            hour ago. Most of this job is standing about, then writing quickly.
          </text>
        </box>

        <grid cols={2} gap={0} gapX={48} gapY={40} w="100%" mobile={{ gridCols: 1, gapX: 0, gapY: 30 }}>
          <Reporter
            name="Dee Kavanagh"
            beat="COUNCIL &amp; BUDGET"
            line="Every full council and cabinet meeting since we opened, and every budget line since 2019. If a figure moved between drafts, she has both drafts."
          />
          <Reporter
            name="Sam Oyelaran"
            beat="COURTS"
            line="Magistrates on Mondays, crown when it sits. Reports what was heard in open court, carefully, including the cases that end in nothing."
          />
          <Reporter
            name="Fenella Wright"
            beat="PLANNING &amp; HOUSING"
            line="The weekly list, the committee, the appeals. Reads the viability assessments so you do not have to, and tells you the objection deadline while it still matters."
          />
          <Reporter
            name="Ade Nwosu"
            beat="SCHOOLS, HEALTH &amp; FRIDAYS"
            line="Admissions, inspections, the trust boards, the hospital trust — and everything that gets announced at 4pm on a Friday, which is never a coincidence."
          />
        </grid>
      </box>
    </section>

    {/* ── 4 · What happened when nobody was in the council chamber ──────────────── */}
    <section
      tw="flex flex-col w-full items-center"
      bg={t.color.ink}
      pad={{ t: 104, b: 108, l: 24, r: 24 }}
      mobile={{ pad: { t: 62, b: 66, l: 18, r: 18 } }}
    >
      <box tw="flex flex-col w-full" maxw={1060} gap={48} mobile={{ gap: 32 }}>
        <box tw="flex flex-col w-full gap-5" maxw={800}>
          <text size={12} ls="2.4px" weight={700} font={t.font.body} color="#D9856F">
            03 — THE COST OF AN EMPTY BENCH
          </text>
          <heading
            tag="h2"
            size={46}
            lh={1.12}
            weight={500}
            font={t.font.head}
            color={t.color.ground}
            tablet={{ size: 38 }}
            mobile={{ size: 28, lh: 1.18 }}
          >
            What happened when nobody was in the council chamber
          </heading>
        </box>

        <grid cols={2} gap={0} gapX={56} w="100%" mobile={{ gridCols: 1, gapX: 0, gapY: 28 }}>
          <img src={IMG.chamber} w="100%" h={400} fit="cover" tablet={{ h: 320 }} mobile={{ h: 220 }} motion={FADE} />
          <box tw="flex flex-col w-full gap-6" justify="center">
            <heading tag="h3" size={78} lh={0.95} weight={500} font={t.font.head} color="#E0A08C" tablet={{ size: 60 }} mobile={{ size: 52 }}>
              £41m
            </heading>
            <text size={20} lh={1.6} font={t.font.body} color={t.color.ground} mobile={{ size: 17 }}>
              In the six years after the old paper closed, the council passed a 41 million pound
              leisure contract with no press present, and the first anyone heard was a leak. That is
              what an empty press bench costs.
            </text>
            <text size={16.5} lh={1.68} font={t.font.body} color="#A8A6A0" mobile={{ size: 15.5 }}>
              It was not corruption and nobody has said it was. It was worse in an ordinary way: a
              long report, a thin summary, a vote at 9.40pm, and not one person in the room whose job
              was to ask the obvious question out loud. We have been in every meeting since. The
              questions are usually obvious. Somebody just has to be there to ask them.
            </text>
          </box>
        </grid>
      </box>
    </section>

    {/* ── 5 · Co-op ownership: one member one vote ──────────────────────────────── */}
    <section
      tw="flex flex-col w-full items-center"
      bg={t.color.civic}
      pad={{ t: 92, b: 96, l: 24, r: 24 }}
      mobile={{ pad: { t: 58, b: 60, l: 18, r: 18 } }}
    >
      <box tw="flex flex-col w-full" maxw={1060} gap={40} mobile={{ gap: 28 }}>
        <box tw="flex flex-col w-full gap-5" maxw={760}>
          <text size={12} ls="2.4px" weight={700} font={t.font.body} color="#BFD2E8">
            04 — OWNERSHIP
          </text>
          <heading
            tag="h2"
            size={46}
            lh={1.12}
            weight={500}
            font={t.font.head}
            color={t.color.ground}
            tablet={{ size: 38 }}
            mobile={{ size: 28, lh: 1.18 }}
          >
            Co-op ownership: one member, one vote
          </heading>
          <text size={19} lh={1.64} font={t.font.body} color="#E8EEF6" maxw={720} mobile={{ size: 16.5 }}>
            One member, one vote, regardless of how much you pay. Members elect two of the seven
            board seats and vote on any change to the editorial code.
          </text>
        </box>

        <grid cols={3} gap={0} gapX={40} w="100%" mobile={{ gridCols: 1, gapX: 0, gapY: 24 }} motion={FADE}>
          <box tw="flex flex-col w-full gap-3" pad={{ t: 24 }}>
            <box h={1} w="100%" bg="#5A7CA6" m={{ b: 10 }} />
            <heading tag="h3" size={22} lh={1.25} weight={500} font={t.font.head} color={t.color.ground}>
              The vote is flat
            </heading>
            <text size={16} lh={1.62} font={t.font.body} color="#C9D8EA">
              Six pounds a month and four pounds a month carry exactly the same weight, and so does a
              free membership taken out this morning.
            </text>
          </box>
          <box tw="flex flex-col w-full gap-3" pad={{ t: 24 }}>
            <box h={1} w="100%" bg="#5A7CA6" m={{ b: 10 }} />
            <heading tag="h3" size={22} lh={1.25} weight={500} font={t.font.head} color={t.color.ground}>
              Two of seven seats
            </heading>
            <text size={16} lh={1.62} font={t.font.body} color="#C9D8EA">
              Elected by members at the AGM, in public, with the minutes published. The other five are
              recruited for skills and can be voted out.
            </text>
          </box>
          <box tw="flex flex-col w-full gap-3" pad={{ t: 24 }}>
            <box h={1} w="100%" bg="#5A7CA6" m={{ b: 10 }} />
            <heading tag="h3" size={22} lh={1.25} weight={500} font={t.font.head} color={t.color.ground}>
              The code is yours
            </heading>
            <text size={16} lh={1.62} font={t.font.body} color="#C9D8EA">
              No change to the editorial code happens without a members' vote. Not a consultation. A
              vote, with a result we are bound by.
            </text>
          </box>
        </grid>
      </box>
    </section>

    {/* ── 6 · Print, email and the noticeboard ──────────────────────────────────── */}
    <section
      tw="flex flex-col w-full items-center"
      bg={t.color.ground}
      pad={{ t: 88, b: 88, l: 24, r: 24 }}
      mobile={{ pad: { t: 56, b: 56, l: 18, r: 18 } }}
    >
      <box tw="flex flex-col w-full" maxw={1060} gap={40} mobile={{ gap: 28 }}>
        <box tw="flex flex-col w-full gap-5" maxw={760}>
          <text size={12} ls="2.4px" weight={700} font={t.font.body} color={t.color.press}>
            05 — HOW IT REACHES YOU
          </text>
          <heading
            tag="h2"
            size={42}
            lh={1.14}
            weight={500}
            font={t.font.head}
            color={t.color.ink}
            tablet={{ size: 36 }}
            mobile={{ size: 27, lh: 1.2 }}
          >
            Print, email and the noticeboard
          </heading>
          <text size={18} lh={1.66} font={t.font.body} color={t.color.grey} maxw={700} mobile={{ size: 16 }}>
            A weekly email, a free public noticeboard anyone can read without paying, and a printed
            edition on the first Thursday of the month delivered to members.
          </text>
        </box>

        <grid cols={3} gap={0} gapX={44} w="100%" mobile={{ gridCols: 1, gapX: 0, gapY: 26 }}>
          <Format
            index="01"
            name="The weekly email"
            line="Thursday morning. Everything from the week, in reading order, with the planning deadlines at the top because they expire."
          />
          <Format
            index="02"
            name="The noticeboard"
            line="Court lists, planning notices and council reports, free and open to everyone, no account, no paywall, no email required."
          />
          <Format
            index="03"
            name="The printed edition"
            line="First Thursday of the month, through the door of every member, and left in libraries, GP waiting rooms and two chip shops."
          />
        </grid>
      </box>
    </section>

    {/* ── 7 · Membership and the free tier that stays free ──────────────────────── */}
    <section
      tw="flex flex-col w-full items-center"
      bg="#F7F3EC"
      pad={{ t: 96, b: 100, l: 24, r: 24 }}
      mobile={{ pad: { t: 58, b: 62, l: 18, r: 18 } }}
    >
      <box tw="flex flex-col w-full" maxw={1060} gap={40} mobile={{ gap: 28 }}>
        <box tw="flex flex-col w-full gap-5" maxw={780}>
          <text size={12} ls="2.4px" weight={700} font={t.font.body} color={t.color.press}>
            06 — MEMBERSHIP
          </text>
          <heading
            tag="h2"
            size={46}
            lh={1.12}
            weight={500}
            font={t.font.head}
            color={t.color.ink}
            tablet={{ size: 38 }}
            mobile={{ size: 28, lh: 1.18 }}
          >
            Membership, and the free tier that stays free
          </heading>
          <text size={19} lh={1.64} font={t.font.body} color={t.color.ink} maxw={720} mobile={{ size: 16.5 }}>
            £6 a month, or £4 if that is a stretch and you say so. The court lists, planning notices
            and council reports stay free for everyone forever, because those are the bits that
            protect people.
          </text>
        </box>

        <grid cols={2} gap={0} gapX={40} w="100%" mobile={{ gridCols: 1, gapX: 0, gapY: 20 }} motion={FADE}>
          <box
            tw="flex flex-col w-full gap-4"
            bg={t.color.ground}
            border={[1, '#DEDAD3']}
            pad={32}
            mobile={{ pad: 22 }}
          >
            <text size={12} ls="2px" weight={700} font={t.font.body} color={t.color.press}>
              FULL MEMBER
            </text>
            <heading tag="h3" size={52} lh={1} weight={500} font={t.font.head} color={t.color.ink} mobile={{ size: 40 }}>
              £6<em> a month</em>
            </heading>
            <text size={16.5} lh={1.66} font={t.font.body} color={t.color.grey} mobile={{ size: 15.5 }}>
              The vote, the monthly printed edition through your door, the weekly email, and the
              knowledge that a reporter is sitting in the chamber on a Wednesday night because you
              paid for the chair.
            </text>
          </box>
          <box
            tw="flex flex-col w-full gap-4"
            bg={t.color.ground}
            border={[1, '#DEDAD3']}
            pad={32}
            mobile={{ pad: 22 }}
          >
            <text size={12} ls="2px" weight={700} font={t.font.body} color={t.color.civic}>
              IF SIX IS A STRETCH
            </text>
            <heading tag="h3" size={52} lh={1} weight={500} font={t.font.head} color={t.color.ink} mobile={{ size: 40 }}>
              £4<em> a month</em>
            </heading>
            <text size={16.5} lh={1.66} font={t.font.body} color={t.color.grey} mobile={{ size: 15.5 }}>
              Same paper, same vote, same everything. You say so on the form, nobody asks why, and
              nobody is told. It is a box, not an application.
            </text>
          </box>
        </grid>

        <box tw="flex flex-col w-full gap-3" pad={{ l: 26, t: 4, b: 4 }} border={[0, '#8C2B2B']} raw="border-left: 4px solid #8C2B2B;">
          <heading tag="h3" size={22} lh={1.3} weight={500} font={t.font.head} color={t.color.ink} mobile={{ size: 19 }}>
            <strong>Free forever</strong> is not a trial
          </heading>
          <text size={17} lh={1.68} font={t.font.body} color={t.color.grey} maxw={760} mobile={{ size: 15.5 }}>
            The court lists, the planning notices and the council reports never go behind anything.
            No counter, no "one article remaining", no email wall. If knowing that a hearing is on
            Tuesday protects somebody, charging them for it is the wrong way round.
          </text>
        </box>
      </box>
    </section>

    {/* ── 8 · Join the co-op — the one centred section on the page ──────────────── */}
    <section
      id="join"
      tw="flex flex-col w-full items-center text-center"
      bg={t.color.press}
      pad={{ t: 104, b: 108, l: 24, r: 24 }}
      mobile={{ pad: { t: 66, b: 70, l: 18, r: 18 } }}
    >
      <box tw="flex flex-col w-full items-center text-center" maxw={720} gap={26} mobile={{ gap: 20 }}>
        <text size={12} ls="2.4px" weight={700} font={t.font.body} color="#F0C9C0" ta="center">
          07 — THE ASK
        </text>
        <heading
          tag="h2"
          size={54}
          lh={1.08}
          weight={500}
          font={t.font.head}
          color={t.color.ground}
          ta="center"
          tablet={{ size: 44 }}
          mobile={{ size: 32, lh: 1.14 }}
          motion={FADE}
        >
          Join the co-op
        </heading>
        <text size={19} lh={1.64} font={t.font.body} color="#F6E3DF" ta="center" maxw={600} mobile={{ size: 16.5 }}>
          Six pounds a month, or four if that is a stretch. One vote either way. It buys a reporter a
          seat in a room that has been empty for six years — and buys you the notes from it on
          Thursday morning.
        </text>
        <text
          href="#join"
          size={17}
          weight={700}
          font={t.font.body}
          color={t.color.press}
          bg={t.color.ground}
          pad={{ t: 17, b: 17, l: 40, r: 40 }}
          ta="center"
          m={{ t: 10 }}
          shadow={[[3, 0, 0, '#141414'], [10, 26, -10, 'rgba(20,20,20,0.35)']]}
          tw="hover:bg-[#141414] hover:text-[#FFFDFA]"
          mobile={{ size: 16, pad: { t: 15, b: 15, l: 30, r: 30 } }}
        >
          Join the co-op
        </text>
        <text size={14.5} lh={1.6} font={t.font.body} color="#EBBDB4" ta="center" maxw={520} m={{ t: 8 }} mobile={{ size: 13.5 }}>
          Cancel in one click. No proprietor, no shareholders, no advertiser with a view about the
          leisure contract. 3,900 members and counting.
        </text>
        <box h={1} w={80} bg="#C56D6D" m={{ t: 22 }} />
        <text size={13} ls="1.6px" font={t.font.body} color="#EBBDB4" ta="center" mobile={{ size: 12 }}>
          THE WARD · A REGISTERED COMMUNITY BENEFIT SOCIETY
        </text>
      </box>
    </section>
  </box>
);
