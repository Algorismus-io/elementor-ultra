# Voltcraft VX

Orange mono on black, module catalogue as a spec grid. Very cohesive.

|  |  |
|---|---|
| **Slug** | `voltcraft-modular` (deploys to `/voltcraft-modular/`) |
| **Archetype** | catalogue grid |
| **Industry** | Modular synthesizer hardware |
| **Page title** | Voltcraft VX — Modular Synthesizer Hardware |
| **Fonts** | Orbitron, Space Mono — Google Fonts, imported by Elementor automatically |
| **Elements** | 201 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (98 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install voltcraft-modular
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
voltcraft-modular/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/voltcraft-modular.page.jsx     the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#0B0B0D` |
| `panel` | `#17171B` |
| `ink` | `#E7E4DC` |
| `knob` | `#D8452F` |
| `jack` | `#C9A227` |
| `trace` | `#2A6B5F` |

Change a value, re-run `npx exjsx-kit install voltcraft-modular`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/voltcraft-modular.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `module_front` | `media/module_front.jpg` | Voltcraft VX module front panel with knobs and patch jacks |
| `rack_patched` | `media/rack_patched.jpg` | Eurorack case patched with Voltcraft VX modules |
| `workshop_solder` | `media/workshop_solder.jpg` | Soldering a Voltcraft VX board in the Tallinn workshop |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
