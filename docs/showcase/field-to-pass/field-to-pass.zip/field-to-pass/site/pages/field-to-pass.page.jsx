import { MEDIA as media } from '../data/media.mjs';
import { FILM, GROWERS, ORDER_ROUTES } from '../data/week33.mjs';
import { FilmCard, GrowerRow, RouteCard } from '../components/cards.jsx';

export const meta = {
  title: 'Field to Pass',
  slug: 'field-to-pass',
  seo: {
    title: 'Field to Pass — wholesale from growers 90 minutes away',
    description:
      'Independent kitchens, straight onto 46 growers, dairies and smokehouses within 90 minutes of the city. Order by 9pm, at your back door by 6am.',
  },
};

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

export default ({ theme: t }) => {
  const c = t.lit;
  const head = t.litFont('head');
  const body = t.litFont('body');

  /** Small caps label used to open every band. */
  const Eyebrow = ({ text, tint }) => (
    <text size={12} weight={700} ls={0.18} color={tint} font={body} tw="uppercase">
      {text}
    </text>
  );

  return (
    <box tw="flex flex-col w-full items-center" pad={0} bg={c.ground} raw="overflow-x: clip;">
      {/* ── 1. Hero ─────────────────────────────────────────────────────── */}
      <section w="100%" dir="column" align="center" pad={{ t: 88, b: 56 }} bg={c.ground} tw="max-md:pt-14">
        <box w="100%" maxw={1240} dir="row" align="flex-end" justify="space-between" gap={56} pad={{ l: 32, r: 32 }} wrap
          tw="max-lg:gap-10 max-md:px-5">
          <box dir="column" gap={22} maxw={720} w="100%">
            <Eyebrow text="Wholesale · Week 33" tint={c.soil} />
            <h1 size={68} lh={1.02} weight={400} color={c.ink} font={head} tw="max-lg:text-[52px] max-md:text-[34px]">
              What is actually good this week, from 90 minutes away.
            </h1>
            <text size={19} lh={1.6} maxw={620} color={c.ink} font={body} raw="opacity: 0.8;" tw="max-md:text-[16px]">
              Field to Pass puts independent kitchens straight onto 46 growers, dairies and smokehouses within 90
              minutes of the city. Order by 9pm, it is at your back door by 6am.
            </text>
            <box dir="row" gap={16} align="center" wrap pad={{ t: 6 }}>
              <text
                href="#account"
                tw="uppercase"
                size={15}
                weight={700}
                ls={0.06}
                color={c.ground}
                font={body}
                bg={c.field}
                pad={{ t: 17, r: 30, b: 17, l: 30 }}
                shadow={[[4, 0, 0, c.ink]]}
                hover={{ bg: c.ink, shadow: [[4, 0, 0, c.sun]] }}
              >
                Open a kitchen account
              </text>
              <text size={15} color={c.ink} font={body} raw="opacity: 0.65;">
                No minimum order · 14-day terms after three weeks
              </text>
            </box>
          </box>

          <box dir="column" gap={14} w={340} pad={{ t: 26, r: 26, b: 26, l: 26 }} bg="#FFFFFF" border={[1, c.rule]}
            shadow={[[6, 0, 0, c.sun]]} tw="max-lg:w-full">
            <Eyebrow text="On the board today" tint={c.field} />
            <text size={17} lh={1.55} color={c.ink} font={body}>
              <strong>Week 33:</strong> Crown Prince squash, the last of the Gariguette strawberries, sea kale from the
              coast, three-week-aged mutton, and a goat curd that will not last past Thursday.
            </text>
          </box>
        </box>
      </section>

      {/* ── 1b. The filmstrip ───────────────────────────────────────────── */}
      <section w="100%" dir="column" align="center" bg={c.ink} pad={{ t: 56, b: 64 }} gap={28}>
        <box w="100%" maxw={1240} dir="row" align="flex-end" justify="space-between" gap={20} pad={{ l: 32, r: 32 }} wrap
          tw="max-md:px-5">
          <box dir="column" gap={10} maxw={640}>
            <Eyebrow text="This week's filmstrip" tint={c.sun} />
            <h2 size={40} lh={1.08} weight={400} color={c.ground} font={head} motion={FADE} tw="max-md:text-[26px]">
              Fourteen things at their best.
            </h2>
          </box>
          <text size={14} color={c.ground} font={body} raw="opacity: 0.6;" tw="max-md:text-[13px]">
            Scroll the strip →&nbsp; every frame carries the farm, the distance and when it was cut.
          </text>
        </box>

        <box
          w="100%"
          raw="overflow-x: auto; overflow-y: hidden; scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch; scrollbar-color: #4E7B3A #1C2418;"
          pad={{ t: 4, b: 20, l: 32, r: 32 }}
          tw="max-md:px-5"
        >
          <box dir="row" wrap={false} gap={18} align="stretch" w="hug">
            {FILM.map((f) => (
              <FilmCard name={f.name} farm={f.farm} dist={f.dist} note={f.note} />
            ))}
          </box>
        </box>

        <box w="100%" maxw={1240} pad={{ l: 32, r: 32 }} tw="max-md:px-5">
          <img src={media.produce_strip.id} w="100%" h={180} fit="cover" tw="max-md:h-[110px]" />
        </box>
      </section>

      {/* ── 2. Cut-off and delivery window ──────────────────────────────── */}
      <section w="100%" dir="column" align="center" bg={c.sun} pad={{ t: 56, b: 56 }}>
        <box w="100%" maxw={1240} dir="column" gap={26} pad={{ l: 32, r: 32 }} tw="max-md:px-5">
          <Eyebrow text="Stated once" tint={c.soil} />
          <box dir="row" align="flex-start" justify="space-between" gap={40} wrap>
            <heading tag="h2" size={44} lh={1.05} weight={400} color={c.ink} font={head} maxw={560}
              tw="max-lg:text-[34px] max-md:text-[26px]">
              Cut-off 9pm. Delivery between 4am and 6am.
            </heading>
            <text size={18} lh={1.6} maxw={520} color={c.ink} font={body} raw="opacity: 0.85;" tw="max-md:text-[16px]">
              Chilled, into your walk-in if you leave it open. One van, one driver, the same one every day.
            </text>
          </box>
          <grid cols={4} gap={0} w="100%" mobile={{ gridCols: 2 }} raw="border-top: 2px solid #1C2418;">
            {[
              ['9pm', 'Order closes'],
              ['10pm', 'Growers see the pick list'],
              ['4am', 'Van loaded, chilled'],
              ['6am', 'At your back door'],
            ].map(([time, label]) => (
              <box dir="column" gap={6} pad={{ t: 22, r: 18, b: 22, l: 0 }} raw="border-right: 1px solid rgba(28,36,24,0.25);">
                <text size={34} weight={400} color={c.ink} font={head} tw="max-md:text-[26px]">
                  {time}
                </text>
                <text size={14} lh={1.45} color={c.ink} font={body} raw="opacity: 0.75;">
                  {label}
                </text>
              </box>
            ))}
          </grid>
        </box>
      </section>

      {/* ── 3. Growers on the platform ──────────────────────────────────── */}
      <section w="100%" dir="column" align="center" bg={c.ground} pad={{ t: 80, b: 80 }} tw="max-md:py-14">
        <box w="100%" maxw={1240} dir="row" align="flex-start" gap={56} pad={{ l: 32, r: 32 }} wrap
          tw="max-lg:gap-10 max-md:px-5">
          <box dir="column" gap={20} w={430} tw="max-lg:w-full">
            <Eyebrow text="Growers on the platform" tint={c.field} />
            <heading tag="h2" size={40} lh={1.08} weight={400} color={c.ink} font={head} motion={FADE}
              tw="max-md:text-[26px]">
              46 producers, average distance 61km.
            </heading>
            <text size={18} lh={1.6} color={c.ink} font={body} raw="opacity: 0.8;" tw="max-md:text-[16px]">
              Every listing shows the farm name, the distance, and when it was cut or lifted. If a grower is having a
              bad week you will see it on the listing before you order it.
            </text>
            <img src={media.grower.id} w="100%" h={280} fit="cover" tw="max-md:h-[200px]" />
          </box>

          <box dir="column" flex={1} w={620} tw="max-lg:w-full">
            <grid cols={2} gapX={40} gapY={0} w="100%" mobile={{ gridCols: 1 }}>
              {GROWERS.map((g) => (
                <GrowerRow farm={g.farm} dist={g.dist} detail={g.detail} />
              ))}
            </grid>
            <text size={15} color={c.soil} font={body} pad={{ t: 24 }} weight={600}>
              …and 38 more, from a two-acre herb cutting at 34km to a smokehouse on the coast at 88km.
            </text>
          </box>
        </box>
      </section>

      {/* ── 4. Pricing ──────────────────────────────────────────────────── */}
      <section w="100%" dir="column" align="center" bg={c.soil} pad={{ t: 72, b: 72 }} tw="max-md:py-14">
        <box w="100%" maxw={1240} dir="row" align="flex-start" justify="space-between" gap={48} pad={{ l: 32, r: 32 }}
          wrap tw="max-md:px-5">
          <box dir="column" gap={18} maxw={620}>
            <Eyebrow text="Pricing" tint={c.sun} />
            <heading tag="h2" size={40} lh={1.08} weight={400} color={c.ground} font={head} tw="max-md:text-[26px]">
              The grower sets the price and sees it.
            </heading>
            <text size={18} lh={1.65} color={c.ground} font={body} raw="opacity: 0.85;" tw="max-md:text-[16px]">
              We add 14 percent and that is the whole model. No listing fees, no shelf placement, no promoted produce.
              The number on the listing is the number the farm wrote down.
            </text>
          </box>
          <box dir="row" gap={0} align="stretch" mobile={{ dir: 'column', w: '100%' }} tw="max-md:w-full">
            <box dir="column" gap={4} pad={{ t: 24, r: 32, b: 24, l: 32 }} bg={c.ground} justify="center"
              mobile={{ w: '100%' }} tw="max-md:px-5">
              <text size={52} weight={400} color={c.ink} font={head} tw="max-md:text-[36px]">
                100%
              </text>
              <text size={14} lh={1.4} color={c.ink} font={body} maxw={150} mobile={{ maxw: 280 }} raw="opacity: 0.7;">
                of the listed price goes to the grower
              </text>
            </box>
            <box dir="column" gap={4} pad={{ t: 24, r: 32, b: 24, l: 32 }} bg={c.sun} justify="center"
              mobile={{ w: '100%' }} tw="max-md:px-5">
              <text size={52} weight={400} color={c.ink} font={head} tw="max-md:text-[36px]">
                14%
              </text>
              <text size={14} lh={1.4} color={c.ink} font={body} maxw={150} mobile={{ maxw: 280 }} raw="opacity: 0.75;">
                added on top, and nothing else
              </text>
            </box>
          </box>
        </box>
      </section>

      {/* ── 5. Ordering ─────────────────────────────────────────────────── */}
      <section w="100%" dir="column" align="center" bg={c.ground} pad={{ t: 80, b: 80 }} tw="max-md:py-14">
        <box w="100%" maxw={1240} dir="column" gap={32} pad={{ l: 32, r: 32 }} tw="max-md:px-5">
          <box dir="row" align="flex-end" justify="space-between" gap={24} wrap>
            <box dir="column" gap={10} maxw={620}>
              <Eyebrow text="Ordering" tint={c.field} />
              <heading tag="h2" size={40} lh={1.08} weight={400} color={c.ink} font={head} motion={FADE}
                tw="max-md:text-[26px]">
                Web, WhatsApp or a phone call.
              </heading>
            </box>
            <text size={17} lh={1.6} maxw={420} color={c.ink} font={body} raw="opacity: 0.75;">
              Chefs order at odd hours from odd places. All three routes hit the same 9pm cut-off.
            </text>
          </box>
          <grid cols={3} gap={20} w="100%" tablet={{ gridCols: 3 }} mobile={{ gridCols: 1 }}>
            {ORDER_ROUTES.map((r) => (
              <RouteCard no={r.no} label={r.label} body={r.body} />
            ))}
          </grid>
          <img src={media.kitchen_prep.id} w="100%" h={260} fit="cover" tw="max-md:h-[170px]" />
        </box>
      </section>

      {/* ── 6. Substitutions and shortages ──────────────────────────────── */}
      <section w="100%" dir="column" align="center" bg={c.field} pad={{ t: 72, b: 72 }} tw="max-md:py-14">
        <box w="100%" maxw={1240} dir="row" align="flex-start" gap={56} pad={{ l: 32, r: 32 }} wrap
          tw="max-lg:gap-10 max-md:px-5">
          <box dir="column" gap={18} maxw={620}>
            <Eyebrow text="Substitutions and shortages" tint={c.sun} />
            <heading tag="h2" size={40} lh={1.08} weight={400} color={c.ground} font={head} tw="max-md:text-[26px]">
              If a crop fails we call you before 10pm, not at 5am.
            </heading>
            <text size={18} lh={1.65} color={c.ground} font={body} raw="opacity: 0.88;" tw="max-md:text-[16px]">
              You approve any substitution or you get a credit. We have never silently swapped an item and we would
              rather lose the order.
            </text>
          </box>
          <box dir="column" gap={0} w={440} tw="max-lg:w-full">
            {[
              ['Before 10pm', 'A call, from a person, the night the pick list breaks.'],
              ['Your call', 'Approve the swap, take the credit, or cancel the line.'],
              ['Never silent', 'No box has ever arrived with something you did not agree to.'],
            ].map(([k, v]) => (
              <box dir="column" gap={6} pad={{ t: 20, b: 20 }} raw="border-top: 1px solid rgba(245,247,240,0.3);">
                <text size={20} weight={400} color={c.sun} font={head}>
                  {k}
                </text>
                <text size={16} lh={1.5} color={c.ground} font={body} raw="opacity: 0.85;">
                  {v}
                </text>
              </box>
            ))}
          </box>
        </box>
      </section>

      {/* ── 7. Credit terms ─────────────────────────────────────────────── */}
      <section w="100%" dir="column" align="center" bg={c.ground} pad={{ t: 72, b: 72 }} tw="max-md:py-14">
        <box w="100%" maxw={1240} dir="row" align="flex-start" justify="space-between" gap={48} pad={{ l: 32, r: 32 }}
          wrap tw="max-md:px-5">
          <box dir="column" gap={16} maxw={560}>
            <Eyebrow text="Credit terms for restaurants" tint={c.soil} />
            <heading tag="h2" size={38} lh={1.08} weight={400} color={c.ink} font={head} tw="max-md:text-[26px]">
              14-day terms after three delivered weeks.
            </heading>
            <text size={18} lh={1.65} color={c.ink} font={body} raw="opacity: 0.8;" tw="max-md:text-[16px]">
              No minimum order, though under 60 there is a 6 delivery charge. One invoice a week, itemised by farm, so
              your GP work takes twenty minutes instead of an evening.
            </text>
          </box>
          <grid cols={3} gap={16} w={520} mobile={{ gridCols: 3 }} tw="max-lg:w-full">
            {[
              ['14 days', 'to settle'],
              ['0', 'minimum order'],
              ['6', 'under a 60 basket'],
            ].map(([n, l]) => (
              <box dir="column" gap={6} pad={{ t: 22, r: 16, b: 22, l: 18 }} bg="#FFFFFF" border={[1, c.rule]}>
                <text size={28} weight={400} color={c.field} font={head} tw="max-md:text-[20px]">
                  {n}
                </text>
                <text size={13} lh={1.4} color={c.ink} font={body} raw="opacity: 0.7;">
                  {l}
                </text>
              </box>
            ))}
          </grid>
        </box>
      </section>

      {/* ── 8. Open a kitchen account ───────────────────────────────────── */}
      <section id="account" w="100%" dir="column" align="center" bg={c.ink} pad={{ t: 88, b: 96 }} tw="max-md:py-16">
        <box w="100%" maxw={860} dir="column" align="center" gap={22} pad={{ l: 32, r: 32 }} ta="center"
          tw="max-md:px-5">
          <Eyebrow text="Open a kitchen account" tint={c.sun} />
          <heading tag="h2" size={52} lh={1.05} weight={400} color={c.ground} font={head} ta="center" motion={FADE}
            tw="max-lg:text-[40px] max-md:text-[30px]">
            Order tonight, unpack it at six.
          </heading>
          <text size={18} lh={1.65} maxw={620} color={c.ground} font={body} ta="center" raw="opacity: 0.82;"
            tw="max-md:text-[16px]">
            Give us the kitchen name, a delivery door and someone who answers a phone after service. Accounts open the
            same week and the first order can go in the same evening.
          </text>
          <text
            href="#account"
            tw="uppercase"
            size={16}
            weight={700}
            ls={0.06}
            color={c.ink}
            font={body}
            bg={c.sun}
            pad={{ t: 19, r: 36, b: 19, l: 36 }}
            m={{ t: 8 }}
            shadow={[[4, 0, 0, c.field]]}
            hover={{ bg: c.ground, shadow: [[4, 0, 0, c.sun]] }}
          >
            Open a kitchen account
          </text>
          <text size={14} color={c.ground} font={body} ta="center" raw="opacity: 0.55;">
            Field to Pass · 46 growers within 90 minutes · cut-off 9pm, delivery 4–6am
          </text>
        </box>
      </section>
    </box>
  );
};
