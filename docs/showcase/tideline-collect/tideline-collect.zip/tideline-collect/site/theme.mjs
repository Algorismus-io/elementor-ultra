/** Tideline design tokens — marine conservation, published-numbers voice. */
export default defineTheme({
  name: 'tideline',
  color: {
    ground: '#F2F7F8',  // page ground
    ink: '#132226',     // display + body text, dark bands
    sea: '#1E6B7A',     // primary / links / CTA
    kelp: '#4A7A4E',    // on-track, growth
    plastic: '#E2653A', // failure, warning, the honest bad news
    rule: '#D4E0E2',    // hairlines
    white: '#FFFFFF',
  },
  font: { head: 'Fraunces', body: 'Nunito Sans' },
  mode: 'literal',
});
