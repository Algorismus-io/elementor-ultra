import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Onsen Mirador',
  slug: 'onsen-mirador',
  seo: {
    title: 'Onsen Mirador — six pools, three hours, silence',
    description:
      'A geothermal bathhouse of six pools cut into basalt, open in three-hour sessions with a maximum of forty bathers. No treatments, no music, no phones.',
  },
};

const C = {
  ground: '#0E1416',
  ink: '#E8EEEC',
  steam: '#9FBDBD',
  cedar: '#A0714B',
  stone: '#3A4448',
  well: '#121A1C',
};

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 700 };

/* ── small type helpers ───────────────────────────────────────── */
const Eyebrow = ({ children, color = C.cedar }) => (
  <text font="Cinzel" size={12} weight={600} ls={0.26} color={color} tw="uppercase">
    {children}
  </text>
);

const Body = ({ children, size = 20, color = C.steam, maxw = 560 }) => (
  <text font="Cormorant Garamond" size={size} color={color} lh={1.65} maxw={maxw} mobile={{ size: 18 }}>
    {children}
  </text>
);

const Rule = ({ color = '#222E31' }) => <div h={1} w="100%" bg={color} pad={0} />;

/* ── the pool entry (registered component; content props only) ── */
const Pool = defineComponent(
  ({ name = '', temp = '', purpose = '' }) => (
    <div tw="flex flex-col gap-2 w-full" pad={{ t: 26, b: 26 }}>
      <div tw="flex flex-row items-start gap-4 w-full">
        <heading tag="h3" font="Cinzel" size={22} weight={500} color={C.ink} mobile={{ size: 19 }}>
          {name}
        </heading>
        <text font="Cinzel" size={13} weight={600} ls={0.12} color={C.cedar}>
          {temp}
        </text>
      </div>
      <text font="Cormorant Garamond" size={18} color={C.steam} lh={1.6} maxw={520}>
        {purpose}
      </text>
    </div>
  ),
  {
    title: 'Pool entry',
    props: {
      name: { label: 'Pool name', group: 'Pool' },
      temp: { label: 'Temperature', group: 'Pool' },
      purpose: { label: 'Purpose', group: 'Pool' },
    },
  },
);

const POOLS = [
  { name: 'The Source', temp: '42°', purpose: 'Where you start and where you should stay for at least twenty minutes before anything else.' },
  { name: 'The Cold Well', temp: '6°', purpose: 'Ninety seconds is enough. Breathe out slowly on the way in and do not gasp.' },
  { name: 'The Long Pool', temp: '37°', purpose: 'Twenty-eight metres, open to the sky in all weather. This is the one people come back for.' },
  { name: 'The Steam Room', temp: '45°', purpose: 'Saturated and unlit. Sit low, breathe through the nose, and leave before you want to.' },
  { name: 'The Ash Pool', temp: '39°', purpose: 'Mineral heavy and dark. Good for shoulders, and better in the second half of a session.' },
  { name: 'The Shallow', temp: '33°', purpose: 'Knee deep and lit from below. Where you go when hot is too much and cold is too far.' },
];

const STEPS = [
  { n: '01', t: 'Hot for twenty', d: 'The Source, unhurried. You are not warm until your shoulders drop.' },
  { n: '02', t: 'Cold for two', d: 'The Cold Well. Long exhale on entry, ninety seconds, out before you shiver.' },
  { n: '03', t: 'Rest for ten', d: 'Cedar bench, no towel over the face, no counting. Let the heat finish moving.' },
  { n: '04', t: 'Repeat three times', d: 'The same three moves. The circuit works because it does not change.' },
  { n: '05', t: 'Then an hour in the long pool', d: 'Thirty-seven degrees under open sky, until the session bell.' },
];

const ABSENT = [
  { t: 'No treatments', d: 'No massage, no scrubs, no wraps, nobody booked in to touch you. Water does the work.' },
  { t: 'No bar', d: 'Cold water, unlimited and free. Nothing to buy inside and nothing to carry between pools.' },
  { t: 'No music', d: 'No speakers, no playlist, no ambient soundtrack. Water on basalt is the whole programme.' },
];

const SESSIONS = [
  { time: '06:00', note: 'The quietest session. Rarely more than twenty bathers.' },
  { time: '09:00', note: 'Slow and half full. Good for a first visit.' },
  { time: '12:00', note: 'Fills late, empties fast.' },
  { time: '15:00', note: 'Steady. The long pool is warmest by now.' },
  { time: '18:00', note: 'Books out first, usually eleven days ahead.' },
];

const ACCESS = [
  { t: 'Step-free to the water', d: 'Ramped entry to the Source and the Long Pool, with a hoist and a trained attendant at both.' },
  { t: 'Private changing', d: 'Two single-occupancy step-free rooms with a bench, a call button and a locker at seated height.' },
  { t: 'Silence, adapted', d: 'We agree hand signals with you at the threshold, so nobody has to speak to ask for anything.' },
  { t: 'Tell us first', d: 'Write to us before you book and we will say plainly what we can adapt and what we cannot.' },
];

export default () => (
  <box tw="flex flex-col w-full" pad={0} bg={C.ground}>

    {/* 1 ── SPLIT HERO ─────────────────────────────────────────── */}
    <section tag="section" pad={0} tw="flex flex-col w-full">
      <grid cols="1.05fr 1fr" gap={0} w="100%" mobile={{ gridCols: 1 }}>
        <div
          tw="flex flex-col justify-center gap-7 w-full"
          pad={{ t: 120, b: 120, l: 72, r: 64 }}
          bg={C.ground}
          minh={720}
          tablet={{ pad: { t: 88, b: 88, l: 40, r: 36 }, minh: 560 }}
          mobile={{ pad: { t: 72, b: 64, l: 24, r: 24 }, minh: 0 }}
        >
          <Eyebrow>Onsen Mirador · Geothermal bathhouse</Eyebrow>
          <h1
            font="Cinzel"
            size={62}
            weight={500}
            color={C.ink}
            lh={1.1}
            maxw={620}
            tablet={{ size: 46 }}
            mobile={{ size: 34 }}
            motion={FADE}
          >
            Water, heat, cold, silence. Nothing else is offered.
          </h1>
          <Body size={22} maxw={580}>
            A geothermal bathhouse of six pools cut into basalt, open in three-hour sessions with a
            maximum of forty bathers. There are no treatments, no music and no phones past the lockers.
          </Body>
          <div tw="flex flex-row items-center gap-5 max-md:flex-col max-md:items-start" pad={{ t: 14 }}>
            <text
              href="#reserve"
              font="Cinzel"
              size={14}
              weight={600}
              ls={0.18}
              color={C.ground}
              bg={C.cedar}
              pad={[18, 34]}
              tw="uppercase hover:bg-[#E8EEEC]"
            >
              Reserve a session
            </text>
            <text font="Cormorant Garamond" size={18} color={C.steam}>
              48 for three hours · five sessions a day
            </text>
          </div>
        </div>
        <div tw="flex flex-col w-full" pad={0} minh={720} tablet={{ minh: 560 }} mobile={{ minh: 0 }}>
          <img src={media.onsen_steam_pool.id} w="100%" h={720} fit="cover" tablet={{ h: 560 }} mobile={{ h: 380 }} />
        </div>
      </grid>
    </section>

    {/* 2 ── THE SIX POOLS ──────────────────────────────────────── */}
    <section tag="section" pad={0} tw="flex flex-col w-full" bg={C.well}>
      <grid cols="1fr 1.35fr" gap={0} w="100%" mobile={{ gridCols: 1 }}>
        <div
          tw="flex flex-col gap-6 w-full"
          pad={{ t: 108, b: 108, l: 72, r: 56 }}
          bg={C.stone}
          tablet={{ pad: { t: 72, b: 56, l: 40, r: 36 } }}
          mobile={{ pad: { t: 56, b: 40, l: 24, r: 24 } }}
        >
          <Eyebrow color={C.ink}>Six pools</Eyebrow>
          <heading tag="h2" font="Cinzel" size={40} weight={500} color={C.ink} lh={1.15} maxw={420} mobile={{ size: 28 }}>
            Each pool has one temperature and one purpose.
          </heading>
          <Body color="#CFE0DE" maxw={420}>
            Cut into basalt and fed from the same spring at ninety-one degrees, cooled in stages. The
            numbers on the wall are the numbers in the water; we do not round them for comfort.
          </Body>
        </div>
        <div
          tw="flex flex-col w-full"
          pad={{ t: 92, b: 92, l: 64, r: 72 }}
          tablet={{ pad: { t: 56, b: 64, l: 40, r: 36 } }}
          mobile={{ pad: { t: 40, b: 56, l: 24, r: 24 } }}
          motion={FADE}
        >
          {POOLS.map((p, i) => (
            <div tw="flex flex-col w-full" pad={0} gap={0}>
              {i > 0 ? <Rule /> : null}
              <Pool name={p.name} temp={p.temp} purpose={p.purpose} />
            </div>
          ))}
        </div>
      </grid>
    </section>

    {/* 3 ── THE CIRCUIT ────────────────────────────────────────── */}
    <section tag="section" pad={0} tw="flex flex-col w-full">
      <grid cols="1fr 1.1fr" gap={0} w="100%" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col w-full" pad={0}>
          <img src={media.onsen_long_pool.id} w="100%" h={860} fit="cover" tablet={{ h: 620 }} mobile={{ h: 340 }} />
        </div>
        <div
          tw="flex flex-col gap-8 w-full justify-center"
          pad={{ t: 104, b: 104, l: 64, r: 72 }}
          tablet={{ pad: { t: 72, b: 72, l: 40, r: 36 } }}
          mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 } }}
        >
          <div tw="flex flex-col gap-5 w-full">
            <Eyebrow>The circuit · three hours</Eyebrow>
            <heading tag="h2" font="Cinzel" size={40} weight={500} color={C.ink} lh={1.15} maxw={520} mobile={{ size: 28 }}>
              Hot for twenty, cold for two, rest for ten.
            </heading>
            <Body maxw={520}>
              Repeat three times, then an hour in the long pool. That is the circuit and there is no
              other advice.
            </Body>
          </div>
          <div tw="flex flex-col gap-0 w-full">
            {STEPS.map((s, i) => (
              <div tw="flex flex-row gap-6 w-full items-start" pad={{ t: 20, b: 20 }}>
                <text font="Cinzel" size={13} weight={600} ls={0.14} color={C.cedar} w={38}>
                  {s.n}
                </text>
                <div tw="flex flex-col gap-1 w-full">
                  <heading tag="h3" font="Cinzel" size={19} weight={500} color={C.ink} mobile={{ size: 17 }}>
                    {s.t}
                  </heading>
                  <text font="Cormorant Garamond" size={18} color={C.steam} lh={1.55} maxw={440}>
                    {s.d}
                  </text>
                </div>
              </div>
            ))}
          </div>
        </div>
      </grid>
    </section>

    {/* 4 ── SILENCE, NUDITY, PHONES ────────────────────────────── */}
    <section
      tag="section"
      tw="flex flex-col w-full"
      bg={C.stone}
      pad={{ t: 104, b: 104, l: 72, r: 72 }}
      tablet={{ pad: { t: 72, b: 72, l: 40, r: 40 } }}
      mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 } }}
    >
      <grid cols="1fr 1.3fr" gap={56} w="100%" mobile={{ gap: 28, gridCols: 1 }}>
        <div tw="flex flex-col gap-5 w-full">
          <Eyebrow color={C.ink}>House rules</Eyebrow>
          <heading tag="h2" font="Cinzel" size={38} weight={500} color={C.ink} lh={1.15} maxw={380} mobile={{ size: 27 }}>
            Stated plainly, so nobody has to ask.
          </heading>
        </div>
        <div tw="flex flex-col gap-7 w-full" motion={FADE}>
          <text font="Cormorant Garamond" size={26} color="#EDF3F1" lh={1.5} maxw={640} mobile={{ size: 20 }}>
            Silence is enforced past the threshold, kindly and consistently. Bathing is unclothed in
            the inner rooms and swimwear is required in the long pool. Phones stay in the lockers and
            we do not make exceptions.
          </text>
          <Rule color="#4C585C" />
          <text font="Cormorant Garamond" size={19} color="#CFE0DE" lh={1.6} maxw={640}>
            If you need to be reachable, the desk will hold a number and come and find you. Staff use
            hand signals inside. A first reminder is a hand on the doorframe; there is rarely a second.
          </text>
        </div>
      </grid>
    </section>

    {/* 5 ── WHAT WE DO NOT HAVE ────────────────────────────────── */}
    <section
      tag="section"
      tw="flex flex-col gap-12 w-full"
      bg={C.ground}
      pad={{ t: 104, b: 104, l: 72, r: 72 }}
      tablet={{ pad: { t: 72, b: 72, l: 40, r: 40 } }}
      mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 }, gap: 32 }}
    >
      <div tw="flex flex-row items-end justify-between gap-8 w-full max-md:flex-col max-md:items-start max-md:gap-4">
        <heading tag="h2" font="Cinzel" size={38} weight={500} color={C.ink} lh={1.15} maxw={520} mobile={{ size: 27 }}>
          What we do not have.
        </heading>
        <Body size={19} maxw={380}>
          The list is short on purpose. Everything absent here is something that would otherwise
          interrupt three hours.
        </Body>
      </div>
      <grid cols={3} gap={0} w="100%" mobile={{ gridCols: 1 }}>
        {ABSENT.map((a) => (
          <div
            tw="flex flex-col gap-4 w-full"
            pad={{ t: 40, b: 40, r: 40 }}
           
            mobile={{ pad: { t: 28, b: 28, r: 0 } }}
          >
            <Rule />
            <heading tag="h3" font="Cinzel" size={24} weight={500} color={C.cedar} pad={{ t: 20 }} mobile={{ size: 20 }}>
              {a.t}
            </heading>
            <text font="Cormorant Garamond" size={19} color={C.steam} lh={1.6}>
              {a.d}
            </text>
          </div>
        ))}
      </grid>
    </section>

    {/* 6 ── SESSIONS & CAPACITY ────────────────────────────────── */}
    <section tag="section" pad={0} tw="flex flex-col w-full" bg={C.well}>
      <grid cols="1.15fr 1fr" gap={0} w="100%" mobile={{ gridCols: 1 }}>
        <div
          tw="flex flex-col gap-2 w-full"
          pad={{ t: 100, b: 100, l: 72, r: 64 }}
          tablet={{ pad: { t: 72, b: 64, l: 40, r: 36 } }}
          mobile={{ pad: { t: 56, b: 40, l: 24, r: 24 } }}
        >
          <Eyebrow>Five sessions a day</Eyebrow>
          <heading tag="h2" font="Cinzel" size={38} weight={500} color={C.ink} lh={1.15} maxw={480} pad={{ t: 12, b: 20 }} mobile={{ size: 27 }}>
            Forty bathers per session, and never more.
          </heading>
          {SESSIONS.map((s) => (
            <div tw="flex flex-col w-full" pad={0}>
              <Rule />
              <div tw="flex flex-row gap-8 items-start w-full" pad={{ t: 18, b: 18 }}>
                <text font="Cinzel" size={20} weight={500} color={C.cedar} w={92}>
                  {s.time}
                </text>
                <text font="Cormorant Garamond" size={19} color={C.steam} lh={1.55}>
                  {s.note}
                </text>
              </div>
            </div>
          ))}
        </div>
        <div
          tw="flex flex-col gap-6 justify-center w-full"
          bg={C.stone}
          pad={{ t: 100, b: 100, l: 60, r: 64 }}
          tablet={{ pad: { t: 64, b: 64, l: 40, r: 36 } }}
          mobile={{ pad: { t: 48, b: 48, l: 24, r: 24 } }}
          motion={FADE}
        >
          <Eyebrow color={C.ink}>Price</Eyebrow>
          <text font="Cinzel" size={64} weight={500} color={C.ink} lh={1} mobile={{ size: 46 }}>
            48
          </text>
          <text font="Cormorant Garamond" size={22} color="#EDF3F1" lh={1.55} maxw={380} mobile={{ size: 19 }}>
            For three hours, including a towel, a robe and as much cold water as you can drink.
          </text>
          <Rule color="#4C585C" />
          <text font="Cormorant Garamond" size={20} color="#CFE0DE" lh={1.55} maxw={380}>
            Ten-session card for 400. The 6am session is the quietest and the 6pm one books out first.
          </text>
        </div>
      </grid>
    </section>

    {/* 7 ── ACCESSIBILITY ──────────────────────────────────────── */}
    <section
      tag="section"
      tw="flex flex-col gap-10 w-full"
      bg={C.ground}
      pad={{ t: 104, b: 104, l: 72, r: 72 }}
      tablet={{ pad: { t: 72, b: 72, l: 40, r: 40 } }}
      mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 }, gap: 28 }}
    >
      <grid cols="1fr 1.3fr" gap={56} w="100%" mobile={{ gap: 24, gridCols: 1 }}>
        <div tw="flex flex-col gap-5 w-full">
          <Eyebrow>Accessibility</Eyebrow>
          <heading tag="h2" font="Cinzel" size={38} weight={500} color={C.ink} lh={1.15} maxw={400} mobile={{ size: 27 }}>
            What we can adapt, and what we cannot.
          </heading>
          <Body size={19} maxw={400}>
            The building is one level below the street with a lift from the lockers to every pool
            deck. Ask us anything before you pay.
          </Body>
        </div>
        <grid cols={2} gap={0} w="100%" mobile={{ gridCols: 1 }}>
          {ACCESS.map((a) => (
            <div tw="flex flex-col gap-3 w-full" pad={{ t: 28, b: 28, r: 36 }} mobile={{ pad: { t: 20, b: 20, r: 0 } }}>
              <Rule />
              <heading tag="h3" font="Cinzel" size={20} weight={500} color={C.ink} pad={{ t: 16 }} mobile={{ size: 18 }}>
                {a.t}
              </heading>
              <text font="Cormorant Garamond" size={18} color={C.steam} lh={1.6}>
                {a.d}
              </text>
            </div>
          ))}
        </grid>
      </grid>
    </section>

    {/* 8 ── RESERVE ────────────────────────────────────────────── */}
    <section tag="section" id="reserve" pad={0} tw="flex flex-col w-full" bg={C.well}>
      <grid cols="1fr 1.05fr" gap={0} w="100%" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col w-full" pad={0}>
          <img src={media.onsen_cold_well.id} w="100%" h={640} fit="cover" tablet={{ h: 480 }} mobile={{ h: 320 }} />
        </div>
        <div
          tw="flex flex-col gap-7 justify-center w-full"
          pad={{ t: 104, b: 104, l: 64, r: 72 }}
          tablet={{ pad: { t: 72, b: 72, l: 40, r: 36 } }}
          mobile={{ pad: { t: 56, b: 64, l: 24, r: 24 } }}
        >
          <Eyebrow>Reserve</Eyebrow>
          <heading tag="h2" font="Cinzel" size={44} weight={500} color={C.ink} lh={1.12} maxw={520} mobile={{ size: 30 }}>
            Three hours, forty bathers, one door.
          </heading>
          <Body size={21} maxw={520}>
            Choose a session and arrive fifteen minutes before it starts. Lockers, towel and robe are
            waiting; phones stay behind at the threshold and the rest is water.
          </Body>
          <div tw="flex flex-row items-center gap-5 max-md:flex-col max-md:items-start">
            <text
              href="#reserve"
              font="Cinzel"
              size={14}
              weight={600}
              ls={0.18}
              color={C.ground}
              bg={C.cedar}
              pad={[18, 34]}
              tw="uppercase hover:bg-[#E8EEEC]"
            >
              Reserve a session
            </text>
            <text font="Cormorant Garamond" size={18} color={C.steam}>
              06:00 · 09:00 · 12:00 · 15:00 · 18:00
            </text>
          </div>
          <Rule />
          <text font="Cormorant Garamond" size={17} color={C.steam} lh={1.6} maxw={520}>
            Onsen Mirador · Silent bathing since the spring was capped. No treatments, no bar, no music.
          </text>
        </div>
      </grid>
    </section>
  </box>
);
