/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "twelve-harvests--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'twelve-harvests--';

export default [
  { slot: `${PREFIX}brew_still`, file: join(MEDIA_DIR, "brew_still.jpg"), alt: "A filter brew resting on a wooden counter" },
  { slot: `${PREFIX}cherries`, file: join(MEDIA_DIR, "cherries.jpg"), alt: "Ripe coffee cherries on the branch" },
  { slot: `${PREFIX}drying_beds`, file: join(MEDIA_DIR, "drying_beds.jpg"), alt: "Parchment coffee drying on raised beds" },
];
