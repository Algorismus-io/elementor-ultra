export default { name: 'plainroll' };
