import { MEDIA as M } from '../data/media.mjs';

export const meta = {
  title: 'Fourth Hand — vintage watches, opened and documented',
  slug: 'fourth-hand',
  seo: {
    title: 'Fourth Hand — vintage watch marketplace',
    description:
      '94 pre-owned mechanical watches in stock, each opened, timed on a Witschi over five positions, graded A to D, and sold with its service records and ownership file.',
  },
};

/* ── tokens (theme arrives as `t`; these mirror it for module-scope helpers) ───────── */
const GROUND = '#131417';
const INK = '#E9E7E2';
const GOLD = '#C9A227';
const STEEL = '#8E959C';
const CARD = '#1C1E22';
const LINE = '#2A2D33';

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* ── small building blocks ────────────────────────────────────────────────────────── */
const Eyebrow = ({ children }) => (
  <text size={11} weight={600} ls={0.22} color={GOLD} font="Lora" raw="text-transform: uppercase;">
    {children}
  </text>
);

const Rule = ({ color = LINE }) => <div tw="w-full h-[1px]" bg={color} pad={0} />;

const SpecRow = ({ k, v, accent }) => (
  <row tw="w-full flex flex-row justify-between items-end gap-2" pad={0}>
    <text w="hug" size={12} color={STEEL} font="Lora">{k}</text>
    <text w="hug" size={12} weight={accent ? 600 : 400} color={accent ? GOLD : INK} font="Lora">{v}</text>
  </row>
);

/* ── the catalogue cell — one registered component, content props only ────────────── */
const Listing = defineComponent(
  ({
    lot = 'FH-000',
    model = 'Model',
    spec = 'Reference',
    grade = 'B',
    serviced = '—',
    rate = '—',
    price = '—',
  }) => (
    <box
      tw="flex flex-col gap-3 p-5 h-full hover:bg-[#22252A]"
      bg={CARD}
      border={[1, LINE]}
      hover={{ border: [1, GOLD] }}
    >
      <row tw="w-full flex flex-row justify-between items-center gap-3" pad={0}>
        <text w="hug" size={11} ls={0.14} color={STEEL} font="Lora">{lot}</text>
        <text w="hug" size={11} weight={700} ls={0.1} color={GROUND} bg={GOLD} pad={[2, 8]} font="Lora">
          {grade}
        </text>
      </row>
      <heading tag="h3" size={19} lh={1.2} weight={500} font="Bodoni Moda" color={INK}>{model}</heading>
      <text size={13} lh={1.55} color={STEEL} font="Lora">{spec}</text>
      <div tw="w-full flex flex-col gap-1.5 pt-3 mt-auto border-t border-[#2A2D33]" pad={{ t: 12 }}>
        <SpecRow k="Serviced" v={serviced} />
        <SpecRow k="Rate" v={rate} />
        <SpecRow k="Price" v={price} accent />
      </div>
    </box>
  ),
  {
    title: 'Catalogue listing',
    props: {
      lot: { label: 'Lot number', group: 'Listing' },
      model: { label: 'Model', group: 'Listing' },
      spec: { label: 'Specification', group: 'Listing' },
      grade: { label: 'Grade', group: 'Condition' },
      serviced: { label: 'Serviced', group: 'Condition' },
      rate: { label: 'Rate', group: 'Condition' },
      price: { label: 'Price (GBP)', group: 'Listing' },
    },
  },
);

const STOCK = [
  { lot: 'FH-2214', model: '1972 Omega Speedmaster 145.022', spec: 'Cal. 861, transitional dial, original bracelet 1171/633.', grade: 'A', serviced: 'January 2026', rate: '+2 s/day', price: '12,400' },
  { lot: 'FH-2198', model: '1961 Rolex Explorer 1016', spec: 'Gilt underline dial, unpolished lugs, service hands declared.', grade: 'B', serviced: 'November 2025', rate: '−1 s/day', price: '38,000' },
  { lot: 'FH-2233', model: '1959 Jaeger-LeCoultre Memovox E855', spec: 'Cal. K825, alarm functions on all positions, later crown.', grade: 'B', serviced: 'December 2025', rate: '+4 s/day', price: '6,900' },
  { lot: 'FH-2241', model: '1969 Zenith El Primero A384', spec: 'Cal. 3019 PHC, redialled by a Swiss house in the 1990s.', grade: 'C', serviced: 'October 2025', rate: '+6 s/day', price: '21,500' },
  { lot: 'FH-2256', model: '1966 Universal Genève Polerouter Date', spec: 'Microrotor cal. 218-2, original dial, crisp case bevels.', grade: 'A', serviced: 'April 2026', rate: '+2 s/day', price: '4,300' },
  { lot: 'FH-2260', model: '1978 Tudor Submariner 94010', spec: 'Snowflake handset, faded blue bezel, ETA 2776 running true.', grade: 'B', serviced: 'February 2026', rate: '+5 s/day', price: '16,750' },
  { lot: 'FH-2267', model: '1970 Seiko 6139-6002', spec: 'Polished case, replacement chronograph seconds hand.', grade: 'C', serviced: 'February 2026', rate: '+8 s/day', price: '2,150' },
  { lot: 'FH-2271', model: '1971 Certina DS-2 Chronolympic', spec: 'Valjoux 726, sold as seen: pusher sticks, dial water-marked.', grade: 'D', serviced: 'Not serviced', rate: '+22 s/day', price: '2,600' },
];

const COUNTERS = [
  { n: '94', k: 'Pieces in stock' },
  { n: '11', k: 'Added this week' },
  { n: '5', k: 'Positions timed' },
  { n: '24', k: 'Month guarantee' },
];

const INSPECTION = [
  { n: '01', h: 'The case comes off', b: 'Every watch is opened on the bench and the movement photographed before anything else happens. Those photographs go in the file whether they flatter the watch or not.' },
  { n: '02', h: 'Five positions on the Witschi', b: 'Dial up, dial down, crown down, crown left, crown up. We publish the average daily rate, the beat error and the amplitude, not a rounded number that sounds good.' },
  { n: '03', h: 'Pressure, not a promise', b: 'Water resistance is tested on a dry chamber and reported as tested to a depth, or reported as not tested. Vintage gaskets are replaced only where the case design allows it.' },
  { n: '04', h: 'Every part against the reference', b: 'Hands, dial, crown, bezel, bracelet and movement are checked against the reference. If a part is not original we say which one and why.' },
];

const FILE = [
  { h: 'Movement photographs', b: 'Full-plate and detail shots taken with the case back off, before and after any service work.' },
  { h: 'Timing results', b: 'Witschi printout across five positions: rate, amplitude and beat error, dated and signed.' },
  { h: 'Service history', b: 'Invoices and worksheets from us and from every prior watchmaker we could trace.' },
  { h: 'Chain of ownership', b: 'Names, dates and territories as far back as we can prove it. Where we cannot prove it we write unknown.' },
];

const GRADES = [
  { g: 'A', img: M.watch_macro.id, h: 'Unpolished', b: 'Sharp lugs, original everything — dial, hands, crown, case finish as it left the factory. The bevels still cut light.' },
  { g: 'B', img: M.movement.id, h: 'Honest wear', b: 'Marks consistent with a life on a wrist. One or two service parts, each named in the file. Case geometry intact.' },
  { g: 'C', img: M.bench.id, h: 'Polished or redialled', b: 'Soft lugs, a refinished dial, or both. Correct and running, priced accordingly, and described without euphemism.' },
  { g: 'D', img: M.watch_macro.id, h: 'Project piece', b: 'Sold as seen. Faults are listed, the price reflects them, and no guarantee of any kind attaches to the sale.' },
];

const SELLING = [
  { n: '01', h: 'Send photographs', b: 'Dial, case back, lugs, movement if you have it open. A phone camera is enough.' },
  { n: '02', h: 'Cash offer in 48 hours', b: 'A firm number against current trade, not a range and not a consignment estimate.' },
  { n: '03', h: 'Insured collection', b: 'We book the courier, we pay for it, and the watch is covered door to door at the offer value.' },
  { n: '04', h: 'Paid the next day', b: 'Our watchmaker signs it off, payment lands the day after. If it is not what you described, it goes back at our cost.' },
];

const VOIDS = [
  'Opening the case yourself, or having it opened by anyone who is not us.',
  'A service performed elsewhere within the guarantee period without telling us first.',
  'Water damage on a watch we reported as not pressure-tested.',
  'Impact damage, magnetism from a device, or parts swapped after delivery.',
];

const CREDENTIALS = [
  { h: 'Ola Brenner', b: 'Head watchmaker. WOSTEP-certified, fourteen years at an independent restorer in Bienne before joining us in 2019.' },
  { h: 'Marguerite Adeyemi', b: 'Dealer and buyer. Fifteen years in the vintage trade, BADA member, sits on two auction-house condition panels.' },
  { h: 'The bench', b: 'Witschi Chronoscope M1, Elma cleaning line, Greiner pressure chamber, and a parts library going back to 1948.' },
  { h: 'The terms', b: 'Registered in England, insured to 2m in transit and on premises, and audited annually against our own stock file.' },
];

/* ── page ─────────────────────────────────────────────────────────────────────────── */
export default ({ theme: t }) => (
  <box tw="w-full flex flex-col" pad={0} bg={GROUND}>

    {/* masthead */}
    <box tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 18, b: 18 }} bg={GROUND}>
      <row tw="w-full max-w-[1240px] flex flex-row justify-between items-center gap-4" pad={0}>
        <text w="hug" size={17} weight={500} ls={0.16} color={INK} font="Bodoni Moda" raw="text-transform: uppercase;">
          Fourth Hand
        </text>
        <text w="hug" size={11} ls={0.12} color={STEEL} font="Lora" tw="max-md:hidden">
          Vintage watches · Clerkenwell, London · Est. 2011
        </text>
      </row>
    </box>
    <Rule />

    {/* ── 1. stock counter + catalogue grid ──────────────────────────────────────── */}
    <box id="stock" tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 72, b: 88 }} bg={GROUND}>
      <div tw="w-full max-w-[1240px] flex flex-col gap-14" pad={0}>

        <grid cols={12} gapX={40} gapY={32} tw="w-full items-center" tablet={{ gridCols: 6 }}>
          <div span={7} tablet={{ span: 6 }} mobile={{ span: 1 }} tw="flex flex-col gap-6" pad={0}>
            <Eyebrow>94 pieces in stock · updated 13 August</Eyebrow>
            <h1
              size={68}
              lh={1.02}
              weight={400}
              font="Bodoni Moda"
              color={INK}
              tablet={{ size: 52 }}
              mobile={{ size: 34 }}
            >
              Every watch on this page has been opened.
            </h1>
            <text size={16} lh={1.7} color={STEEL} font="Lora" maxw={620} mobile={{ size: 15 }}>
              94 pieces in stock, each inspected by our watchmaker, timed on a Witschi over five
              positions, and sold with the service records and the previous owner's paperwork where
              it exists.
            </text>
            <row tw="flex flex-row gap-4 items-center flex-wrap" pad={{ t: 4 }}>
              <text
                w="hug"
                href="#catalogue"
                size={13}
                weight={600}
                ls={0.1}
                color={GROUND}
                bg={GOLD}
                pad={[14, 26]}
                font="Lora"
                tw="hover:bg-[#E0B62C]"
              >
                Browse the catalogue
              </text>
              <text w="hug" href="#selling" size={13} color={INK} font="Lora" pad={[14, 4]} tw="hover:text-[#C9A227]">
                Or sell us yours →
              </text>
            </row>
          </div>
          <div span={5} tablet={{ span: 6 }} mobile={{ span: 1 }} pad={0} tw="flex flex-col">
            <img src={M.watch_macro.id} tw="w-full h-[420px] object-cover max-lg:h-[320px] max-md:h-[240px]" />
          </div>
        </grid>

        {/* counter strip */}
        <div tw="w-full flex flex-col" pad={0}>
          <Rule color={GOLD} />
          <grid cols={4} gapX={0} gapY={0} tw="w-full" tablet={{ gridCols: 4 }} mobile={{ gridCols: 2 }}>
            {COUNTERS.map((c) => (
              <div tw="flex flex-col gap-1 py-6 px-5 max-md:px-3" pad={0} border={[1, LINE]}>
                <text size={38} lh={1} weight={400} color={INK} font="Bodoni Moda" mobile={{ size: 28 }}>{c.n}</text>
                <text size={11} ls={0.12} color={STEEL} font="Lora" raw="text-transform: uppercase;">{c.k}</text>
              </div>
            ))}
          </grid>
        </div>

        {/* the grid */}
        <div id="catalogue" tw="w-full flex flex-col gap-6" pad={0}>
          <row tw="w-full flex flex-row justify-between items-end gap-4 flex-wrap" pad={0}>
            <h2 w="hug" size={34} weight={400} font="Bodoni Moda" color={INK} mobile={{ size: 26 }}>
              Current stock
            </h2>
            <text w="hug" size={12} color={STEEL} font="Lora">
              Grades A–D · prices in GBP · rate measured after service
            </text>
          </row>

          <grid cols={12} gapX={20} gapY={20} tw="w-full" tablet={{ gridCols: 6 }}>
            {/* feature listing — the canonical sample */}
            <div
              span={6}
              tablet={{ span: 6 }}
              mobile={{ span: 1 }}
              tw="flex flex-col hover:bg-[#22252A]"
              pad={0}
              bg={CARD}
              border={[1, LINE]}
              motion={FADE}
            >
              <img src={M.movement.id} tw="w-full h-[260px] object-cover max-md:h-[200px]" />
              <div tw="flex flex-col gap-3 p-6 max-md:p-5" pad={0}>
                <row tw="w-full flex flex-row justify-between items-center gap-3" pad={0}>
                  <text w="hug" size={11} ls={0.14} color={STEEL} font="Lora">FH-2205 · second execution</text>
                  <text w="hug" size={11} weight={700} ls={0.1} color={GROUND} bg={GOLD} pad={[2, 8]} font="Lora">B</text>
                </row>
                <heading tag="h3" size={28} lh={1.15} weight={400} font="Bodoni Moda" color={INK} mobile={{ size: 22 }}>
                  1968 Heuer Autavia 2446C
                </heading>
                <text size={14} lh={1.6} color={STEEL} font="Lora">
                  Valjoux 72, compressor case unpolished with the original chamfer intact. Dial
                  original, lume matched and honest. One service pusher gasket, noted in the file.
                </text>
                <div tw="w-full flex flex-col gap-1.5 pt-4 border-t border-[#2A2D33]" pad={{ t: 14 }}>
                  <SpecRow k="Serviced" v="March 2026" />
                  <SpecRow k="Rate (5 positions)" v="+3 s/day" />
                  <SpecRow k="Amplitude" v="278°" />
                  <SpecRow k="Price" v="14,800" accent />
                </div>
              </div>
            </div>

            {/* first four cells beside the feature */}
            {STOCK.slice(0, 2).map((s) => (
              <div span={3} tablet={{ span: 3 }} mobile={{ span: 1 }} pad={0} tw="flex flex-col">
                <Listing {...s} />
              </div>
            ))}
            {STOCK.slice(2, 4).map((s) => (
              <div span={3} tablet={{ span: 3 }} mobile={{ span: 1 }} pad={0} tw="flex flex-col">
                <Listing {...s} />
              </div>
            ))}
            {STOCK.slice(4).map((s) => (
              <div span={3} tablet={{ span: 3 }} mobile={{ span: 1 }} pad={0} tw="flex flex-col">
                <Listing {...s} />
              </div>
            ))}
          </grid>

          <row tw="w-full flex flex-row justify-between items-center gap-4 flex-wrap" pad={{ t: 8 }}>
            <text w="hug" size={13} color={STEEL} font="Lora">
              Showing 9 of 94. The rest of the stock file is available on request or in the shop.
            </text>
            <text w="hug" href="#browse" size={13} weight={600} color={GOLD} font="Lora" tw="hover:text-[#E9E7E2]">
              See the full catalogue →
            </text>
          </row>
        </div>
      </div>
    </box>

    {/* ── 2. the four-point inspection ───────────────────────────────────────────── */}
    <box tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 80, b: 80 }} bg={CARD}>
      <grid cols={12} gapX={48} gapY={40} tw="w-full max-w-[1240px]" tablet={{ gridCols: 6 }}>
        <div span={4} tablet={{ span: 6 }} mobile={{ span: 1 }} tw="flex flex-col gap-6" pad={0}>
          <Eyebrow>The four-point inspection</Eyebrow>
          <h2 size={40} lh={1.1} weight={400} font="Bodoni Moda" color={INK} mobile={{ size: 28 }} motion={FADE}>
            We open the case, and then we write down what we found.
          </h2>
          <text size={15} lh={1.7} color={STEEL} font="Lora">
            We open the case, photograph the movement, time it in five positions, pressure-test water
            resistance, and check every part against the reference. If a part is not original we say
            which one and why.
          </text>
          <img src={M.bench.id} tw="w-full h-[240px] object-cover max-md:h-[200px]" />
        </div>
        <div span={8} tablet={{ span: 6 }} mobile={{ span: 1 }} pad={0} tw="flex flex-col">
          <grid cols={2} gapX={32} gapY={32} tw="w-full" tablet={{ gridCols: 2 }}>
            {INSPECTION.map((p) => (
              <div tw="flex flex-col gap-3 pt-6" pad={{ t: 24 }} raw="border-top: 1px solid #2A2D33;">
                <text size={12} weight={700} ls={0.16} color={GOLD} font="Lora">{p.n}</text>
                <heading tag="h3" size={22} lh={1.25} weight={400} font="Bodoni Moda" color={INK}>{p.h}</heading>
                <text size={14} lh={1.7} color={STEEL} font="Lora">{p.b}</text>
              </div>
            ))}
          </grid>
        </div>
      </grid>
    </box>

    {/* ── 3. provenance file ─────────────────────────────────────────────────────── */}
    <box tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 80, b: 80 }} bg={GROUND}>
      <div tw="w-full max-w-[1240px] flex flex-col gap-10" pad={0}>
        <row tw="w-full flex flex-row justify-between items-end gap-8 flex-wrap" pad={0}>
          <div w="hug" tw="flex flex-col gap-4 max-w-[540px]" pad={0}>
            <Eyebrow>The provenance file</Eyebrow>
            <h2 size={40} lh={1.1} weight={400} font="Bodoni Moda" color={INK} mobile={{ size: 28 }}>
              Four documents travel with every watch.
            </h2>
          </div>
          <text w="hug" size={15} lh={1.7} color={STEEL} font="Lora" maxw={520}>
            Every watch ships with a printed file: movement photographs, timing results, service
            history, and the chain of ownership as far back as we can prove it. Where we cannot prove
            it we write unknown.
          </text>
        </row>
        <grid cols={4} gapX={20} gapY={20} tw="w-full" tablet={{ gridCols: 2 }}>
          {FILE.map((f, i) => (
            <div
              tw="flex flex-col gap-3 p-6 h-full hover:bg-[#22252A]"
              pad={0}
              bg={CARD}
              border={[1, LINE]}
              motion={FADE}
            >
              <text size={11} weight={700} ls={0.16} color={GOLD} font="Lora">{`0${i + 1}`}</text>
              <heading tag="h3" size={20} lh={1.25} weight={400} font="Bodoni Moda" color={INK}>{f.h}</heading>
              <text size={13} lh={1.65} color={STEEL} font="Lora">{f.b}</text>
            </div>
          ))}
        </grid>
      </div>
    </box>

    {/* ── 4. grading scale ───────────────────────────────────────────────────────── */}
    <box tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 80, b: 80 }} bg={CARD}>
      <div tw="w-full max-w-[1240px] flex flex-col gap-10" pad={0}>
        <div tw="flex flex-col gap-4 max-w-[720px]" pad={0}>
          <Eyebrow>The grading scale</Eyebrow>
          <h2 size={40} lh={1.1} weight={400} font="Bodoni Moda" color={INK} mobile={{ size: 28 }}>
            Four grades, and no room between them.
          </h2>
          <text size={15} lh={1.7} color={STEEL} font="Lora">
            The grade is set by the watchmaker at the bench, not by the person writing the listing.
            It never moves to help a sale.
          </text>
        </div>
        <grid cols={4} gapX={20} gapY={24} tw="w-full" tablet={{ gridCols: 2 }}>
          {GRADES.map((g) => (
            <div tw="flex flex-col" pad={0} bg={GROUND} border={[1, LINE]}>
              <img src={g.img} tw="w-full h-[200px] object-cover max-md:h-[180px]" />
              <div tw="flex flex-col gap-3 p-6 max-md:p-5" pad={0}>
                <row tw="w-full flex flex-row items-end gap-3" pad={0}>
                  <text w="hug" size={40} lh={1} weight={400} color={GOLD} font="Bodoni Moda">{g.g}</text>
                  <heading tag="h3" w="hug" size={18} weight={400} font="Bodoni Moda" color={INK}>{g.h}</heading>
                </row>
                <text size={13} lh={1.65} color={STEEL} font="Lora">{g.b}</text>
              </div>
            </div>
          ))}
        </grid>
        <text size={13} lh={1.7} color={STEEL} font="Lora" maxw={760}>
          A: unpolished, sharp lugs, original everything. B: honest wear, one or two service parts.
          C: polished or redialled, priced accordingly. D: project piece, sold as seen, no guarantee.
        </text>
      </div>
    </box>

    {/* ── 5. selling to us ───────────────────────────────────────────────────────── */}
    <box id="selling" tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 80, b: 80 }} bg={GROUND}>
      <div tw="w-full max-w-[1240px] flex flex-col gap-10" pad={0}>
        <row tw="w-full flex flex-row justify-between items-end gap-8 flex-wrap" pad={0}>
          <div w="hug" tw="flex flex-col gap-4 max-w-[560px]" pad={0}>
            <Eyebrow>Selling to us</Eyebrow>
            <h2 size={40} lh={1.1} weight={400} font="Bodoni Moda" color={INK} mobile={{ size: 28 }}>
              Send photographs, get a cash offer within 48 hours.
            </h2>
          </div>
          <text w="hug" size={15} lh={1.7} color={STEEL} font="Lora" maxw={500}>
            Insured collection, and payment the day after our watchmaker signs it off. We buy
            outright between 2,000 and 40,000 — no consignment, no waiting on a buyer, no fee taken
            off the back end.
          </text>
        </row>
        <grid cols={4} gapX={0} gapY={0} tw="w-full" tablet={{ gridCols: 2 }}>
          {SELLING.map((s) => (
            <div tw="flex flex-col gap-3 p-7 max-md:p-5 h-full" pad={0} border={[1, LINE]} bg={GROUND}>
              <text size={12} weight={700} ls={0.16} color={GOLD} font="Lora">{s.n}</text>
              <heading tag="h3" size={20} lh={1.25} weight={400} font="Bodoni Moda" color={INK}>{s.h}</heading>
              <text size={13} lh={1.65} color={STEEL} font="Lora">{s.b}</text>
            </div>
          ))}
        </grid>
      </div>
    </box>

    {/* ── 6. guarantee ───────────────────────────────────────────────────────────── */}
    <box tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 80, b: 80 }} bg={CARD}>
      <grid cols={12} gapX={48} gapY={40} tw="w-full max-w-[1240px]" tablet={{ gridCols: 6 }}>
        <div
          span={6}
          tablet={{ span: 6 }}
          mobile={{ span: 1 }}
          tw="flex flex-col gap-5 p-8 max-md:p-6"
          pad={0}
          bg={GROUND}
          border={[1, GOLD]}
          motion={FADE}
        >
          <Eyebrow>The guarantee</Eyebrow>
          <h2 size={34} lh={1.15} weight={400} font="Bodoni Moda" color={INK} mobile={{ size: 26 }}>
            24 months on authenticity. 14 days for any reason at all.
          </h2>
          <text size={15} lh={1.7} color={STEEL} font="Lora">
            24-month authenticity guarantee and a 14-day return with no reason required. Open the
            case yourself and both end immediately.
          </text>
          <div tw="w-full flex flex-col gap-2 pt-4 border-t border-[#2A2D33]" pad={{ t: 16 }}>
            <SpecRow k="Authenticity" v="24 months" />
            <SpecRow k="Return window" v="14 days, no reason" />
            <SpecRow k="Refund" v="Full, including outbound carriage" accent />
          </div>
        </div>
        <div span={6} tablet={{ span: 6 }} mobile={{ span: 1 }} tw="flex flex-col gap-5" pad={0}>
          <Eyebrow>What voids it</Eyebrow>
          <text size={15} lh={1.7} color={STEEL} font="Lora">
            Four things, stated plainly so nobody has to read them out of a paragraph later.
          </text>
          <div tw="w-full flex flex-col" pad={0}>
            {VOIDS.map((v, i) => (
              <row tw="w-full flex flex-row gap-4 items-start py-4" pad={{ t: 16, b: 16 }} raw="border-top: 1px solid #2A2D33;">
                <text w="hug" size={12} weight={700} color={GOLD} font="Lora">{`0${i + 1}`}</text>
                <text size={14} lh={1.65} color={INK} font="Lora">{v}</text>
              </row>
            ))}
          </div>
        </div>
      </grid>
    </box>

    {/* ── 7. credentials ─────────────────────────────────────────────────────────── */}
    <box tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 80, b: 80 }} bg={GROUND}>
      <grid cols={12} gapX={48} gapY={40} tw="w-full max-w-[1240px]" tablet={{ gridCols: 6 }}>
        <div span={5} tablet={{ span: 6 }} mobile={{ span: 1 }} tw="flex flex-col gap-6" pad={0}>
          <Eyebrow>Who signs it off</Eyebrow>
          <h2 size={40} lh={1.1} weight={400} font="Bodoni Moda" color={INK} mobile={{ size: 28 }}>
            One watchmaker, one dealer, one bench.
          </h2>
          <img src={M.bench.id} tw="w-full h-[300px] object-cover max-md:h-[220px]" />
        </div>
        <div span={7} tablet={{ span: 6 }} mobile={{ span: 1 }} pad={0} tw="flex flex-col">
          <grid cols={2} gapX={24} gapY={24} tw="w-full" tablet={{ gridCols: 2 }}>
            {CREDENTIALS.map((c) => (
              <div tw="flex flex-col gap-3 p-6 h-full hover:bg-[#22252A]" pad={0} bg={CARD} border={[1, LINE]}>
                <heading tag="h3" size={20} lh={1.25} weight={400} font="Bodoni Moda" color={INK}>{c.h}</heading>
                <text size={13} lh={1.7} color={STEEL} font="Lora">{c.b}</text>
              </div>
            ))}
          </grid>
        </div>
      </grid>
    </box>

    {/* ── 8. browse current stock — the one centred section ──────────────────────── */}
    <box
      id="browse"
      tw="w-full flex flex-col items-center text-center px-6 max-md:px-5"
      pad={{ t: 96, b: 96 }}
      bg={CARD}
      raw="border-top: 1px solid #C9A227;"
    >
      <div tw="w-full max-w-[760px] flex flex-col items-center gap-6" pad={0}>
        <Eyebrow>94 in stock · 11 added this week</Eyebrow>
        <h2 size={52} lh={1.05} weight={400} ta="center" font="Bodoni Moda" color={INK} mobile={{ size: 30 }} motion={FADE}>
          Browse the current stock.
        </h2>
        <text size={16} lh={1.7} ta="center" color={STEEL} font="Lora" maxw={620}>
          Each listing carries its grade, its timing results and its file. Nothing is hidden behind
          an enquiry form, and nothing is described as mint.
        </text>
        <text
          w="hug"
          href="#catalogue"
          size={13}
          weight={600}
          ls={0.1}
          color={GROUND}
          bg={GOLD}
          pad={[16, 34]}
          font="Lora"
          tw="hover:bg-[#E0B62C]"
        >
          Browse the catalogue
        </text>
      </div>
    </box>

    {/* footer */}
    <Rule />
    <box tw="w-full flex flex-col items-center px-6 max-md:px-5" pad={{ t: 28, b: 36 }} bg={GROUND}>
      <row tw="w-full max-w-[1240px] flex flex-row justify-between items-center gap-4 flex-wrap" pad={0}>
        <text w="hug" size={12} color={STEEL} font="Lora">
          Fourth Hand · 14 Clerkenwell Green, London · Registered in England 07741220
        </text>
        <text w="hug" size={12} color={STEEL} font="Lora">
          Every watch on this page has been opened.
        </text>
      </row>
    </box>
  </box>
);
