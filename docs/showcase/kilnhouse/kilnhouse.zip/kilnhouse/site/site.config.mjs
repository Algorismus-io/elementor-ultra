export default { name: 'kilnhouse' };
