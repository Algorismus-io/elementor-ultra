/** Field to Pass — design tokens. */
export default defineTheme({
  name: 'field-to-pass',
  color: {
    ground: '#F5F7F0',
    ink: '#1C2418',
    field: '#4E7B3A',
    soil: '#7A5230',
    sun: '#E5A83B',
    rule: '#D2D9C7',
  },
  font: { head: 'Alfa Slab One', body: 'Vollkorn' },
  mode: 'literal',
});
