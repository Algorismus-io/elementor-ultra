import { MEDIA as M } from '../data/media.mjs';

export const meta = {
  title: 'Loud Quarry',
  slug: 'loud-quarry',
  seo: {
    title: 'Loud Quarry — 14 to 16 August. 62 acts. Four stages in live granite.',
    description:
      'Three days in a disused granite quarry. 62 acts, four stages, no VIP tier. Weekend with camping 189. Grab a ticket.',
  },
};

/* literal hex for raw CSS (raw blocks never see theme envelopes) */
const GROUND = '#101014';
const INK = '#F2F0EA';
const ACID = '#D9FF00';
const HOT = '#FF1F5A';
const COOL = '#00B7FF';

const TILT_L = 'transform:rotate(-1.4deg)';
const TILT_R = 'transform:rotate(1.1deg)';
const TORN_TOP =
  'clip-path:polygon(0 14px,7% 4px,15% 12px,26% 2px,38% 11px,49% 3px,61% 12px,72% 2px,84% 11px,93% 3px,100% 12px,100% 100%,0 100%)';
const TORN_BOTTOM =
  'clip-path:polygon(0 0,100% 0,100% calc(100% - 12px),91% 100%,80% calc(100% - 11px),69% 100%,57% calc(100% - 12px),46% 100%,34% calc(100% - 10px),22% 100%,11% calc(100% - 12px),0 100%)';
const STUB =
  'border:2px dashed rgba(242,240,234,.45);clip-path:polygon(0 0,100% 0,100% 100%,0 100%);';
const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* ── repeaters (content props only) ───────────────────────────────── */

const Stub = defineComponent(
  ({ tier = 'WEEKEND', price = '189', note = 'with camping', line = 'Three days, one tent-sized patch of gravel.' }) => (
    <div
      cls="lq-stub"
      tw="flex flex-col gap-3 px-6 py-7"
      raw={STUB}
      bg="#17171D"
      hover={{ bg: '#1F1F27' }}
    >
      <text font="Space Grotesk" size={12} ls="2px" color={COOL} weight={700}>
        {tier}
      </text>
      <heading tag="h3" font="Bungee" size={54} lh={1} color={ACID} mobile={{ size: 42 }}>
        {price}
      </heading>
      <text font="Space Grotesk" size={15} weight={700} color={INK}>
        {note}
      </text>
      <text font="Space Grotesk" size={14} lh={1.55} color="#9A99A4">
        {line}
      </text>
    </div>
  ),
  {
    title: 'LQ Ticket Stub',
    props: {
      tier: { label: 'Tier', group: 'Stub' },
      price: { label: 'Price', group: 'Stub' },
      note: { label: 'Note', group: 'Stub' },
      line: { label: 'Small print', group: 'Stub' },
    },
  },
);

const Day = ({ day, date, tint, headliners, rest }) => (
  <div cls="lq-day" tw="flex flex-col" span={4}>
    <div cls="lq-day-head" tw="flex flex-row items-center justify-between px-4 py-2" bg={tint}>
      <text font="Bungee" size={20} color={GROUND}>
        {day}
      </text>
      <text font="Space Grotesk" size={13} weight={700} color={GROUND}>
        {date}
      </text>
    </div>
    <div cls="lq-day-body" tw="flex flex-col gap-2 px-4 py-6" raw={`border-left:2px solid ${tint}`}>
      {headliners.map((n) => (
        <heading cls="lq-act" tag="h3" font="Bungee" size={30} lh={1.05} color={INK} mobile={{ size: 26 }}>
          {n}
        </heading>
      ))}
      <text font="Space Grotesk" size={15} lh={1.9} color="#8F8E99" m={{ t: 10 }}>
        {rest}
      </text>
    </div>
  </div>
);

const Stage = ({ n, name, line, tint }) => (
  <div cls="lq-stage" tw="flex flex-col gap-3 px-6 py-8" span={3} raw={`border-top:6px solid ${tint}`} bg="#16161C">
    <text font="Bungee" size={13} color={tint}>
      {n}
    </text>
    <heading tag="h3" font="Bungee" size={26} lh={1.1} color={INK}>
      {name}
    </heading>
    <text font="Space Grotesk" size={15} lh={1.6} color="#A3A2AC">
      {line}
    </text>
  </div>
);

const PHOTOS = [
  M.crowd_close.id, M.quarry_night.id, M.camp_morning.id, M.crowd_close.id,
  M.quarry_night.id, M.camp_morning.id, M.crowd_close.id, M.quarry_night.id,
  M.camp_morning.id, M.crowd_close.id, M.quarry_night.id, M.camp_morning.id,
];

/* ── page ─────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={{ b: 96 }} bg={t.color.ground}>
    {/* ─── 1. torn-poster hero ─────────────────────────────────── */}
    <div tw="flex flex-row flex-wrap items-center justify-between px-6 py-2 w-full" gap={10} bg={t.color.acid}>
      <text font={t.font.head} size={13} color={t.color.ground}>
        LOUD QUARRY
      </text>
      <text font={t.font.body} size={13} weight={700} ls="1px" color={t.color.ground}>
        FOUR STAGES · 62 ACTS · NO VIP
      </text>
      <text font={t.font.head} size={13} color={t.color.ground}>
        14—16 AUG
      </text>
    </div>

    <section tw="flex flex-col w-full px-6 pt-16 pb-0" bg={t.color.ground}>
      <grid cols={12} gapX={28} gapY={32} tw="w-full max-w-[1200px]" m={{ l: 'auto', r: 'auto' }}>
        <div span={8} tw="flex flex-col gap-6">
          <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.hot}>
            A DISUSED GRANITE QUARRY · 14—16 AUGUST
          </text>
          <h1
            font={t.font.head}
            size={92}
            lh={0.92}
            color={t.color.ink}
            tablet={{ size: 64 }}
            mobile={{ size: 38 }}
            raw={`& strong{color:${ACID};display:block} & em{color:${HOT};font-style:normal;display:block}`}
          >
            THREE DAYS<br /><strong>IN A HOLE</strong><em>IN THE GROUND</em>
          </h1>
          <text font={t.font.body} size={19} lh={1.6} color="#B7B6C0" maxw={620} mobile={{ size: 16 }}>
            14 to 16 August. 62 acts. Four stages cut into live granite. No VIP, no cabanas,
            no queue-jump. Same ticket for everyone.
          </text>
          <text
            href="#tickets"
            font={t.font.head}
            size={18}
            color={GROUND}
            bg={t.color.acid}
            pad={{ t: 16, b: 16, l: 30, r: 30 }}
            w="hug"
            ta="center"
            hover={{ bg: t.color.hot, color: INK }}
            raw={TILT_L}
          >
            Grab a ticket
          </text>
        </div>

        <div span={4} tw="flex flex-col gap-4">
          <div tw="flex flex-col gap-1 px-5 py-6" bg={t.color.hot} raw={TILT_R}>
            <text font={t.font.head} size={44} lh={1} color={GROUND} mobile={{ size: 34 }}>
              189
            </text>
            <text font={t.font.body} size={14} weight={700} color={GROUND}>
              WEEKEND + CAMPING. THAT IS THE WHOLE PRICE LIST, NEARLY.
            </text>
          </div>
          <img src={M.quarry_night.id} w="100%" h={300} fit="cover" raw={TORN_BOTTOM} tablet={{ h: 220 }} />
          <text font={t.font.body} size={13} lh={1.6} color="#8F8E99">
            Gates 14:00 Friday. Last coach back 04:00 Monday. It will not wait.
          </text>
        </div>
      </grid>
    </section>

    <img
      src={M.crowd_close.id}
      w="100%"
      h={260}
      fit="cover"
      m={{ t: 56 }}
      raw={TORN_TOP}
      mobile={{ h: 170 }}
    />

    {/* ─── 2. the lineup wall ──────────────────────────────────── */}
    <section tw="flex flex-col w-full px-6 py-20" bg="#0B0B0E" id="lineup">
      <div tw="flex flex-col gap-3 w-full max-w-[1200px]" m={{ l: 'auto', r: 'auto', b: 44 }}>
        <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.cool}>
          THE WALL
        </text>
        <heading
          tag="h2"
          font={t.font.head}
          size={56}
          lh={1}
          color={t.color.ink}
          mobile={{ size: 32 }}
          motion={FADE}
        >
          62 ACTS. NOWHERE TO HIDE.
        </heading>
      </div>

      <grid cols={12} gapX={24} gapY={40} tw="w-full max-w-[1200px]" m={{ l: 'auto', r: 'auto' }}>
        <Day
          day="FRIDAY"
          date="14 AUG"
          tint={ACID}
          headliners={['Molasses Kid', 'Nine Volt Choir', 'SISTER SISTER SISTER', 'Hollow Bones']}
          rest="Kerosene Pony · Gravel Sermon · Ada Nine · The Wet Field · Bitumen · Copper Tongue · Low Bell Society · Marla Frost · Dry Dock Choir · Signal Fault · Pale Radio · Hexley Kids · Thin Ice Disco · Nettlebrook"
        />
        <Day
          day="SATURDAY"
          date="15 AUG"
          tint={HOT}
          headliners={['GRANITE MOUTH', 'Yelena Skye', 'Bad Weather Club', 'Truant Sun']}
          rest="Fourteen Hills · Sodium Lamp · Orla Vance · The Quarry Dogs · Milk Teeth Revival · Slow Puncture · Hare & Hound · Vane · Junction Six · Cold Brass · Little Static · Peat Smoke · Rumour Mill · Aster Deep"
        />
        <Day
          day="SUNDAY"
          date="16 AUG"
          tint={COOL}
          headliners={['THE LAST BUS', 'Fen Machine', 'Otto & the Overburden', 'Sunday Blast']}
          rest="Wren Kelly · Blunt Instrument · Halogen Fields · The Rope Ladder · Emmy Trench · Grit · Nine Mile Beach · Tundra Fair · Public Grief · Salt Marsh Boys · Ferrous · Old Gods of Ashby · Tremor Line · Closing Set: everyone left standing"
        />
      </grid>
    </section>

    {/* ─── 3. four stages ──────────────────────────────────────── */}
    <section tw="flex flex-col w-full px-6 py-16" bg={t.color.ink}>
      <div tw="flex flex-row flex-wrap items-end justify-between w-full max-w-[1200px]" gap={16} m={{ l: 'auto', r: 'auto', b: 32 }}>
        <heading tag="h2" font={t.font.head} size={40} lh={1} color={GROUND} mobile={{ size: 28 }}>
          FOUR STAGES
        </heading>
        <text font={t.font.body} size={15} weight={700} color="#4A4954" maxw={420}>
          Cut into live granite. One line each, because that is all they need.
        </text>
      </div>
      <grid cols={12} gapX={16} gapY={16} tw="w-full max-w-[1200px]" m={{ l: 'auto', r: 'auto' }}>
        <Stage n="01" name="THE FACE" tint={ACID} line="40 metres of sheer rock and a wall of bass." />
        <Stage n="02" name="THE CUT" tint={HOT} line="Techno until sunrise." />
        <Stage n="03" name="THE BENCH" tint={COOL} line="Folk and hangovers." />
        <Stage n="04" name="THE PIT" tint={INK} line="Whatever fits." />
      </grid>
    </section>

    {/* ─── 4. ticket stubs ─────────────────────────────────────── */}
    <section tw="flex flex-col w-full px-6 py-20" bg={t.color.ground} id="tickets">
      <div tw="flex flex-col gap-3 w-full max-w-[1200px]" m={{ l: 'auto', r: 'auto', b: 36 }}>
        <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.acid}>
          TEAR HERE
        </text>
        <heading tag="h2" font={t.font.head} size={48} lh={1} color={t.color.ink} mobile={{ size: 30 }} motion={FADE}>
          FOUR STUBS. NO VIP TIER.
        </heading>
      </div>
      <grid cols={4} gapX={18} gapY={18} tw="w-full max-w-[1200px]" m={{ l: 'auto', r: 'auto' }} mobile={{ gridCols: 1 }} tablet={{ gridCols: 2 }}>
        <Stub tier="WEEKEND" price="189" note="with camping" line="Three days and a tent-sized patch of gravel. Showers exist. Queues for them also exist." />
        <Stub tier="WEEKEND" price="149" note="no camping" line="Same three days, your own bed. Coaches run every two hours." />
        <Stub tier="SATURDAY" price="79" note="day ticket only" line="In at noon, out by the last coach. Granite Mouth closes The Face." />
        <Stub tier="UNDER 16" price="FREE" note="with an adult" line="One child per adult. Ear defenders at the gate, no charge." />
      </grid>
      <text
        href="#tickets"
        font={t.font.head}
        size={20}
        color={GROUND}
        bg={t.color.acid}
        pad={{ t: 18, b: 18, l: 36, r: 36 }}
        w="hug"
        ta="center"
        m={{ t: 36 }}
        hover={{ bg: t.color.hot, color: INK }}
      >
        Grab a ticket
      </text>
    </section>

    {/* ─── 5. getting there ────────────────────────────────────── */}
    <section tw="flex flex-col w-full" bg="#0B0B0E">
      <grid cols={12} gapX={0} gapY={0} tw="w-full">
        <div span={5}>
          <img src={M.camp_morning.id} w="100%" h={520} fit="cover" tablet={{ h: 300 }} mobile={{ h: 240 }} />
        </div>
        <div span={7} tw="flex flex-col gap-8 px-10 py-16" mobile={{ pad: { l: 24, r: 24, t: 40, b: 40 } }}>
          <heading tag="h2" font={t.font.head} size={40} lh={1.05} color={t.color.ink} mobile={{ size: 28 }}>
            GETTING THERE, SLEEPING THERE
          </heading>
          <div cls="lq-travel" tw="flex flex-col gap-2" raw={`border-left:3px solid ${ACID}`} pad={{ l: 18 }}>
            <heading tag="h3" font={t.font.head} size={17} color={t.color.acid}>
              COACH
            </heading>
            <text font={t.font.body} size={16} lh={1.6} color="#B7B6C0" maxw={560}>
              Coaches run from six cities every two hours. Last one back leaves at 4am Monday
              and it will not wait.
            </text>
          </div>
          <div cls="lq-travel" tw="flex flex-col gap-2" raw={`border-left:3px solid ${HOT}`} pad={{ l: 18 }}>
            <heading tag="h3" font={t.font.head} size={17} color={t.color.hot}>
              CAMP
            </heading>
            <text font={t.font.body} size={16} lh={1.6} color="#B7B6C0" maxw={560}>
              The campsite is the upper bench, gravel and gorse, open from noon Thursday.
              Pitch where you land. Standpipes every forty metres.
            </text>
          </div>
          <div cls="lq-travel" tw="flex flex-col gap-2" raw={`border-left:3px solid ${COOL}`} pad={{ l: 18 }}>
            <heading tag="h3" font={t.font.head} size={17} color={t.color.cool}>
              QUARRY RULES
            </heading>
            <text font={t.font.body} size={16} lh={1.6} color="#B7B6C0" maxw={560}>
              Stay off the working faces, follow the painted line, and do not climb the spoil
              heap. Stewards in orange are the ones who know where you are.
            </text>
          </div>
        </div>
      </grid>
    </section>

    {/* ─── 6. last year in twelve photographs ──────────────────── */}
    <section tw="flex flex-col w-full px-6 py-20" bg={t.color.ground}>
      <div tw="flex flex-row flex-wrap items-end justify-between w-full max-w-[1200px]" gap={16} m={{ l: 'auto', r: 'auto', b: 28 }}>
        <heading tag="h2" font={t.font.head} size={40} lh={1} color={t.color.ink} mobile={{ size: 28 }}>
          LAST YEAR, IN TWELVE
        </heading>
        <text font={t.font.body} size={14} weight={700} ls="2px" color={t.color.cool}>
          NO FILTER, NO DRONES
        </text>
      </div>
      <grid cols={4} gapX={10} gapY={10} tw="w-full max-w-[1200px]" m={{ l: 'auto', r: 'auto' }} mobile={{ gridCols: 2 }} tablet={{ gridCols: 3 }}>
        {PHOTOS.map((id) => (
          <img cls="lq-photo" src={id} w="100%" h={190} fit="cover" mobile={{ h: 120 }} />
        ))}
      </grid>
    </section>

    {/* ─── 7. banned, plainly ──────────────────────────────────── */}
    <section tw="flex flex-col w-full px-6 py-20" bg="#0B0B0E">
      <grid cols={12} gapX={24} gapY={24} tw="w-full max-w-[1200px]" m={{ l: 'auto', r: 'auto' }}>
        <div span={6} tw="flex flex-col gap-5 px-8 py-10" bg={t.color.hot}>
          <heading tag="h2" font={t.font.head} size={36} lh={1} color={GROUND} mobile={{ size: 26 }}>
            BANNED
          </heading>
          <text font={t.font.body} size={19} lh={1.75} weight={500} color={GROUND}>
            Glass.<br />Drones.<br />Gazebos over 3m.<br />Anything with a flame.
          </text>
          <text font={t.font.body} size={14} lh={1.6} color="#3A0715">
            Bag checks at every gate. Confiscated is confiscated — there is no left luggage.
          </text>
        </div>
        <div span={6} tw="flex flex-col gap-5 px-8 py-10" raw={`border:2px solid ${ACID}`}>
          <heading tag="h2" font={t.font.head} size={36} lh={1} color={t.color.acid} mobile={{ size: 26 }}>
            BRING
          </heading>
          <text font={t.font.body} size={19} lh={1.75} weight={500} color={t.color.ink}>
            A torch.<br />A raincoat.<br />Better shoes than you think you need.
          </text>
          <text font={t.font.body} size={14} lh={1.6} color="#8F8E99">
            The quarry floor is loose stone and it rains sideways. Ask anyone who came in 2025.
          </text>
        </div>
      </grid>
    </section>

    {/* ─── 8. sticky ticket bar ────────────────────────────────── */}
    <box
      raw="position:fixed;left:0;right:0;bottom:0;z-index:998"
      tw="flex flex-row flex-wrap items-center justify-between w-full px-5 py-3"
      gap={12}
      bg={t.color.acid}
    >
      <text font={t.font.head} size={15} color={GROUND} mobile={{ size: 12 }}>
        LOUD QUARRY · 14—16 AUG
      </text>
      <text font={t.font.body} size={13} weight={700} color={GROUND} mobile={{ size: 11 }}>
        Weekend + camping 189 · Under 16 free
      </text>
      <text
        href="#tickets"
        font={t.font.head}
        size={14}
        color={ACID}
        bg={GROUND}
        pad={{ t: 11, b: 11, l: 20, r: 20 }}
        ta="center"
        hover={{ bg: HOT, color: INK }}
        mobile={{ size: 12 }}
      >
        Grab a ticket
      </text>
    </box>
  </box>
);
