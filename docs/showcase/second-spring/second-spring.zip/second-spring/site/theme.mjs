/** Second Spring — design tokens. */
export default defineTheme({
  name: 'second-spring',
  color: {
    ground: '#FBF6F1',
    ink: '#2A2320',
    rose: '#C36A63',
    sage: '#7C9382',
    deep: '#4A3A38',
    paper: '#FFFDFB',
  },
  font: { head: 'Instrument Serif', body: 'Figtree' },
  mode: 'literal',
});
