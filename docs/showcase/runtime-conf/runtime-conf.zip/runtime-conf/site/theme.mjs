/** RUNTIME — design tokens. Typographic poster: two inks, one flash, hairline grid. */
export default defineTheme({
  name: 'runtime',
  color: {
    ground: '#FFFFFF',
    ink: '#000000',
    flash: '#FF4A00',
    grid: '#EAEAEA',
    night: '#12121A',
  },
  font: { head: 'Anton', body: 'Space Grotesk' },
  mode: 'literal',
});
