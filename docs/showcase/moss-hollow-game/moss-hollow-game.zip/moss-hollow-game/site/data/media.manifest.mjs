/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "moss-hollow-game--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'moss-hollow-game--';

export default [
  { slot: `${PREFIX}forage`, file: join(MEDIA_DIR, "forage_scene.jpg"), alt: "Foraging in the woods around Moss Hollow" },
  { slot: `${PREFIX}valley`, file: join(MEDIA_DIR, "valley_art.jpg"), alt: "The Moss Hollow valley in painted art style" },
  { slot: `${PREFIX}winter`, file: join(MEDIA_DIR, "winter_scene.jpg"), alt: "A quiet winter evening in Moss Hollow" },
];
