/** Ledgerless — fintech for freelancers. Oversized type as layout. */
export const meta = {
  title: 'Ledgerless',
  slug: 'ledgerless',
  seo: {
    title: 'Ledgerless — one number you can actually spend',
    description:
      'A business account for freelancers that holds back tax and National Insurance the moment income lands, files the return in January, and shows you one safe-to-spend number.',
  },
};

const C = {
  ground: '#0D0C0F',
  ink: '#FAF7F2',
  money: '#B6FF6B',
  warn: '#FF8A3D',
  muted: '#6A6772',
  line: '#26232B',
};
const HEAD = 'Bricolage Grotesque';
const BODY = 'Public Sans';

const fadeUp = { effect: 'fade', trigger: 'scrollIn', duration: 700 };

/* ── shared bits ─────────────────────────────────────────────────────── */

const Eyebrow = ({ children, color = C.muted }) => (
  <text
    w="100%"
    font={BODY}
    size={12}
    weight={600}
    color={color}
    ls={0.18}
    tw="uppercase"
    mobile={{ size: 11 }}
    cls="eyebrow"
  >
    {children}
  </text>
);

/* Filing-day steps — registered component, content props only. */
const Step = defineComponent(
  ({ num = '01', title = 'Step', body = '' }) => (
    <div
      tw="flex flex-col gap-3 py-8"
      raw="border-top: 1px solid #26232B;"
      cls="step"
    >
      <text w="100%" font={HEAD} size={64} weight={700} color={C.money} lh={0.9} mobile={{ size: 48 }}>
        {num}
      </text>
      <h3 w="100%" font={HEAD} size={22} weight={600} color={C.ink} lh={1.15} mobile={{ size: 20 }}>
        {title}
      </h3>
      <text w="100%" font={BODY} size={15} color={C.muted} lh={1.6}>
        {body}
      </text>
    </div>
  ),
  {
    title: 'Filing Step',
    props: {
      num: { label: 'Number', group: 'Content' },
      title: { label: 'Title', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
    },
  },
);

/* Balance rows — styling is uniform, colour differences live in the wrapper. */
const BalanceRow = ({ label, amount, note, tone, big }) => (
  <div
    tw="flex flex-row items-end justify-between gap-6 py-7 max-md:flex-col max-md:items-start max-md:gap-2 max-md:py-6"
    raw="border-top: 1px solid #26232B;"
    cls="balance-row"
  >
    <div tw="flex flex-col gap-1" maxw={360}>
      <h3 w="100%" font={HEAD} size={20} weight={600} color={C.ink} lh={1.2}>
        {label}
      </h3>
      <text w="100%" font={BODY} size={14} color={C.muted} lh={1.55}>
        {note}
      </text>
    </div>
    <text
      font={HEAD}
      size={big ? 108 : 64}
      weight={700}
      color={tone}
      lh={0.9}
      ls={-0.03}
      ta="right"
      tablet={{ size: big ? 80 : 52 }}
      mobile={{ size: big ? 60 : 42, ta: 'left' }}
    >
      {amount}
    </text>
  </div>
);

/* One month column of the set-aside chart. */
const MonthBar = ({ m, v, hot }) => (
  <div tw="flex flex-col justify-end items-stretch grow gap-2" h={240} mobile={{ h: 140, gap: 6 }} cls="month-col">
    <text
      font={BODY}
      size={11}
      weight={600}
      color={hot ? C.warn : C.muted}
      ta="center"
      mobile={{ size: 8 }}
      cls="month-pct"
    >
      {v}%
    </text>
    <div
      w="100%"
      h={Math.round(v * 2.4)}
      radius={3}
      bg={hot ? C.warn : C.money}
      mobile={{ h: Math.round(v * 1.35) }}
      cls="month-bar"
    />
    <text font={BODY} size={11} color={C.muted} ta="center" tw="uppercase" mobile={{ size: 8 }} cls="month-label">
      {m}
    </text>
  </div>
);

const MONTHS = [
  { m: 'Apr', v: 26 }, { m: 'May', v: 31 }, { m: 'Jun', v: 22 }, { m: 'Jul', v: 34 },
  { m: 'Aug', v: 29 }, { m: 'Sep', v: 18, hot: true }, { m: 'Oct', v: 33 }, { m: 'Nov', v: 37 },
  { m: 'Dec', v: 24 }, { m: 'Jan', v: 30 }, { m: 'Feb', v: 35 }, { m: 'Mar', v: 41 },
];

/* ── page ────────────────────────────────────────────────────────────── */

export default () => (
  <box tw="flex flex-col w-full items-stretch" pad={0} bg={C.ground}>

    {/* 1 — the number, as the whole first screen */}
    <section
      tw="flex flex-col w-full items-start justify-between px-10 pt-8 pb-14 max-lg:px-8 max-md:px-5 max-md:pb-10"
      minh={780}
      grad={[168, '#0D0C0F', '#17131C']}
      mobile={{ minh: 640 }}
    >
      <div tw="flex flex-row items-center justify-between w-full gap-4 pb-10 max-md:pb-8" raw="border-bottom: 1px solid #26232B;">
        <text font={HEAD} size={17} weight={700} color={C.ink} ls={-0.01}>
          Ledgerless
        </text>
        <Eyebrow>Business account · August</Eyebrow>
      </div>

      <div tw="flex flex-col gap-4 w-full py-10 max-md:py-8">
        <Eyebrow color={C.money}>Safe to spend</Eyebrow>
        <h1
          w="100%"
          font={HEAD}
          size={280}
          weight={700}
          color={C.ink}
          lh={0.78}
          ls={-0.05}
          raw="& em { color: #B6FF6B; font-style: normal; }"
          motion={{ effect: 'fade', trigger: 'load', duration: 800 }}
          tablet={{ size: 168 }}
          mobile={{ size: 96, ls: -0.04 }}
        >
          <em>£</em>3,418
        </h1>
      </div>

      <grid cols="1.1fr 1fr" gap={40} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
        <text w="100%" font={BODY} size={19} color={C.ink} lh={1.55} maxw={560} mobile={{ size: 16 }}>
          That is what is actually yours this month. Ledgerless takes your income, holds back the tax
          and National Insurance the moment it lands, and shows you one number you can spend without a
          knot in your stomach.
        </text>
        <div tw="flex flex-col items-start justify-end gap-4">
          <text
            href="#open"
            font={BODY}
            size={16}
            weight={700}
            color={C.ground}
            bg={C.money}
            pad={{ t: 18, b: 18, l: 32, r: 32 }}
            radius={999}
            tw="no-underline cursor-pointer"
            hover={{ bg: C.ink }}
          >
            Open an account
          </text>
          <Eyebrow>£9 a month · no transaction fees</Eyebrow>
        </div>
      </grid>
    </section>

    {/* 2 — three balances */}
    <section tw="flex flex-col w-full items-start gap-2 px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16" bg="#111014">
      <div tw="flex flex-col gap-4 pb-6" maxw={720}>
        <Eyebrow>Where the money sits</Eyebrow>
        <h2
          w="100%"
          font={HEAD}
          size={72}
          weight={700}
          color={C.ink}
          lh={0.95}
          ls={-0.03}
          motion={fadeUp}
          tablet={{ size: 56 }}
          mobile={{ size: 38 }}
        >
          Three balances. One of them is yours.
        </h2>
      </div>

      <BalanceRow
        label="In the account"
        amount="£7,946"
        note="Everything that has landed this month, before anything is held back."
        tone={C.ink}
      />
      <BalanceRow
        label="Held for HMRC"
        amount="£3,102"
        note="Income tax and National Insurance, moved out the moment each payment arrives."
        tone={C.warn}
      />
      <BalanceRow
        label="Rolling buffer"
        amount="£1,426"
        note="A quiet cushion for the month a client pays late. You can release it any time."
        tone={C.muted}
      />
      <BalanceRow
        label="Safe to spend"
        amount="£3,418"
        note="The only figure on this page you need to remember."
        tone={C.money}
        big
      />
    </section>

    {/* 3 — how the set-aside is calculated, month by month */}
    <section tw="flex flex-col w-full items-start gap-10 px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16 max-md:gap-8" bg={C.ground}>
      <grid cols="1fr 1fr" gap={48} w="100%" mobile={{ gridCols: 1, gap: 24 }}>
        <div tw="flex flex-col gap-4">
          <Eyebrow>Set-aside rate, month by month</Eyebrow>
          <h2
            w="100%"
            font={HEAD}
            size={64}
            weight={700}
            color={C.ink}
            lh={0.95}
            ls={-0.03}
            motion={fadeUp}
            tablet={{ size: 48 }}
            mobile={{ size: 34 }}
          >
            Not a flat 30 percent guess.
          </h2>
        </div>
        <text w="100%" font={BODY} size={17} color={C.muted} lh={1.65} maxw={520} mobile={{ size: 15 }}>
          We recalculate your set-aside every time you get paid, using your actual year-to-date
          income, not a flat 30 percent guess. Have a quiet month and the number goes up, not down.
        </text>
      </grid>

      <div tw="flex flex-row items-end justify-between gap-3 w-full pt-6 max-md:gap-1" raw="border-top: 1px solid #26232B;">
        {MONTHS.map((x) => (
          <MonthBar m={x.m} v={x.v} hot={x.hot} />
        ))}
      </div>
      <text w="100%" font={BODY} size={13} color={C.muted} lh={1.6}>
        <strong>September was quiet</strong> — two invoices, no retainer. The rate dropped to 18
        percent and your safe-to-spend number went up the same afternoon.
      </text>
    </section>

    {/* 4 — filing day */}
    <section tw="flex flex-col w-full items-start gap-10 px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16" bg="#111014">
      <div tw="flex flex-col gap-5" maxw={860}>
        <Eyebrow color={C.money}>Filing day</Eyebrow>
        <h2
          w="100%"
          font={HEAD}
          size={80}
          weight={700}
          color={C.ink}
          lh={0.92}
          ls={-0.035}
          motion={fadeUp}
          tablet={{ size: 58 }}
          mobile={{ size: 38 }}
        >
          One button, in January.
        </h2>
        <text w="100%" font={BODY} size={18} color={C.muted} lh={1.6} maxw={640} mobile={{ size: 15 }}>
          In January we prepare the return, show you every figure and where it came from, and file it
          when you press one button. If we get the maths wrong, we pay the penalty.
        </text>
      </div>

      <grid cols={4} gap={32} w="100%" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1, gap: 0 }}>
        <Step num="01" title="We prepare it" body="Your return is drafted from the payments already in the account. Nothing to upload." />
        <Step num="02" title="You see the workings" body="Every figure links back to the invoice, expense or transfer it came from." />
        <Step num="03" title="You press once" body="Approve and we file it with HMRC, then pay the bill from the money already held." />
        <Step num="04" title="We cover our errors" body="If we get the maths wrong, we pay the penalty. That is the whole guarantee." />
      </grid>
    </section>

    {/* 5 — fees, as one sentence */}
    <section tw="flex flex-col w-full items-start gap-6 px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16" bg={C.money}>
      <Eyebrow color="#3B5B1C">The fee, in full</Eyebrow>
      <h2
        w="100%"
        font={HEAD}
        size={200}
        weight={700}
        color={C.ground}
        lh={0.8}
        ls={-0.05}
        motion={fadeUp}
        tablet={{ size: 128 }}
        mobile={{ size: 76 }}
      >
        £9 a month.
      </h2>
      <text w="100%" font={BODY} size={26} weight={600} color="#1E2A12" lh={1.35} maxw={780} mobile={{ size: 18 }}>
        No transaction fees, no FX markup above 0.4 percent, no charge for filing.
      </text>
    </section>

    {/* 6 — who it is not for */}
    <section tw="flex flex-col w-full items-start gap-8 px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16" bg={C.ground}>
      <grid cols="1fr 1.4fr" gap={48} w="100%" mobile={{ gridCols: 1, gap: 20 }}>
        <div tw="flex flex-col gap-4">
          <Eyebrow color={C.warn}>Honestly</Eyebrow>
          <h2
            w="100%"
            font={HEAD}
            size={64}
            weight={700}
            color={C.ink}
            lh={0.95}
            ls={-0.03}
            tablet={{ size: 48 }}
            mobile={{ size: 34 }}
          >
            Who it is not for.
          </h2>
        </div>
        <div tw="flex flex-col">
          <text
            w="100%"
            font={HEAD}
            size={30}
            weight={600}
            color={C.ink}
            lh={1.25}
            tw="py-6"
            raw="border-top: 1px solid #26232B;"
            mobile={{ size: 21 }}
            cls="exclusion"
          >
            Limited companies with employees.
          </text>
          <text
            w="100%"
            font={HEAD}
            size={30}
            weight={600}
            color={C.ink}
            lh={1.25}
            tw="py-6"
            raw="border-top: 1px solid #26232B;"
            mobile={{ size: 21 }}
            cls="exclusion"
          >
            VAT-registered businesses over the threshold yet.
          </text>
          <text
            w="100%"
            font={HEAD}
            size={30}
            weight={600}
            color={C.ink}
            lh={1.25}
            tw="py-6"
            raw="border-top: 1px solid #26232B; border-bottom: 1px solid #26232B;"
            mobile={{ size: 21 }}
          >
            Anyone who enjoys spreadsheets.
          </text>
          <text w="100%" font={BODY} size={15} color={C.muted} lh={1.6} tw="pt-6">
            If that is you, we would rather say so now than take £9 a month off you for a year.
          </text>
        </div>
      </grid>
    </section>

    {/* 7 — regulatory and deposit protection */}
    <section tw="flex flex-col w-full items-start gap-6 px-10 py-16 max-lg:px-8 max-md:px-5 max-md:py-12" bg="#111014">
      <grid cols="auto 1fr" gap={40} w="100%" mobile={{ gridCols: 1, gap: 16 }}>
        <text font={HEAD} size={56} weight={700} color={C.ink} lh={0.9} ls={-0.03} mobile={{ size: 38 }}>
          £85,000
        </text>
        <text w="100%" font={BODY} size={16} color={C.muted} lh={1.7} maxw={720} mobile={{ size: 14 }}>
          Deposits held at a UK clearing bank and covered to £85,000 by the FSCS. Ledgerless is an
          agent, not the bank.
        </text>
      </grid>
    </section>

    {/* 8 — open an account (the page's one centred section) */}
    <section
      id="open"
      tw="flex flex-col w-full items-center text-center gap-8 px-10 py-32 max-lg:px-8 max-md:px-5 max-md:py-20"
      grad={[200, '#0D0C0F', '#1B2410']}
    >
      <Eyebrow color={C.money}>Ten minutes, one form</Eyebrow>
      <h2
        w="100%"
        font={HEAD}
        size={128}
        weight={700}
        color={C.ink}
        lh={0.86}
        ls={-0.045}
        ta="center"
        motion={fadeUp}
        tablet={{ size: 84 }}
        mobile={{ size: 46 }}
      >
        Open an account
      </h2>
      <text w="100%" font={BODY} size={18} color={C.muted} lh={1.6} maxw={560} ta="center" mobile={{ size: 15 }}>
        Then stop thinking about January. Your safe-to-spend number updates the moment the next
        payment lands.
      </text>
      <text
        href="#open"
        font={BODY}
        size={17}
        weight={700}
        color={C.ground}
        bg={C.money}
        pad={{ t: 20, b: 20, l: 40, r: 40 }}
        radius={999}
        tw="no-underline cursor-pointer"
        hover={{ bg: C.ink }}
      >
        Open an account
      </text>
      <text font={BODY} size={13} color={C.muted} lh={1.6} ta="center">
        £9 a month · cancel any time · deposits covered to £85,000 by the FSCS
      </text>
    </section>
  </box>
);
