/** Tracewell — terminal/console tokens. */
export default defineTheme({
  name: 'tracewell',
  color: {
    ground: '#07090A',
    panel: '#0E1315',
    ink: '#C8D6D2',
    accent: '#4CFFB0',
    alert: '#FF5C4D',
    dim: '#4A5A57',
    line: '#1A2224',
  },
  font: { head: 'JetBrains Mono', body: 'Inter' },
  radius: { sm: 4, md: 6, lg: 10 },
  mode: 'literal',
});
