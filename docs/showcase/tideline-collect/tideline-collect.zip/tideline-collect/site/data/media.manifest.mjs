/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "tideline-collect--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'tideline-collect--';

export default [
  { slot: `${PREFIX}boom_river`, file: join(MEDIA_DIR, "boom_river.jpg"), alt: "A Tideline interception boom strung across a river mouth, catching floating plastic on the ebb tide" },
  { slot: `${PREFIX}estuary`, file: join(MEDIA_DIR, "estuary.jpg"), alt: "Wide estuary where the river meets open water, the last place plastic can be caught cheaply" },
  { slot: `${PREFIX}sorting`, file: join(MEDIA_DIR, "sorting.jpg"), alt: "Volunteers hand-sorting recovered plastic into type-graded bags on a windy hard standing" },
];
