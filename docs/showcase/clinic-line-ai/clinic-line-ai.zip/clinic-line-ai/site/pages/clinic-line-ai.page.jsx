import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Clinic Line — AI voice agents for dental and physio clinics',
  seo: {
    title: 'Clinic Line — your clinic phone, answered every time',
    description:
      'Clinic Line answers the calls your reception cannot, books straight into Dentally, Cliniko, Pabau or SystmOne, and puts anything clinical through to a human within seconds. £179 a month per site.',
  },
};

/* ---------- shared bits ---------- */

const Band = ({ theme: t, bg, pad, id, children }) => (
  <section id={id} tw="flex flex-col items-center w-full" bg={bg} pad={pad}>
    <div tw="flex flex-col w-full max-w-[1120px]" pad={0}>{children}</div>
  </section>
);

const Eyebrow = ({ theme: t, color, children }) => (
  <text size={13} weight={600} ls="1.6px" font={t.font.body} color={color || t.color.trust}>
    {children}
  </text>
);

const Cta = ({ theme: t, label, tone }) => (
  <text
    href="#book"
    tag="a"
    font={t.font.body}
    size={16}
    weight={600}
    color={tone === 'light' ? t.color.trust : '#FFFFFF'}
    bg={tone === 'light' ? '#FFFFFF' : t.color.trust}
    pad={{ t: 17, b: 17, l: 30, r: 30 }}
    radius={10}
    w="hug"
    ta="center"
    shadow={[[6, 16, -6, 'rgba(37,99,201,0.45)'], [1, 2, 0, 'rgba(22,32,43,0.12)']]}
    hover={{ bg: tone === 'light' ? t.color.mint : '#1B4EA6', shadow: [[10, 26, -8, 'rgba(37,99,201,0.5)']] }}
  >
    {label}
  </text>
);

/* Three feature cards — registered as one native Elementor component (content props only). */
const FeatureCard = defineComponent(
  ({ step = '01', title = '', body = '' }, ctx) => {
    const t = ctx.theme;
    return (
      <div
        cls="feature-card"
        tw="flex flex-col w-full"
        bg="#FFFFFF"
        pad={32}
        radius={16}
        gap={14}
        border={[1, '#E3EAF1']}
        shadow={[[2, 4, 0, 'rgba(22,32,43,0.04)'], [18, 40, -24, 'rgba(22,32,43,0.18)']]}
        hover={{ border: [1, '#2563C9'], shadow: [[24, 48, -22, 'rgba(37,99,201,0.28)']] }}
      >
        <text size={13} weight={700} ls="1.4px" font={t.font.body} color={t.color.trust}>{step}</text>
        <heading tag="h3" size={22} weight={600} font={t.font.head} color={t.color.ink} lh={1.25}>
          {title}
        </heading>
        <text size={16} font={t.font.body} color={t.color.grey} lh={1.7}>{body}</text>
      </div>
    );
  },
  {
    title: 'Clinic Line feature card',
    props: {
      step: { label: 'Step number', group: 'Content' },
      title: { label: 'Card title', group: 'Content' },
      body: { label: 'Card body', group: 'Content' },
    },
  },
);

const Stat = ({ theme: t, n, label }) => (
  <div tw="flex flex-col" gap={4} pad={0} mobile={{ w: '100%' }}>
    <text size={34} weight={600} font={t.font.head} color={t.color.ink} lh={1.15}>{n}</text>
    <text size={14} font={t.font.body} color={t.color.grey} lh={1.5}>{label}</text>
  </div>
);

const TranscriptLine = ({ theme: t, who, line, tone }) => (
  <div
    tw="flex flex-col w-full"
    gap={6}
    pad={{ t: 16, b: 16, l: 18, r: 18 }}
    radius={12}
    bg={tone === 'agent' ? 'rgba(221,240,234,0.10)' : 'rgba(255,255,255,0.06)'}
  >
    <text size={12} weight={700} ls="1.2px" font={t.font.body} color={tone === 'agent' ? t.color.mint : '#9FB2C4'}>
      {who}
    </text>
    <text size={16} font={t.font.body} color="#EAF1F7" lh={1.6}>{line}</text>
  </div>
);

const Chip = ({ theme: t, name, note }) => (
  <div
    tw="flex flex-col"
    gap={4}
    bg="#FFFFFF"
    pad={{ t: 18, b: 18, l: 20, r: 20 }}
    radius={12}
    border={[1, '#CBE3DA']}
    hover={{ border: [1, '#2563C9'] }}
  >
    <text size={17} weight={600} font={t.font.head} color={t.color.ink}>{name}</text>
    <text size={13} font={t.font.body} color={t.color.grey} lh={1.5}>{note}</text>
  </div>
);

const NeverRule = ({ theme: t, n, title, body }) => (
  <div tw="flex flex-col w-full" gap={8} pad={{ l: 22, t: 4, b: 4 }} border={[0, 'transparent']}
    raw="border-left: 2px solid #2563C9;">
    <heading tag="h3" size={19} weight={600} font={t.font.head} color="#FFFFFF">{title}</heading>
    <text size={15} font={t.font.body} color="#A9BACA" lh={1.65}>{body}</text>
  </div>
);

/* ---------- the page ---------- */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={t.color.ground}>

    {/* 1 — centred hero (the page's only centred single-column section) */}
    <section tw="flex flex-col items-center w-full" bg={t.color.ground} pad={{ t: 96, b: 0, l: 24, r: 24 }}
      mobile={{ pad: { t: 56, b: 0, l: 20, r: 20 } }}>
      <div tw="flex flex-col items-center w-full max-w-[860px] text-center" gap={22} pad={0}>
        <text size={13} weight={600} ls="1.6px" font={t.font.body} color={t.color.trust} ta="center">
          AI VOICE RECEPTION FOR DENTAL &amp; PHYSIO CLINICS
        </text>
        <heading tag="h1" w="100%" size={62} weight={600} font={t.font.head} color={t.color.ink} lh={1.08} ta="center"
          tablet={{ size: 48 }} mobile={{ size: 34 }}>
          Your practice missed 61 calls last month.
        </heading>
        <text size={19} font={t.font.body} color={t.color.grey} lh={1.65} maxw={680} ta="center" mobile={{ size: 16 }}>
          Clinic Line answers every one, books straight into your existing diary, and puts anything clinical
          through to a human within seconds. Set up in an afternoon, no new software for your reception team.
        </text>
        <div tw="flex flex-row items-center justify-center" gap={14} wrap="wrap" pad={{ t: 6 }}>
          <Cta theme={t} label="Book a 15 minute setup call" />
          <text href="#recording" tag="a" size={16} weight={600} font={t.font.body} color={t.color.ink}
            pad={{ t: 17, b: 17, l: 24, r: 24 }} radius={10} border={[1, '#D5DEE7']} w="hug"
            hover={{ bg: t.color.mint, border: [1, '#CBE3DA'] }}>
            Listen to a real call
          </text>
        </div>
      </div>

      {/* stat strip — sits under the hero, splits the rhythm before the cards */}
      <div tw="flex flex-row w-full max-w-[1120px] justify-between" gap={24} wrap="wrap"
        bg={t.color.mint} radius={18} pad={{ t: 30, b: 30, l: 36, r: 36 }} m={{ t: 64 }}
        mobile={{ pad: { t: 24, b: 24, l: 22, r: 22 }, m: { t: 40 }, dir: 'column', gap: 22 }}
        motion={{ effect: 'fade', trigger: 'scrollIn' }}>
        <Stat theme={t} n="61" label="calls missed in an average month, per site" />
        <Stat theme={t} n="2 sec" label="average time to answer, day or night" />
        <Stat theme={t} n="9/wk" label="bookings a typical clinic loses to voicemail" />
        <Stat theme={t} n="1 pm" label="the hour reception is most likely to miss you" />
      </div>
    </section>

    {/* 2 — three cards: answers, books, escalates */}
    <Band theme={t} bg={t.color.ground} pad={{ t: 88, b: 88, l: 24, r: 24 }}>
      <div tw="flex flex-row w-full justify-between items-end" gap={24} wrap="wrap" pad={{ b: 40 }}>
        <div tw="flex flex-col max-w-[560px]" gap={12} pad={0}>
          <Eyebrow theme={t}>WHAT IT DOES ON EVERY CALL</Eyebrow>
          <heading tag="h2" size={40} weight={600} font={t.font.head} color={t.color.ink} lh={1.15}
            mobile={{ size: 28 }}>
            Three jobs, done the same way every time.
          </heading>
        </div>
        <text size={16} font={t.font.body} color={t.color.grey} lh={1.7} maxw={340}>
          No menus, no hold music, no &ldquo;press one for appointments&rdquo;. It talks, it books, or it hands over.
        </text>
      </div>
      <grid cols={3} gap={24} w="100%" tablet={{ gridCols: 3 }} mobile={{ gridCols: 1 }}
        motion={{ effect: 'fade', trigger: 'scrollIn' }}>
        <FeatureCard
          step="01"
          title="It answers"
          body="Answers on the second ring, at 7am, at lunch, and at 9pm on a Sunday. Same voice, same script, every time."
        />
        <FeatureCard
          step="02"
          title="It books"
          body="Books, moves and cancels appointments directly in Dentally, Cliniko, Pabau or SystmOne, respecting your gaps and your clinician rules."
        />
        <FeatureCard
          step="03"
          title="It escalates"
          body="Anything about symptoms, pain or medication goes to a human immediately with the call summary already written."
        />
      </grid>
    </Band>

    {/* 3 — listen to a real call recording (dark band, two columns) */}
    <section id="recording" tw="flex flex-col items-center w-full" bg={t.color.ink}
      pad={{ t: 96, b: 96, l: 24, r: 24 }} mobile={{ pad: { t: 60, b: 60, l: 20, r: 20 } }}>
      <grid cols="0.9fr 1.1fr" gap={48} w="100%" maxw={1120} mobile={{ gridCols: 1, gap: 32 }}>
        <div tw="flex flex-col" gap={20} pad={0}>
          <Eyebrow theme={t} color={t.color.mint}>A REAL CALL, TUESDAY 19:41</Eyebrow>
          <heading tag="h2" size={38} weight={600} font={t.font.head} color="#FFFFFF" lh={1.15} mobile={{ size: 26 }}>
            Hear what your patients hear.
          </heading>
          <text size={16} font={t.font.body} color="#A9BACA" lh={1.7}>
            This is an unedited booking taken after hours at a two-surgery practice in Leeds. Forty-one seconds,
            one appointment, no receptionist awake for it.
          </text>
          <img src={media.reception.id} w="100%" radius={16} fit="cover" h={220} mobile={{ h: 180 }} />
          <div tw="flex flex-row items-center w-full" gap={16} bg="rgba(255,255,255,0.07)" radius={12}
            pad={{ t: 16, b: 16, l: 18, r: 18 }}>
            <text size={22} color={t.color.mint} font={t.font.body} weight={700}>&#9654;</text>
            <div tw="flex flex-col" gap={4} pad={0} flex={1}>
              <text size={15} weight={600} font={t.font.body} color="#FFFFFF">After-hours booking · 0:41</text>
              <text size={13} font={t.font.body} color="#8FA3B6">Recording shared with the practice&rsquo;s permission</text>
            </div>
          </div>
        </div>
        <div tw="flex flex-col w-full" gap={12} pad={0} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
          <TranscriptLine theme={t} tone="agent" who="CLINIC LINE"
            line="Good evening, Meadow Dental. The practice is closed but I can book you in — what do you need?" />
          <TranscriptLine theme={t} tone="caller" who="CALLER"
            line="I chipped a filling. Can I get in this week?" />
          <TranscriptLine theme={t} tone="agent" who="CLINIC LINE"
            line="I can see Thursday 08:20 or Friday 16:10 with Dr Ahmed. Which suits you?" />
          <TranscriptLine theme={t} tone="caller" who="CALLER"
            line="Thursday. Is it going to hurt in the meantime?" />
          <TranscriptLine theme={t} tone="agent" who="CLINIC LINE"
            line="That&rsquo;s a clinical question, so I&rsquo;m putting you through to the on-call nurse now. Your Thursday 08:20 is confirmed." />
        </div>
      </grid>
    </section>

    {/* 4 — diary systems it plugs into */}
    <Band theme={t} bg={t.color.mint} pad={{ t: 80, b: 80, l: 24, r: 24 }}>
      <grid cols="1fr 1.35fr" gap={48} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
        <div tw="flex flex-col" gap={14} pad={0}>
          <Eyebrow theme={t}>PLUGS INTO YOUR DIARY</Eyebrow>
          <heading tag="h2" size={36} weight={600} font={t.font.head} color={t.color.ink} lh={1.15} mobile={{ size: 26 }}>
            Your reception team learns nothing new.
          </heading>
          <text size={16} font={t.font.body} color={t.color.grey} lh={1.7}>
            Clinic Line writes into the diary you already run, using your slot lengths, your clinician rules and
            your cancellation policy. Bookings appear where your team expects them, tagged so you can see which
            ones we saved.
          </text>
        </div>
        <grid cols={2} gap={16} w="100%" mobile={{ gridCols: 1 }} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
          <Chip theme={t} name="Dentally" note="Two-way sync, per-surgery slot rules" />
          <Chip theme={t} name="Cliniko" note="Practitioner availability respected" />
          <Chip theme={t} name="Pabau" note="Book, move and cancel" />
          <Chip theme={t} name="SystmOne" note="Read-and-write via approved gateway" />
        </grid>
      </grid>
    </Band>

    {/* 5 — what it will never do */}
    <Band theme={t} bg={t.color.ink} pad={{ t: 88, b: 88, l: 24, r: 24 }}>
      <grid cols="0.85fr 1.15fr" gap={48} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
        <div tw="flex flex-col" gap={14} pad={0}>
          <Eyebrow theme={t} color={t.color.mint}>HARD LIMITS</Eyebrow>
          <heading tag="h2" size={36} weight={600} font={t.font.head} color="#FFFFFF" lh={1.15} mobile={{ size: 26 }}>
            What it will never do.
          </heading>
          <text size={16} font={t.font.body} color="#A9BACA" lh={1.7}>
            It never gives clinical advice, never triages, and never takes card payments over the phone.
            Those three lines are hard-coded, not prompted.
          </text>
        </div>
        <div tw="flex flex-col w-full" gap={26} pad={0} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
          <NeverRule theme={t} title="No clinical advice"
            body="If a caller describes a symptom, the agent stops selling appointments and finds a human. It does not reassure, suggest painkillers, or guess." />
          <NeverRule theme={t} title="No triage"
            body="It will not decide who is urgent. Every clinical call is handed to your on-call contact with a written summary attached." />
          <NeverRule theme={t} title="No card payments"
            body="Card details are never spoken to the agent. Deposits go out as a payment link from your own system, after the call." />
        </div>
      </grid>
    </Band>

    {/* 6 — practice manager testimonial with numbers */}
    <Band theme={t} bg={t.color.wash} pad={{ t: 88, b: 88, l: 24, r: 24 }}>
      <grid cols="0.8fr 1.2fr" gap={48} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
        <img src={media.manager_portrait.id} w="100%" h={420} fit="cover" radius={18}
          mobile={{ h: 280 }}
          shadow={[[24, 60, -30, 'rgba(22,32,43,0.35)']]} />
        <div tw="flex flex-col justify-center" gap={24} pad={0}>
          <heading tag="h2" size={30} weight={500} font={t.font.head} color={t.color.ink} lh={1.4} mobile={{ size: 22 }}>
            &ldquo;We were losing about nine bookings a week to voicemail. Six weeks in we had recovered all of them
            and my receptionist stopped eating lunch at her desk.&rdquo;
          </heading>
          <text size={15} weight={600} font={t.font.body} color={t.color.grey}>
            Practice manager, three-site dental group, Bristol
          </text>
          <div tw="flex flex-row w-full" gap={32} wrap="wrap" pad={{ t: 8 }}
            mobile={{ dir: 'column', gap: 18 }}
            raw="border-top: 1px solid #DCE4EC;">
            <Stat theme={t} n="+9" label="bookings recovered a week" />
            <Stat theme={t} n="6 wks" label="to full payback" />
            <Stat theme={t} n="3" label="sites on one number" />
          </div>
        </div>
      </grid>
    </Band>

    {/* 7 — pricing and 30-day cancel */}
    <Band theme={t} bg={t.color.ground} pad={{ t: 88, b: 88, l: 24, r: 24 }}>
      <grid cols="1.1fr 0.9fr" gap={48} w="100%" mobile={{ gridCols: 1, gap: 28 }}>
        <div tw="flex flex-col justify-center" gap={14} pad={0}>
          <Eyebrow theme={t}>PRICING</Eyebrow>
          <heading tag="h2" size={38} weight={600} font={t.font.head} color={t.color.ink} lh={1.15} mobile={{ size: 26 }}>
            One price per site. Unlimited calls.
          </heading>
          <text size={17} font={t.font.body} color={t.color.grey} lh={1.7}>
            <strong>£179 a month per site, unlimited calls. Cancel any time in the first 30 days and we refund
            it in full.</strong> No setup fee, no per-minute billing, no contract to get out of. Most practices
            cover it back with the first two recovered bookings.
          </text>
        </div>
        <div tw="flex flex-col w-full" gap={16} bg={t.color.ground} pad={34} radius={18}
          border={[1, '#E3EAF1']}
          shadow={[[2, 6, 0, 'rgba(22,32,43,0.05)'], [30, 60, -30, 'rgba(22,32,43,0.22)']]}
          motion={{ effect: 'fade', trigger: 'scrollIn' }}>
          <div tw="flex flex-row items-end" gap={8} pad={0}>
            <heading tag="h3" size={52} weight={600} font={t.font.head} color={t.color.ink} mobile={{ size: 40 }}>
              £179
            </heading>
            <text size={16} font={t.font.body} color={t.color.grey} pad={{ b: 10 }}>/ month / site</text>
          </div>
          <text size={15} font={t.font.body} color={t.color.grey} lh={1.8}>
            Unlimited answered calls<br />Diary write-back to your existing system<br />
            Human escalation with written summaries<br />Call recordings and monthly missed-call report<br />
            Set up in an afternoon
          </text>
          <div tw="flex flex-col" gap={4} bg={t.color.mint} radius={10} pad={{ t: 14, b: 14, l: 16, r: 16 }}>
            <text size={14} weight={600} font={t.font.body} color={t.color.ink}>30-day full refund</text>
            <text size={13} font={t.font.body} color={t.color.grey} lh={1.5}>
              Cancel in the first 30 days and we return the lot, no exit call.
            </text>
          </div>
          <Cta theme={t} label="Book a 15 minute setup call" />
        </div>
      </grid>
    </Band>

    {/* 8 — book a 15 minute setup call */}
    <section id="book" tw="flex flex-col items-center w-full" bg={t.color.trust}
      pad={{ t: 76, b: 76, l: 24, r: 24 }} mobile={{ pad: { t: 52, b: 52, l: 20, r: 20 } }}>
      <div tw="flex flex-row items-center justify-between w-full max-w-[1120px]" gap={32} wrap="wrap" pad={0}
        mobile={{ dir: 'column', align: 'flex-start', gap: 24 }}>
        <div tw="flex flex-col max-w-[620px]" gap={12} pad={0} mobile={{ w: '100%' }}>
          <heading tag="h2" size={38} weight={600} font={t.font.head} color="#FFFFFF" lh={1.15} mobile={{ size: 27 }}>
            Book a 15 minute setup call
          </heading>
          <text size={17} font={t.font.body} color="#D6E4FA" lh={1.65}>
            Bring your diary system and your opening hours. We will tell you how many calls you are missing
            before you decide anything.
          </text>
        </div>
        <Cta theme={t} label="Book a 15 minute setup call" tone="light" />
      </div>
    </section>

  </box>
);
