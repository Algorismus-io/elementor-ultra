export default { name: 'hardin-drains' };
