# The Undertow

Austere editorial index. Hairlines, a numbered contents rail, nothing wasted.

|  |  |
|---|---|
| **Slug** | `the-undertow` (deploys to `/the-undertow/`) |
| **Archetype** | editorial index rail |
| **Industry** | Investigative magazine |
| **Page title** | The Undertow |
| **Fonts** | Playfair Display, Spectral — Google Fonts, imported by Elementor automatically |
| **Elements** | 214 |
| **Images** | 2 |
| **Global classes used** | 0 — built `--inline` (100 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install the-undertow
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
the-undertow/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/the-undertow.page.jsx          the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F7F5F0` |
| `ink` | `#111111` |
| `red` | `#B3121D` |
| `grey` | `#6F6C66` |
| `rule` | `#D8D4CC` |

Change a value, re-run `npx exjsx-kit install the-undertow`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/the-undertow.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `documents` | `media/documents.jpg` | Stacked pages of disclosed documents, annotated and tagged |
| `reporter_field` | `media/reporter_field.jpg` | A reporter working in the field, notebook in hand |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
