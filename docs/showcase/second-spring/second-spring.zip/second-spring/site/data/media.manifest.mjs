/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "second-spring--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'second-spring--';

export default [
  { slot: `${PREFIX}consult_scene`, file: join(MEDIA_DIR, "consult_scene.jpg"), alt: "A menopause-trained doctor speaking with a patient over a video consultation" },
  { slot: `${PREFIX}portrait_calm`, file: join(MEDIA_DIR, "portrait_calm.jpg"), alt: "A woman in her fifties sitting calmly by a window" },
];
