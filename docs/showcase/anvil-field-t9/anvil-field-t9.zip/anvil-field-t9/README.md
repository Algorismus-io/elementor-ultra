# Anvil Field T9

Dense spec sheet done properly — the table IS the design.

|  |  |
|---|---|
| **Slug** | `anvil-field-t9` (deploys to `/anvil-field-t9/`) |
| **Archetype** | spec-sheet table as hero |
| **Industry** | Rugged computing hardware |
| **Page title** | Anvil T9 — full specification |
| **Fonts** | Saira Condensed, IBM Plex Sans — Google Fonts, imported by Elementor automatically |
| **Elements** | 134 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (66 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install anvil-field-t9
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
anvil-field-t9/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/anvil-field-t9.page.jsx        the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#101314` |
| `panel` | `#191D1F` |
| `ink` | `#DDE3E4` |
| `hazard` | `#FFB000` |
| `line` | `#2C3335` |
| `green` | `#5FD08A` |

Change a value, re-run `npx exjsx-kit install anvil-field-t9`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/anvil-field-t9.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `device_field` | `media/device_field.jpg` | Anvil T9 rugged field laptop open on a survey tripod case |
| `hot_swap` | `media/hot_swap.jpg` | Gloved hands swapping a hot-swap battery on the Anvil T9 |
| `deployment` | `media/deployment.jpg` | Field crew using the Anvil T9 on a utilities deployment |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
