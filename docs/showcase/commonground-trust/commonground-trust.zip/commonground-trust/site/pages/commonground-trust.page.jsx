import { watershedMap, parcelPlan } from '../components/map.mjs';
import { IMG } from '../data/media.mjs';
const { curlew, meadowWide, volunteerSurvey } = IMG;

export const meta = {
  title: 'Common Ground Trust',
  slug: 'commonground-trust',
  seo: {
    title: 'Common Ground Trust — we buy the river back, one field at a time',
    description:
      '4,180 acres of the Wenn valley floodplain and grassland held in permanent trust. See every parcel protected, every parcel under offer, and what twelve pounds a month buys in square metres.',
  },
};

/* ── shared bits ───────────────────────────────────────────────────────────── */

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 600 };

/** Small all-caps section marker: rule + label, the survey-sheet tic. */
const Marker = ({ n, label, t, tone }) => (
  <row tw="flex flex-row items-center gap-3" pad={0} w="100%">
    <box w={28} h={2} bg={tone === 'dark' ? t.color.grass : t.color.ochre} pad={0} />
    <text
      font={t.font.body}
      size={12}
      weight={700}
      ls={0.1}
      color={tone === 'dark' ? '#9FB08F' : '#6B7A66'}
    >
      {`${n} — ${label}`}
    </text>
  </row>
);

/** Horizontal hairline. */
const Rule = ({ t, tone }) => (
  <box w="100%" h={1} pad={0} bg={tone === 'dark' ? '#33463A' : t.color.rule} />
);

/* ── 3 · parcel dossier row ────────────────────────────────────────────────── */

const ParcelRow = ({ p, t }) => (
  <box tw="flex flex-col w-full gap-6" pad={{ t: 34, b: 34 }} raw={`& { border-top: 1px solid ${t.color.rule}; }`}>
    <grid cols="120px 1fr 300px" gap={36} tablet={{ gridCols: '96px 1fr' }} mobile={{ gridCols: '1fr' }} w="100%">
      <box pad={0} w="100%" maxw={120} raw={`& { border: 1px solid ${t.color.rule}; }`}>
        <html raw={parcelPlan(p.plan, p.brook)} />
      </box>

      <box tw="flex flex-col gap-3" pad={0}>
        <row tw="flex flex-row items-end gap-3 flex-wrap" pad={0}>
          <text font={t.font.body} size={12} weight={700} ls={0.09} color={t.color.ochre}>
            {`PARCEL ${p.num}`}
          </text>
          <text font={t.font.body} size={12} ls={0.08} color="#7C8878">
            {p.grid}
          </text>
        </row>
        <h3 font={t.font.head} size={30} weight={500} lh={1.14} color={t.color.ink} mobile={{ size: 25 }}>
          {p.name}
        </h3>
        <text font={t.font.body} size={16.5} lh={1.62} color="#41513F" maxw={520}>
          {p.desc}
        </text>
      </box>

      <box tw="flex flex-col gap-3" pad={0}>
        <row tw="flex flex-row items-end justify-between gap-4" pad={0} w="100%">
          <text font={t.font.body} size={13} weight={600} ls={0.05} color="#7C8878">
            RAISED
          </text>
          <text font={t.font.head} size={22} weight={600} color={t.color.grass}>
            {p.raised}
          </text>
        </row>
        <box w="100%" h={10} pad={0} bg="#E2E7DB" radius={0} raw="& { overflow: hidden; }">
          <box h={10} pad={0} bg={t.color.grass} w={p.pct} />
        </box>
        <row tw="flex flex-row items-end justify-between gap-4" pad={0} w="100%">
          <text font={t.font.body} size={13} color="#7C8878">
            {`${p.pct} of ${p.asking}`}
          </text>
          <text font={t.font.body} size={13} weight={600} color={t.color.ochre}>
            {`${p.gap} to go`}
          </text>
        </row>
        <text
          href="#standing-order"
          font={t.font.body}
          size={14.5}
          weight={600}
          color={t.color.river}
          pad={{ t: 6 }}
          hover={{ color: t.color.ink }}
          raw="& { text-decoration: underline; text-underline-offset: 4px; }"
        >
          {`Put money into ${p.short} →`}
        </text>
      </box>
    </grid>
  </box>
);

/* ── 5 · species ledger row (registered component — content props only) ────── */

const SpeciesRow = defineComponent(
  ({ species = '', place = '', when = '', note = '' }) => (
    <box tw="flex flex-col gap-2 w-full" pad={{ t: 22, b: 22 }} raw="& { border-top: 1px solid #33463A; }">
      <row tw="flex flex-row items-end justify-between gap-5 flex-wrap" pad={0} w="100%">
        <heading tag="h3" font="Newsreader" size={27} weight={500} color="#F3F5EF" mobile={{ size: 23 }}>
          {species}
        </heading>
        <text font="Source Sans 3" size={13} weight={700} ls={0.09} color="#C4913C">
          {when}
        </text>
      </row>
      <text font="Source Sans 3" size={12.5} weight={600} ls={0.08} color="#8FA283">
        {place}
      </text>
      <text font="Source Sans 3" size={16} lh={1.6} color="#C9D6C2" maxw={560}>
        {note}
      </text>
    </box>
  ),
  {
    title: 'Species record',
    props: {
      species: { label: 'Species', group: 'Record' },
      place: { label: 'Place', group: 'Record' },
      when: { label: 'Date', group: 'Record' },
      note: { label: 'Note', group: 'Record' },
    },
  },
);

/* ── data ──────────────────────────────────────────────────────────────────── */

const PARCELS = [
  {
    num: '44',
    name: 'Marsden Bottom',
    short: 'Marsden Bottom',
    grid: 'SE 4412 · floodplain meadow',
    desc:
      '63 acres of unploughed floodplain meadow between two blocks we already hold. Asking price 412,000. Raised so far 289,400.',
    asking: '£412,000',
    raised: '£289,400',
    gap: '£122,600',
    pct: '70%',
    plan: 'M22 26 L92 18 L102 84 L34 96 Z',
    brook: 'M10 4 C 46 40, 30 70, 62 116',
  },
  {
    num: '7',
    name: 'Hollin Ing',
    short: 'Hollin Ing',
    grid: 'SE 4718 · ridge-and-furrow grassland',
    desc:
      '116 acres of ridge-and-furrow grassland on the valley’s south side, never reseeded and never drained. The last unimproved field of its size on the Wenn. Asking price 690,000. Raised so far 512,300.',
    asking: '£690,000',
    raised: '£512,300',
    gap: '£177,700',
    pct: '74%',
    plan: 'M18 34 L98 24 L106 78 L26 92 Z',
    brook: 'M4 96 C 44 76, 60 46, 116 30',
  },
  {
    num: '51',
    name: 'Ash Carr Bank',
    short: 'Ash Carr Bank',
    grid: 'SE 4906 · wet woodland and bank',
    desc:
      '38 acres of wet woodland on the outside of the Wenn’s tightest meander, four kilometres of it water vole bank. Under offer from a fishing syndicate as well as from us. Asking price 244,000. Raised so far 61,900.',
    asking: '£244,000',
    raised: '£61,900',
    gap: '£182,100',
    pct: '25%',
    plan: 'M30 20 L90 28 L84 92 L24 84 Z',
    brook: 'M116 10 C 70 44, 84 78, 40 116',
  },
];

const LADDER = [
  { amount: '£6', sqm: '20 m²', note: 'a hedge bottom' },
  { amount: '£12', sqm: '40 m²', note: 'a curlew’s nest scrape and the grass round it' },
  { amount: '£25', sqm: '83 m²', note: 'a spring line and the flush below it' },
  { amount: '£50', sqm: '167 m²', note: 'a full field corner, fenced' },
];

const SPECIES = [
  {
    species: 'Curlew',
    place: 'Ash Carr',
    when: '2023',
    note: 'Returned after nineteen years absent. Two pairs in 2023, five in 2025, all on ground we stopped being mown in May.',
  },
  {
    species: 'Water vole',
    place: 'Wenn, Marsden reach',
    when: '2025',
    note: 'Recorded on four kilometres of bank. The mink raft survey found nothing for the third year running.',
  },
  {
    species: 'Otter',
    place: 'Whole valley',
    when: 'Winter 2025',
    note: 'Spraint found at every survey point last winter — twenty-two points, twenty-two positives.',
  },
];

const PATHS = [
  {
    kind: 'A bequest',
    lede: 'Leave us the land, or leave us the money to buy it.',
    steps: [
      'Tell your solicitor the charity number: 1073344.',
      'Name the parcel if you have one in mind, or leave it open and we will buy where the river needs it most.',
      'Land left to us is never resold. It goes into the same permanent trust as everything on the map above.',
    ],
    foot: 'We will talk to your executors, your family, and your farm agent, for as long as it takes.',
  },
  {
    kind: 'A conservation easement',
    lede: 'Keep your land. Give up the right to ruin it.',
    steps: [
      'You stay the owner and you keep farming it.',
      'A covenant registered against the title removes the development and drainage rights, permanently.',
      'We monitor it once a year, in person, and the covenant binds every owner after you.',
    ],
    foot: 'Four Wenn farms have done this since 2019. Two of them are still in the same families.',
  },
];

const ACCOUNTS = [
  { line: 'Land purchase', pence: '61p', w: '61%', tone: 'grass' },
  { line: 'Upkeep, fencing, scrub clearance, surveys', pence: '23p', w: '23%', tone: 'grass' },
  { line: 'Three salaries', pence: '13p', w: '13%', tone: 'ochre' },
  { line: 'Accountant and audit', pence: '3p', w: '3%', tone: 'ochre' },
];

/* ── page ──────────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>

    {/* ─── 1 · watershed map ─────────────────────────────────────────────── */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 28, b: 96 }} bg={t.color.ground}>
      <box tw="flex flex-col w-full gap-10" maxw={1280} pad={{ l: 40, r: 40 }} tablet={{ pad: { l: 28, r: 28 } }} mobile={{ pad: { l: 20, r: 20 } }}>

        <row tw="flex flex-row items-center justify-between gap-6 flex-wrap w-full" pad={{ b: 18 }} raw={`& { border-bottom: 1px solid ${t.color.rule}; }`}>
          <text font={t.font.head} size={19} weight={600} ls={0.015} color={t.color.ink}>
            Common Ground Trust
          </text>
          <text font={t.font.body} size={12.5} weight={600} ls={0.09} color="#7C8878">
            THE WENN VALLEY · REGISTERED CHARITY 1073344
          </text>
        </row>

        <grid cols="0.88fr 1.12fr" gap={56} tablet={{ gridCols: '1fr' }} mobile={{ gridCols: '1fr' }} w="100%">

          <box tw="flex flex-col gap-7" pad={{ t: 12 }}>
            <Marker n="01" label="THE WATERSHED" t={t} />
            <h1 font={t.font.head} size={62} weight={500} lh={1.04} ls={-0.02} color={t.color.ink} tablet={{ size: 54 }} mobile={{ size: 37 }}>
              We buy the river back, one field at a time.
            </h1>
            <text font={t.font.body} size={19} lh={1.62} color="#41513F" maxw={540} mobile={{ size: 17 }}>
              Common Ground Trust holds 4,180 acres along the Wenn valley in permanent trust. Not
              managed, not leased. <strong>Bought outright, protected forever</strong>, and opened to
              anyone who can walk to it.
            </text>

            <row tw="flex flex-row items-center gap-4 flex-wrap" pad={{ t: 4 }}>
              <text
                href="#standing-order"
                font={t.font.body}
                size={16}
                weight={600}
                ls={0.03}
                color={t.color.ground}
                bg={t.color.ink}
                pad={[16, 30]}
                hover={{ bg: t.color.grass }}
              >
                Protect an acre
              </text>
              <text
                href="#parcels"
                font={t.font.body}
                size={16}
                weight={600}
                color={t.color.ink}
                pad={[16, 26]}
                raw={`& { border: 1px solid ${t.color.rule}; }`}
                hover={{ bg: '#E7EBE1' }}
              >
                Read the three dossiers
              </text>
            </row>

            <box tw="flex flex-col gap-2" pad={{ t: 14 }} raw={`& { border-top: 1px solid ${t.color.rule}; }`}>
              <text font={t.font.body} size={13.5} lh={1.55} color="#7C8878" maxw={460}>
                Every boundary on this map is a Land Registry title we hold or an offer we have made.
                Nothing on it is aspirational.
              </text>
            </box>
          </box>

          <box tw="flex flex-col gap-4 w-full" pad={0}>
            <box w="100%" pad={0} raw={`& { border: 1px solid ${t.color.rule}; }`} shadow={[[1, 2, 0, 'rgba(27,42,32,0.05)'], [12, 32, -12, 'rgba(27,42,32,0.14)']]}>
              <html raw={watershedMap()} />
            </box>

            <grid cols={3} gap={18} mobile={{ gridCols: '1fr' }} w="100%">
              <row tw="flex flex-row items-center gap-3" pad={0}>
                <box w={16} h={16} pad={0} bg={t.color.grass} raw="& { opacity: 0.5; }" />
                <text font={t.font.body} size={13} lh={1.4} color="#41513F">
                  Held in trust
                </text>
              </row>
              <row tw="flex flex-row items-center gap-3" pad={0}>
                <box w={16} h={16} pad={0} raw={`& { border: 2px dashed ${t.color.ochre}; }`} />
                <text font={t.font.body} size={13} lh={1.4} color="#41513F">
                  Under offer now
                </text>
              </row>
              <row tw="flex flex-row items-center gap-3" pad={0}>
                <box w={16} h={16} pad={0} raw={`& { border: 1px dashed ${t.color.ink}; background: repeating-linear-gradient(45deg, rgba(27,42,32,0.45) 0 2px, transparent 2px 6px); }`} />
                <text font={t.font.body} size={13} lh={1.4} color="#41513F">
                  Lost this year
                </text>
              </row>
            </grid>
          </box>
        </grid>
      </box>
    </section>

    {/* ─── 2 · counter ───────────────────────────────────────────────────── */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 84, b: 84 }} bg={t.color.ink}>
      <box tw="flex flex-col w-full gap-12" maxw={1280} pad={{ l: 40, r: 40 }} tablet={{ pad: { l: 28, r: 28 } }} mobile={{ pad: { l: 20, r: 20 } }}>
        <Marker n="02" label="THE LEDGER, THIS MORNING" t={t} tone="dark" />

        <grid cols="1.25fr 1fr 1fr" gap={0} tablet={{ gridCols: '1fr' }} mobile={{ gridCols: '1fr' }} w="100%">
          <box tw="flex flex-col gap-2" pad={{ r: 44, t: 8, b: 8 }} tablet={{ pad: { r: 0, b: 30 } }} motion={FADE}>
            <text font={t.font.head} size={92} weight={500} lh={1} ls={-0.03} color={t.color.grass} tablet={{ size: 76 }} mobile={{ size: 62 }}>
              4,180
            </text>
            <text font={t.font.body} size={15} weight={700} ls={0.1} color="#9FB08F">
              ACRES HELD
            </text>
            <text font={t.font.body} size={15.5} lh={1.6} color="#B7C6B0" maxw={330} pad={{ t: 6 }}>
              Bought outright and held in permanent trust. None of it can be sold, and none of it
              has been.
            </text>
          </box>

          <box tw="flex flex-col gap-2" pad={{ l: 44, r: 44, t: 8, b: 8 }} tablet={{ pad: { l: 0, t: 30, b: 30 } }} raw="& { border-left: 1px solid #33463A; }" motion={FADE}>
            <text font={t.font.head} size={72} weight={500} lh={1} ls={-0.026} color={t.color.ochre} tablet={{ size: 62 }} mobile={{ size: 54 }}>
              217
            </text>
            <text font={t.font.body} size={15} weight={700} ls={0.1} color="#C9A96E">
              ACRES UNDER OFFER
            </text>
            <text font={t.font.body} size={15.5} lh={1.6} color="#B7C6B0" maxw={300} pad={{ t: 6 }}>
              Three parcels. Contracts drawn, deposits down, money still short on all three.
            </text>
          </box>

          <box tw="flex flex-col gap-2" pad={{ l: 44, t: 8, b: 8 }} tablet={{ pad: { l: 0, t: 30 } }} raw="& { border-left: 1px solid #33463A; }" motion={FADE}>
            <text font={t.font.head} size={72} weight={500} lh={1} ls={-0.026} color="#E4E9DE" tablet={{ size: 62 }} mobile={{ size: 54 }}>
              96
            </text>
            <text font={t.font.body} size={15} weight={700} ls={0.1} color="#8FA283">
              ACRES LOST THIS YEAR
            </text>
            <text font={t.font.body} size={15.5} lh={1.6} color="#B7C6B0" maxw={300} pad={{ t: 6 }}>
              Lost to development while we were raising the money. Outline consent granted in
              March; we were 140,000 short in February.
            </text>
          </box>
        </grid>

        <box w="100%" h={1} pad={0} bg="#33463A" />
        <text font={t.font.head} size={26} weight={400} lh={1.45} color="#DCE4D6" maxw={760} mobile={{ size: 21 }}>
          The third number is the reason for the first two. <em>Land goes when the money is slow.</em>
        </text>
      </box>
    </section>

    {/* ─── 3 · parcel dossier ────────────────────────────────────────────── */}
    <section id="parcels" tw="flex flex-col w-full items-center" pad={{ t: 92, b: 92 }} bg={t.color.paper}>
      <box tw="flex flex-col w-full gap-9" maxw={1280} pad={{ l: 40, r: 40 }} tablet={{ pad: { l: 28, r: 28 } }} mobile={{ pad: { l: 20, r: 20 } }}>
        <Marker n="03" label="UNDER OFFER NOW" t={t} />
        <grid cols="1fr 0.85fr" gap={48} tablet={{ gridCols: '1fr' }} w="100%">
          <h2 font={t.font.head} size={46} weight={500} lh={1.1} ls={-0.018} color={t.color.ink} tablet={{ size: 40 }} mobile={{ size: 31 }}>
            The three we are trying to buy now.
          </h2>
          <text font={t.font.body} size={17} lh={1.65} color="#41513F" maxw={480} pad={{ t: 8 }}>
            Each one is a signed offer against a real title. The money raised sits in a restricted
            account and is spent on that parcel or returned. Numbers below were true at 06:00 today.
          </text>
        </grid>

        <box tw="flex flex-col w-full" pad={{ t: 12 }}>
          {PARCELS.map((p) => (
            <ParcelRow p={p} t={t} />
          ))}
          <box w="100%" h={1} pad={0} bg={t.color.rule} />
        </box>
      </box>
    </section>

    {/* ─── 4 · what your money buys ──────────────────────────────────────── */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 92, b: 92 }} bg={t.color.ground}>
      <box tw="flex flex-col w-full gap-11" maxw={1280} pad={{ l: 40, r: 40 }} tablet={{ pad: { l: 28, r: 28 } }} mobile={{ pad: { l: 20, r: 20 } }}>
        <Marker n="04" label="WHAT THE MONEY BUYS" t={t} />

        <grid cols="0.95fr 1.05fr" gap={64} tablet={{ gridCols: '1fr' }} w="100%">
          <box tw="flex flex-col gap-6" pad={0}>
            <h2 font={t.font.head} size={46} weight={500} lh={1.1} ls={-0.018} color={t.color.ink} tablet={{ size: 40 }} mobile={{ size: 31 }}>
              Twelve pounds a month, in square metres.
            </h2>
            <text font={t.font.body} size={18.5} lh={1.62} color="#41513F" maxw={520} mobile={{ size: 17 }}>
              12 pounds a month protects roughly <strong>40 square metres a year</strong>, and keeps
              protecting it after you stop.
            </text>
            <text font={t.font.body} size={16} lh={1.65} color="#5A6A57" maxw={520}>
              That is the whole arithmetic. Land in the Wenn valley runs at about 6,500 an acre;
              a standing order becomes a deposit, a deposit becomes a contract, and the contract
              does not lapse when your circumstances change.
            </text>

            <box tw="flex flex-col w-full" pad={{ t: 10 }}>
              {LADDER.map((l) => (
                <grid cols="88px 110px 1fr" gap={16} w="100%" mobile={{ gridCols: '70px 92px 1fr' }} pad={{ t: 16, b: 16 }} raw={`& { border-top: 1px solid ${t.color.rule}; }`}>
                  <text font={t.font.head} size={26} weight={600} lh={1.1} color={t.color.ink} mobile={{ size: 22 }}>
                    {l.amount}
                  </text>
                  <text font={t.font.head} size={26} weight={500} lh={1.1} color={t.color.grass} mobile={{ size: 22 }}>
                    {l.sqm}
                  </text>
                  <text font={t.font.body} size={15.5} lh={1.5} color="#5A6A57">
                    {l.note}
                  </text>
                </grid>
              ))}
            </box>
          </box>

          <box tw="flex flex-col gap-4" pad={0}>
            <box w="100%" pad={22} bg={t.color.paper} raw={`& { border: 1px solid ${t.color.rule}; }`}>
              <html
                raw={`<svg viewBox="0 0 420 300" width="100%" role="img" aria-label="Forty shaded squares, each one square metre, making up the 40 square metres that twelve pounds a month protects for a year." xmlns="http://www.w3.org/2000/svg" style="display:block;width:100%;height:auto">
  <rect width="420" height="300" fill="#FFFFFF"/>
  ${Array.from({ length: 60 }, (_, i) => {
    const c = i % 10;
    const r = Math.floor(i / 10);
    const on = i < 40;
    return `<rect x="${18 + c * 38}" y="${18 + r * 38}" width="32" height="32" fill="${on ? '#6E8B3D' : '#F3F5EF'}" fill-opacity="${on ? 0.42 : 1}" stroke="${on ? '#6E8B3D' : '#C9D1C2'}" stroke-width="1.4"/>`;
  }).join('')}
  <line x1="18" y1="258" x2="402" y2="258" stroke="#C9D1C2" stroke-width="1"/>
  <text x="18" y="280" font-family="'Source Sans 3', sans-serif" font-size="14" font-weight="700" fill="#1B2A20" letter-spacing="0.8">40 m² PROTECTED, ONE YEAR OF £12 A MONTH</text>
  <text x="402" y="280" text-anchor="end" font-family="'Source Sans 3', sans-serif" font-size="13" fill="#C4913C">1 square = 1 m²</text>
</svg>`}
              />
            </box>
            <text font={t.font.body} size={13.5} lh={1.55} color="#7C8878" maxw={470}>
              Forty square metres is a curlew’s nest scrape and the tussocks a chick hides in for its
              first fortnight. It is not a symbol. It is the actual area.
            </text>
          </box>
        </grid>
      </box>
    </section>

    {/* ─── 5 · species that came back ────────────────────────────────────── */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 0, b: 0 }} bg={t.color.ink}>
      <grid cols="1fr 1fr" gap={0} tablet={{ gridCols: '1fr' }} w="100%">
        <box tw="flex flex-col w-full" pad={0} minh={420}>
          <img src={curlew} w="100%" h="100%" fit="cover" minh={420} tablet={{ minh: 320 }} mobile={{ minh: 260 }} />
        </box>

        <box tw="flex flex-col gap-8" pad={{ t: 88, b: 88, l: 64, r: 64 }} tablet={{ pad: { t: 60, b: 60, l: 28, r: 28 } }} mobile={{ pad: { t: 52, b: 52, l: 20, r: 20 } }}>
          <Marker n="05" label="CAME BACK, WITH DATES" t={t} tone="dark" />
          <h2 font={t.font.head} size={44} weight={500} lh={1.1} ls={-0.018} color="#F3F5EF" tablet={{ size: 38 }} mobile={{ size: 30 }}>
            What returned, and the year it did.
          </h2>
          <text font={t.font.body} size={16.5} lh={1.62} color="#B7C6B0" maxw={520}>
            Volunteers walk fixed transects four times a year. These are their records, not our
            claims — the raw survey sheets go up every December.
          </text>

          <box tw="flex flex-col w-full" pad={0}>
            {SPECIES.map((s) => (
              <SpeciesRow species={s.species} place={s.place} when={s.when} note={s.note} />
            ))}
          </box>

          <row tw="flex flex-row items-center gap-4" pad={{ t: 10 }}>
            <box w={92} h={92} pad={0} raw="& { overflow: hidden; }">
              <img src={volunteerSurvey} w="100%" h={92} fit="cover" />
            </box>
            <text font={t.font.body} size={14.5} lh={1.55} color="#9FB08F" maxw={340}>
              Sixty-one volunteers, twenty-two survey points, four visits a year. Nobody is paid to
              count.
            </text>
          </row>
        </box>
      </grid>
    </section>

    {/* ─── 6 · leave land, not just money ────────────────────────────────── */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 92, b: 92 }} bg={t.color.paper} raw={`& { border-top: 4px solid ${t.color.ochre}; }`}>
      <box tw="flex flex-col w-full gap-11" maxw={1280} pad={{ l: 40, r: 40 }} tablet={{ pad: { l: 28, r: 28 } }} mobile={{ pad: { l: 20, r: 20 } }}>
        <Marker n="06" label="TWO OTHER WAYS" t={t} />

        <grid cols="1.1fr 0.9fr" gap={48} tablet={{ gridCols: '1fr' }} w="100%">
          <h2 font={t.font.head} size={46} weight={500} lh={1.1} ls={-0.018} color={t.color.ink} tablet={{ size: 40 }} mobile={{ size: 31 }}>
            Leave land, not just money.
          </h2>
          <text font={t.font.body} size={17} lh={1.65} color="#41513F" maxw={480} pad={{ t: 8 }}>
            Roughly a third of the map above arrived this way. Neither path costs you anything while
            you are alive to enjoy the ground.
          </text>
        </grid>

        <grid cols="1fr 1fr" gap={0} tablet={{ gridCols: '1fr' }} w="100%" pad={{ t: 12 }}>
          {PATHS.map((p, i) => (
            <box
              tw="flex flex-col gap-5"
              pad={i === 0 ? { r: 56, t: 34, b: 34 } : { l: 56, t: 34, b: 34 }}
              tablet={{ pad: { l: 0, r: 0, t: 34, b: 34 } }}
              raw={i === 0 ? `& { border-top: 1px solid ${t.color.rule}; }` : `& { border-top: 1px solid ${t.color.rule}; border-left: 1px solid ${t.color.rule}; }`}
            >
              <text font={t.font.body} size={12.5} weight={700} ls={0.1} color={t.color.ochre}>
                {`PATH ${i === 0 ? 'A' : 'B'}`}
              </text>
              <h3 font={t.font.head} size={32} weight={500} lh={1.14} color={t.color.ink} mobile={{ size: 26 }}>
                {p.kind}
              </h3>
              <text font={t.font.head} size={21} weight={400} lh={1.45} color={t.color.river} maxw={420}>
                {p.lede}
              </text>
              <box tw="flex flex-col gap-4" pad={{ t: 6 }}>
                {p.steps.map((s, j) => (
                  <row tw="flex flex-row items-start gap-4" pad={0}>
                    <text font={t.font.body} size={13} weight={700} color={t.color.grass} w={22} pad={{ t: 3 }}>
                      {`0${j + 1}`}
                    </text>
                    <text font={t.font.body} size={16} lh={1.6} color="#41513F" maxw={420}>
                      {s}
                    </text>
                  </row>
                ))}
              </box>
              <text font={t.font.body} size={14.5} lh={1.55} color="#7C8878" maxw={420} pad={{ t: 8 }} raw={`& { border-top: 1px solid ${t.color.rule}; padding-top: 14px; }`}>
                {p.foot}
              </text>
            </box>
          ))}
        </grid>

        <row tw="flex flex-row items-center gap-4 flex-wrap" pad={0}>
          <text
            href="mailto:land@commongroundtrust.org?subject=Bequest%20or%20easement"
            font={t.font.body}
            size={16}
            weight={600}
            color={t.color.ink}
            pad={[15, 28]}
            raw={`& { border: 1px solid ${t.color.ink}; }`}
            hover={{ bg: t.color.ink, color: t.color.ground }}
          >
            Talk to us about land
          </text>
          <text font={t.font.body} size={14.5} lh={1.55} color="#7C8878">
            One person answers that address. She has walked every parcel on the map.
          </text>
        </row>
      </box>
    </section>

    {/* ─── 7 · accounts ──────────────────────────────────────────────────── */}
    <section id="accounts" tw="flex flex-col w-full items-center" pad={{ t: 92, b: 92 }} bg={t.color.ground}>
      <box tw="flex flex-col w-full gap-10" maxw={1280} pad={{ l: 40, r: 40 }} tablet={{ pad: { l: 28, r: 28 } }} mobile={{ pad: { l: 20, r: 20 } }}>
        <Marker n="07" label="WHERE EVERY POUND WENT" t={t} />

        <grid cols="0.9fr 1.1fr" gap={56} tablet={{ gridCols: '1fr' }} w="100%">
          <box tw="flex flex-col gap-6" pad={0}>
            <h2 font={t.font.head} size={46} weight={500} lh={1.1} ls={-0.018} color={t.color.ink} tablet={{ size: 40 }} mobile={{ size: 31 }}>
              84p of every pound went into land.
            </h2>
            <text font={t.font.body} size={17.5} lh={1.62} color="#41513F" maxw={480}>
              84p of every pound went into land and its upkeep last year. The remaining 16p paid
              three salaries and an accountant. The full accounts are one click away and always will
              be.
            </text>
            <text
              href="#accounts-detail"
              font={t.font.body}
              size={15.5}
              weight={600}
              color={t.color.river}
              hover={{ color: t.color.ink }}
              raw="& { text-decoration: underline; text-underline-offset: 4px; }"
            >
              The 2025 accounts, line by line →
            </text>
          </box>

          <box id="accounts-detail" tw="flex flex-col gap-7" pad={0} motion={FADE}>
            <box tw="flex flex-col gap-3" pad={0} w="100%">
              <row tw="flex flex-row w-full" pad={0} h={54} raw="& { overflow: hidden; }">
                <box w="84%" h={54} pad={0} bg={t.color.grass} tw="flex flex-col justify-center" >
                  <text font={t.font.body} size={14} weight={700} ls={0.07} color="#F3F5EF" pad={{ l: 14 }}>
                    84p LAND
                  </text>
                </box>
                <box w="16%" h={54} pad={0} bg={t.color.ochre} tw="flex flex-col justify-center">
                  <text font={t.font.body} size={14} weight={700} ls={0.05} color="#2A1E0C" pad={{ l: 10 }}>
                    16p
                  </text>
                </box>
              </row>
              <text font={t.font.body} size={13} lh={1.5} color="#7C8878">
                Year ended 31 March 2026 · income £2,441,900 · independently examined
              </text>
            </box>

            <box tw="flex flex-col w-full" pad={0}>
              {ACCOUNTS.map((a) => (
                <grid cols="1fr 120px 64px" gap={16} w="100%" mobile={{ gridCols: '1fr 80px 52px' }} pad={{ t: 14, b: 14 }} raw={`& { border-top: 1px solid ${t.color.rule}; }`}>
                  <text font={t.font.body} size={16} lh={1.5} color={t.color.ink}>
                    {a.line}
                  </text>
                  <box w="100%" h={8} pad={0} bg="#E2E7DB" m={{ t: 6 }} raw="& { overflow: hidden; }">
                    <box h={8} pad={0} w={a.w} bg={a.tone === 'grass' ? t.color.grass : t.color.ochre} />
                  </box>
                  <text font={t.font.head} size={19} weight={600} ta="right" color={t.color.ink}>
                    {a.pence}
                  </text>
                </grid>
              ))}
              <box w="100%" h={1} pad={0} bg={t.color.ink} />
              <row tw="flex flex-row items-end justify-between" pad={{ t: 12 }} w="100%">
                <text font={t.font.body} size={13} weight={700} ls={0.08} color="#7C8878">
                  TOTAL
                </text>
                <text font={t.font.head} size={19} weight={600} color={t.color.ink}>
                  100p
                </text>
              </row>
            </box>
          </box>
        </grid>
      </box>
    </section>

    {/* ─── 8 · standing order ────────────────────────────────────────────── */}
    <section id="standing-order" tw="flex flex-col w-full items-center" pad={{ t: 0, b: 0 }} bg={t.color.ink}>
      <box w="100%" pad={0} h={220} tablet={{ h: 170 }} mobile={{ h: 130 }} raw="& { overflow: hidden; }">
        <img src={meadowWide} w="100%" h={220} fit="cover" tablet={{ h: 170 }} mobile={{ h: 130 }} />
      </box>

      <box tw="flex flex-col w-full items-center" pad={{ t: 84, b: 96 }}>
        <box tw="flex flex-col w-full gap-11" maxw={1280} pad={{ l: 40, r: 40 }} tablet={{ pad: { l: 28, r: 28 } }} mobile={{ pad: { l: 20, r: 20 } }}>
          <Marker n="08" label="STANDING ORDER" t={t} tone="dark" />

          <grid cols="0.95fr 1.05fr" gap={60} tablet={{ gridCols: '1fr' }} w="100%">
            <box tw="flex flex-col gap-6" pad={0}>
              <h2 font={t.font.head} size={50} weight={500} lh={1.08} ls={-0.02} color="#F3F5EF" tablet={{ size: 42 }} mobile={{ size: 33 }}>
                Protect an acre.
              </h2>
              <text font={t.font.body} size={18.5} lh={1.62} color="#C9D6C2" maxw={470} mobile={{ size: 17 }}>
                A standing order is the only thing that lets us bid before a parcel goes to auction.
                It is the difference between the 217 acres and the 96.
              </text>
              <box tw="flex flex-col gap-3" pad={{ t: 12 }} raw="& { border-top: 1px solid #33463A; }">
                <text font={t.font.body} size={15} lh={1.6} color="#9FB08F" maxw={430}>
                  No newsletter unless you ask. No telephone calls, ever. Cancel at your bank without
                  telling us — we will not chase you.
                </text>
                <text font={t.font.body} size={15} lh={1.6} color="#9FB08F" maxw={430}>
                  Gift Aid adds 25p to every pound if you are a UK taxpayer, and it costs you nothing.
                </text>
              </box>
            </box>

            <box tw="flex flex-col gap-5" pad={0}>
              <text font={t.font.body} size={13} weight={700} ls={0.1} color="#8FA283">
                CHOOSE A MONTHLY AMOUNT
              </text>

              <grid cols={2} gap={14} mobile={{ gridCols: '1fr' }} w="100%">
                {LADDER.map((l) => (
                  <box
                    tw="flex flex-col gap-1"
                    pad={[20, 22]}
                    raw="& { border: 1px solid #33463A; }"
                    hover={{ bg: '#243528', raw: 'border-color: #6E8B3D;' }}
                  >
                    <row tw="flex flex-row items-end gap-3" pad={0}>
                      <text font={t.font.head} size={32} weight={600} lh={1} color="#F3F5EF" mobile={{ size: 28 }}>
                        {l.amount}
                      </text>
                      <text font={t.font.body} size={13.5} color="#8FA283">
                        a month
                      </text>
                    </row>
                    <text font={t.font.body} size={14.5} weight={600} color={t.color.grass}>
                      {`protects ${l.sqm} a year`}
                    </text>
                  </box>
                ))}
              </grid>

              <row tw="flex flex-row items-center gap-4 flex-wrap" pad={{ t: 6 }}>
                <text
                  href="mailto:give@commongroundtrust.org?subject=Standing%20order"
                  font={t.font.body}
                  size={17}
                  weight={700}
                  ls={0.03}
                  color={t.color.ink}
                  bg={t.color.grass}
                  pad={[18, 34]}
                  hover={{ bg: '#8AA855' }}
                >
                  Set up a standing order
                </text>
                <text font={t.font.body} size={14.5} lh={1.5} color="#8FA283" maxw={230}>
                  Or give once, or give a different amount — say so in the message.
                </text>
              </row>
            </box>
          </grid>

          <box w="100%" h={1} pad={0} bg="#33463A" m={{ t: 20 }} />
          <row tw="flex flex-row items-center justify-between gap-6 flex-wrap w-full" pad={0}>
            <text font={t.font.head} size={17} weight={600} color="#F3F5EF">
              Common Ground Trust
            </text>
            <text font={t.font.body} size={13} lh={1.5} color="#8FA283" maxw={620}>
              Registered charity 1073344 · The Old Weighbridge, Marsden, Wenn valley · Land held in
              permanent trust since 1998
            </text>
          </row>
        </box>
      </box>
    </section>
  </box>
);
