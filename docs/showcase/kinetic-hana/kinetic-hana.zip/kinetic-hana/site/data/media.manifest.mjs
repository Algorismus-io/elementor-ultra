/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "kinetic-hana--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'kinetic-hana--';

export default [
  { slot: `${PREFIX}still_a`, file: join(MEDIA_DIR, "still_frame_a.jpg"), alt: "Still frame from a title sequence by Hana Sekigawa" },
  { slot: `${PREFIX}still_b`, file: join(MEDIA_DIR, "still_frame_b.jpg"), alt: "Still frame from a broadcast package by Hana Sekigawa" },
  { slot: `${PREFIX}studio_desk`, file: join(MEDIA_DIR, "studio_desk.jpg"), alt: "Hana Sekigawa studio desk with After Effects timeline on screen" },
];
