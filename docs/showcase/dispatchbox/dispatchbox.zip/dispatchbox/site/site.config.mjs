export default { name: 'dispatchbox' };
