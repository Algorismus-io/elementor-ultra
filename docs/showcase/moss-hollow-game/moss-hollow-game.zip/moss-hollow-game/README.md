# Moss Hollow

Hand-illustrated warmth, seasons panel, genuinely charming.

|  |  |
|---|---|
| **Slug** | `moss-hollow-game` (deploys to `/moss-hollow-game/`) |
| **Archetype** | bento grid |
| **Industry** | Mobile game |
| **Page title** | Moss Hollow |
| **Fonts** | Pacifico, Nunito — Google Fonts, imported by Elementor automatically |
| **Elements** | 105 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (58 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install moss-hollow-game
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
moss-hollow-game/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/moss-hollow-game.page.jsx      the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F3F7EC` |
| `tile` | `#E4EEDA` |
| `ink` | `#26331F` |
| `moss` | `#6E9152` |
| `berry` | `#A8446B` |
| `honey` | `#E4A93C` |

Change a value, re-run `npx exjsx-kit install moss-hollow-game`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/moss-hollow-game.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `forage` | `media/forage_scene.jpg` | Foraging in the woods around Moss Hollow |
| `valley` | `media/valley_art.jpg` | The Moss Hollow valley in painted art style |
| `winter` | `media/winter_scene.jpg` | A quiet winter evening in Moss Hollow |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
