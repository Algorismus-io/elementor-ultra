/** Hana Sekigawa — motion design portfolio tokens. */
export default defineTheme({
  name: 'hana',
  color: {
    ground: '#0A0A0C',
    ink: '#F4F4F6',
    signal: '#FF4D6D',
    chrome: '#B9BCC7',
    deep: '#15151B',
  },
  font: { head: 'Syncopate', body: 'Sen' },
  mode: 'literal',
});
