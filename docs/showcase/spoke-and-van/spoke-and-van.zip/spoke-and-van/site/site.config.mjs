export default { name: 'spoke-and-van' };
