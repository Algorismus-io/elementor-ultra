/** Plainroll — the cost-ledger landing page. */
export const meta = {
  title: 'Plainroll — £29 flat payroll for UK small businesses',
  slug: 'paystack-plain',
  seo: {
    title: 'Plainroll — payroll for UK small businesses, £29 a month flat',
    description:
      'Plainroll runs payroll for up to 50 employees at £29 a month. Pensions, RTI filing, P60s, year-end, payslips and your accountant’s login are all in that number.',
  },
};

/* ── palette (mirrors theme.mjs; components cannot take style props) ── */
const GROUND = '#FAFAF8';
const INK = '#121212';
const OURS = '#0F6E5A';
const THEIRS = '#9A9A9A';
const FLAG = '#D64545';
const RULE = '#E2E2DE';
const HEAD = 'Familjen Grotesk';
const BODY = 'Inter';

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 600 };

/* ── ledger rows: content-only props, one registered component per visual variant ── */
const OursRow = defineComponent(
  ({ item = 'Line item', cost = '£0' }) => (
    <row
      cls="ledger-row-ours"
      w="100%"
      justify="space-between"
      align="flex-start"
      gap={16}
      pad={{ t: 13, b: 13 }}
      raw="border-bottom: 1px solid #E2E2DE;"
    >
      <text size={15} font={BODY} color={INK} lh={1.5} mobile={{ size: 14 }}>
        {item}
      </text>
      <text size={15} font={HEAD} weight={600} color={OURS} lh={1.5} mobile={{ size: 14 }}>
        {cost}
      </text>
    </row>
  ),
  {
    title: 'Ledger row — Plainroll',
    props: { item: { label: 'Line item', group: 'Ledger' }, cost: { label: 'Cost', group: 'Ledger' } },
  },
);

const TheirsRow = defineComponent(
  ({ item = 'Line item', cost = '£0' }) => (
    <row
      cls="ledger-row-theirs"
      w="100%"
      justify="space-between"
      align="flex-start"
      gap={16}
      pad={{ t: 13, b: 13 }}
      raw="border-bottom: 1px solid #E2E2DE;"
    >
      <text size={15} font={BODY} color="#4A4A4A" lh={1.5} mobile={{ size: 14 }}>
        {item}
      </text>
      <text size={15} font={HEAD} weight={600} color={FLAG} lh={1.5} mobile={{ size: 14 }}>
        {cost}
      </text>
    </row>
  ),
  {
    title: 'Ledger row — theirs',
    props: { item: { label: 'Line item', group: 'Ledger' }, cost: { label: 'Cost', group: 'Ledger' } },
  },
);

const IncludedRow = defineComponent(
  ({ item = 'Included', note = 'in the £29' }) => (
    <row cls="flat-row" w="100%" justify="space-between" align="flex-start" gap={16} pad={{ t: 12, b: 12 }} raw="border-bottom: 1px solid rgba(255,255,255,0.14);">
      <text size={15} font={BODY} color="#F2F2EE" lh={1.5}>
        {item}
      </text>
      <text size={13} font={BODY} weight={500} color="#6FD3B8" lh={1.6} ta="right">
        {note}
      </text>
    </row>
  ),
  {
    title: 'Flat-fee inclusion',
    props: { item: { label: 'Item', group: 'Flat' }, note: { label: 'Note', group: 'Flat' } },
  },
);

const ExtraRow = defineComponent(
  ({ item = 'Extra', note = 'billed on top' }) => (
    <row cls="extra-row" w="100%" justify="space-between" align="flex-start" gap={16} pad={{ t: 12, b: 12 }} raw="border-bottom: 1px solid rgba(255,255,255,0.14);">
      <text size={15} font={BODY} color="#C9C9C4" lh={1.5}>
        {item}
      </text>
      <text size={13} font={BODY} weight={500} color="#E8837F" lh={1.6} ta="right">
        {note}
      </text>
    </row>
  ),
  {
    title: 'Charged extra',
    props: { item: { label: 'Item', group: 'Extra' }, note: { label: 'Note', group: 'Extra' } },
  },
);

/* ── plain helpers (inline expansion) ── */
const Wrap = ({ children, maxw = 1120 }) => (
  <box w="100%" maxw={maxw} m={{ l: 'auto', r: 'auto' }} tw="flex flex-col">
    {children}
  </box>
);

const Eyebrow = ({ text: label, color = OURS }) => (
  <text size={12} font={BODY} weight={600} ls="1.6px" color={color} tw="uppercase">
    {label}
  </text>
);

const Cta = ({ label = 'Run your first payroll free', dark = false }) => (
  <text
    href="#start"
    tag="span"
    size={16}
    font={HEAD}
    weight={600}
    color={dark ? INK : '#FFFFFF'}
    bg={dark ? '#FFFFFF' : OURS}
    pad={{ t: 16, b: 16, l: 28, r: 28 }}
    radius={6}
    ta="center"
    hover={{ bg: dark ? '#E7F0EC' : '#0B5546', color: dark ? OURS : '#FFFFFF' }}
  >
    {label}
  </text>
);

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
    {/* ══ 1. Cost ledger ══════════════════════════════════════════════ */}
    <section tw="flex flex-col w-full" pad={{ t: 72, b: 96, l: 24, r: 24 }} bg={t.color.ground}>
      <Wrap>
        <grid cols={12} gap={48} tw="w-full">
          <box span={7} mobile={{ span: 1 }} tw="flex flex-col gap-6">
            <Eyebrow text="Plainroll · flat-fee UK payroll" />
            <h1
              size={62}
              weight={600}
              lh={1.04}
              ls="-1.4px"
              font={t.font.head}
              color={t.color.ink}
              tablet={{ size: 48 }}
              mobile={{ size: 34, lh: 1.1 }}
            >
              Payroll for 18 people should not cost <em>£214</em> a month.
              <br />
            </h1>
            <text size={18} font={t.font.body} color="#3C3C3A" lh={1.65} maxw={560} mobile={{ size: 16 }}>
              Plainroll is £29 a month for up to 50 employees. Pensions, RTI filing, P60s, year-end,
              payslips and your accountant’s login are all in that number, because there is nothing
              else to sell you.
            </text>
            <row gap={16} wrap="wrap" align="center" pad={{ t: 8 }}>
              <Cta />
              <text size={14} font={t.font.body} color={t.color.theirs} lh={1.6}>
                No card. First pay run on us.
              </text>
            </row>
          </box>

          <box span={5} mobile={{ span: 1 }} tw="flex flex-col gap-3" pad={{ t: 8 }}>
            <text size={14} font={t.font.body} color="#3C3C3A" lh={1.7}>
              An 18-person payroll, priced by both sides of the market. Same month, same filings,
              same people getting paid.
            </text>
            <box h={1} bg={t.color.rule} w="100%" m={{ t: 8 }} />
            <row justify="space-between" align="flex-end" gap={12}>
              <text size={13} font={t.font.body} color={t.color.theirs}>
                Difference
              </text>
              <text size={30} font={t.font.head} weight={600} color={t.color.ours} mobile={{ size: 26 }}>
                £2,217 a year
              </text>
            </row>
          </box>
        </grid>

        {/* the ledger itself */}
        <grid cols={2} gap={0} gapX={0} tw="w-full" m={{ t: 56 }} motion={FADE}>
          <box
            tw="flex flex-col"
            bg="#FFFFFF"
            pad={{ t: 28, b: 28, l: 28, r: 28 }}
            raw="border-top: 3px solid #0F6E5A;"
            mobile={{ pad: { t: 22, b: 22, l: 18, r: 18 } }}
          >
            <row justify="space-between" align="flex-end" gap={12} pad={{ b: 14 }}>
              <h2 size={22} weight={600} font={t.font.head} color={t.color.ink} mobile={{ size: 19 }}>
                Plainroll
              </h2>
              <text size={12} font={t.font.body} weight={600} ls="1.2px" color={t.color.ours} tw="uppercase">
                Flat
              </text>
            </row>
            <OursRow item="Base fee, up to 50 employees" cost="£29.00" />
            <OursRow item="Per employee, × 18" cost="£0.00" />
            <OursRow item="Pension auto-enrolment and assessment" cost="£0.00" />
            <OursRow item="RTI: FPS and EPS to HMRC" cost="£0.00" />
            <OursRow item="P45s, P60s and year-end" cost="£0.00" />
            <OursRow item="Off-cycle and corrective pay runs" cost="£0.00" />
            <OursRow item="CSV and Xero export" cost="£0.00" />
            <OursRow item="Accountant seat" cost="£0.00" />
            <OursRow item="Support, phone and email" cost="£0.00" />
            <row justify="space-between" align="flex-end" gap={12} pad={{ t: 20 }}>
              <text size={15} font={t.font.body} weight={600} color={t.color.ink}>
                Total, every month
              </text>
              <text size={36} font={t.font.head} weight={600} color={t.color.ours} ls="-0.8px" mobile={{ size: 28 }}>
                £29.00
              </text>
            </row>
          </box>

          <box
            tw="flex flex-col"
            bg="#F3F3F0"
            pad={{ t: 28, b: 28, l: 28, r: 28 }}
            raw="border-top: 3px solid #9A9A9A;"
            mobile={{ pad: { t: 22, b: 22, l: 18, r: 18 } }}
          >
            <row justify="space-between" align="flex-end" gap={12} pad={{ b: 14 }}>
              <h2 size={22} weight={600} font={t.font.head} color="#5A5A58" mobile={{ size: 19 }}>
                The two you are considering
              </h2>
              <text size={12} font={t.font.body} weight={600} ls="1.2px" color={t.color.theirs} tw="uppercase">
                Modular
              </text>
            </row>
            <TheirsRow item="Base fee" cost="£8.00" />
            <TheirsRow item="Per employee, £4 × 18" cost="£72.00" />
            <TheirsRow item="Pension module" cost="£6.00" />
            <TheirsRow item="Year-end, £45 spread over 12" cost="£3.75" />
            <TheirsRow item="Off-cycle runs, £12 × 2" cost="£24.00" />
            <TheirsRow item="Support tier you will end up on" cost="£100.00" />
            <TheirsRow item="P45s, P60s" cost="in the tier" />
            <TheirsRow item="Accountant seat" cost="£0.00" />
            <TheirsRow item="CSV export" cost="£0.00" />
            <row justify="space-between" align="flex-end" gap={12} pad={{ t: 20 }}>
              <text size={15} font={t.font.body} weight={600} color="#5A5A58">
                Total, every month
              </text>
              <text size={36} font={t.font.head} weight={600} color={t.color.flag} ls="-0.8px" mobile={{ size: 28 }}>
                £213.75
              </text>
            </row>
          </box>
        </grid>
        <text size={13} font={t.font.body} color={t.color.theirs} lh={1.7} m={{ t: 14 }} maxw={620}>
          Call it £214. Their list price, our list price, one 18-person payroll. Nothing on either
          side is a promotional rate.
        </text>
      </Wrap>
    </section>

    {/* ══ 2. What flat means ══════════════════════════════════════════ */}
    <section tw="flex flex-col w-full" pad={{ t: 96, b: 96, l: 24, r: 24 }} bg={t.color.ink}>
      <Wrap>
        <grid cols={12} gap={48} tw="w-full">
          <box span={4} mobile={{ span: 1 }} tw="flex flex-col gap-5">
            <Eyebrow text="What flat means" color="#6FD3B8" />
            <h2
              size={40}
              weight={600}
              lh={1.1}
              ls="-0.8px"
              font={t.font.head}
              color="#FFFFFF"
              tablet={{ size: 34 }}
              mobile={{ size: 28 }}
            >
              One number. The list is not a teaser.
            </h2>
            <text size={16} font={t.font.body} color="#B7B7B2" lh={1.7}>
              Flat means the invoice does not move when you hire, when someone leaves, when April
              arrives, or when you need a second pay run because a timesheet came in late.
            </text>
          </box>
          <box span={4} mobile={{ span: 1 }} tw="flex flex-col">
            <h3 size={13} font={t.font.body} weight={600} ls="1.4px" color="#6FD3B8" tw="uppercase" pad={{ b: 10 }}>
              In the £29
            </h3>
            <IncludedRow item="Auto-enrolment, assessment and re-enrolment" note="included" />
            <IncludedRow item="Pension file to your provider" note="included" />
            <IncludedRow item="RTI filing, FPS and EPS" note="included" />
            <IncludedRow item="P45s and P60s" note="included" />
            <IncludedRow item="Unlimited pay runs" note="included" />
            <IncludedRow item="CSV and Xero export" note="included" />
            <IncludedRow item="Accountant seat" note="free forever" />
            <IncludedRow item="Support from people who have run payroll" note="included" />
          </box>
          <box span={4} mobile={{ span: 1 }} tw="flex flex-col">
            <h3 size={13} font={t.font.body} weight={600} ls="1.4px" color="#E8837F" tw="uppercase" pad={{ b: 10 }}>
              What they charge extra for
            </h3>
            <ExtraRow item="Each employee, every month" note="£4 each" />
            <ExtraRow item="The pension module" note="£6 a month" />
            <ExtraRow item="Year-end processing" note="£45 a year" />
            <ExtraRow item="Off-cycle pay run" note="£12 a run" />
            <ExtraRow item="Phone support" note="tier upgrade" />
            <ExtraRow item="Historic payslip access" note="archive fee" />
            <ExtraRow item="Second company on one login" note="new subscription" />
            <ExtraRow item="Leaving and taking your data" note="export fee" />
          </box>
        </grid>
      </Wrap>
    </section>

    {/* ══ 3. Payroll day ══════════════════════════════════════════════ */}
    <section tw="flex flex-col w-full" pad={{ t: 104, b: 104, l: 24, r: 24 }} bg={t.color.ground}>
      <Wrap>
        <row justify="space-between" align="flex-end" gap={24} wrap="wrap" pad={{ b: 40 }} raw="border-bottom: 1px solid #E2E2DE;">
          <box tw="flex flex-col gap-4" maxw={640}>
            <Eyebrow text="Payroll day" />
            <h2
              size={44}
              weight={600}
              lh={1.08}
              ls="-1px"
              font={t.font.head}
              color={t.color.ink}
              tablet={{ size: 36 }}
              mobile={{ size: 29 }}
            >
              The eleven minutes, described.
            </h2>
          </box>
          <text size={64} font={t.font.head} weight={600} color={t.color.ours} ls="-2px" lh={1} mobile={{ size: 44 }}>
            11 min
          </text>
        </row>

        <grid cols={3} gap={40} tw="w-full" m={{ t: 48 }} motion={FADE}>
          <box tw="flex flex-col gap-3">
            <row align="flex-end" gap={12}>
              <text size={13} font={t.font.head} weight={600} color={t.color.ours}>
                01
              </text>
              <text size={13} font={t.font.body} color={t.color.theirs} ls="0.6px">
                minutes 0–4
              </text>
            </row>
            <h3 size={22} weight={600} font={t.font.head} color={t.color.ink} lh={1.2}>
              Approve the hours
            </h3>
            <text size={15} font={t.font.body} color="#3C3C3A" lh={1.7}>
              Salaried people are already right. Hourly people arrive from your timesheet, rounded
              the way you told us to round them, with last month beside them for comparison.
            </text>
          </box>
          <box tw="flex flex-col gap-3">
            <row align="flex-end" gap={12}>
              <text size={13} font={t.font.head} weight={600} color={t.color.flag}>
                02
              </text>
              <text size={13} font={t.font.body} color={t.color.theirs} ls="0.6px">
                minutes 4–9
              </text>
            </row>
            <h3 size={22} weight={600} font={t.font.head} color={t.color.ink} lh={1.2}>
              Check the two flags we raise
            </h3>
            <text size={15} font={t.font.body} color="#3C3C3A" lh={1.7}>
              A starter with no P45. Someone who crossed the auto-enrolment threshold this month.
              We do not bury them in a report; they are the only two things on the screen.
            </text>
          </box>
          <box tw="flex flex-col gap-3">
            <row align="flex-end" gap={12}>
              <text size={13} font={t.font.head} weight={600} color={t.color.ours}>
                03
              </text>
              <text size={13} font={t.font.body} color={t.color.theirs} ls="0.6px">
                minutes 9–11
              </text>
            </row>
            <h3 size={22} weight={600} font={t.font.head} color={t.color.ink} lh={1.2}>
              Press run
            </h3>
            <text size={15} font={t.font.body} color="#3C3C3A" lh={1.7}>
              Payslips go out, the pension file goes to your provider, and the RTI submission goes
              to HMRC before you have closed the tab.
            </text>
          </box>
        </grid>
      </Wrap>
    </section>

    {/* ══ 4. Pension, RTI, year-end ═══════════════════════════════════ */}
    <section
      tw="flex flex-col w-full"
      pad={{ t: 88, b: 88, l: 24, r: 24 }}
      grad={[160, '#F1F4F2', '#FAFAF8']}
    >
      <Wrap>
        <grid cols={12} gap={48} tw="w-full">
          <box span={4} mobile={{ span: 1 }} tw="flex flex-col gap-4">
            <Eyebrow text="Compliance" />
            <h2
              size={38}
              weight={600}
              lh={1.1}
              ls="-0.8px"
              font={t.font.head}
              color={t.color.ink}
              tablet={{ size: 32 }}
              mobile={{ size: 27 }}
            >
              Pension, RTI and year-end, handled.
            </h2>
            <text size={15} font={t.font.body} color="#3C3C3A" lh={1.7}>
              These are the three things that turn a twenty-minute job into a Saturday. They are
              not modules here. They are the product.
            </text>
          </box>

          <box span={8} mobile={{ span: 1 }} tw="flex flex-col">
            <grid cols={3} gap={0} tw="w-full">
              <box tw="flex flex-col gap-3" pad={{ r: 28, b: 24 }} raw="border-right: 1px solid #E2E2DE;" mobile={{ pad: { r: 0, b: 24 } }}>
                <text size={12} font={t.font.body} weight={600} ls="1.4px" color={t.color.ours} tw="uppercase">
                  Pension
                </text>
                <h3 size={19} weight={600} font={t.font.head} color={t.color.ink} lh={1.25}>
                  Auto-enrolment on the clock
                </h3>
                <text size={14} font={t.font.body} color="#3C3C3A" lh={1.7}>
                  Every employee assessed each pay period, postponement handled, contributions
                  calculated, the file sent to Nest, Smart, The People’s Pension or your provider.
                  Re-enrolment is diarised three years out and we tell you before it lands.
                </text>
              </box>
              <box tw="flex flex-col gap-3" pad={{ l: 28, r: 28, b: 24 }} raw="border-right: 1px solid #E2E2DE;" mobile={{ pad: { l: 0, r: 0, b: 24 } }}>
                <text size={12} font={t.font.body} weight={600} ls="1.4px" color={t.color.ours} tw="uppercase">
                  RTI
                </text>
                <h3 size={19} weight={600} font={t.font.head} color={t.color.ink} lh={1.25}>
                  Filed on or before payday
                </h3>
                <text size={14} font={t.font.body} color="#3C3C3A" lh={1.7}>
                  The FPS goes on the day you run, not the day someone remembers. EPS for statutory
                  recoveries and the employment allowance goes when it is due, and you get the HMRC
                  receipt reference in writing every time.
                </text>
              </box>
              <box tw="flex flex-col gap-3" pad={{ l: 28, b: 24 }} mobile={{ pad: { l: 0, b: 0 } }}>
                <text size={12} font={t.font.body} weight={600} ls="1.4px" color={t.color.ours} tw="uppercase">
                  Year-end
                </text>
                <h3 size={19} weight={600} font={t.font.head} color={t.color.ink} lh={1.25}>
                  April without the invoice
                </h3>
                <text size={14} font={t.font.body} color="#3C3C3A" lh={1.7}>
                  Final submission, P60s to every employee, new tax codes applied from the P9
                  notices, thresholds rolled forward. It is one email telling you it is done, and it
                  costs the same £29 as March.
                </text>
              </box>
            </grid>
          </box>
        </grid>
      </Wrap>
    </section>

    {/* ══ 5. Switching mid-year ═══════════════════════════════════════ */}
    <section tw="flex flex-col w-full" pad={{ t: 96, b: 96, l: 24, r: 24 }} bg={t.color.ground}>
      <Wrap>
        <grid cols={12} gap={56} tw="w-full">
          <box span={6} mobile={{ span: 1 }} tw="flex flex-col gap-5">
            <Eyebrow text="Switching" />
            <h2
              size={40}
              weight={600}
              lh={1.1}
              ls="-0.9px"
              font={t.font.head}
              color={t.color.ink}
              tablet={{ size: 33 }}
              mobile={{ size: 27 }}
            >
              Switch mid-year without breaking your figures.
            </h2>
            <text size={17} font={t.font.body} color="#3C3C3A" lh={1.7}>
              Bring your year-to-date figures from any provider mid-year. We reconcile them against
              your last FPS and tell you if they do not add up before you commit.
            </text>
            <text size={15} font={t.font.body} color="#3C3C3A" lh={1.7}>
              You do not have to wait for April, and you do not have to run two systems in parallel
              for a quarter to feel safe. If the reconciliation fails, we tell you which employee
              and which figure, and nothing moves until you say so.
            </text>
          </box>

          <box span={6} mobile={{ span: 1 }} tw="flex flex-col" bg="#FFFFFF" pad={{ t: 26, b: 26, l: 26, r: 26 }} raw="border: 1px solid #E2E2DE;" radius={6}>
            <row justify="space-between" align="flex-end" gap={12} wrap="wrap" pad={{ b: 16 }} raw="border-bottom: 1px solid #E2E2DE;">
              <text size={13} font={t.font.body} weight={600} ls="1.2px" color={t.color.ink} tw="uppercase" mobile={{ size: 12, ls: "0.8px" }}>
                Reconciliation, 18 employees
              </text>
              <text size={12} font={t.font.body} color={t.color.theirs} mobile={{ size: 12 }}>
                vs last FPS
              </text>
            </row>
            <OursRow item="Gross pay to date" cost="matches" />
            <OursRow item="PAYE income tax to date" cost="matches" />
            <OursRow item="Employee NI to date" cost="matches" />
            <OursRow item="Employer NI to date" cost="matches" />
            <TheirsRow item="Pension contributions, 1 employee" cost="£18.40 out" />
            <OursRow item="Student loan deductions" cost="matches" />
            <text size={14} font={t.font.body} color="#3C3C3A" lh={1.7} pad={{ t: 16 }}>
              One line disagrees. We show you which person, which period and which figure, before
              your first Plainroll run, not after it.
            </text>
          </box>
        </grid>
      </Wrap>
    </section>

    {/* ══ 6. When HMRC writes ═════════════════════════════════════════ */}
    <section
      tw="flex flex-col w-full"
      pad={{ t: 96, b: 96, l: 24, r: 24 }}
      grad={[155, '#0F6E5A', '#0A4A3D']}
    >
      <Wrap>
        <grid cols={12} gap={48} tw="w-full">
          <box span={7} mobile={{ span: 1 }} tw="flex flex-col gap-5">
            <Eyebrow text="If HMRC writes to you" color="#A9E7D4" />
            <h2
              size={42}
              weight={600}
              lh={1.1}
              ls="-1px"
              font={t.font.head}
              color="#FFFFFF"
              tablet={{ size: 34 }}
              mobile={{ size: 28 }}
            >
              We deal with it, and we pay any penalty that was our error.
            </h2>
            <text size={17} font={t.font.body} color="#CFE8DF" lh={1.7} maxw={600}>
              If HMRC writes to you about a submission we made, we deal with it and we pay any
              penalty that was our error. That is in the terms, not just the marketing.
            </text>
          </box>
          <box span={5} mobile={{ span: 1 }} tw="flex flex-col gap-4" pad={{ t: 10 }}>
            <box tw="flex flex-col gap-2" bg="rgba(255,255,255,0.09)" pad={{ t: 18, b: 18, l: 20, r: 20 }} radius={6}>
              <text size={13} font={t.font.body} weight={600} ls="1.2px" color="#FFFFFF" tw="uppercase">
                Forward the letter
              </text>
              <text size={14} font={t.font.body} color="#CFE8DF" lh={1.7}>
                One email to the team that filed it. You are not opening a ticket and you are not
                explaining PAYE to a first-line agent.
              </text>
            </box>
            <box tw="flex flex-col gap-2" bg="rgba(255,255,255,0.09)" pad={{ t: 18, b: 18, l: 20, r: 20 }} radius={6}>
              <text size={13} font={t.font.body} weight={600} ls="1.2px" color="#FFFFFF" tw="uppercase">
                Support, in writing
              </text>
              <text size={14} font={t.font.body} color="#CFE8DF" lh={1.7}>
                Support is email and phone, 8am to 6pm, answered by four people in Manchester who
                have all run payroll for a living.
              </text>
            </box>
          </box>
        </grid>
      </Wrap>
    </section>

    {/* ══ 7. Accountant access ════════════════════════════════════════ */}
    <section tw="flex flex-col w-full" pad={{ t: 88, b: 88, l: 24, r: 24 }} bg={t.color.ground}>
      <Wrap>
        <grid cols={12} gap={48} tw="w-full" align="center">
          <box span={7} mobile={{ span: 1 }} tw="flex flex-col gap-5">
            <Eyebrow text="Your accountant" />
            <h2
              size={38}
              weight={600}
              lh={1.1}
              ls="-0.8px"
              font={t.font.head}
              color={t.color.ink}
              tablet={{ size: 32 }}
              mobile={{ size: 27 }}
            >
              Accountant access, free forever.
            </h2>
            <text size={16} font={t.font.body} color="#3C3C3A" lh={1.7} maxw={620}>
              Their own login, their own permissions, journals in the format they already use, and
              the year-end pack without a single forwarded PDF. We do not charge them for it, we do
              not charge you for it, and we do not use it as the reason you need the next tier up.
            </text>
            <row gap={28} wrap="wrap" pad={{ t: 8 }}>
              <box tw="flex flex-col gap-1">
                <text size={13} font={t.font.body} color={t.color.theirs}>
                  Seats
                </text>
                <text size={22} font={t.font.head} weight={600} color={t.color.ink}>
                  Unlimited
                </text>
              </box>
              <box tw="flex flex-col gap-1">
                <text size={13} font={t.font.body} color={t.color.theirs}>
                  Export
                </text>
                <text size={22} font={t.font.head} weight={600} color={t.color.ink}>
                  CSV and Xero
                </text>
              </box>
              <box tw="flex flex-col gap-1">
                <text size={13} font={t.font.body} color={t.color.theirs}>
                  Price
                </text>
                <text size={22} font={t.font.head} weight={600} color={t.color.ours}>
                  £0
                </text>
              </box>
            </row>
          </box>
          <box span={5} mobile={{ span: 1 }} tw="flex flex-col gap-3" bg="#FFFFFF" pad={{ t: 30, b: 30, l: 28, r: 28 }} raw="border-left: 3px solid #0F6E5A;">
            <text size={72} font={t.font.head} weight={600} color={t.color.ours} lh={1} ls="-3px" mobile={{ size: 52 }}>
              £0
            </text>
            <text size={15} font={t.font.body} color="#3C3C3A" lh={1.7}>
              The accountant seat line on our ledger, and the one line on theirs that is also free —
              which tells you where the rest of their pricing is hiding.
            </text>
          </box>
        </grid>
      </Wrap>
    </section>

    {/* ══ 8. CTA ══════════════════════════════════════════════════════ */}
    <section id="start" tw="flex flex-col w-full items-center text-center" pad={{ t: 100, b: 100, l: 24, r: 24 }} bg={t.color.ink}>
      <box w="100%" maxw={720} m={{ l: 'auto', r: 'auto' }} tw="flex flex-col items-center gap-6 text-center">
        <Eyebrow text="£29 a month, up to 50 employees" color="#6FD3B8" />
        <h2
          size={48}
          weight={600}
          lh={1.08}
          ls="-1.2px"
          ta="center"
          font={t.font.head}
          color="#FFFFFF"
          tablet={{ size: 38 }}
          mobile={{ size: 30 }}
        >
          Run your first payroll free.
        </h2>
        <text size={17} font={t.font.body} color="#B7B7B2" lh={1.7} ta="center" maxw={560}>
          Bring your figures, run one payroll on us, and check every number against what you were
          going to file anyway. If it does not add up, you have lost an afternoon and nothing else.
        </text>
        <Cta dark />
        <text size={13} font={t.font.body} color={t.color.theirs} lh={1.7} ta="center">
          Plainroll · flat-fee payroll for UK businesses · support 8am–6pm, Manchester
        </text>
      </box>
    </section>
  </box>
);
