/** Blunt Instrument — design tokens. */
export default defineTheme({
  name: 'blunt-instrument',
  color: {
    ground: '#000000', // page black
    ink: '#FFFFFF',    // type on black
    yell: '#FFE600',   // the number, the accent
    blood: '#FF2D2D',  // losses, refusals
    grey: '#666666',   // secondary copy
  },
  font: { head: 'Unbounded', body: 'Plus Jakarta Sans' },
  mode: 'literal',
});
