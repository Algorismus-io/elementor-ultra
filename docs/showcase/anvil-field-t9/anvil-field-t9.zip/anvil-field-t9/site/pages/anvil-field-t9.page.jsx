/** Anvil T9 — full specification. Spec-sheet table as hero. */
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Anvil T9 — full specification',
  slug: 'anvil-field-t9',
  seo: {
    title: 'Anvil T9 — full specification | Anvil Field Systems',
    description:
      'A 14-inch ruggedised field laptop with dual hot-swap batteries, a 1400-nit sunlight-readable screen and a five-year parts guarantee. Full spec table, test results and procurement terms.',
  },
};

const GROUND = '#101314';
const PANEL = '#191D1F';
const INK = '#DDE3E4';
const HAZARD = '#FFB000';
const LINE = '#2C3335';
const GREEN = '#5FD08A';
const MUTED = '#8B9698';
const HEAD = 'Saira Condensed';
const BODY = 'IBM Plex Sans';

/* ── repeaters: content props only ───────────────────────────────────── */

const SpecRow = defineComponent(
  ({ label = 'Display', value = '', mark = '' }) => (
    <div
      cls="spec-row"
      tw="flex flex-row items-start w-full gap-8 py-5 border-b border-[#2C3335] max-md:flex-col max-md:gap-2 max-md:py-4"
      hover={{ bg: '#1E2426' }}
    >
      <heading
        tag="h3"
        w={210}
        tw="uppercase max-md:w-full"
        size={18}
        weight={600}
        font={HEAD}
        color={HAZARD}
        ls={0.06}
        lh={1.3}
      >
        {label}
      </heading>
      <text flex={1} size={15} font={BODY} color={INK} lh={1.65}>
        {value}
      </text>
      <text
        w={120}
        tw="uppercase max-md:w-full"
        size={12}
        weight={500}
        font={HEAD}
        color={MUTED}
        ls={0.08}
        ta="right"
        mobile={{ ta: 'left' }}
      >
        {mark}
      </text>
    </div>
  ),
  {
    title: 'Spec row',
    props: {
      label: { label: 'Subsystem', group: 'Spec' },
      value: { label: 'Specification', group: 'Spec' },
      mark: { label: 'Standard', group: 'Spec' },
    },
  },
);

const TestCard = defineComponent(
  ({ code = '', title = '', result = '', detail = '' }) => (
    <div
      cls="test-card"
      tw="flex flex-col gap-3 border-t border-[#FFB000]"
      pad={{ t: 22, r: 22, b: 26, l: 22 }}
      bg={GROUND}
      hover={{ bg: '#14181A' }}
    >
      <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.1} tw="uppercase">
        {code}
      </text>
      <heading tag="h3" size={26} weight={600} font={HEAD} color={INK} lh={1.15}>
        {title}
      </heading>
      <text size={34} weight={700} font={HEAD} color={GREEN} lh={1.1}>
        {result}
      </text>
      <text size={14} font={BODY} color={MUTED} lh={1.6}>
        {detail}
      </text>
    </div>
  ),
  {
    title: 'Test card',
    props: {
      code: { label: 'Standard', group: 'Test' },
      title: { label: 'Test', group: 'Test' },
      result: { label: 'Result', group: 'Test' },
      detail: { label: 'Detail', group: 'Test' },
    },
  },
);

const DataRow = defineComponent(
  ({ label = '', value = '' }) => (
    <div
      cls="data-row"
      tw="flex flex-row items-start gap-6 w-full py-3 border-b border-[#2C3335] max-md:flex-col max-md:gap-1"
    >
      <text w={140} tw="uppercase max-md:w-full" size={12} weight={600} font={HEAD} color={MUTED} ls={0.08}>
        {label}
      </text>
      <text flex={1} size={15} font={BODY} color={INK} lh={1.6}>
        {value}
      </text>
    </div>
  ),
  {
    title: 'Data row',
    props: { label: { label: 'Label', group: 'Row' }, value: { label: 'Value', group: 'Row' } },
  },
);

const DeployCard = defineComponent(
  ({ sector = '', title = '', body = '', stat = '' }) => (
    <div
      cls="deploy-card"
      tw="flex flex-col gap-4 border border-[#2C3335]"
      pad={24}
      bg={PANEL}
      hover={{ border: [1, HAZARD], bg: '#1E2426' }}
    >
      <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.1} tw="uppercase">
        {sector}
      </text>
      <heading tag="h3" size={27} weight={600} font={HEAD} color={INK} lh={1.15}>
        {title}
      </heading>
      <text size={14.5} font={BODY} color={MUTED} lh={1.65}>
        {body}
      </text>
      <text size={13} weight={500} font={HEAD} color={GREEN} ls={0.04} tw="uppercase">
        {stat}
      </text>
    </div>
  ),
  {
    title: 'Deployment card',
    props: {
      sector: { label: 'Sector', group: 'Deployment' },
      title: { label: 'Title', group: 'Deployment' },
      body: { label: 'Body', group: 'Deployment' },
      stat: { label: 'Stat', group: 'Deployment' },
    },
  },
);

const fade = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

export default () => (
  <box tw="flex flex-col w-full" pad={0} bg={GROUND}>
    {/* ── 1 · SPEC TABLE AS THE FIRST SCREEN ───────────────────────── */}
    <section tw="flex flex-col items-center w-full px-6 max-md:px-4" pad={{ t: 0, b: 0 }} bg={GROUND}>
      <div tw="flex flex-col w-full max-w-[1180px]">
        <div
          tw="flex flex-row items-center justify-between w-full gap-4 py-4 border-b border-[#2C3335] max-md:flex-col max-md:items-start max-md:gap-1"
        >
          <text size={13} weight={600} font={HEAD} color={INK} ls={0.16} tw="uppercase">
            Anvil Field Systems
          </text>
          <text size={12} weight={500} font={HEAD} color={MUTED} ls={0.12} tw="uppercase">
            Model T9 · Rev C · Datasheet 2026-08
          </text>
        </div>

        <grid cols={12} gap={40} tw="w-full max-md:gap-6" pad={{ t: 56, b: 40 }} mobile={{ gridCols: 1 }}>
          <div span={7} tw="flex flex-col gap-6 max-lg:col-span-12">
            <h1
              size={78}
              weight={700}
              font={HEAD}
              color={INK}
              lh={1.02}
              ls={-0.01}
              tw="uppercase"
              tablet={{ size: 60 }}
              mobile={{ size: 38 }}
            >
              Anvil T9 — full specification
            </h1>
            <text size={17.5} font={BODY} color={MUTED} lh={1.7} maxw={620} mobile={{ size: 15.5 }}>
              A 14-inch field laptop built to be repaired with a screwdriver at minus 20 degrees.
              Everything you need to compare it is on this page, in a table, before you have to talk
              to anyone.
            </text>
            <div tw="flex flex-row items-center gap-5 max-md:flex-col max-md:items-start max-md:gap-3">
              <text
                href="#demo"
                tw="uppercase"
                size={14}
                weight={700}
                font={HEAD}
                color={GROUND}
                ls={0.08}
                bg={HAZARD}
                pad={{ t: 15, r: 30, b: 15, l: 30 }}
                hover={{ bg: '#FFC845' }}
              >
                Request a demo unit
              </text>
              <text size={14} font={BODY} color={MUTED} lh={1.6}>
                From 3,240 per unit. Stock lead time 12 working days.
              </text>
            </div>
          </div>
          <div span={5} tw="flex flex-col max-lg:col-span-12">
            <img
              src={media.device_field.id}
              tw="w-full border border-[#2C3335]"
              h={330}
              fit="cover"
              tablet={{ h: 300 }}
              mobile={{ h: 210 }}
            />
          </div>
        </grid>

        <div tw="flex flex-row items-end justify-between gap-6 w-full pb-3 border-b border-[#FFB000] max-md:flex-col max-md:items-start max-md:gap-2">
          <h2 size={30} weight={600} font={HEAD} color={INK} ls={0.02} tw="uppercase">
            Specification table
          </h2>
          <text size={12} weight={500} font={HEAD} color={MUTED} ls={0.1} tw="uppercase">
            All figures measured, not modelled
          </text>
        </div>

        <div tw="flex flex-col w-full" pad={{ b: 72 }} mobile={{ pad: { b: 48 } }}>
          <SpecRow
            label="Display"
            value="14in 1400-nit sunlight readable, glove and wet-finger touch, IP68 sealed bezel"
            mark="IP68"
          />
          <SpecRow
            label="Drop"
            value="MIL-STD-810H Method 516.8 Proc IV, 26 drops from 1.5m onto plywood over concrete, powered on"
            mark="810H 516.8"
          />
          <SpecRow
            label="Battery"
            value="Dual hot-swap 74Wh, 11 hours mixed use, swap without shutdown, replaceable in the field in 40 seconds"
            mark="2 × 74Wh"
          />
          <SpecRow
            label="Compute"
            value="Core Ultra 7 165H, 32GB DDR5 (64GB option), two removable NVMe bays up to 4TB each, one with a keyed carrier for classified removal"
            mark="32GB · 8TB"
          />
          <SpecRow
            label="Chassis"
            value="Magnesium alloy frame with replaceable corner bumpers, 2.94kg with both batteries, operating minus 20 to plus 60 degrees"
            mark="2.94 kg"
          />
          <SpecRow
            label="Sealing"
            value="IP68 dust ingress and 1.5m immersion for 30 minutes, salt fog per Method 509.7, sand and dust per Method 510.7"
            mark="IP68"
          />
          <SpecRow
            label="Service"
            value="Eleven screws to the mainboard. Storage, RAM, battery, keyboard and display bezel are all user-replaceable"
            mark="11 screws"
          />
          <SpecRow
            label="Guarantee"
            value="Five years of parts availability from date of purchase, written into the contract, with a 3-year return-to-base repair term"
            mark="5 years"
          />
        </div>
      </div>
    </section>

    {/* ── 2 · TEST RESULTS ─────────────────────────────────────────── */}
    <section
      tw="flex flex-col items-center w-full px-6 border-t border-[#2C3335] max-md:px-4"
      pad={{ t: 80, b: 80 }}
      bg={PANEL}
      mobile={{ pad: { t: 52, b: 52 } }}
    >
      <div tw="flex flex-col w-full max-w-[1180px] gap-10 max-md:gap-7">
        <div tw="flex flex-row items-end justify-between gap-8 w-full max-lg:flex-col max-lg:items-start max-lg:gap-4">
          <div tw="flex flex-col gap-4 max-w-[640px]">
            <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.12} tw="uppercase">
              02 · Test results
            </text>
            <h2
              size={46}
              weight={600}
              font={HEAD}
              color={INK}
              lh={1.05}
              tw="uppercase"
              mobile={{ size: 31 }}
            >
              Drop, dust and thermal — with the standard cited
            </h2>
            <text size={16} font={BODY} color={MUTED} lh={1.7}>
              Every figure below comes from a witnessed test at an accredited lab, with the method
              number printed so you can check it against your own tender wording. Reports are sent
              as PDFs on request, unredacted.
            </text>
          </div>
          <text size={13} font={BODY} color={MUTED} lh={1.7} maxw={260}>
            Lab: TÜV-accredited, ISO/IEC 17025. Report set ANV-T9-2026-04.
          </text>
        </div>

        <grid cols={3} gap={24} tw="w-full" motion={fade} mobile={{ gridCols: 1 }} tablet={{ gridCols: 1 }}>
          <TestCard
            code="MIL-STD-810H 516.8 Proc IV"
            title="Transit drop"
            result="26 / 26 passed"
            detail="Twenty-six drops from 1.5m onto 5cm plywood over concrete, powered on, on every face, edge and corner. No data loss, no bezel separation, hinge torque within spec after test."
          />
          <TestCard
            code="MIL-STD-810H 510.7 · IEC 60529"
            title="Dust and water"
            result="IP68 sustained"
            detail="Eight hours blowing dust at 8.9 m/s, then 30 minutes at 1.5m immersion. Ports sealed by gasketed doors; the unit was operated wet for one hour afterwards with no thermal fault."
          />
          <TestCard
            code="MIL-STD-810H 501.7 / 502.7"
            title="Thermal envelope"
            result="−20 °C to +60 °C"
            detail="Cold start at minus 20 within 45 seconds, sustained load at plus 60 with no throttle below base clock. Battery hot-swap validated across the full range with gloves on."
          />
        </grid>
      </div>
    </section>

    {/* ── 3 · HOT-SWAP AND FIELD SERVICE ───────────────────────────── */}
    <section
      tw="flex flex-col items-center w-full px-6 max-md:px-4"
      pad={{ t: 88, b: 88 }}
      bg={GROUND}
      mobile={{ pad: { t: 52, b: 52 } }}
    >
      <div tw="flex flex-col w-full max-w-[1180px]">
        <grid cols={12} gap={48} tw="w-full max-md:gap-8" mobile={{ gridCols: 1 }}>
          <div span={5} tw="flex flex-col gap-4 max-lg:col-span-12">
            <img
              src={media.hot_swap.id}
              tw="w-full border border-[#2C3335]"
              h={420}
              fit="cover"
              tablet={{ h: 320 }}
              mobile={{ h: 230 }}
            />
            <text size={12} font={BODY} color={MUTED} lh={1.6}>
              Battery B carries the machine while battery A is out. No shutdown, no dock, no tools.
            </text>
          </div>
          <div span={7} tw="flex flex-col gap-6 max-lg:col-span-12" motion={fade}>
            <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.12} tw="uppercase">
              03 · Hot-swap and serviceability
            </text>
            <h2 size={46} weight={600} font={HEAD} color={INK} lh={1.05} tw="uppercase" mobile={{ size: 31 }}>
              Eleven screws to the mainboard
            </h2>
            <text size={16.5} font={BODY} color={INK} lh={1.75} maxw={640}>
              Storage, RAM, battery, keyboard and display bezel are all user-replaceable. Full
              service manual and part numbers are public and free.
            </text>
            <div tw="flex flex-col w-full border-t border-[#2C3335]" pad={{ t: 8 }}>
              <DataRow label="Battery" value="Dual 74Wh hot-swap, replaced in the field in 40 seconds, no shutdown — P/N ANV-BT74" />
              <DataRow label="Storage" value="Two NVMe bays behind one captive screw, keyed carrier for secure removal — P/N ANV-SSD-C2" />
              <DataRow label="Memory" value="Two SODIMM slots, 32GB fitted, 64GB supported — standard DDR5-5600, no proprietary module" />
              <DataRow label="Keyboard" value="Sealed backlit unit, four screws from the top deck, replaced without opening the chassis" />
              <DataRow label="Bezel" value="Display bezel and corner bumpers are consumables, stocked and priced like consumables" />
              <DataRow label="Manual" value="Full service manual, exploded diagrams and the complete part-number list are public and free" />
            </div>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 4 · PORTS, RADIOS, EXPANSION ─────────────────────────────── */}
    <section
      tw="flex flex-col items-center w-full px-6 border-t border-[#2C3335] max-md:px-4"
      pad={{ t: 80, b: 80 }}
      bg={PANEL}
      mobile={{ pad: { t: 52, b: 52 } }}
    >
      <div tw="flex flex-col w-full max-w-[1180px] gap-10 max-md:gap-7">
        <div tw="flex flex-col gap-4 max-w-[720px]">
          <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.12} tw="uppercase">
            04 · Interfaces
          </text>
          <h2 size={46} weight={600} font={HEAD} color={INK} lh={1.05} tw="uppercase" mobile={{ size: 31 }}>
            Ports, radios and the expansion bay
          </h2>
          <text size={16} font={BODY} color={MUTED} lh={1.7}>
            Every port is a real port behind a gasketed door — no dongle is required to reach a
            serial device, and the expansion bay is specified once and configured at order.
          </text>
        </div>

        <grid cols={3} gap={24} tw="w-full" mobile={{ gridCols: 1 }} tablet={{ gridCols: 1 }}>
          <div cls="iface-col" tw="flex flex-col gap-2 border-t border-[#FFB000]" pad={{ t: 20 }}>
            <heading tag="h3" size={24} weight={600} font={HEAD} color={INK} tw="uppercase" pad={{ b: 6 }}>
              Ports
            </heading>
            <DataRow label="USB" value="2 × USB-C 40Gbps with 100W PD in, 2 × USB-A 10Gbps" />
            <DataRow label="Video" value="HDMI 2.1 full size, plus dual 4K over either USB-C" />
            <DataRow label="Legacy" value="True RS-232 DE-9 serial and RJ-45 2.5GbE, both sealed" />
            <DataRow label="Power" value="Locking DC barrel, 12–32V vehicle input tolerant" />
          </div>
          <div cls="iface-col" tw="flex flex-col gap-2 border-t border-[#FFB000]" pad={{ t: 20 }}>
            <heading tag="h3" size={24} weight={600} font={HEAD} color={INK} tw="uppercase" pad={{ b: 6 }}>
              Radios
            </heading>
            <DataRow label="Cellular" value="5G sub-6 with dual physical SIM and eSIM, removable module" />
            <DataRow label="Wireless" value="Wi-Fi 7 tri-band, Bluetooth 5.4, both on an M.2 card you can pull" />
            <DataRow label="GNSS" value="Dedicated multi-band receiver, sub-metre with correction service" />
            <DataRow label="Kill" value="Physical RF kill switch on the left flank, mechanically latched" />
          </div>
          <div cls="iface-col" tw="flex flex-col gap-2 border-t border-[#FFB000]" pad={{ t: 20 }}>
            <heading tag="h3" size={24} weight={600} font={HEAD} color={INK} tw="uppercase" pad={{ b: 6 }}>
              Expansion bay
            </heading>
            <DataRow label="Option A" value="Smart card and contactless reader, FIPS 201 compatible" />
            <DataRow label="Option B" value="Second 2.5GbE plus a fibre SFP cage for substation work" />
            <DataRow label="Option C" value="Thermal imager and barcode head for asset inspection" />
            <DataRow label="Option D" value="Blanking plate — sealed, and the bay stays field-swappable" />
          </div>
        </grid>
      </div>
    </section>

    {/* ── 5 · DEPLOYMENTS ──────────────────────────────────────────── */}
    <section
      tw="flex flex-col items-center w-full px-6 max-md:px-4"
      pad={{ t: 88, b: 88 }}
      bg={GROUND}
      mobile={{ pad: { t: 52, b: 52 } }}
    >
      <div tw="flex flex-col w-full max-w-[1180px] gap-10 max-md:gap-7">
        <div tw="flex flex-row items-end justify-between gap-8 w-full max-lg:flex-col max-lg:items-start max-lg:gap-4">
          <div tw="flex flex-col gap-4 max-w-[600px]">
            <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.12} tw="uppercase">
              05 · In service
            </text>
            <h2 size={46} weight={600} font={HEAD} color={INK} lh={1.05} tw="uppercase" mobile={{ size: 31 }}>
              Three deployments
            </h2>
          </div>
          <text size={13} font={BODY} color={MUTED} lh={1.7} maxw={300}>
            Reference sites available under NDA, including the crews who have had units in the
            field since the T7.
          </text>
        </div>

        <img
          src={media.deployment.id}
          tw="w-full border border-[#2C3335]"
          h={340}
          fit="cover"
          tablet={{ h: 260 }}
          mobile={{ h: 190 }}
        />

        <grid cols={3} gap={24} tw="w-full" motion={fade} mobile={{ gridCols: 1 }} tablet={{ gridCols: 1 }}>
          <DeployCard
            sector="Pipeline"
            title="Pipeline integrity survey"
            body="Inline inspection crews run the T9 off vehicle power at 12–32V, pull data over RS-232 from legacy pigging gear and hot-swap batteries at the valve station instead of driving back to the truck."
            stat="Fleet of 240 · 3 years in service"
          />
          <DeployCard
            sector="Forestry"
            title="Forestry inventory"
            body="Wet gloves, rain, and a screen you can still read at noon under canopy gaps. GNSS to sub-metre with correction, and a bezel the crew replaces themselves when a branch wins."
            stat="Zero return-to-base in 18 months"
          />
          <DeployCard
            sector="Disaster response"
            title="Disaster response"
            body="Deployed cold at minus 20, booted in 45 seconds, run on generator or vehicle power for a week. The RF kill switch is mechanical, which is what the incident commander asked for."
            stat="72-hour deployments, no dock"
          />
        </grid>
      </div>
    </section>

    {/* ── 6 · PROCUREMENT ──────────────────────────────────────────── */}
    <section
      tw="flex flex-col items-center w-full px-6 border-t border-[#2C3335] max-md:px-4"
      pad={{ t: 80, b: 80 }}
      bg={PANEL}
      mobile={{ pad: { t: 52, b: 52 } }}
    >
      <div tw="flex flex-col w-full max-w-[1180px]">
        <grid cols={12} gap={48} tw="w-full max-md:gap-8" mobile={{ gridCols: 1 }}>
          <div span={7} tw="flex flex-col gap-6 max-lg:col-span-12">
            <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.12} tw="uppercase">
              06 · Procurement
            </text>
            <h2 size={46} weight={600} font={HEAD} color={INK} lh={1.05} tw="uppercase" mobile={{ size: 31 }}>
              Lead times, frameworks, volume pricing
            </h2>
            <text size={16.5} font={BODY} color={INK} lh={1.75} maxw={620}>
              Stock lead time 12 working days. Listed on two national framework agreements. Volume
              pricing from 25 units, with a written 5-year price hold.
            </text>
            <div tw="flex flex-col w-full border-t border-[#2C3335]" pad={{ t: 8 }}>
              <DataRow label="Lead time" value="12 working days from stock, 6 weeks for a configured expansion bay" />
              <DataRow label="Frameworks" value="Listed on two national framework agreements; direct award permitted under both" />
              <DataRow label="Volume" value="Tiered pricing from 25 units, again at 100 and 500, quoted in writing" />
              <DataRow label="Price hold" value="5-year price hold written into the contract, not a quotation footnote" />
              <DataRow label="Compliance" value="Country-of-origin declaration, RoHS and REACH statements, TAA position on request" />
              <DataRow label="Trials" value="Demo units shipped free for 30 days, no purchase order needed to start" />
            </div>
          </div>
          <div span={5} tw="flex flex-col gap-5 max-lg:col-span-12">
            <div
              tw="flex flex-col gap-3 border border-[#FFB000]"
              pad={28}
              bg={GROUND}
              shadow={[[10, 0, 0, '#FFB000'], [24, 60, -10, 'rgba(0,0,0,0.55)']]}
            >
              <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.12} tw="uppercase">
                Unit price
              </text>
              <text size={54} weight={700} font={HEAD} color={INK} lh={1.05} mobile={{ size: 40 }}>
                From 3,240
              </text>
              <text size={14.5} font={BODY} color={MUTED} lh={1.65}>
                Per unit. Demo units shipped free for 30 days and yes, you may drop it.
              </text>
              <text
                href="#demo"
                tw="uppercase"
                size={13}
                weight={700}
                font={HEAD}
                color={GROUND}
                ls={0.08}
                ta="center"
                bg={HAZARD}
                pad={{ t: 14, r: 22, b: 14, l: 22 }}
                m={{ t: 8 }}
                hover={{ bg: '#FFC845' }}
              >
                Request a demo unit
              </text>
            </div>
            <div tw="flex flex-col gap-2 border border-[#2C3335]" pad={22} bg={GROUND}>
              <text size={13} weight={600} font={HEAD} color={GREEN} ls={0.08} tw="uppercase">
                In stock now
              </text>
              <text size={14} font={BODY} color={MUTED} lh={1.65}>
                412 units of the base configuration are on the shelf. Configured bays build to order
                on a six-week cycle and ship in tranches if you need the first crews equipped early.
              </text>
            </div>
          </div>
        </grid>
      </div>
    </section>

    {/* ── 7 · FIVE-YEAR COMMITMENT ─────────────────────────────────── */}
    <section
      tw="flex flex-col items-center w-full px-6 max-md:px-4"
      pad={{ t: 80, b: 80 }}
      bg={GROUND}
      mobile={{ pad: { t: 52, b: 52 } }}
    >
      <div
        tw="flex flex-row items-start gap-12 w-full max-w-[1180px] border-l border-[#FFB000] max-lg:flex-col max-lg:gap-6"
        pad={{ t: 40, r: 40, b: 40, l: 40 }}
        bg={PANEL}
        mobile={{ pad: 24 }}
        motion={fade}
      >
        <div tw="flex flex-col gap-1">
          <text size={82} weight={700} font={HEAD} color={HAZARD} lh={1} mobile={{ size: 56 }}>
            5
          </text>
          <text size={13} weight={600} font={HEAD} color={MUTED} ls={0.14} tw="uppercase">
            Years, contractual
          </text>
        </div>
        <div tw="flex flex-col gap-4 flex-1">
          <h2 size={40} weight={600} font={HEAD} color={INK} lh={1.1} tw="uppercase" mobile={{ size: 28 }}>
            Parts and repair commitment
          </h2>
          <text size={16.5} font={BODY} color={INK} lh={1.75} maxw={720}>
            Five years of parts availability from date of purchase, guaranteed in the contract, not
            the marketing.
          </text>
          <text size={15} font={BODY} color={MUTED} lh={1.7} maxw={720}>
            That means stocked batteries, bezels, keyboards and mainboards for five years from the
            day your unit ships — not five years from the day we stop building the model. Repair
            turnaround is 10 working days return-to-base, with a loan pool for fleets over 50 units.
          </text>
        </div>
      </div>
    </section>

    {/* ── 8 · REQUEST A DEMO UNIT (the one centred section) ─────────── */}
    <section
      id="demo"
      tw="flex flex-col items-center w-full px-6 text-center border-t border-[#2C3335] max-md:px-4"
      pad={{ t: 96, b: 96 }}
      bg={PANEL}
      mobile={{ pad: { t: 60, b: 60 } }}
    >
      <div tw="flex flex-col items-center gap-6 w-full max-w-[760px] text-center">
        <text size={12} weight={600} font={HEAD} color={HAZARD} ls={0.14} tw="uppercase">
          08 · Trial
        </text>
        <h2
          size={56}
          weight={700}
          font={HEAD}
          color={INK}
          lh={1.05}
          ta="center"
          tw="uppercase"
          mobile={{ size: 34 }}
        >
          Request a demo unit
        </h2>
        <text size={17} font={BODY} color={MUTED} lh={1.7} ta="center" maxw={620} mobile={{ size: 15.5 }}>
          From 3,240 per unit. Demo units shipped free for 30 days and yes, you may drop it. Tell us
          the crew, the climate and the software you have to run, and a configured unit goes out on
          the next courier.
        </text>
        <text
          href="mailto:demo@anvilfield.example?subject=Anvil%20T9%20demo%20unit"
          tw="uppercase"
          size={15}
          weight={700}
          font={HEAD}
          color={GROUND}
          ls={0.08}
          bg={HAZARD}
          pad={{ t: 17, r: 38, b: 17, l: 38 }}
          hover={{ bg: '#FFC845' }}
        >
          Request a demo unit
        </text>
        <text size={13} font={BODY} color={MUTED} lh={1.7} ta="center">
          Or ask for the full test report set, the service manual and the framework numbers —
          all three are sent without a sales call.
        </text>
      </div>
    </section>
  </box>
);
