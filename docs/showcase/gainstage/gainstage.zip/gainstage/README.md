# Gainstage

Bento done tastefully, waveform accents, clean dark UI.

|  |  |
|---|---|
| **Slug** | `gainstage` (deploys to `/gainstage/`) |
| **Archetype** | bento grid |
| **Industry** | Creator tool for podcasters |
| **Page title** | Gainstage |
| **Fonts** | Outfit, Manrope — Google Fonts, imported by Elementor automatically |
| **Elements** | 586 |
| **Images** | 2 |
| **Global classes used** | 0 — built `--inline` (210 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install gainstage
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
gainstage/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/gainstage.page.jsx             the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#0F1116` |
| `tile` | `#181B22` |
| `ink` | `#EDEEF2` |
| `wave` | `#7C5CFF` |
| `hot` | `#FF6B6B` |
| `ok` | `#48E0A0` |

Change a value, re-run `npx exjsx-kit install gainstage`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/gainstage.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `host_recording` | `media/host_recording.jpg` | Podcast host recording an episode at a microphone |
| `studio_desk` | `media/studio_desk.jpg` | Home studio desk with audio interface and headphones |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
