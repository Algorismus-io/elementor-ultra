/** Gainstage design tokens. */
export default defineTheme({
  name: 'gainstage',
  color: {
    ground: '#0F1116',   // page background
    tile: '#181B22',     // bento tile surface
    tile2: '#12141A',    // alternate band background
    line: '#272B35',     // hairline borders
    ink: '#EDEEF2',      // display + body text
    dim: '#9AA1B0',      // secondary copy
    wave: '#7C5CFF',      // brand accent
    hot: '#FF6B6B',      // things being removed
    ok: '#48E0A0',       // things that survive the edit
  },
  font: { head: 'Outfit', body: 'Manrope' },
  mode: 'literal',
});
