# Quarter Inserted

Cyan-magenta-amber arcade neon, unapologetically loud.

|  |  |
|---|---|
| **Slug** | `quarter-inserted` (deploys to `/quarter-inserted/`) |
| **Archetype** | full-bleed colour blocks with hard seams |
| **Industry** | Arcade bar |
| **Page title** | Quarter Inserted |
| **Fonts** | Monoton, Chivo — Google Fonts, imported by Elementor automatically |
| **Elements** | 280 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (113 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install quarter-inserted
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
quarter-inserted/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/quarter-inserted.page.jsx      the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#12061F` |
| `ink` | `#F5F0FF` |
| `magenta` | `#FF00A8` |
| `cyan` | `#00E5FF` |
| `amber` | `#FFC400` |
| `deep` | `#2A0B45` |

Change a value, re-run `npx exjsx-kit install quarter-inserted`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/quarter-inserted.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `arcade_floor` | `media/arcade_floor.jpg` | Rows of lit arcade cabinets on the Quarter Inserted floor |
| `bar_pour` | `media/bar_pour.jpg` | A pint being poured behind the Quarter Inserted bar |
| `pinball_hands` | `media/pinball_hands.jpg` | Hands on the flipper buttons of a pinball table |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
