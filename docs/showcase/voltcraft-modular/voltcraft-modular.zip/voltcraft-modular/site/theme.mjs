/** Voltcraft VX — analogue Eurorack, Tallinn. */
export default defineTheme({
  name: 'voltcraft',
  color: {
    ground: '#0B0B0D',   // page ground
    panel: '#17171B',    // module panel
    ink: '#E7E4DC',      // panel silkscreen text
    knob: '#D8452F',     // knob red — primary accent
    jack: '#C9A227',     // jack gold — spec accent
    trace: '#2A6B5F',    // pcb trace green
    dim: '#8A867D',      // muted body
  },
  font: { head: 'Orbitron', body: 'Space Mono' },
  mode: 'literal',
});
