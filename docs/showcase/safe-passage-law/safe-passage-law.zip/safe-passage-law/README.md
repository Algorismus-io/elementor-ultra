# Safe Passage

Institutional blue, strong stats — deliberately sober.

|  |  |
|---|---|
| **Slug** | `safe-passage-law` (deploys to `/safe-passage-law/`) |
| **Archetype** | single-column long-form |
| **Industry** | Refugee legal aid nonprofit |
| **Page title** | Safe Passage |
| **Fonts** | Libre Baskerville, Assistant — Google Fonts, imported by Elementor automatically |
| **Elements** | 100 |
| **Images** | 2 |
| **Global classes used** | 0 — built `--inline` (64 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install safe-passage-law
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
safe-passage-law/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/safe-passage-law.page.jsx      the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FFFFFF` |
| `ink` | `#1A1A1A` |
| `deep` | `#153A5B` |
| `amber` | `#D98324` |
| `line` | `#DCDCDC` |

Change a value, re-run `npx exjsx-kit install safe-passage-law`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/safe-passage-law.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `corridor` | `media/corridor.jpg` | A quiet tribunal corridor with rows of empty chairs |
| `hands_documents` | `media/hands_documents.jpg` | Hands resting on a stack of asylum case documents |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
