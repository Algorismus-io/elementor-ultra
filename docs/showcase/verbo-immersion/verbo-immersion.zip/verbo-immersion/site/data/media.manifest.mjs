/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "verbo-immersion--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'verbo-immersion--';

export default [
  { slot: `${PREFIX}class_small`, file: join(MEDIA_DIR, "class_small.jpg"), alt: "Four students and a teacher around a small table mid-conversation" },
  { slot: `${PREFIX}street_life`, file: join(MEDIA_DIR, "street_life.jpg"), alt: "A busy street where the language is spoken every day" },
];
