export default { name: 'moss-hollow' };
