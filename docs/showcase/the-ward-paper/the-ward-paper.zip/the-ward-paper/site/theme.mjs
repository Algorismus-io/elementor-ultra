/** The Ward — reader-owned local newspaper. Newsprint tokens. */
export default defineTheme({
  name: 'the-ward',
  color: {
    ground: '#FFFDFA', // newsprint page
    ink: '#141414',    // body + display text
    press: '#8C2B2B',  // masthead red, the accountability voice
    civic: '#2A4E7A',  // council blue, the co-op voice
    rule: '#DEDAD3',   // hairlines between stories
    grey: '#6B6B67',   // standfirsts, bylines, captions
    white: '#FFFFFF',
  },
  font: { head: 'Playfair Display', body: 'Source Serif 4' },
  mode: 'literal',
});
