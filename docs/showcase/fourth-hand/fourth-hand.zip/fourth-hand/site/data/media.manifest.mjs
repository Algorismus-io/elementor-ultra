/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "fourth-hand--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'fourth-hand--';

export default [
  { slot: `${PREFIX}bench`, file: join(MEDIA_DIR, "bench.jpg"), alt: "Watchmaker’s bench with tools and a movement under inspection" },
  { slot: `${PREFIX}movement`, file: join(MEDIA_DIR, "movement.jpg"), alt: "Open mechanical watch movement photographed during inspection" },
  { slot: `${PREFIX}watch_macro`, file: join(MEDIA_DIR, "watch_macro.jpg"), alt: "Macro photograph of a vintage watch dial and case" },
];
