export default { name: 'site' };
