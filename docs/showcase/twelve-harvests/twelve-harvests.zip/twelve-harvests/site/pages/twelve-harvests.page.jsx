/**
 * Twelve Harvests — the coffee year as a timeline spine.
 * Structure: every section hangs off a vertical rule that runs from the calendar to the CTA.
 */
import t from '../theme.mjs';
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Twelve Harvests',
  slug: 'twelve-harvests',
  seo: {
    title: 'Twelve Harvests — one single-origin coffee a month, at harvest',
    description:
      'A specialty coffee subscription that follows the harvest calendar around the world. One single-origin a month, roasted the day after we ship, with the farmgate price printed on the bag.',
  },
};

const C = t.color;
const F = t.font;

/* ── shared measures ── */
const WRAP = 'w-full max-w-[1160px] px-8 max-lg:px-7 max-md:px-5';
const RAIL = 64;   // desktop spine gutter
const RAIL_M = 34; // mobile spine gutter

/* ═══ registered components (content props only) ═══ */

/** One month on the spine: dot, continuing rule, and the origin that is ripe. */
const MonthRow = defineComponent(
  ({ month = 'January', origin = 'Guatemala · Huehuetenango', note = 'Washed Caturra.' }) => (
    <row tw="w-full items-stretch gap-7 max-md:gap-4">
      <col tw="items-center gap-0" w={RAIL} mobile={{ w: RAIL_M }} pad={0}>
        <div tw="w-[10px] h-[10px] rounded-full" bg={C.rule} m={{ t: 10 }} />
        <div tw="w-[2px] flex-1" bg={C.rule} />
      </col>
      <grid cols="200px 1fr" gap={16} tw="w-full pb-9 max-md:pb-7" mobile={{ gridCols: 1, gap: 4 }}>
        <heading tag="h3" size={26} font={F.head} color={C.ink} lh={1.15} mobile={{ size: 21 }}>
          {month}
        </heading>
        <col tw="gap-1">
          <text size={16} weight={600} font={F.body} color={C.ink} ls={0.01}>
            {origin}
          </text>
          <text size={15} font={F.body} color="#7A6353" lh={1.6} maxw={520}>
            {note}
          </text>
        </col>
      </grid>
    </row>
  ),
  {
    title: 'TH Month Row',
    props: {
      month: { label: 'Month', group: 'Calendar' },
      origin: { label: 'Origin', group: 'Calendar' },
      note: { label: 'Note', group: 'Calendar' },
    },
  },
);

/** The month currently in the box — same row, cherry marker, shipping flag. */
const MonthRowNow = defineComponent(
  ({ month = 'August', origin = 'Rwanda · Nyamasheke', note = 'Gitwe washed Red Bourbon.', flag = 'in the box' }) => (
    <row tw="w-full items-stretch gap-7 max-md:gap-4">
      <col tw="items-center gap-0" w={RAIL} mobile={{ w: RAIL_M }} pad={0}>
        <div tw="w-[18px] h-[18px] rounded-full" bg={C.cherry} m={{ t: 6 }} shadow={[[0, 0, 5, '#EFE1CE']]} />
        <div tw="w-[2px] flex-1" bg={C.cherry} />
      </col>
      <grid cols="200px 1fr" gap={16} tw="w-full pb-9 max-md:pb-7" mobile={{ gridCols: 1, gap: 4 }}>
        <col tw="gap-2 items-start">
          <heading tag="h3" size={26} font={F.head} color={C.cherry} lh={1.15} mobile={{ size: 21 }}>
            {month}
          </heading>
          <text
            size={11}
            weight={600}
            font={F.body}
            color={C.ground}
            bg={C.cherry}
            pad={[4, 10]}
            radius={2}
            ls={0.12}
          >
            {flag}
          </text>
        </col>
        <col tw="gap-1">
          <text size={16} weight={600} font={F.body} color={C.ink} ls={0.01}>
            {origin}
          </text>
          <text size={15} font={F.body} color="#7A6353" lh={1.6} maxw={520}>
            {note}
          </text>
        </col>
      </grid>
    </row>
  ),
  {
    title: 'TH Month Row Current',
    props: {
      month: { label: 'Month', group: 'Calendar' },
      origin: { label: 'Origin', group: 'Calendar' },
      note: { label: 'Note', group: 'Calendar' },
      flag: { label: 'Flag', group: 'Calendar' },
    },
  },
);

/** A brew guide card. */
const BrewCard = defineComponent(
  ({ method = 'V60', dose = '18g in, 300g out', grind = 'Medium-fine', time = '3:30', note = 'Four pours.' }) => (
    <col
      cls="brew-card"
      tw="gap-4 p-7 max-md:p-6"
      bg={C.ground}
      border={[1, C.rule]}
      radius={3}
      hover={{ border: [1, C.cherry], shadow: [[10, 26, -18, 'rgba(43,29,20,0.35)']] }}
    >
      <heading tag="h3" size={30} font={F.head} color={C.ink} lh={1.1}>
        {method}
      </heading>
      <div tw="w-[38px] h-[2px]" bg={C.cherry} />
      <text size={16} weight={600} font={F.body} color={C.ink}>
        {dose}
      </text>
      <col tw="gap-1">
        <text size={14} font={F.body} color="#7A6353" lh={1.6}>
          {grind}
        </text>
        <text size={14} font={F.body} color="#7A6353" lh={1.6}>
          {time}
        </text>
      </col>
      <text size={15} font={F.body} color={C.leaf} lh={1.6}>
        {note}
      </text>
    </col>
  ),
  {
    title: 'TH Brew Card',
    props: {
      method: { label: 'Method', group: 'Recipe' },
      dose: { label: 'Dose', group: 'Recipe' },
      grind: { label: 'Grind', group: 'Recipe' },
      time: { label: 'Total time', group: 'Recipe' },
      note: { label: 'Note', group: 'Recipe' },
    },
  },
);

/** One origin in the last-24 ledger. */
const OriginTile = defineComponent(
  ({ country = 'Ethiopia', count = '5 bags', note = 'Guji and Yirgacheffe.' }) => (
    <col cls="origin-tile" tw="gap-2 py-6 pr-5 max-md:py-5" raw="border-top-width: 1px; border-top-style: solid; border-color: rgba(217,201,180,0.35);">
      <text size={13} weight={600} font={F.body} color="#C8A96B" ls={0.1}>
        {count}
      </text>
      <heading tag="h3" size={24} font={F.head} color={C.ground} lh={1.15}>
        {country}
      </heading>
      <text size={14} font={F.body} color="rgba(239,225,206,0.66)" lh={1.6}>
        {note}
      </text>
    </col>
  ),
  {
    title: 'TH Origin Tile',
    props: {
      country: { label: 'Country', group: 'Ledger' },
      count: { label: 'Count', group: 'Ledger' },
      note: { label: 'Note', group: 'Ledger' },
    },
  },
);

/* ═══ data ═══ */

const MONTHS = [
  ['January', 'Guatemala · Huehuetenango', 'Washed Caturra from the first pass of the Central American picking. Cocoa, dried fig, a long dry finish.'],
  ['February', 'Costa Rica · Tarrazú', 'White honey Catuaí, dried twelve days on the patio. Red apple and cane sugar.'],
  ['March', 'Nicaragua · Dipilto', 'Washed Javanica, the last of the northern crop before the rains. Almond and lime blossom.'],
  ['April', 'El Salvador · Santa Ana', 'Natural Pacamara, slow-dried in shade. Strawberry, rum-soaked raisin, thick body.'],
  ['May', 'Indonesia · Aceh Gayo', 'Wet-hulled Ateng, picked while everything else in the world is resting. Cedar, tamarind, green herb.'],
  ['June', 'Indonesia · Toraja', 'Wet-hulled Typica from the highlands. Baker’s chocolate, tobacco leaf, a savoury edge.'],
  ['July', 'Ethiopia · Guji', 'Washed heirloom off the first Ethiopian containers of the year. Jasmine, bergamot, white peach.'],
];

const MONTHS_AFTER = [
  ['September', 'Ethiopia · Yirgacheffe', 'Natural heirloom, forty days on raised beds. Blueberry, apricot, a syrupy finish.'],
  ['October', 'Colombia · Huila', 'Washed Pink Bourbon from the main autumn crop. Mandarin, honeysuckle, brown sugar.'],
  ['November', 'Colombia · Nariño', 'Washed Caturra grown at 2,050 metres. Lime leaf, caramel, bright and clean.'],
  ['December', 'Brazil · Cerrado Mineiro', 'Pulped natural Yellow Catuaí, straight after the Brazilian harvest. Hazelnut, milk chocolate, low acidity.'],
];

const PRICES = [
  ['What we paid', '5.40', 100, C.cherry, 'Per kilo, at the farmgate, to the Gitwe washing station.'],
  ['Fairtrade floor', '1.80', 33, C.rule, 'The minimum price a certified buyer may pay.'],
  ['New York C', '1.62', 30, C.rule, 'The commodity benchmark the week we bought.'],
];

const FRESH = [
  ['Tuesday', 'Roasted', 'One profile, one drum, the whole month’s allocation in a morning.'],
  ['Wednesday', 'Shipped', 'Bagged with a valve and out the door before the beans are cool.'],
  ['Thursday', 'On your table', 'Friday at the latest. The date on the bag is the roast date, not a best-before.'],
  ['+4 days', 'Rest it', 'Leave it alone. Degassing coffee brews thin and tastes of nothing much.'],
  ['+1 month', 'Drink it', 'Past that it is still fine, just quieter. Nothing here sits in a warehouse.'],
];

const BREWS = [
  ['V60', '18g in, 300g out', 'Medium-fine, a little finer than table salt', '3:30 total, four pours', 'Bloom 50g for 40 seconds, then pour to 300 in even stages.'],
  ['Kalita Wave', '20g in, 320g out', 'Medium, the flat bed is forgiving', '3:15 total, five pours', 'Keep the bed flat and the water level low. It wants patience, not technique.'],
  ['Chemex', '30g in, 500g out', 'Medium-coarse, the thick filter is slow', '4:30 total, three pours', 'Rinse the filter properly. Anything less and you will taste the paper.'],
];

const ORIGINS = [
  ['Ethiopia', '5 bags', 'Guji, Yirgacheffe, and one lot from Uraga.'],
  ['Colombia', '4 bags', 'Huila and Nariño, two autumns running.'],
  ['Rwanda', '3 bags', 'Nyamasheke and Rulindo, all washed.'],
  ['Brazil', '3 bags', 'Cerrado Mineiro, pulped natural, every December.'],
  ['Indonesia', '3 bags', 'Aceh Gayo and Toraja, wet-hulled.'],
  ['Guatemala', '2 bags', 'Huehuetenango, both washed Caturra.'],
  ['Costa Rica', '2 bags', 'Tarrazú honeys from the same mill.'],
  ['El Salvador', '2 bags', 'Santa Ana naturals, one Pacamara, one Bourbon.'],
];

/* ═══ small local pieces (styles vary → plain functions, inline-expanded) ═══ */

const Eyebrow = ({ children, color = C.cherry }) => (
  <text size={12} weight={600} font={F.body} color={color} ls={0.16} raw="text-transform: uppercase;">
    {children}
  </text>
);

const PriceBar = ([label, value, pct, tint, note]) => (
  <col cls="price-column" tw="gap-4">
    <text size={13} weight={600} font={F.body} color="#7A6353" ls={0.08}>
      {label}
    </text>
    <row tw="items-end gap-2">
      <heading tag="h3" size={64} font={F.head} color={tint === C.cherry ? C.cherry : C.ink} lh={1} mobile={{ size: 46 }}>
        {value}
      </heading>
      <text size={14} font={F.body} color="#7A6353" m={{ b: 12 }}>
        / kilo
      </text>
    </row>
    <div tw="w-full h-[10px]" bg="rgba(217,201,180,0.4)" radius={1}>
      <div tw="h-[10px]" w={`${pct}%`} bg={tint} radius={1} />
    </div>
    <text size={14} font={F.body} color="#7A6353" lh={1.65}>
      {note}
    </text>
  </col>
);

const FreshStep = ([when, what, note], i) => (
  <col cls="fresh-step" tw="gap-3">
    <div tw="w-full h-[2px]" bg={i === 0 ? C.cherry : C.rule} />
    <div tw="w-[9px] h-[9px] rounded-full" bg={i === 0 ? C.cherry : C.rule} />
    <text size={13} weight={600} font={F.body} color={i === 0 ? C.cherry : '#7A6353'} ls={0.08}>
      {when}
    </text>
    <heading tag="h3" size={22} font={F.head} color={C.ink} lh={1.15}>
      {what}
    </heading>
    <text size={14} font={F.body} color="#7A6353" lh={1.6}>
      {note}
    </text>
  </col>
);

const Plan = ({ weight, price, blurb, lead }) => (
  <col
    cls="plan-block"
    tw="gap-4 p-8 max-md:p-6"
    bg={C.ground}
    border={[1, lead ? C.ink : C.rule]}
    radius={3}
    hover={{ bg: '#FFFDF9', shadow: [[12, 30, -20, 'rgba(43,29,20,0.4)']] }}
  >
    <Eyebrow color={lead ? C.cherry : '#7A6353'}>{lead ? 'most people start here' : 'for two, or for one who drinks a lot'}</Eyebrow>
    <row tw="items-end gap-3">
      <heading tag="h3" size={44} font={F.head} color={C.ink} lh={1} mobile={{ size: 36 }}>
        {weight}
      </heading>
      <text size={26} font={F.head} color={C.cherry}>
        {price}
      </text>
      <text size={14} font={F.body} color="#7A6353">
        a month
      </text>
    </row>
    <text size={15} font={F.body} color="#7A6353" lh={1.7}>
      {blurb}
    </text>
    <text
      href="#start"
      size={14}
      weight={600}
      font={F.body}
      color={C.ground}
      bg={C.ink}
      pad={[13, 22]}
      radius={2}
      w="hug"
      tw="hover:bg-[#9E2B2B] hover:text-[#FCF8F2] cursor-pointer"
    >
      Start next month
    </text>
  </col>
);

/* ═══ the page ═══ */

export default () => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={C.ground}>

    {/* ── masthead ── */}
    <div tw={`flex flex-col items-center w-full`} bg={C.ground}>
      <div tw={WRAP}>
        <row
          tw="w-full items-center justify-between py-6"
          raw="border-bottom-width: 1px; border-bottom-style: solid; border-color: #D9C9B4;"
        >
          <text size={19} font={F.head} color={C.ink} ls={0.01}>
            Twelve Harvests
          </text>
          <text size={13} font={F.body} color="#7A6353" tw="max-md:hidden">
            One single-origin a month · farmgate price on every bag
          </text>
        </row>
      </div>
    </div>

    {/* ── 0. hero: asymmetric, the spine starts here ── */}
    <div tw="flex flex-col items-center w-full" bg={C.ground}>
      <div tw={WRAP}>
        <grid cols="1.1fr 0.9fr" gap={64} tw="w-full pt-24 pb-20 max-lg:pt-16 max-md:pt-12 max-md:pb-14" gapY={40} mobile={{ gridCols: 1 }}>
          <col tw="gap-7 justify-center">
            <Eyebrow>Harvest calendar, not a release calendar</Eyebrow>
            <h1 size={68} weight={400} font={F.head} color={C.ink} lh={1.04} maxw={640} tablet={{ size: 52 }} mobile={{ size: 34 }}>
              Coffee arrives when it is ripe, not when it is convenient.
            </h1>
            <text size={18} font={F.body} color="#5C463A" lh={1.75} maxw={560} mobile={{ size: 16 }}>
              One single-origin coffee a month, chosen because it just came off the drying beds somewhere in the world.
              Roasted the day after we ship, with the price we paid the farmer printed on the bag.
            </text>
            <row tw="items-center gap-5 max-md:gap-4" wrap="wrap">
              <text
                href="#start"
                size={15}
                weight={600}
                font={F.body}
                color={C.ground}
                bg={C.cherry}
                pad={[16, 30]}
                radius={2}
                tw="hover:bg-[#2B1D14] cursor-pointer"
              >
                Start next month
              </text>
              <text
                href="#calendar"
                size={15}
                weight={600}
                font={F.body}
                color={C.ink}
                tw="underline underline-offset-4 hover:text-[#9E2B2B] cursor-pointer"
              >
                See the coffee year
              </text>
            </row>
            <row tw="items-center gap-3 pt-2 flex-nowrap">
              <div tw="w-[10px] h-[10px] rounded-full shrink-0" bg={C.cherry} />
              <text size={14} font={F.body} color="#7A6353" tw="flex-1" lh={1.6}>
                In the box now: August, Gitwe washed Red Bourbon, Rwanda. Ships 22 August.
              </text>
            </row>
          </col>
          <col tw="gap-3">
            <img src={media.cherries.id} tw="w-full object-cover" h={520} radius={3} tablet={{ h: 420 }} mobile={{ h: 300 }} />
            <text size={12} font={F.body} color="#8B7565" lh={1.6}>
              Nyamasheke, Rwanda — the last selective pass, late June.
            </text>
          </col>
        </grid>
      </div>
    </div>

    {/* ── 1. the calendar spine ── */}
    <div tw="flex flex-col items-center w-full" bg={C.cream} id="calendar">
      <div tw={WRAP}>
        <grid cols="1fr 1fr" gap={56} tw="w-full pt-24 pb-10 max-md:pt-16" mobile={{ gridCols: 1, gap: 20 }}>
          <col tw="gap-4">
            <Eyebrow>Section one</Eyebrow>
            <h2 size={46} weight={400} font={F.head} color={C.ink} lh={1.1} maxw={480} mobile={{ size: 32 }}
              motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              The coffee year, January to December.
            </h2>
          </col>
          <col tw="gap-4 justify-end pb-2">
            <text size={17} font={F.body} color="#5C463A" lh={1.75} maxw={520} mobile={{ size: 15 }}>
              Ethiopia and Rwanda in summer, Colombia in the autumn, Brazil after that, and Indonesia in the strange
              middle of the year when nothing else is fresh.
            </text>
            <text size={14} font={F.body} color="#8B7565" lh={1.7} maxw={520}>
              The spine below is the year. We do not repeat an origin twice in twelve months, and we do not buy
              anything that has been sitting.
            </text>
          </col>
        </grid>

        <col tw="w-full gap-0 pt-8 pb-24 max-md:pb-16">
          {MONTHS.map(([month, origin, note]) => (
            <MonthRow month={month} origin={origin} note={note} />
          ))}
          <MonthRowNow
            month="August"
            origin="Rwanda · Nyamasheke"
            note="Gitwe washed Red Bourbon. Blackcurrant, black tea, and a finish like a stewed plum."
            flag="in the box"
          />
          {MONTHS_AFTER.map(([month, origin, note]) => (
            <MonthRow month={month} origin={origin} note={note} />
          ))}
          <row tw="w-full items-start gap-7 max-md:gap-4">
            <col tw="items-center" w={RAIL} mobile={{ w: RAIL_M }} pad={0}>
              <div tw="w-[10px] h-[10px] rounded-full" bg={C.rule} />
            </col>
            <text size={14} font={F.body} color="#8B7565" lh={1.7} maxw={520}>
              Then it starts again in Guatemala, with a crop nobody has tasted yet.
            </text>
          </row>
        </col>
      </div>
    </div>

    {/* ── 2. this month's coffee ── */}
    <div tw="flex flex-col items-center w-full" bg={C.ink}>
      <div tw={WRAP}>
        <grid cols="0.85fr 1.15fr" gap={64} tw="w-full py-24 max-lg:py-20 max-md:py-14" gapY={36} mobile={{ gridCols: 1 }}>
          <col tw="gap-3">
            <img src={media.drying_beds.id} tw="w-full object-cover" h={480} radius={3} tablet={{ h: 380 }} mobile={{ h: 280 }} />
            <text size={12} font={F.body} color="rgba(239,225,206,0.55)" lh={1.6}>
              Raised beds at Gitwe. Eighteen days, turned by hand every hour of daylight.
            </text>
          </col>
          <col tw="gap-6 justify-center">
            <Eyebrow color="#C8A96B">Section two · in the box now</Eyebrow>
            <h2 size={44} weight={400} font={F.head} color={C.ground} lh={1.12} maxw={560} mobile={{ size: 30 }}
              motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              August: Gitwe washed Red Bourbon, Nyamasheke, Rwanda.
            </h2>
            <row tw="gap-3" wrap="wrap">
              <text size={13} weight={600} font={F.body} color={C.ground} pad={[8, 14]} radius={2} raw="border-width: 1px; border-style: solid; border-color: rgba(239,225,206,0.35);">
                Blackcurrant
              </text>
              <text size={13} weight={600} font={F.body} color={C.ground} pad={[8, 14]} radius={2} raw="border-width: 1px; border-style: solid; border-color: rgba(239,225,206,0.35);">
                Black tea
              </text>
              <text size={13} weight={600} font={F.body} color={C.ground} pad={[8, 14]} radius={2} raw="border-width: 1px; border-style: solid; border-color: rgba(239,225,206,0.35);">
                Stewed plum
              </text>
            </row>
            <text size={17} font={F.body} color="rgba(239,225,206,0.82)" lh={1.8} maxw={560} mobile={{ size: 15 }}>
              Blackcurrant, black tea, and a finish like a stewed plum. Ships 22 August, which is nineteen days after the
              last cherry came off the bed.
            </text>
            <grid cols={2} gap={24} tw="w-full pt-4" gapY={20}>
              <col tw="gap-1">
                <text size={12} weight={600} font={F.body} color="#C8A96B" ls={0.1}>Producer</text>
                <text size={15} font={F.body} color={C.ground} lh={1.6}>Gitwe washing station, 219 smallholders</text>
              </col>
              <col tw="gap-1">
                <text size={12} weight={600} font={F.body} color="#C8A96B" ls={0.1}>Altitude</text>
                <text size={15} font={F.body} color={C.ground} lh={1.6}>1,780 – 1,940 m</text>
              </col>
              <col tw="gap-1">
                <text size={12} weight={600} font={F.body} color="#C8A96B" ls={0.1}>Process</text>
                <text size={15} font={F.body} color={C.ground} lh={1.6}>Fully washed, 18 days on raised beds</text>
              </col>
              <col tw="gap-1">
                <text size={12} weight={600} font={F.body} color="#C8A96B" ls={0.1}>Ships</text>
                <text size={15} font={F.body} color={C.ground} lh={1.6}>22 August, roasted the day before</text>
              </col>
            </grid>
          </col>
        </grid>
      </div>
    </div>

    {/* ── 3. what we pay, side by side ── */}
    <div tw="flex flex-col items-center w-full" bg={C.ground}>
      <div tw={WRAP}>
        <col tw="w-full gap-4 pt-24 max-md:pt-16">
          <Eyebrow>Section three</Eyebrow>
          <h2 size={46} weight={400} font={F.head} color={C.ink} lh={1.1} maxw={620} mobile={{ size: 32 }}
            motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            What we pay, and what everyone pays.
          </h2>
          <text size={17} font={F.body} color="#5C463A" lh={1.75} maxw={620} mobile={{ size: 15 }}>
            We paid 5.40 a kilo at the farmgate. The Fairtrade floor is 1.80. The New York C price that week was 1.62.
          </text>
        </col>
        <grid cols={3} gap={44} tw="w-full pt-14 pb-8" gapY={40}>
          {PRICES.map((p) => PriceBar(p))}
        </grid>
        <col
          tw="w-full gap-3 p-8 mb-24 max-md:p-6 max-md:mb-16"
          bg={C.cream}
          radius={3}
          raw="border-left-width: 3px; border-left-style: solid; border-color: #4C6B3C;"
        >
          <text size={15} font={F.body} color={C.ink} lh={1.8} maxw={760}>
            The number is printed on the bag next to the roast date. It is the price paid to the washing station for
            parchment, converted to green, before shipping and duty. Nobody makes you do this, which is exactly why we
            print it.
          </text>
          <text size={14} weight={600} font={F.body} color={C.leaf} lh={1.6}>
            Three times the commodity price, on a lot that would clear at half of it.
          </text>
        </col>
      </div>
    </div>

    {/* ── 4. roast profile and freshness ── */}
    <div tw="flex flex-col items-center w-full" bg={C.cream}>
      <div tw={WRAP}>
        <grid cols="1fr 0.75fr" gap={56} tw="w-full pt-24 pb-12 max-md:pt-16" gapY={32} mobile={{ gridCols: 1 }}>
          <col tw="gap-4 justify-center">
            <Eyebrow>Section four</Eyebrow>
            <h2 size={44} weight={400} font={F.head} color={C.ink} lh={1.1} maxw={560} mobile={{ size: 30 }}
              motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              One roast profile, and a five-day head start.
            </h2>
            <text size={17} font={F.body} color="#5C463A" lh={1.8} maxw={560} mobile={{ size: 15 }}>
              Roasted Tuesday, shipped Wednesday, on your table Thursday or Friday. Rest it four days before you touch
              it, then it is good for a month.
            </text>
            <text size={15} font={F.body} color="#7A6353" lh={1.8} maxw={560}>
              Filter roast only, dropped light enough to keep the acidity and long enough that nothing tastes green.
              We do not run a second, darker version for people with espresso machines.
            </text>
          </col>
          <col tw="gap-3 justify-center">
            <img src={media.brew_still.id} tw="w-full object-cover" h={340} radius={3} mobile={{ h: 240 }} />
            <text size={12} font={F.body} color="#8B7565" lh={1.6}>
              Day five. 18g in, 300g out, four pours.
            </text>
          </col>
        </grid>
        <grid cols={5} gap={28} tw="w-full pb-24 max-md:pb-16" gapY={28} tablet={{ gridCols: 2 }}>
          {FRESH.map((f, i) => FreshStep(f, i))}
        </grid>
      </div>
    </div>

    {/* ── 5. brew guides ── */}
    <div tw="flex flex-col items-center w-full" bg={C.ground}>
      <div tw={WRAP}>
        <grid cols="1fr 1fr" gap={56} tw="w-full pt-24 pb-12 max-md:pt-16" mobile={{ gridCols: 1, gap: 20 }}>
          <col tw="gap-4">
            <Eyebrow>Section five</Eyebrow>
            <h2 size={44} weight={400} font={F.head} color={C.ink} lh={1.1} maxw={480} mobile={{ size: 30 }}
              motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              Three ways in, one starting recipe.
            </h2>
          </col>
          <col tw="gap-3 justify-end pb-1">
            <text size={17} font={F.body} color="#5C463A" lh={1.8} maxw={520} mobile={{ size: 15 }}>
              Filter recipe to start: 18g in, 300g out, 94 degrees, four pours, three and a half minutes total. Adjust
              the grind, not the ratio.
            </text>
            <text size={14} font={F.body} color="#8B7565" lh={1.7} maxw={520}>
              Every bag ships with the month&rsquo;s numbers on the back, because a Rwandan washed lot and a wet-hulled
              Sumatra do not want the same grind.
            </text>
          </col>
        </grid>
        <grid cols={3} gap={28} tw="w-full pb-24 max-md:pb-16" gapY={24} tablet={{ gridCols: 1 }}>
          {BREWS.map(([method, dose, grind, time, note]) => (
            <BrewCard method={method} dose={dose} grind={grind} time={time} note={note} />
          ))}
        </grid>
      </div>
    </div>

    {/* ── 6. subscription and pausing ── */}
    <div tw="flex flex-col items-center w-full" bg={C.cream}>
      <div tw={WRAP}>
        <col tw="w-full gap-4 pt-24 max-md:pt-16">
          <Eyebrow>Section six</Eyebrow>
          <h2 size={46} weight={400} font={F.head} color={C.ink} lh={1.1} maxw={620} mobile={{ size: 32 }}
            motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            Two sizes, and a pause button that actually pauses.
          </h2>
        </col>
        <grid cols="1fr 1fr 0.8fr" gap={28} tw="w-full pt-12 pb-24 max-md:pb-16" gapY={24} tablet={{ gridCols: 1 }}>
          <Plan
            weight="250g"
            price="21"
            lead
            blurb="One bag a month. About fifteen brews for a single filter drinker, which is most people who own a grinder."
          />
          <Plan
            weight="500g"
            price="36"
            blurb="Same coffee, twice the bag, one delivery. Cheaper per cup and it still arrives four days off the roaster."
          />
          <col tw="gap-4 justify-center py-2">
            <text size={16} weight={600} font={F.body} color={C.ink} lh={1.6}>
              Pausing
            </text>
            <text size={15} font={F.body} color="#5C463A" lh={1.8}>
              250g a month for 21. 500g for 36. Pause any time from the email, no login, no retention offer, no dark
              pattern.
            </text>
            <text size={14} font={F.body} color="#7A6353" lh={1.7}>
              There is a pause link at the bottom of every dispatch note. One click holds the next shipment, two holds
              it until you say otherwise.
            </text>
          </col>
        </grid>
      </div>
    </div>

    {/* ── 7. where the last 24 came from ── */}
    <div tw="flex flex-col items-center w-full" bg={C.ink}>
      <div tw={WRAP}>
        <grid cols="1fr 1fr" gap={56} tw="w-full pt-24 pb-10 max-md:pt-16" mobile={{ gridCols: 1, gap: 20 }}>
          <col tw="gap-4">
            <Eyebrow color="#C8A96B">Section seven</Eyebrow>
            <h2 size={44} weight={400} font={F.head} color={C.ground} lh={1.1} maxw={480} mobile={{ size: 30 }}
              motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              Where the last twenty-four coffees came from.
            </h2>
          </col>
          <col tw="gap-3 justify-end pb-1">
            <text size={16} font={F.body} color="rgba(239,225,206,0.78)" lh={1.8} maxw={520}>
              Two years of boxes, eight countries, twenty-four lots. No origin has appeared twice in the same twelve
              months, and every farmgate price is still on the archive page.
            </text>
          </col>
        </grid>
        <grid cols={4} gap={28} tw="w-full pb-24 max-md:pb-16" gapY={0} tablet={{ gridCols: 2 }}>
          {ORIGINS.map(([country, count, note]) => (
            <OriginTile country={country} count={count} note={note} />
          ))}
        </grid>
      </div>
    </div>

    {/* ── 8. start (the one centred section) ── */}
    <div tw="flex flex-col items-center w-full" bg={C.cherry} id="start">
      <div tw={WRAP}>
        <col tw="w-full items-center text-center gap-6 py-28 max-md:py-16">
          <div tw="w-[2px] h-[46px]" bg="rgba(252,248,242,0.55)" />
          <Eyebrow color="rgba(252,248,242,0.8)">Section eight</Eyebrow>
          <h2 size={52} weight={400} font={F.head} color={C.ground} lh={1.08} maxw={720} ta="center" mobile={{ size: 32 }}>
            Start with next month&rsquo;s harvest.
          </h2>
          <text size={18} font={F.body} color="rgba(252,248,242,0.85)" lh={1.75} maxw={560} ta="center" mobile={{ size: 16 }}>
            Order before the 18th and the September lot is yours: Ethiopian natural heirloom, forty days on raised beds,
            roasted the day after we ship.
          </text>
          <text
            href="#calendar"
            size={15}
            weight={600}
            font={F.body}
            color={C.cherry}
            bg={C.ground}
            pad={[17, 34]}
            radius={2}
            tw="hover:bg-[#2B1D14] hover:text-[#FCF8F2] cursor-pointer"
          >
            Start next month
          </text>
          <text size={13} font={F.body} color="rgba(252,248,242,0.7)" ta="center">
            21 a month for 250g · pause from any email · farmgate price on every bag
          </text>
        </col>
      </div>
    </div>

    {/* ── footer strip ── */}
    <div tw="flex flex-col items-center w-full" bg={C.ink}>
      <div tw={WRAP}>
        <row tw="w-full items-center justify-between py-8 gap-6" wrap="wrap">
          <text size={16} font={F.head} color={C.ground}>
            Twelve Harvests
          </text>
          <text size={13} font={F.body} color="rgba(239,225,206,0.6)" lh={1.6}>
            Roasted in small batches · shipped Wednesdays · farmgate prices published monthly
          </text>
        </row>
      </div>
    </div>

  </box>
);
