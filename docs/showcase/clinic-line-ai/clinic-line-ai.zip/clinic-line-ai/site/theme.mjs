/** Design tokens — every page receives these as `theme`. */
export default defineTheme({
  name: 'clinic-line',
  color: {
    ground: '#FFFFFF',
    ink: '#16202B',
    trust: '#2563C9',
    mint: '#DDF0EA',
    grey: '#5D6B7A',
    wash: '#F4F7FA',
  },
  font: { head: 'Sora', body: 'Hanken Grotesk' },
  mode: 'literal',
});
