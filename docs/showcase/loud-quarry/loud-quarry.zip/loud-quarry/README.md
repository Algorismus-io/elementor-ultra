# Loud Quarry

A real poster wall. Lime and hot pink on black, line-up grids that feel printed.

|  |  |
|---|---|
| **Slug** | `loud-quarry` (deploys to `/loud-quarry/`) |
| **Archetype** | poster wall / zine spread |
| **Industry** | Music festival |
| **Page title** | Loud Quarry |
| **Fonts** | Bungee, Space Grotesk — Google Fonts, imported by Elementor automatically |
| **Elements** | 133 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (86 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install loud-quarry
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
loud-quarry/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/loud-quarry.page.jsx           the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#101014` |
| `ink` | `#F2F0EA` |
| `acid` | `#D9FF00` |
| `hot` | `#FF1F5A` |
| `cool` | `#00B7FF` |

Change a value, re-run `npx exjsx-kit install loud-quarry`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/loud-quarry.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `camp_morning` | `media/camp_morning.jpg` | Tents in the quarry campsite at first light |
| `crowd_close` | `media/crowd_close.jpg` | Crowd pressed to the barrier at the front of a stage |
| `quarry_night` | `media/quarry_night.jpg` | Floodlit granite quarry walls at night |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
