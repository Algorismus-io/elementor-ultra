/** Clause Radar — clause coverage specification. */
export const meta = {
  title: 'Clause Radar — Clause coverage and measured accuracy',
  seo: {
    title: 'Clause Radar — clause coverage and measured accuracy',
    description:
      'Clause Radar reviews inbound contracts against your playbook and returns a redline where every change cites the clause it came from. See the covered clause types, recall and false positive rates.',
  },
};

/* ── data ────────────────────────────────────────────────────────────── */

const CLAUSES = [
  {
    clause: 'Limitation of liability',
    flags: 'Uncapped indirect loss, mutual vs one-way caps, carve-out asymmetry',
    recall: '0.97',
    fp: '0.04',
  },
  {
    clause: 'Indemnities',
    flags: 'One-way indemnities, uncapped IP indemnity, defence-and-settle control',
    recall: '0.96',
    fp: '0.05',
  },
  {
    clause: 'Termination',
    flags: 'Convenience termination without notice, cure periods under 30 days',
    recall: '0.95',
    fp: '0.03',
  },
  {
    clause: 'Governing law and venue',
    flags: 'Non-preferred jurisdiction, exclusive foreign venue, jury trial waiver',
    recall: '0.98',
    fp: '0.02',
  },
  {
    clause: 'Data protection',
    flags: 'Missing sub-processor notice, transfer without SCCs, breach notice over 72 hours',
    recall: '0.94',
    fp: '0.06',
  },
  {
    clause: 'Intellectual property',
    flags: 'Assignment of background IP, feedback licences, residual knowledge carve-outs',
    recall: '0.93',
    fp: '0.07',
  },
  {
    clause: 'Confidentiality',
    flags: 'Perpetual survival, residuals exception, missing return-or-destroy obligation',
    recall: '0.97',
    fp: '0.04',
  },
  {
    clause: 'Payment terms',
    flags: 'Net terms beyond 45 days, unilateral uplift, set-off against other agreements',
    recall: '0.96',
    fp: '0.03',
  },
  {
    clause: 'Auto-renewal',
    flags: 'Renewal outside your notice window, price escalation on renewal',
    recall: '0.99',
    fp: '0.02',
  },
  {
    clause: 'Insurance',
    flags: 'Limits above your policy, additional-insured and waiver-of-subrogation demands',
    recall: '0.91',
    fp: '0.08',
  },
  {
    clause: 'Assignment and change of control',
    flags: 'Free assignment to competitors, silent change-of-control transfer',
    recall: '0.95',
    fp: '0.05',
  },
];

const REFUSALS = [
  {
    n: '01',
    t: 'It does not give legal advice',
    d: 'It reports what your playbook says about a clause and what the counterparty wrote. The judgement stays with your counsel, in your words, on your record.',
  },
  {
    n: '02',
    t: 'It does not sign anything',
    d: 'No signature block, no execution workflow, no approval on your behalf. The redline leaves the product as a document a human sends.',
  },
  {
    n: '03',
    t: 'It refuses to auto-accept escalate-always clauses',
    d: 'Any position you have marked escalate-always is routed to a named reviewer. There is no setting that turns this off. It is a hard limit in the product.',
  },
];

const DATA_FACTS = [
  { k: 'Processing region', v: 'Your tenant', d: 'eu-west, uk-south or us-east, fixed at provisioning and never crossed.' },
  { k: 'Model training', v: 'Never', d: 'Your documents and playbook are excluded from every training and evaluation set.' },
  { k: 'Retention floor', v: '24 hours', d: 'Purge schedule is yours, down to 24 hours after review completes.' },
  { k: 'Assurance', v: 'SOC 2 II', d: 'Full DPA and SOC 2 Type II report available before a trial, not after.' },
];

/* ── repeaters (content props only) ──────────────────────────────────── */

const TRACKS = 'minmax(190px, 1.05fr) 2.15fr 104px 104px';

const ClauseRow = defineComponent(
  ({ clause, flags, recall, fp }) => {
    const t = useTheme();
    return (
      <box tw="w-full flex flex-col">
        <grid
          cols={TRACKS}
          gap={18}
          tw="w-full px-5 py-4 items-start"
          mobile={{ gridCols: '1fr', gap: 8, pad: { t: 18, b: 18, l: 18, r: 18 } }}
          hover={{ bg: '#F5F7F9' }}
        >
          <text size={15} weight={600} lh={1.45} font={t.font.head} color={t.color.ink}>
            {clause}
          </text>
          <text size={13} lh={1.6} font={t.font.body} color="#59616B">
            {flags}
          </text>
          <box tw="flex flex-col gap-1">
            <text size={15} weight={500} font={t.font.body} color={t.color.safe}>
              {recall}
            </text>
            <text size={10} ls={0.08} font={t.font.body} color="#8A929C">
              RECALL
            </text>
          </box>
          <box tw="flex flex-col gap-1">
            <text size={15} weight={500} font={t.font.body} color={t.color.flag}>
              {fp}
            </text>
            <text size={10} ls={0.08} font={t.font.body} color="#8A929C">
              FALSE POS.
            </text>
          </box>
        </grid>
        <box w="100%" h={1} bg={t.color.rule} />
      </box>
    );
  },
  {
    title: 'Clause coverage row',
    props: {
      clause: { label: 'Clause type', group: 'Row' },
      flags: { label: 'What it flags', group: 'Row' },
      recall: { label: 'Recall', group: 'Rates' },
      fp: { label: 'False positive rate', group: 'Rates' },
    },
  },
);

const Refusal = defineComponent(
  ({ n, t: title, d }) => {
    const th = useTheme();
    return (
      <box tw="flex flex-col gap-3 pl-6 py-2" raw="border-left: 2px solid #B3341E;">
        <text size={11} ls={0.12} font={th.font.body} color={th.color.flag}>
          {n}
        </text>
        <heading tag="h3" size={20} weight={600} lh={1.35} font={th.font.head} color={th.color.ink}>
          {title}
        </heading>
        <text size={13} lh={1.7} font={th.font.body} color="#59616B">
          {d}
        </text>
      </box>
    );
  },
  {
    title: 'Refusal item',
    props: {
      n: { label: 'Index', group: 'Refusal' },
      t: { label: 'Title', group: 'Refusal' },
      d: { label: 'Description', group: 'Refusal' },
    },
  },
);

const DataFact = defineComponent(
  ({ k, v, d }) => {
    const t = useTheme();
    return (
      <box tw="flex flex-col gap-3 pt-5" raw="border-top: 1px solid rgba(255,255,255,0.18);">
        <text size={10} ls={0.12} font={t.font.body} color="#7E8894">
          {k}
        </text>
        <heading tag="h3" size={26} weight={500} lh={1.2} font={t.font.head} color="#FFFFFF">
          {v}
        </heading>
        <text size={12} lh={1.7} font={t.font.body} color="#98A2AE">
          {d}
        </text>
      </box>
    );
  },
  {
    title: 'Data fact',
    props: {
      k: { label: 'Label', group: 'Fact' },
      v: { label: 'Value', group: 'Fact' },
      d: { label: 'Detail', group: 'Fact' },
    },
  },
);

/* ── local section helpers (inline expansion) ────────────────────────── */

const Eyebrow = ({ children, color = '#1F3A5F', font }) => (
  <text size={11} ls={0.14} weight={500} font={font} color={color}>
    {children}
  </text>
);

/* ── page ────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => {
  const F = t.font;
  const C = t.color;
  const fade = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

  return (
    <box tw="flex flex-col w-full" pad={0} bg={C.ground}>
      {/* ── 1. Spec-sheet hero ─────────────────────────────────────── */}
      <section tw="w-full flex flex-col px-6 pt-10 pb-24 max-md:px-4 max-md:pb-16" bg={C.ground}>
        <box tw="w-full max-w-[1200px] mx-auto flex flex-col">
          <box
            tw="w-full flex flex-row justify-between items-center pb-4 gap-4 max-md:flex-col max-md:items-start max-md:gap-2"
            raw="border-bottom: 1px solid #E1E5E9;"
          >
            <text size={13} ls={0.16} weight={600} font={F.body} color={C.legal}>
              CLAUSE RADAR
            </text>
            <text size={11} ls={0.1} font={F.body} color="#8A929C">
              COVERAGE SPECIFICATION · REV 4.2 · JUNE 2026
            </text>
          </box>

          <grid
            cols="1.35fr 1fr"
            gapX={64}
            gapY={32}
            tw="w-full pt-14 pb-12 items-end max-md:pt-9 max-md:pb-8"
            mobile={{ gridCols: '1fr' }}
            tablet={{ gridCols: '1fr' }}
          >
            <box tw="flex flex-col gap-6">
              <h1
                size={58}
                weight={600}
                lh={1.08}
                ls={-0.02}
                font={F.head}
                color={C.ink}
                tablet={{ size: 46 }}
                mobile={{ size: 33 }}
              >
                Clause coverage and measured accuracy
              </h1>
              <text size={15} lh={1.75} maxw={620} font={F.body} color="#4A525C" mobile={{ size: 13 }}>
                Clause Radar reviews inbound contracts against your playbook and returns a redline
                where every change cites the clause it came from. Here is exactly which clause types
                it covers and how often it is wrong.
              </text>
            </box>

            <box tw="flex flex-col gap-4 p-6 max-md:p-5" bg="#FAFBFC" raw="border: 1px solid #E1E5E9;">
              <text size={10} ls={0.12} font={F.body} color="#8A929C">
                MEASURED ON 4,180 INBOUND CONTRACTS
              </text>
              <box tw="flex flex-row gap-8 flex-wrap">
                <box tw="flex flex-col gap-1">
                  <text size={30} weight={500} lh={1.1} font={F.head} color={C.legal}>
                    11
                  </text>
                  <text size={11} font={F.body} color="#59616B">
                    clause types
                  </text>
                </box>
                <box tw="flex flex-col gap-1">
                  <text size={30} weight={500} lh={1.1} font={F.head} color={C.safe}>
                    0.96
                  </text>
                  <text size={11} font={F.body} color="#59616B">
                    median recall
                  </text>
                </box>
                <box tw="flex flex-col gap-1">
                  <text size={30} weight={500} lh={1.1} font={F.head} color={C.flag}>
                    0.04
                  </text>
                  <text size={11} font={F.body} color="#59616B">
                    median false positives
                  </text>
                </box>
              </box>
            </box>
          </grid>

          {/* the table */}
          <box tw="w-full flex flex-col" raw="border: 1px solid #E1E5E9;">
            <grid
              cols={TRACKS}
              gap={18}
              tw="w-full px-5 py-3.5 items-center"
              bg={C.legal}
              mobile={{ gridCols: '1fr', gap: 4 }}
            >
              <text size={10} ls={0.12} weight={600} font={F.body} color="#FFFFFF">
                CLAUSE TYPE
              </text>
              <text size={10} ls={0.12} weight={600} font={F.body} color="#B9C6D6">
                WHAT IT FLAGS
              </text>
              <text size={10} ls={0.12} weight={600} font={F.body} color="#B9C6D6">
                RECALL
              </text>
              <text size={10} ls={0.12} weight={600} font={F.body} color="#B9C6D6">
                FALSE POS.
              </text>
            </grid>
            {CLAUSES.map((c) => (
              <ClauseRow clause={c.clause} flags={c.flags} recall={c.recall} fp={c.fp} />
            ))}
            <box tw="w-full flex flex-row justify-between gap-6 px-5 py-4 max-md:flex-col max-md:gap-2" bg="#FAFBFC">
              <text size={11} lh={1.7} font={F.body} color="#8A929C">
                Rates scored against counsel&apos;s final redline, January to June 2026.
              </text>
              <text size={11} lh={1.7} font={F.body} color="#8A929C">
                Recall = flagged when it should be. False positive = flagged when it should not be.
              </text>
            </box>
          </box>
        </box>
      </section>

      {/* ── 2. Playbook encoding ───────────────────────────────────── */}
      <section tw="w-full flex flex-col px-6 py-24 max-md:px-4 max-md:py-16" bg={C.legal}>
        <grid
          cols="1fr 1fr"
          gapX={72}
          gapY={40}
          tw="w-full max-w-[1200px] mx-auto items-start"
          mobile={{ gridCols: '1fr' }}
          tablet={{ gridCols: '1fr' }}
        >
          <box tw="flex flex-col gap-6" motion={fade}>
            <Eyebrow font={F.body} color="#8FA6C2">
              02 — ENCODING
            </Eyebrow>
            <heading
              tag="h2"
              size={40}
              weight={600}
              lh={1.15}
              font={F.head}
              color="#FFFFFF"
              mobile={{ size: 28 }}
            >
              How your playbook is encoded, and by whom
            </heading>
            <text size={14} lh={1.8} maxw={520} font={F.body} color="#B9C6D6" mobile={{ size: 13 }}>
              We encode your actual playbook in a two-hour session with your counsel, not a generic
              template. Positions are stored as readable rules you can edit yourself without us.
            </text>
            <box tw="flex flex-col gap-4 pt-2">
              {[
                ['Two hours with your counsel', 'A lawyer from our side walks your positions, fallbacks and escalation triggers clause by clause.'],
                ['Rules you can read', 'Every position becomes a plain-text rule with an owner and a fallback. No model prompts, no black box.'],
                ['You hold the pen after', 'Edit, add or retire a rule yourself. Changes take effect on the next document, with a version history.'],
              ].map(([h, d], i) => (
                <box tw="flex flex-row gap-4 items-start">
                  <text size={11} ls={0.1} font={F.body} color="#8FA6C2" w={28}>
                    {`0${i + 1}`}
                  </text>
                  <box tw="flex flex-col gap-1.5 flex-1">
                    <text size={14} weight={600} font={F.body} color="#FFFFFF">
                      {h}
                    </text>
                    <text size={12.5} lh={1.7} font={F.body} color="#9DAFC4">
                      {d}
                    </text>
                  </box>
                </box>
              ))}
            </box>
          </box>

          <box
            tw="flex flex-col gap-4 p-7 max-md:p-5"
            bg="#16293F"
            radius={2}
            raw="border: 1px solid rgba(255,255,255,0.14);"
            shadow={[
              [12, 24, -8, 'rgba(0,0,0,0.35)'],
              [2, 4, 0, 'rgba(0,0,0,0.18)'],
            ]}
          >
            <box tw="w-full flex flex-row justify-between items-center pb-3" raw="border-bottom: 1px solid rgba(255,255,255,0.14);">
              <text size={11} ls={0.1} font={F.body} color="#8FA6C2">
                playbook / liability.rules
              </text>
              <text size={11} font={F.body} color="#6F8299">
                v14 · owner: GC
              </text>
            </box>
            {[
              ['rule', 'liability.cap', '#FFFFFF'],
              ['position', 'cap = 12 months fees, mutual', '#9BD7B6'],
              ['fallback', '18 months if term > 24 months', '#9BD7B6'],
              ['never', 'uncapped indirect or consequential loss', '#E79C8B'],
              ['escalate', 'any carve-out naming data breach', '#E79C8B'],
              ['cites', 'MSA playbook §4.2, board policy 2024-11', '#B9C6D6'],
            ].map(([k, v, col]) => (
              <box tw="flex flex-row gap-4 items-start">
                <text size={12.5} lh={1.7} font={F.body} color="#7E93AB" w={92}>
                  {k}
                </text>
                <text size={12.5} lh={1.7} font={F.body} color={col} tw="flex-1">
                  {v}
                </text>
              </box>
            ))}
          </box>
        </grid>
      </section>

      {/* ── 3. Worked redline ──────────────────────────────────────── */}
      <section tw="w-full flex flex-col px-6 py-24 max-md:px-4 max-md:py-16" bg="#FAFBFC">
        <box tw="w-full max-w-[1200px] mx-auto flex flex-col gap-10">
          <box tw="w-full flex flex-row justify-between items-end gap-8 max-md:flex-col max-md:items-start max-md:gap-4" motion={fade}>
            <box tw="flex flex-col gap-4">
              <Eyebrow font={F.body}>03 — WORKED EXAMPLE</Eyebrow>
              <heading tag="h2" size={40} weight={600} lh={1.15} font={F.head} color={C.ink} mobile={{ size: 28 }}>
                A worked redline of a real MSA clause
              </heading>
            </box>
            <text size={14} lh={1.8} maxw={470} font={F.body} color="#4A525C" mobile={{ size: 13 }}>
              Every proposed edit shows the original text, the change, your playbook position and the
              fallback you already approved. Accept, reject or escalate in Word without leaving the
              document.
            </text>
          </box>

          <grid
            cols="1.55fr 1fr"
            gapX={28}
            gapY={24}
            tw="w-full items-start"
            mobile={{ gridCols: '1fr' }}
            tablet={{ gridCols: '1fr' }}
          >
            <box tw="flex flex-col" bg="#FFFFFF" raw="border: 1px solid #E1E5E9;">
              <box tw="w-full flex flex-row justify-between items-center px-6 py-3.5 max-md:px-4" bg="#FFFFFF" raw="border-bottom: 1px solid #E1E5E9;">
                <text size={11} ls={0.1} font={F.body} color="#59616B">
                  MSA §9.3 — LIMITATION OF LIABILITY
                </text>
                <text size={11} ls={0.1} font={F.body} color={C.flag}>
                  1 CHANGE PROPOSED
                </text>
              </box>
              <box tw="flex flex-col gap-4 px-6 py-6 max-md:px-4">
                <text
                  size={14}
                  lh={1.95}
                  font={F.body}
                  color="#98A0A9"
                  raw="text-decoration: line-through; text-decoration-color: #B3341E; text-decoration-thickness: 1px;"
                >
                  Supplier&apos;s total aggregate liability under this Agreement shall not exceed the
                  fees paid in the three (3) months preceding the claim, and Supplier shall have no
                  liability for any indirect or consequential loss howsoever arising.
                </text>
                <text
                  size={14}
                  lh={1.95}
                  font={F.body}
                  color={C.safe}
                  raw="text-decoration: underline; text-decoration-color: #2E7D5B; text-underline-offset: 4px;"
                >
                  Each party&apos;s total aggregate liability under this Agreement shall not exceed
                  the fees paid in the twelve (12) months preceding the claim. Neither party excludes
                  liability for indirect or consequential loss arising from breach of confidentiality
                  or the data protection obligations in §11.
                </text>
              </box>
              <box tw="w-full flex flex-row gap-3 px-6 py-4 max-md:px-4 flex-wrap" bg="#FAFBFC" raw="border-top: 1px solid #E1E5E9;">
                <text
                  size={12}
                  weight={500}
                  font={F.body}
                  color="#FFFFFF"
                  bg={C.safe}
                  pad={[9, 18]}
                  href="#book"
                  hover={{ bg: '#25654A' }}
                >
                  Accept
                </text>
                <text
                  size={12}
                  weight={500}
                  font={F.body}
                  color={C.ink}
                  pad={[9, 18]}
                  href="#book"
                  raw="border: 1px solid #E1E5E9;"
                  hover={{ bg: '#EEF1F4' }}
                >
                  Reject
                </text>
                <text
                  size={12}
                  weight={500}
                  font={F.body}
                  color={C.flag}
                  pad={[9, 18]}
                  href="#book"
                  raw="border: 1px solid #B3341E;"
                  hover={{ bg: '#FBEFEC' }}
                >
                  Escalate to GC
                </text>
              </box>
            </box>

            <box tw="flex flex-col gap-5 p-6 max-md:p-5" bg="#FFFFFF" raw="border: 1px solid #E1E5E9;">
              <text size={10} ls={0.12} font={F.body} color="#8A929C">
                WHY THIS CHANGE
              </text>
              {[
                ['Playbook position', 'liability.cap — 12 months fees, mutual', C.legal],
                ['Approved fallback', '18 months, one-way, if term exceeds 24 months', C.legal],
                ['Trigger', 'Uncapped exclusion of indirect loss — never position', C.flag],
                ['Cited to', 'MSA playbook §4.2 · board policy 2024-11', '#59616B'],
                ['Confidence', 'Recall 0.97 · false positive rate 0.04', C.safe],
              ].map(([k, v, col]) => (
                <box tw="flex flex-col gap-1.5">
                  <text size={11} font={F.body} color="#8A929C">
                    {k}
                  </text>
                  <text size={13} lh={1.6} weight={500} font={F.body} color={col}>
                    {v}
                  </text>
                </box>
              ))}
            </box>
          </grid>
        </box>
      </section>

      {/* ── 4. Refusals ────────────────────────────────────────────── */}
      <section tw="w-full flex flex-col px-6 py-24 max-md:px-4 max-md:py-16" bg={C.ground}>
        <box tw="w-full max-w-[1200px] mx-auto flex flex-col gap-12">
          <box tw="w-full flex flex-col gap-4 max-w-[720px]" motion={fade}>
            <Eyebrow font={F.body} color={C.flag}>
              04 — HARD LIMITS
            </Eyebrow>
            <heading tag="h2" size={40} weight={600} lh={1.15} font={F.head} color={C.ink} mobile={{ size: 28 }}>
              What it refuses to do without a lawyer
            </heading>
            <text size={14} lh={1.8} font={F.body} color="#4A525C" mobile={{ size: 13 }}>
              It does not give legal advice, does not sign anything, and refuses to auto-accept any
              clause you have marked as escalate-always. Those are hard limits in the product.
            </text>
          </box>
          <grid cols={3} gapX={40} gapY={32} tw="w-full items-start" mobile={{ gridCols: '1fr' }} tablet={{ gridCols: 1 }}>
            {REFUSALS.map((r) => (
              <Refusal n={r.n} t={r.t} d={r.d} />
            ))}
          </grid>
        </box>
      </section>

      {/* ── 5. Data residency ──────────────────────────────────────── */}
      <section tw="w-full flex flex-col px-6 py-24 max-md:px-4 max-md:py-16" bg={C.ink}>
        <box tw="w-full max-w-[1200px] mx-auto flex flex-col gap-12">
          <box tw="w-full flex flex-row justify-between items-end gap-10 max-md:flex-col max-md:items-start max-md:gap-5">
            <box tw="flex flex-col gap-4 max-w-[560px]">
              <Eyebrow font={F.body} color="#7E8894">
                05 — DATA
              </Eyebrow>
              <heading tag="h2" size={40} weight={600} lh={1.15} font={F.head} color="#FFFFFF" mobile={{ size: 28 }}>
                Where your documents go and how long they stay
              </heading>
            </box>
            <text size={14} lh={1.8} maxw={470} font={F.body} color="#98A2AE" mobile={{ size: 13 }}>
              Documents are processed in your own tenant region, never used for training, and purged
              on your schedule down to 24 hours. Full DPA and SOC 2 Type II report available before a
              trial.
            </text>
          </box>
          <grid cols={4} gapX={32} gapY={32} tw="w-full items-start" mobile={{ gridCols: '1fr' }} tablet={{ gridCols: 2 }}>
            {DATA_FACTS.map((f) => (
              <DataFact k={f.k} v={f.v} d={f.d} />
            ))}
          </grid>
        </box>
      </section>

      {/* ── 6. Integration ─────────────────────────────────────────── */}
      <section tw="w-full flex flex-col px-6 py-24 max-md:px-4 max-md:py-16" grad={[170, '#FFFFFF', '#F3F6F9']}>
        <grid
          cols="1fr 1.1fr"
          gapX={64}
          gapY={40}
          tw="w-full max-w-[1200px] mx-auto items-center"
          mobile={{ gridCols: '1fr' }}
          tablet={{ gridCols: '1fr' }}
        >
          <box tw="flex flex-col gap-6" motion={fade}>
            <Eyebrow font={F.body}>06 — WHERE IT RUNS</Eyebrow>
            <heading tag="h2" size={40} weight={600} lh={1.15} font={F.head} color={C.ink} mobile={{ size: 28 }}>
              Word and email integration
            </heading>
            <text size={14} lh={1.8} maxw={520} font={F.body} color="#4A525C" mobile={{ size: 13 }}>
              Forward a contract to your review address and the redline comes back as a tracked-changes
              document. Or open it in Word and work through the panel clause by clause. There is no new
              system for your team to live in, and no upload portal to remember.
            </text>
            <box tw="flex flex-col gap-3 pt-2">
              {[
                'Word add-in for Microsoft 365, deployed by your admin',
                'review@yourcompany — forward, receive a tracked redline in minutes',
                'Outlook thread stays intact; the counterparty sees an ordinary attachment',
              ].map((line) => (
                <box tw="flex flex-row gap-3 items-start">
                  <text size={13} lh={1.7} font={F.body} color={C.legal}>
                    —
                  </text>
                  <text size={13} lh={1.7} flex={1} font={F.body} color="#4A525C">
                    {line}
                  </text>
                </box>
              ))}
            </box>
          </box>

          <box
            tw="flex flex-col"
            bg="#FFFFFF"
            raw="border: 1px solid #E1E5E9;"
            shadow={[
              [18, 40, -12, 'rgba(16,20,24,0.14)'],
              [2, 6, 0, 'rgba(16,20,24,0.05)'],
            ]}
          >
            <box tw="w-full flex flex-row items-center gap-3 px-5 py-3" bg="#FAFBFC" raw="border-bottom: 1px solid #E1E5E9;">
              <box w={9} h={9} radius={9} bg={C.flag} />
              <box w={9} h={9} radius={9} bg="#D8B23C" />
              <box w={9} h={9} radius={9} bg={C.safe} />
              <text size={11} ls={0.08} font={F.body} color="#8A929C" tw="pl-3">
                Vendor_MSA_v3.docx — Clause Radar
              </text>
            </box>
            <grid cols="1fr 210px" gap={0} tw="w-full items-stretch" mobile={{ gridCols: '1fr' }}>
              <box tw="flex flex-col gap-3 px-5 py-6" raw="border-right: 1px solid #E1E5E9;">
                <text size={12} lh={1.9} font={F.body} color="#B4BAC1">
                  9.1 Each party shall comply with all applicable laws in the performance of this
                  Agreement.
                </text>
                <text size={12} lh={1.9} font={F.body} color={C.ink} bg="#FBEFEC" shadow={[0, 0, 4, '#FBEFEC']}>
                  9.3 Supplier&apos;s total aggregate liability shall not exceed the fees paid in the
                  three (3) months preceding the claim…
                </text>
                <text size={12} lh={1.9} font={F.body} color="#B4BAC1">
                  9.4 Nothing in this Agreement limits liability for death or personal injury caused
                  by negligence.
                </text>
              </box>
              <box tw="flex flex-col gap-4 px-5 py-6" bg="#FAFBFC">
                <text size={10} ls={0.12} font={F.body} color="#8A929C">
                  REVIEW PANEL
                </text>
                <box tw="flex flex-col gap-2 p-3" bg="#FFFFFF" raw="border-left: 2px solid #B3341E; border-top: 1px solid #E1E5E9; border-right: 1px solid #E1E5E9; border-bottom: 1px solid #E1E5E9;">
                  <text size={11} font={F.body} color={C.flag}>
                    §9.3 · cap below playbook
                  </text>
                  <text size={11} lh={1.6} font={F.body} color="#59616B">
                    liability.cap wants 12 months, mutual
                  </text>
                </box>
                <box tw="flex flex-col gap-2 p-3" bg="#FFFFFF" raw="border-left: 2px solid #2E7D5B; border-top: 1px solid #E1E5E9; border-right: 1px solid #E1E5E9; border-bottom: 1px solid #E1E5E9;">
                  <text size={11} font={F.body} color={C.safe}>
                    §9.4 · matches playbook
                  </text>
                  <text size={11} lh={1.6} font={F.body} color="#59616B">
                    no change proposed
                  </text>
                </box>
              </box>
            </grid>
          </box>
        </grid>
      </section>

      {/* ── 7. Pricing ─────────────────────────────────────────────── */}
      <section tw="w-full flex flex-col px-6 py-24 max-md:px-4 max-md:py-16" bg={C.ground}>
        <box tw="w-full max-w-[1200px] mx-auto flex flex-col gap-10">
          <box tw="flex flex-col gap-4 max-w-[720px]">
            <Eyebrow font={F.body}>07 — PRICING</Eyebrow>
            <heading tag="h2" size={40} weight={600} lh={1.15} font={F.head} color={C.ink} mobile={{ size: 28 }}>
              Per seat, with unlimited documents
            </heading>
          </box>
          <grid
            cols="1fr 1.25fr"
            gapX={0}
            gapY={0}
            tw="w-full items-stretch"
            raw="border: 1px solid #E1E5E9;"
            mobile={{ gridCols: '1fr' }}
          >
            <box tw="flex flex-col gap-5 p-10 max-md:p-6" bg={C.legal}>
              <box tw="flex flex-row items-end gap-2">
                <heading tag="h3" size={62} weight={600} lh={1} font={F.head} color="#FFFFFF" mobile={{ size: 44 }}>
                  £340
                </heading>
                <text size={13} font={F.body} color="#9DAFC4" tw="pb-3">
                  /seat/month
                </text>
              </box>
              <text size={13} lh={1.8} font={F.body} color="#B9C6D6">
                Unlimited documents. Billed annually, invoiced to legal ops, no per-contract meter to
                explain to finance.
              </text>
              <text
                size={13}
                weight={500}
                font={F.body}
                color={C.legal}
                bg="#FFFFFF"
                pad={[13, 24]}
                ta="center"
                href="#book"
                tw="mt-2"
                hover={{ bg: '#EAF0F6' }}
              >
                Book a playbook session
              </text>
            </box>
            <box tw="flex flex-col gap-6 p-10 max-md:p-6" bg="#FFFFFF">
              <text size={14} lh={1.85} font={F.body} color="#4A525C">
                £340 per seat per month with unlimited documents, because charging per contract makes
                your team hesitate to use it and that defeats the purpose.
              </text>
              <box tw="w-full h-px" bg={C.rule} />
              <grid cols={2} gapX={28} gapY={18} tw="w-full" mobile={{ gridCols: '1fr' }}>
                {[
                  ['Included', 'Playbook encoding session with counsel'],
                  ['Included', 'Word add-in and review inbox'],
                  ['Included', 'Unlimited documents and reviewers in-app'],
                  ['Included', 'DPA, SOC 2 Type II, tenant region choice'],
                  ['Not charged', 'Per-contract or per-page fees'],
                  ['Not charged', 'Re-encoding when your playbook changes'],
                ].map(([k, v]) => (
                  <box tw="flex flex-col gap-1">
                    <text size={10} ls={0.1} font={F.body} color={k === 'Included' ? C.safe : C.flag}>
                      {k.toUpperCase()}
                    </text>
                    <text size={12.5} lh={1.6} font={F.body} color={C.ink}>
                      {v}
                    </text>
                  </box>
                ))}
              </grid>
            </box>
          </grid>
        </box>
      </section>

      {/* ── 8. CTA (the one centred section) ───────────────────────── */}
      <section
        id="book"
        tw="w-full flex flex-col items-center gap-7 px-6 py-28 text-center max-md:px-4 max-md:py-20"
        grad={[165, '#1F3A5F', '#101418']}
      >
        <box tw="flex flex-col items-center gap-6 w-full max-w-[720px]" motion={fade}>
          <Eyebrow font={F.body} color="#8FA6C2">
            08 — NEXT
          </Eyebrow>
          <heading tag="h2" size={46} weight={600} lh={1.15} font={F.head} color="#FFFFFF" ta="center" mobile={{ size: 30 }}>
            Book a playbook session
          </heading>
          <text size={14} lh={1.8} ta="center" font={F.body} color="#B9C6D6" mobile={{ size: 13 }}>
            Two hours with your counsel and ours. You leave with your positions encoded as readable
            rules and a coverage report against your last fifty inbound contracts — before you decide
            anything.
          </text>
          <text
            size={14}
            weight={500}
            font={F.body}
            color={C.ink}
            bg="#FFFFFF"
            pad={[15, 32]}
            href="mailto:playbook@clauseradar.com?subject=Playbook%20session"
            hover={{ bg: '#DCE4EE' }}
          >
            Book a playbook session
          </text>
          <text size={11.5} lh={1.7} ta="center" font={F.body} color="#7E93AB">
            playbook@clauseradar.com · DPA and SOC 2 Type II report sent before the call
          </text>
        </box>
      </section>
    </box>
  );
};
