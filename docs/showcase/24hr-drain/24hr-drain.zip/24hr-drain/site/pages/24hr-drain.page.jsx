/** Hardin Drains — 24-hour emergency drainage.
 *  Structural archetype: full-bleed colour blocks with hard seams. No imagery, by design. */

export const meta = {
  title: 'Hardin Drains — 24 Hour Emergency Drainage',
  slug: '24hr-drain',
  seo: {
    title: 'Hardin Drains — 0800 555 0166 · 24 Hour Emergency Drainage',
    description:
      '24-hour emergency drainage. We answer in person, not a queue. £140 for the first hour, £70 an hour after, plus VAT. Average arrival 52 minutes inside the ring road.',
  },
};

const TEL = 'tel:08005550166';
const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 400 };

/* ── repeaters (content props only) ─────────────────────────────────────── */

const Step = defineComponent(
  ({ num = '01', head = '', body = '' }) => (
    <div tw="flex flex-col w-full" bg="#D40000" pad={{ t: 36, r: 28, b: 40, l: 28 }} gap={14}>
      <text font="Archivo Black" size={44} lh={1} color="#000000" mobile={{ size: 36 }}>
        {num}
      </text>
      <heading tag="h3" font="Archivo Black" size={22} lh={1.15} color="#FFFFFF" ls="0px" mobile={{ size: 20 }}>
        {head}
      </heading>
      <text font="Roboto Mono" size={15} lh={1.6} color="#FFFFFF" weight={400}>
        {body}
      </text>
    </div>
  ),
  { title: 'Emergency Step', props: { num: { label: 'Number' }, head: { label: 'Heading' }, body: { label: 'Body' } } },
);

const ClearItem = defineComponent(
  ({ head = '', body = '' }) => (
    <div tw="flex flex-col w-full" bg="#FFFFFF" pad={{ t: 30, r: 26, b: 34, l: 26 }} gap={10}>
      <heading tag="h3" font="Archivo Black" size={26} lh={1.1} color="#000000" mobile={{ size: 21 }}>
        {head}
      </heading>
      <text font="Roboto Mono" size={15} lh={1.6} color="#111111">
        {body}
      </text>
    </div>
  ),
  { title: 'Tonight Item', props: { head: { label: 'Heading' }, body: { label: 'Body' } } },
);

const AreaTime = defineComponent(
  ({ figure = '', unit = '', area = '', body = '' }) => (
    <div tw="flex flex-col w-full" bg="#111111" pad={{ t: 34, r: 26, b: 38, l: 26 }} gap={8}>
      <text font="Archivo Black" size={84} lh={0.9} ls="-3px" color="#FFDD00" tablet={{ size: 64 }} mobile={{ size: 58 }}>
        {figure}
      </text>
      <text font="Roboto Mono" size={13} weight={700} ls="2px" color="#FFDD00">
        {unit}
      </text>
      <heading tag="h3" font="Archivo Black" size={20} lh={1.2} color="#FFFFFF" pad={{ t: 10 }}>
        {area}
      </heading>
      <text font="Roboto Mono" size={15} lh={1.6} color="#FFFFFF">
        {body}
      </text>
    </div>
  ),
  {
    title: 'Response Time',
    props: {
      figure: { label: 'Figure' },
      unit: { label: 'Unit' },
      area: { label: 'Area' },
      body: { label: 'Body' },
    },
  },
);

const PayLine = defineComponent(
  ({ head = '', body = '' }) => (
    <div tw="flex flex-col w-full" bg="#FFDD00" pad={{ t: 28, r: 24, b: 32, l: 24 }} gap={10}>
      <heading tag="h3" font="Archivo Black" size={24} lh={1.1} color="#000000" mobile={{ size: 20 }}>
        {head}
      </heading>
      <text font="Roboto Mono" size={15} lh={1.6} color="#111111">
        {body}
      </text>
    </div>
  ),
  { title: 'Payment Line', props: { head: { label: 'Heading' }, body: { label: 'Body' } } },
);

/* ── page ───────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} gap={0} bg={t.color.white}>

    {/* 0 · hard strip */}
    <div tw="flex flex-row w-full flex-wrap" bg={t.color.ink} pad={{ t: 12, r: 24, b: 12, l: 24 }} gap={10} justify="space-between" align="center">
      <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.ground} mobile={{ size: 11, ls: '2px' }}>
        HARDIN DRAINS
      </text>
      <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.white} mobile={{ size: 11, ls: '2px' }}>
        OPEN NOW · 24/7
      </text>
    </div>

    {/* 1 · YELLOW SLAB — the number, at maximum size */}
    <section tw="flex flex-col w-full items-start" bg={t.color.ground} pad={{ t: 56, r: 24, b: 0, l: 24 }} gap={0} tablet={{ pad: { t: 44, r: 24, b: 0, l: 24 } }}>
      <div tw="flex flex-col w-full" maxw={1240} m={{ l: 'auto', r: 'auto' }} gap={0}>
        <text font={t.font.body} size={15} weight={700} ls="3px" color={t.color.ink} mobile={{ size: 12, ls: '2px' }}>
          BLOCKED DRAIN? CALL THIS NUMBER.
        </text>
        <h1
          href={TEL}
          font={t.font.head}
          size={124}
          lh={0.92}
          ls="-5px"
          w="100%"
          color={t.color.ink}
          pad={{ t: 18, b: 18 }}
          tablet={{ size: 82, ls: '-3px' }}
          mobile={{ size: 40, ls: '-1px', lh: 1 }}
          tw="hover:text-[#D40000]"
        >
          0800 555 0166
        </h1>
        <text
          href={TEL}
          font={t.font.head}
          size={46}
          lh={1}
          ls="1px"
          ta="center"
          w="100%"
          color={t.color.white}
          bg={t.color.alert}
          pad={{ t: 30, r: 20, b: 32, l: 20 }}
          tablet={{ size: 38 }}
          mobile={{ size: 28, pad: { t: 24, b: 26 } }}
          tw="hover:bg-[#000000] hover:text-[#FFDD00]"
        >
          CALL NOW
        </text>
        <text font={t.font.body} size={18} lh={1.55} color={t.color.ink} maxw={720} pad={{ t: 26, b: 56 }} mobile={{ size: 15 }}>
          24-hour emergency drainage. We answer in person, not a queue. Average arrival 52 minutes inside the ring
          road.
        </text>
      </div>
    </section>

    {/* 2 · BLACK SLAB — the price before we come out */}
    <section tw="flex flex-col w-full" bg={t.color.block} pad={{ t: 76, r: 24, b: 76, l: 24 }} mobile={{ pad: { t: 48, r: 20, b: 48, l: 20 } }}>
      <grid cols={12} gap={36} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }}>
        <div span={5} mobile={{ span: 1 }} tw="flex flex-col" gap={16} motion={FADE}>
          <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.ground}>
            02 — THE PRICE
          </text>
          <heading tag="h2" font={t.font.head} size={52} lh={1.02} ls="-2px" color={t.color.white} tablet={{ size: 40 }} mobile={{ size: 30, ls: '-1px' }}>
            The price before we come out
          </heading>
        </div>
        <div span={7} mobile={{ span: 1 }} tw="flex flex-col" gap={18}>
          <text font={t.font.head} size={112} lh={0.9} ls="-5px" color={t.color.ground} tablet={{ size: 84 }} mobile={{ size: 56, ls: '-2px' }}>
            £140
          </text>
          <text font={t.font.body} size={19} lh={1.6} color={t.color.white} maxw={640} mobile={{ size: 15 }}>
            £140 for the first hour, £70 an hour after, plus VAT. Same price at 3am as at 3pm. We tell you the total
            before we start work and it does not change.
          </text>
          <text font={t.font.body} size={14} weight={700} ls="2px" color={t.color.ground} bg="#1D1D1D" pad={{ t: 14, r: 16, b: 14, l: 16 }} w="hug" mobile={{ size: 11, ls: '1px' }}>
            NO CALL-OUT FEE · NO NIGHT SURCHARGE
          </text>
        </div>
      </grid>
    </section>

    {/* 3 · RED SLAB — the next two minutes */}
    <section tw="flex flex-col w-full" bg={t.color.alert} pad={{ t: 72, r: 24, b: 72, l: 24 }} gap={38} mobile={{ pad: { t: 48, r: 20, b: 48, l: 20 }, gap: 26 }}>
      <div tw="flex flex-col w-full" maxw={1240} m={{ l: 'auto', r: 'auto' }} gap={12}>
        <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.ink}>
          03 — WHILE YOU WAIT
        </text>
        <heading tag="h2" font={t.font.head} size={56} lh={1.02} ls="-2px" color={t.color.white} maxw={900} tablet={{ size: 42 }} mobile={{ size: 30, ls: '-1px' }} motion={FADE}>
          Do this in the next two minutes
        </heading>
      </div>
      <div tw="flex flex-col w-full" maxw={1240} m={{ l: 'auto', r: 'auto' }} bg={t.color.ink} pad={0}>
        <grid cols={3} gap={6} w="100%">
          <Step
            num="01"
            head="Turn off the stop tap"
            body="It is under the kitchen sink. Turn it clockwise until it stops. That halts anything else going down the pipe."
          />
          <Step
            num="02"
            head="Do not flush anything"
            body="Every flush adds to what is already backing up. Keep the family off the toilets and out of the shower until we arrive."
          />
          <Step
            num="03"
            head="No drain cleaner"
            body="Do not pour drain cleaner in, it makes the jetting harder and we will charge you for the extra hour."
          />
        </grid>
      </div>
    </section>

    {/* 4 · WHITE SLAB — what we can clear tonight */}
    <section tw="flex flex-col w-full" bg={t.color.white} pad={{ t: 76, r: 24, b: 76, l: 24 }} gap={34} mobile={{ pad: { t: 48, r: 20, b: 48, l: 20 } }}>
      <div tw="flex flex-row w-full flex-wrap" maxw={1240} m={{ l: 'auto', r: 'auto' }} gap={20} justify="space-between" align="flex-end">
        <heading tag="h2" font={t.font.head} size={56} lh={1.02} ls="-2px" color={t.color.ink} maxw={720} tablet={{ size: 42 }} mobile={{ size: 30, ls: '-1px' }} motion={FADE}>
          What we can clear tonight
        </heading>
        <text font={t.font.body} size={14} weight={700} ls="2px" color={t.color.white} bg={t.color.ink} pad={{ t: 12, r: 16, b: 12, l: 16 }} w="hug" mobile={{ size: 11, ls: '1px' }}>
          JETTER + CAMERA ON EVERY VAN
        </text>
      </div>
      <div tw="flex flex-col w-full" maxw={1240} m={{ l: 'auto', r: 'auto' }} bg={t.color.ink} pad={3}>
        <grid cols={3} gap={3} w="100%">
          <ClearItem head="Blocked toilets" body="The most common 2am call. Usually cleared inside the first hour." />
          <ClearItem head="Blocked mains drains" body="High-pressure jetting from the nearest chamber, back to free flow." />
          <ClearItem head="Collapsed gullies" body="We open it up, tell you what we can see, and quote before we dig." />
          <ClearItem head="Sewage backup" body="Contained, cleared and flushed through. We do not leave it half done." />
          <ClearItem head="Camera surveys" body="Recorded survey with a report you can send to an insurer or a landlord." />
          <ClearItem head="Outside gullies and yards" body="Leaf packs, silt and fat. Cleared and rodded while we are on site." />
        </grid>
      </div>
      <text font={t.font.body} size={18} lh={1.6} color={t.color.ink} maxw={860} m={{ l: 'auto', r: 'auto' }} w="100%" mobile={{ size: 15 }}>
        Blocked toilets, blocked mains drains, collapsed gullies, sewage backup, and camera surveys. We carry a jetter
        and a camera on every van, every shift.
      </text>
    </section>

    {/* 5 · BLACK SLAB — response times by area */}
    <section tw="flex flex-col w-full" bg={t.color.block} pad={{ t: 76, r: 24, b: 76, l: 24 }} gap={34} mobile={{ pad: { t: 48, r: 20, b: 48, l: 20 } }}>
      <div tw="flex flex-col w-full" maxw={1240} m={{ l: 'auto', r: 'auto' }} gap={12}>
        <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.alert}>
          05 — HOW LONG
        </text>
        <heading tag="h2" font={t.font.head} size={56} lh={1.02} ls="-2px" color={t.color.white} tablet={{ size: 42 }} mobile={{ size: 30, ls: '-1px' }} motion={FADE}>
          Response times by area
        </heading>
      </div>
      <div tw="flex flex-col w-full" maxw={1240} m={{ l: 'auto', r: 'auto' }} bg={t.color.ground} pad={5}>
        <grid cols={3} gap={5} w="100%">
          <AreaTime figure="52" unit="MINUTES AVERAGE" area="Inside the ring road" body="City centre, the terraces and everything within the ring. Most nights it is quicker." />
          <AreaTime figure="80" unit="MINUTES AVERAGE" area="Outer districts" body="Estates and villages past the ring road. We give you a window on the phone and we keep to it." />
          <AreaTime figure="—" unit="WE WILL SAY SO" area="Past the bypass" body="Anything past the bypass, we will tell you honestly on the phone if we are the wrong people to call." />
        </grid>
      </div>
    </section>

    {/* 6 · YELLOW SLAB — how we take payment */}
    <section tw="flex flex-col w-full" bg={t.color.ground} pad={{ t: 76, r: 24, b: 76, l: 24 }} mobile={{ pad: { t: 48, r: 20, b: 48, l: 20 } }}>
      <grid cols={12} gap={36} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }}>
        <div span={4} mobile={{ span: 1 }} tw="flex flex-col" gap={16}>
          <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.ink}>
            06 — PAYMENT
          </text>
          <heading tag="h2" font={t.font.head} size={52} lh={1.02} ls="-2px" color={t.color.ink} tablet={{ size: 40 }} mobile={{ size: 30, ls: '-1px' }} motion={FADE}>
            How we take payment
          </heading>
          <text font={t.font.body} size={17} lh={1.6} color={t.color.ink} mobile={{ size: 15 }}>
            Card on the doorstep, bank transfer, or invoice for landlords and agents. No cash surcharge and no
            call-out deposit.
          </text>
        </div>
        <div span={8} mobile={{ span: 1 }} tw="flex flex-col w-full" bg={t.color.ink} pad={5}>
          <grid cols={1} gap={5} w="100%">
            <PayLine head="Card on the doorstep" body="Chip and pin or contactless, taken before we drive away. Receipt by text or email." />
            <PayLine head="Bank transfer" body="Details on the invoice, seven days. Same total we quoted before the first hour started." />
            <PayLine head="Invoice for landlords and agents" body="Thirty days on an account. One reference per property, one statement per month." />
          </grid>
        </div>
      </grid>
    </section>

    {/* 7 · GREY SLAB — landlord and commercial accounts */}
    <section tw="flex flex-col w-full" bg={t.color.grey} pad={{ t: 72, r: 24, b: 72, l: 24 }} mobile={{ pad: { t: 48, r: 20, b: 48, l: 20 } }}>
      <grid cols={12} gap={36} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }}>
        <div span={7} mobile={{ span: 1 }} tw="flex flex-col" gap={16}>
          <text font={t.font.body} size={13} weight={700} ls="3px" color={t.color.alert}>
            07 — ACCOUNTS
          </text>
          <heading tag="h2" font={t.font.head} size={48} lh={1.04} ls="-2px" color={t.color.ink} tablet={{ size: 38 }} mobile={{ size: 28, ls: '-1px' }} motion={FADE}>
            Landlord and commercial accounts
          </heading>
          <text font={t.font.body} size={17} lh={1.6} color={t.color.ink} maxw={620} mobile={{ size: 15 }}>
            One number for every property on your book. We attend the tenant, clear the drain, and send you the
            report and the invoice. No deposit, no per-property sign-up, and the same hourly rate at 3am as at 3pm.
          </text>
        </div>
        <div span={5} mobile={{ span: 1 }} tw="flex flex-col w-full" bg={t.color.white} pad={{ t: 28, r: 26, b: 30, l: 26 }} gap={14}>
          <text font={t.font.body} size={13} weight={700} ls="2px" color={t.color.ink}>
            ON EVERY ACCOUNT
          </text>
          <text font={t.font.body} size={16} lh={1.7} color={t.color.ink}>
            Photo and camera report per visit. Purchase-order references on the invoice. Out-of-hours attendance at
            the same rate. Monthly statement, thirty-day terms.
          </text>
          <text
            href={TEL}
            font={t.font.head}
            size={20}
            ta="center"
            w="100%"
            color={t.color.white}
            bg={t.color.ink}
            pad={{ t: 18, r: 14, b: 20, l: 14 }}
            tw="hover:bg-[#D40000]"
          >
            OPEN AN ACCOUNT — 0800 555 0166
          </text>
        </div>
      </grid>
    </section>

    {/* 8 · BLACK SLAB — the number again */}
    <section tw="flex flex-col w-full items-center" bg={t.color.block} pad={{ t: 72, r: 24, b: 80, l: 24 }} gap={0} mobile={{ pad: { t: 52, r: 20, b: 56, l: 20 } }}>
      <div tw="flex flex-col w-full items-center" maxw={1100} gap={0}>
        <text font={t.font.body} size={14} weight={700} ls="3px" color={t.color.ground} ta="center" mobile={{ size: 12, ls: '2px' }}>
          STILL STANDING IN IT? RING US.
        </text>
        <heading
          tag="h2"
          href={TEL}
          font={t.font.head}
          size={112}
          lh={0.95}
          ls="-5px"
          ta="center"
          w="100%"
          color={t.color.ground}
          pad={{ t: 16, b: 20 }}
          tablet={{ size: 76, ls: '-3px' }}
          mobile={{ size: 38, ls: '-1px', lh: 1.05 }}
          tw="hover:text-[#FFFFFF]"
        >
          0800 555 0166
        </heading>
        <text
          href={TEL}
          font={t.font.head}
          size={40}
          ta="center"
          w="100%"
          color={t.color.white}
          bg={t.color.alert}
          pad={{ t: 28, r: 20, b: 30, l: 20 }}
          tablet={{ size: 34 }}
          mobile={{ size: 26, pad: { t: 22, b: 24 } }}
          tw="hover:bg-[#FFDD00] hover:text-[#000000]"
        >
          CALL NOW
        </text>
        <text font={t.font.body} size={15} lh={1.6} ta="center" color={t.color.white} maxw={640} pad={{ t: 24 }} mobile={{ size: 13 }}>
          Hardin Drains · 24 hours, every night of the year · A person answers, not a queue
        </text>
      </div>
    </section>

  </box>
);
