/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "sediment-wine--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'sediment-wine--';

export default [
  { slot: `${PREFIX}bottles_table`, file: join(MEDIA_DIR, "bottles_table.jpg"), alt: "Six natural wine bottles standing on a scuffed wooden table" },
  { slot: `${PREFIX}pour`, file: join(MEDIA_DIR, "pour.jpg"), alt: "Cloudy red wine being poured into a tumbler" },
  { slot: `${PREFIX}vineyard`, file: join(MEDIA_DIR, "vineyard.jpg"), alt: "A small hillside vineyard in late summer" },
];
