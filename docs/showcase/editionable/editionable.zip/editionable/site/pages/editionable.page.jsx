import { MEDIA as M } from '../data/media.mjs';

export const meta = {
  title: 'Editionable',
  slug: 'editionable',
  seo: {
    title: 'Editionable — small editions from living artists, with the numbers left in',
    description:
      'Strictly limited editions from living artists. We publish the edition size, the printer, the paper and exactly what the artist is paid. Editions of 40 or fewer, signed and numbered.',
  },
};

/* ── shared type helpers ─────────────────────────────────────────── */
const CAPS = { size: 11, weight: 500, ls: 0.14, font: 'Jost' };

/* One work in the diagonal hang. Style varies per tile, so this stays an inline
   component (defineComponent props may only carry content, never style). */
const Work = ({ t, title, artist, meta: m, span, drop, img, tone, h, ink }) => (
  <col
    span={span}
    gap={14}
    m={{ t: drop }}
    mobile={{ m: { t: 0 }, gap: 10 }}
    hover={{ m: { t: drop > 8 ? drop - 8 : 0 } }}
    cls="work"
  >
    {img ? (
      <img src={img} w="100%" h={h} fit="cover" radius={2} cls="work-plate" />
    ) : (
      <box
        w="100%"
        minh={h}
        bg={tone}
        radius={2}
        pad={22}
        align="flex-end"
        justify="flex-start"
        dir="column"
        border={[1, t.color.rule]}
        cls="work-swatch"
      >
        <text font={t.font.head} size={40} lh={1} color={ink} mobile={{ size: 32 }}>
          {String(m.n)}
        </text>
        <text {...CAPS} color={ink} m={{ t: 6 }}>
          of {m.of}
        </text>
      </box>
    )}
    <box dir="column" gap={4} w="100%" cls="work-caption">
      <heading tag="h2" font={t.font.head} size={21} lh={1.15} color={t.color.ink} w="100%">
        {title}
      </heading>
      <text size={13} font={t.font.body} color={t.color.muted} lh={1.5} w="100%">
        {artist} · edition of {m.of} · £{m.price}
      </text>
    </box>
  </col>
);

/* Ledger row — pure content props, so it registers as a native Elementor component. */
const EditionRow = defineComponent(
  ({ work = '', artist = '', edition = '', printer = '', retail = '', share = '' }) => (
    <grid cols={12} gap={16} w="100%" pad={{ t: 18, b: 18 }}>
      <col span={4} gap={3}>
        <heading tag="h3" font="Italiana" size={24} lh={1.15} color="#FAF7F4">
          {work}
        </heading>
        <text size={13} font="Jost" color="#9A9088">
          {artist}
        </text>
      </col>
      <text span={2} size={14} font="Jost" color="#FAF7F4">
        {edition}
      </text>
      <text span={3} size={14} font="Jost" color="#9A9088">
        {printer}
      </text>
      <text span={1} size={14} font="Jost" color="#FAF7F4">
        {retail}
      </text>
      <text span={2} size={14} font="Jost" weight={500} color="#E8B04B">
        {share}
      </text>
    </grid>
  ),
  {
    title: 'Edition ledger row',
    props: {
      work: { label: 'Work', group: 'Edition' },
      artist: { label: 'Artist', group: 'Edition' },
      edition: { label: 'Edition size', group: 'Numbers' },
      printer: { label: 'Printer & paper', group: 'Numbers' },
      retail: { label: 'Retail', group: 'Numbers' },
      share: { label: 'Artist receives', group: 'Numbers' },
    },
  },
);

export default ({ theme: t }) => {
  const works = [
    { title: 'Low Tide, Six', artist: 'Marta Osei', meta: { n: 25, of: 25, price: '420' }, span: 5, drop: 0, img: M.gallery_wall.id, h: 460 },
    { title: 'Nightshift', artist: 'Ilya Behar', meta: { n: 18, of: 18, price: '380' }, span: 4, drop: 56, tone: t.color.ink, ink: t.color.ground, h: 260 },
    { title: 'Pale Orchard', artist: 'Rae Nwosu', meta: { n: 40, of: 40, price: '240' }, span: 3, drop: 104, tone: t.color.shade, ink: t.color.ink, h: 210 },
    { title: 'Kiln Field', artist: 'Tomas Reidy', meta: { n: 12, of: 12, price: '760' }, span: 5, drop: 24, img: M.print_macro.id, h: 340 },
    { title: 'Blue Hour Study', artist: 'Ana Vidal', meta: { n: 30, of: 30, price: '295' }, span: 3, drop: 0, tone: t.color.accent, ink: '#FFFFFF', h: 300 },
    { title: 'Corner Shop, 6am', artist: 'J. Okonkwo', meta: { n: 22, of: 22, price: '450' }, span: 4, drop: 64, tone: t.color.warm, ink: t.color.ink, h: 230 },
    { title: 'Sixteen Windows', artist: 'Lise Marchand', meta: { n: 35, of: 35, price: '330' }, span: 5, drop: 112, img: M.artist_studio.id, h: 380 },
    { title: 'Green Room', artist: 'Hal Whitmore', meta: { n: 15, of: 15, price: '540' }, span: 4, drop: 0, tone: t.color.shade, ink: t.color.ink, h: 250 },
    { title: 'The Long Field', artist: 'Nia Prosser', meta: { n: 8, of: 8, price: '1,180' }, span: 3, drop: 72, tone: t.color.ink, ink: t.color.warm, h: 200 },
  ];

  const steps = [
    ['01', 'The artist fixes the number', 'Twelve, twenty-five, forty. Whatever it is, it is decided before a single sheet is printed and it never moves.'],
    ['02', 'A named studio prints it', 'One press run, one paper, one batch of ink. We publish the studio and the stock so you can go and ask them yourself.'],
    ['03', 'The artist signs and numbers it', 'In pencil, in the margin: 7/25. Your number is yours and it is recorded against your name.'],
    ['04', 'The file is retired', 'No second run, no larger version later, no open edition of the same image. The number on the paper stays true.'],
  ];

  const facts = [
    ['Returns', 'Fourteen days, no reason needed, we pay return shipping. If you get it home and the room says no, that is a completely legitimate reason.'],
    ['Condition', 'Every work is checked against the studio proof, logged with its number, and shipped flat under tissue in a rigid box, or crated if it is framed.'],
    ['Resale', 'We keep the register, so we can confirm your number and its condition to a buyer years from now. We take nothing when you sell it on.'],
  ];

  return (
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
      {/* ── masthead ─────────────────────────────────────────────── */}
      <box w="100%" pad={{ t: 26, b: 26, l: 32, r: 32 }} mobile={{ pad: { l: 20, r: 20, t: 18, b: 18 } }}>
        <row w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} justify="space-between" align="center" gap={16} wrap="wrap">
          <heading tag="h2" font={t.font.head} size={26} lh={1} color={t.color.ink} ls={0.04}>
            Editionable
          </heading>
          <text {...CAPS} color={t.color.muted}>
            Edition Twelve · thirty-one works · live now
          </text>
        </row>
      </box>
      <box w="100%" h={1} bg={t.color.rule} />

      {/* ── 1. the diagonal hang ─────────────────────────────────── */}
      <section w="100%" pad={{ t: 72, b: 130, l: 32, r: 32 }} mobile={{ pad: { t: 44, b: 64, l: 20, r: 20 } }}>
        <grid cols={12} gap={26} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} mobile={{ gridCols: 1, gap: 40 }}>
          <col span={7} gap={26} pad={{ r: 40, b: 30 }} mobile={{ pad: { r: 0, b: 0 }, gap: 20 }}>
            <text {...CAPS} color={t.color.accent}>
              Strictly limited · living artists · published numbers
            </text>
            <h1 font={t.font.head} size={78} lh={1.02} color={t.color.ink} w="100%" tablet={{ size: 58 }} mobile={{ size: 38 }}>
              Small editions from living artists, with the numbers left in.
            </h1>
            <text size={18} font={t.font.body} color={t.color.muted} lh={1.65} maxw={520}>
              Every work here is an edition of 40 or fewer, printed by a named studio, signed by the
              artist. We publish the edition size, the printer, the paper and exactly what the artist
              is paid.
            </text>
            <row gap={14} align="center" wrap="wrap" m={{ t: 6 }}>
              <text
                href="#drop"
                size={15}
                weight={500}
                font={t.font.body}
                color="#FFFFFF"
                bg={t.color.accent}
                pad={[15, 30]}
                radius={2}
                tw="hover:bg-[#5A2BB0]"
              >
                Browse the current edition
              </text>
              <text size={14} font={t.font.body} color={t.color.muted}>
                Instalments from £75/month
              </text>
            </row>
          </col>
          {works.map((w) => (
            <Work t={t} {...w} />
          ))}
        </grid>
      </section>

      {/* ── 2. every edition, size and artist share ──────────────── */}
      <section w="100%" bg={t.color.ink} pad={{ t: 108, b: 108, l: 32, r: 32 }} mobile={{ pad: { t: 60, b: 60, l: 20, r: 20 } }}>
        <box w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} dir="column" gap={44}>
          <grid cols={12} gap={26} w="100%">
            <heading
              tag="h2"
              span={7}
              font={t.font.head}
              size={54}
              lh={1.08}
              color={t.color.ground}
              tablet={{ size: 42 }}
              mobile={{ size: 32 }}
              motion={{ effect: 'fade', trigger: 'scrollIn' }}
            >
              Every edition, with the size and the artist's share printed next to it.
            </heading>
            <box span={5} pad={{ l: 30, t: 8 }} mobile={{ pad: { l: 0 } }} dir="column" gap={16} justify="flex-end">
              <box w={64} h={2} bg={t.color.warm} />
              <text size={16} font={t.font.body} color="#B8AFA6" lh={1.7}>
                Typical work: edition of 25, giclée on Hahnemühle 308gsm, printed at Trace Studio,
                London. Retail 420. The artist receives 231.
              </text>
            </box>
          </grid>

          <box w="100%" dir="column" gap={0}>
            <grid cols={12} gap={16} w="100%" pad={{ b: 14 }}>
              <text span={4} {...CAPS} color="#8C837B">Work</text>
              <text span={2} {...CAPS} color="#8C837B">Edition</text>
              <text span={3} {...CAPS} color="#8C837B">Printer · paper</text>
              <text span={1} {...CAPS} color="#8C837B">Retail</text>
              <text span={2} {...CAPS} color="#8C837B">Artist gets</text>
            </grid>
            <box w="100%" h={1} bg="#332E29" />
            <EditionRow work="Low Tide, Six" artist="Marta Osei" edition="25 of 25 left" printer="Trace Studio · Hahnemühle 308gsm" retail="£420" share="£231" />
            <EditionRow work="Kiln Field" artist="Tomas Reidy" edition="4 of 12 left" printer="Bench & Rule · Somerset Velvet" retail="£760" share="£418" />
            <EditionRow work="Blue Hour Study" artist="Ana Vidal" edition="19 of 30 left" printer="Trace Studio · Canson Rag 310gsm" retail="£295" share="£162" />
            <EditionRow work="The Long Field" artist="Nia Prosser" edition="2 of 8 left" printer="Ardal Press · cotton rag, hand-torn" retail="£1,180" share="£649" />
            <text size={14} font={t.font.body} color="#8C837B" lh={1.7} pad={{ t: 22 }}>
              The artist's share is 55% of retail, paid within fourteen days of sale. Printing, framing,
              shipping, insurance and our own margin come out of the rest, and we will show you that
              breakdown for any work if you ask for it.
            </text>
          </box>
        </box>
      </section>

      {/* ── 3. how an edition works ──────────────────────────────── */}
      <section w="100%" pad={{ t: 112, b: 112, l: 32, r: 32 }} mobile={{ pad: { t: 60, b: 60, l: 20, r: 20 } }}>
        <grid cols={12} gap={40} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }}>
          <col span={5} gap={20} pad={{ t: 60 }} mobile={{ pad: { t: 0 } }}>
            <img src={M.print_macro.id} w="100%" h={520} fit="cover" radius={2} mobile={{ h: 300 }} />
            <text size={13} font={t.font.body} color={t.color.muted} lh={1.6}>
              Giclée on 308gsm cotton rag, photographed at 4×. The tooth of the paper is the reason a
              print does not look like a poster.
            </text>
          </col>
          <col span={7} gap={30}>
            <text {...CAPS} color={t.color.accent}>
              For people who have never bought one
            </text>
            <heading tag="h2" font={t.font.head} size={52} lh={1.08} color={t.color.ink} tablet={{ size: 40 }} mobile={{ size: 31 }} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              How an edition works
            </heading>
            <text size={18} font={t.font.body} color={t.color.muted} lh={1.7} maxw={560}>
              An edition is a fixed number of prints, made once, signed and numbered, then the file is
              retired. It is not a poster and it is not a unique painting, and the price sits honestly
              between them.
            </text>
            <box dir="column" gap={0} w="100%" m={{ t: 6 }}>
              {steps.map(([n, head, body], i) => (
                <col w="100%" gap={0}>
                  <box w="100%" h={1} bg={t.color.rule} />
                <row
                  w="100%"
                  gap={22}
                  align="flex-start"
                  pad={{ t: 22, b: 22, l: i * 26 }}
                  mobile={{ pad: { l: 0, t: 18, b: 18 }, gap: 14 }}
                >
                  <text font={t.font.head} size={30} lh={1} color={t.color.warm} w={54}>
                    {n}
                  </text>
                  <col gap={6} flex={1}>
                    <heading tag="h3" font={t.font.body} size={17} weight={500} color={t.color.ink}>
                      {head}
                    </heading>
                    <text size={15} font={t.font.body} color={t.color.muted} lh={1.65}>
                      {body}
                    </text>
                  </col>
                </row>
                </col>
              ))}
            </box>
          </col>
        </grid>
      </section>

      {/* ── 4. framing, hanging, what it looks like at home ───────── */}
      <section w="100%" bg={t.color.shade} pad={{ t: 112, b: 112, l: 32, r: 32 }} mobile={{ pad: { t: 60, b: 60, l: 20, r: 20 } }}>
        <grid cols={12} gap={30} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }}>
          <box span={7} w="100%">
            <img src={M.gallery_wall.id} w="100%" h={560} fit="cover" radius={2} mobile={{ h: 320 }} />
          </box>
          <col span={5} gap={22} pad={{ t: 90, l: 10 }} mobile={{ pad: { t: 0, l: 0 } }}>
            <heading tag="h2" font={t.font.head} size={46} lh={1.1} color={t.color.ink} tablet={{ size: 36 }} mobile={{ size: 30 }} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
              Framing, hanging, and what a print actually looks like at home
            </heading>
            <text size={17} font={t.font.body} color={t.color.muted} lh={1.7}>
              Buy it unframed and take it to a framer, or add our oak or black frame with museum glass
              for 95. We ship framed works in a crate and we have broken two in three years.
            </text>
            <box bg={t.color.paper} pad={26} radius={2} dir="column" gap={14} border={[1, t.color.rule]} w="100%">
              <text {...CAPS} color={t.color.ink}>
                Hang it like this
              </text>
              <text size={15} font={t.font.body} color={t.color.muted} lh={1.65}>
                Centre at 145cm from the floor, a hand's width above a sofa back, and give a small work
                more wall than you think it needs. Museum glass kills reflections; north light is
                kindest to paper.
              </text>
            </box>
          </col>
        </grid>
      </section>

      {/* ── 5. the artists ───────────────────────────────────────── */}
      <section w="100%" pad={{ t: 112, b: 112, l: 32, r: 32 }} mobile={{ pad: { t: 60, b: 60, l: 20, r: 20 } }}>
        <grid cols={12} gap={40} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }}>
          <col span={6} gap={24}>
            <text {...CAPS} color={t.color.accent}>
              The artists, and how we choose them
            </text>
            <row align="flex-end" gap={16} wrap="wrap">
              <heading tag="h2" font={t.font.head} size={100} lh={1} color={t.color.ink} mobile={{ size: 64 }} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
                One in forty
              </heading>
            </row>
            <text size={18} font={t.font.body} color={t.color.muted} lh={1.7} maxw={520}>
              We take on roughly one artist in forty who approaches us, and we go and see the work in
              person before we do. Artists keep every right except the edition itself.
            </text>
            <box w="100%" h={1} bg={t.color.rule} m={{ t: 8, b: 8 }} />
            <text size={16} font={t.font.body} color={t.color.muted} lh={1.7} maxw={520}>
              No exclusivity clauses, no first refusal on future work, no clause that follows them to a
              gallery. When an edition sells out, the relationship is finished unless both of us want
              another one.
            </text>
          </col>
          <box span={6} w="100%" pad={{ t: 40 }} mobile={{ pad: { t: 0 } }}>
            <img src={M.artist_studio.id} w="100%" h={600} fit="cover" radius={2} mobile={{ h: 340 }} />
          </box>
        </grid>
      </section>

      {/* ── 6. returns, condition and resale ─────────────────────── */}
      <section w="100%" bg={t.color.paper} pad={{ t: 100, b: 100, l: 32, r: 32 }} mobile={{ pad: { t: 60, b: 60, l: 20, r: 20 } }}>
        <grid cols={12} gap={40} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }}>
          <heading tag="h2" span={4} font={t.font.head} size={44} lh={1.1} color={t.color.ink} mobile={{ size: 30 }} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            Returns, condition and resale
          </heading>
          <col span={8} gap={0} pad={{ t: 10 }}>
            {facts.map(([head, body]) => (
              <col w="100%" gap={0}>
                <box w="100%" h={1} bg={t.color.rule} />
              <row w="100%" gap={28} align="flex-start" pad={{ t: 24, b: 24 }} mobile={{ gap: 8, dir: 'column' }}>
                <heading tag="h3" font={t.font.head} size={24} lh={1.2} color={t.color.ink} w={180}>
                  {head}
                </heading>
                <text size={16} font={t.font.body} color={t.color.muted} lh={1.7} flex={1}>
                  {body}
                </text>
              </row>
              </col>
            ))}
          </col>
        </grid>
      </section>

      {/* ── 7. instalments ───────────────────────────────────────── */}
      <section w="100%" bg={t.color.accent} pad={{ t: 96, b: 96, l: 32, r: 32 }} mobile={{ pad: { t: 56, b: 56, l: 20, r: 20 } }}>
        <grid cols={12} gap={36} w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} align="center">
          <col span={5} gap={20}>
            <heading tag="h2" font={t.font.head} size={92} lh={1} color="#FFFFFF" mobile={{ size: 56 }}>
              Four payments
            </heading>
            <text {...CAPS} color="#E5D5FF">
              No interest · no credit check · no lender
            </text>
          </col>
          <col span={7} gap={22} pad={{ l: 20 }} mobile={{ pad: { l: 0 } }}>
            <text size={19} font={t.font.body} color="#FFFFFF" lh={1.7}>
              Split anything over 300 into four monthly payments with no interest and no credit check,
              because it is our money at risk, not a lender's.
            </text>
            <grid cols={4} gap={12} w="100%" mobile={{ gridCols: 2 }}>
              {['Today', 'Month two', 'Month three', 'Month four'].map((label) => (
                <col gap={4} pad={[14, 16]} bg="#8F58E8" radius={2}>
                  <text {...CAPS} color="#E5D5FF">
                    {label}
                  </text>
                  <text size={20} font={t.font.body} weight={500} color="#FFFFFF">
                    £105
                  </text>
                </col>
              ))}
            </grid>
            <text size={14} font={t.font.body} color="#E5D5FF" lh={1.6}>
              Example shown on a £420 edition. The work ships on the first payment, not the last.
            </text>
          </col>
        </grid>
      </section>

      {/* ── 8. browse the current drop (the one centred section) ──── */}
      <section id="drop" w="100%" bg={t.color.ink} pad={{ t: 120, b: 120, l: 32, r: 32 }} mobile={{ pad: { t: 70, b: 70, l: 20, r: 20 } }}>
        <col w="100%" maxw={720} m={{ l: 'auto', r: 'auto' }} align="center" gap={26} ta="center">
          <text {...CAPS} color={t.color.warm}>
            Edition Twelve closes when it sells out
          </text>
          <heading tag="h2" font={t.font.head} size={60} lh={1.05} color={t.color.ground} ta="center" mobile={{ size: 36 }} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
            Thirty-one works, none of them printed twice.
          </heading>
          <text size={17} font={t.font.body} color="#B8AFA6" lh={1.7} ta="center" maxw={540}>
            Numbers, printers and artist shares published on every one. Fourteen days to change your
            mind, and we pay the return shipping.
          </text>
          <text
            href="#drop"
            size={16}
            weight={500}
            font={t.font.body}
            color={t.color.ink}
            bg={t.color.warm}
            pad={[17, 36]}
            radius={2}
            m={{ t: 8 }}
            tw="hover:bg-[#FFFFFF]"
          >
            Browse the current edition
          </text>
        </col>
      </section>

      {/* ── footer ───────────────────────────────────────────────── */}
      <box w="100%" bg={t.color.ink} pad={{ t: 0, b: 46, l: 32, r: 32 }} mobile={{ pad: { l: 20, r: 20, b: 32 } }}>
        <col w="100%" maxw={1240} m={{ l: 'auto', r: 'auto' }} gap={0}>
          <box w="100%" h={1} bg="#332E29" />
        <row w="100%" justify="space-between" align="center" gap={14} wrap="wrap" pad={{ t: 30 }}>
          <text size={13} font={t.font.body} color="#8C837B">
            Editionable — editions of 40 or fewer, from living artists.
          </text>
          <text size={13} font={t.font.body} color="#8C837B">
            London · hello@editionable.com
          </text>
        </row>
        </col>
      </box>
    </box>
  );
};
