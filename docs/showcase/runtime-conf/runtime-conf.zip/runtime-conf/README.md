# RUNTIME

Poster-grade. Black slab type at display scale with one orange cut — reads at 3 metres.

|  |  |
|---|---|
| **Slug** | `runtime-conf` (deploys to `/runtime-conf/`) |
| **Archetype** | oversized type as layout |
| **Industry** | Developer conference |
| **Page title** | RUNTIME — 4—5 Nov, Rotterdam |
| **Fonts** | Anton, Space Grotesk — Google Fonts, imported by Elementor automatically |
| **Elements** | 192 |
| **Images** | none — this page is type + colour only |
| **Global classes used** | 0 — built `--inline` (81 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install runtime-conf
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
runtime-conf/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/runtime-conf.page.jsx          the page itself: layout + copy
    page.bundle.json            the built, inline bundle that gets deployed
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FFFFFF` |
| `ink` | `#000000` |
| `flash` | `#FF4A00` |
| `grid` | `#EAEAEA` |
| `night` | `#12121A` |

Change a value, re-run `npx exjsx-kit install runtime-conf`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/runtime-conf.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — this page ships none by design; it is built from type, colour and layout. To add
some, create `site/data/media.manifest.mjs` following the pattern in any image-bearing page.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
