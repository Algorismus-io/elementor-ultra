# Byte Cubs

Primary blocks and rounded cards — reads instantly as for-kids without being childish.

|  |  |
|---|---|
| **Slug** | `byte-cubs` (deploys to `/byte-cubs/`) |
| **Archetype** | overlapping stacked cards |
| **Industry** | Children's coding education |
| **Page title** | Byte Cubs — after-school coding clubs for 7 to 12 year olds |
| **Fonts** | Fredoka, Nunito — Google Fonts, imported by Elementor automatically |
| **Elements** | 120 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (88 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install byte-cubs
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
byte-cubs/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/byte-cubs.page.jsx             the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FFF9E8` |
| `ink` | `#20223A` |
| `berry` | `#FF5D8F` |
| `sky` | `#3AA7FF` |
| `lime` | `#8BE04E` |
| `sun` | `#FFC93C` |

Change a value, re-run `npx exjsx-kit install byte-cubs`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/byte-cubs.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `kids_building` | `media/kids_building.jpg` | Two kids at a laptop building a game together in an after-school club room |
| `showcase_night` | `media/showcase_night.jpg` | Parents playing the games their children built at a Byte Cubs showcase night |
| `sketch_desk` | `media/sketch_desk.jpg` | A desk covered in hand-drawn game sketches and level plans |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
