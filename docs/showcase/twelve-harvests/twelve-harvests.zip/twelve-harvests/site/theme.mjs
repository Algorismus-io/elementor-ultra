/** Twelve Harvests — brand tokens. Every hex on the page comes from here. */
export default defineTheme({
  name: 'twelve-harvests',
  color: {
    ground: '#FCF8F2',
    ink: '#2B1D14',
    cherry: '#9E2B2B',
    leaf: '#4C6B3C',
    cream: '#EFE1CE',
    rule: '#D9C9B4',
  },
  font: { head: 'Abril Fatface', body: 'Work Sans' },
  mode: 'literal',
});
