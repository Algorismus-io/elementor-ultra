/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "long-barn-weddings--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'long-barn-weddings--';

export default [
  { slot: `${PREFIX}barn_interior`, file: join(MEDIA_DIR, "barn_interior.jpg"), alt: "The Long Barn dressed for a wedding: long trestle tables running the length of a 17th century oak truss roof strung with festoon lights" },
  { slot: `${PREFIX}farmhouse_morning`, file: join(MEDIA_DIR, "farmhouse_morning.jpg"), alt: "The farmhouse at The Long Barn on a Sunday morning, where twenty-two guests sleep and breakfast is served" },
  { slot: `${PREFIX}meadow_ceremony`, file: join(MEDIA_DIR, "meadow_ceremony.jpg"), alt: "An outdoor wedding ceremony in the meadow at The Long Barn" },
];
