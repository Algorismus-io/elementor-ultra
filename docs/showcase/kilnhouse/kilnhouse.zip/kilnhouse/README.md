# Kilnhouse

Warm clay palette and beautiful still lifes; the glaze swatches are a real designer's move.

|  |  |
|---|---|
| **Slug** | `kilnhouse` (deploys to `/kilnhouse/`) |
| **Archetype** | catalogue grid |
| **Industry** | DTC cookware |
| **Page title** | Kilnhouse — Flame-fired stoneware from Coimbra |
| **Fonts** | Fraunces, Karla — Google Fonts, imported by Elementor automatically |
| **Elements** | 175 |
| **Images** | 4 |
| **Global classes used** | 0 — built `--inline` (77 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install kilnhouse
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
kilnhouse/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/kilnhouse.page.jsx             the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F4EFE6` |
| `ink` | `#221D18` |
| `clay` | `#B4572F` |
| `glaze` | `#2F4A46` |
| `chalk` | `#FFFFFF` |
| `rule` | `#CDC3B4` |

Change a value, re-run `npx exjsx-kit install kilnhouse`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/kilnhouse.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `catalogue_still` | `media/catalogue_still.jpg` | Six stoneware shapes laid out on a linen cloth |
| `glaze_macro` | `media/glaze_macro.jpg` | Macro detail of a flame-fired glaze surface |
| `kiln_firing` | `media/kiln_firing.jpg` | Stoneware being fired in the Coimbra kiln |
| `kitchen_use` | `media/kitchen_use.jpg` | Kilnhouse braiser in use on a home kitchen hob |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
