/** Hardin Drains — brutal emergency palette. Full-bleed colour blocks, hard seams. */
export default defineTheme({
  name: 'hardin',
  color: {
    ground: '#FFDD00',   // yellow slab
    ink: '#000000',      // hard black type
    alert: '#D40000',    // call-now red
    block: '#111111',    // black slab
    grey: '#DEDEDE',     // grey slab (accounts)
    white: '#FFFFFF',
  },
  font: { head: 'Archivo Black', body: 'Roboto Mono' },
  mode: 'literal',
});
