/** Repeating content units — registered as native Elementor components (content props only). */
import theme from '../theme.mjs';

const c = theme.lit;

/** One frame of the week's filmstrip. */
export const FilmCard = ({ name = 'Item', farm = 'Farm', dist = '0 km', note = '' }) => (
    <box
      cls="film-card"
      w={272}
      raw="flex: 0 0 272px; scroll-snap-align: start;"
      bg={c.ground}
      pad={{ t: 22, r: 22, b: 24, l: 22 }}
      gap={10}
      dir="column"
      justify="flex-start"
      border={[1, c.rule]}
      shadow={[[2, 0, 0, c.sun], [10, 24, -12, 'rgba(0,0,0,0.45)']]}
      hover={{ bg: '#FFFFFF', shadow: [[2, 0, 0, c.field], [14, 30, -12, 'rgba(0,0,0,0.55)']] }}
    >
      <text size={12} weight={600} ls={0.14} color={c.soil} font={theme.litFont('body')} tw="uppercase">
        {dist}
      </text>
      <heading tag="h3" size={22} lh={1.15} color={c.ink} font={theme.litFont('head')} tw="max-md:text-[20px]">
        {name}
      </heading>
      <text size={14} weight={600} color={c.field} font={theme.litFont('body')}>
        {farm}
      </text>
      <text size={15} lh={1.5} color={c.ink} font={theme.litFont('body')} raw="opacity: 0.78;">
        {note}
      </text>
    </box>
  );

/** One producer in the grower grid. */
export const GrowerRow = ({ farm = 'Farm', dist = '0 km', detail = '' }) => (
    <box
      cls="grower-row"
      w="100%"
      dir="column"
      gap={6}
      pad={{ t: 20, r: 20, b: 22, l: 0 }}
      raw="border-top: 1px solid #D2D9C7;"
      hover={{ raw: 'background: rgba(78,123,58,0.06);' }}
    >
      <box w="100%" dir="row" justify="space-between" align="flex-end" gap={12}>
        <heading tag="h3" size={19} lh={1.2} color={c.ink} font={theme.litFont('head')} tw="max-md:text-[17px]">
          {farm}
        </heading>
        <text size={14} weight={600} color={c.soil} font={theme.litFont('body')}>
          {dist}
        </text>
      </box>
      <text size={15} lh={1.5} color={c.ink} font={theme.litFont('body')} raw="opacity: 0.75;">
        {detail}
      </text>
    </box>
  );

/** One ordering route. */
export const RouteCard = ({ no = '01', label = 'Route', body = '' }) => (
    <box cls="route-card" w="100%" dir="column" gap={12} pad={{ t: 28, r: 24, b: 28, l: 24 }} bg="#FFFFFF" border={[1, c.rule]}>
      <text size={13} weight={700} ls={0.18} color={c.sun} font={theme.litFont('body')}>
        {no}
      </text>
      <heading tag="h3" size={26} lh={1.15} color={c.ink} font={theme.litFont('head')} tw="max-md:text-[22px]">
        {label}
      </heading>
      <text size={16} lh={1.6} color={c.ink} font={theme.litFont('body')} raw="opacity: 0.78;">
        {body}
      </text>
    </box>
  );
