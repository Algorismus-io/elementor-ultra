# Second Spring

Serif long-form that treats the reader as an adult; portraits used well.

|  |  |
|---|---|
| **Slug** | `second-spring` (deploys to `/second-spring/`) |
| **Archetype** | single-column long-form |
| **Industry** | Menopause telehealth |
| **Page title** | Second Spring |
| **Fonts** | Instrument Serif, Figtree — Google Fonts, imported by Elementor automatically |
| **Elements** | 171 |
| **Images** | 2 |
| **Global classes used** | 0 — built `--inline` (88 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install second-spring
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
second-spring/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/second-spring.page.jsx         the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FBF6F1` |
| `ink` | `#2A2320` |
| `rose` | `#C36A63` |
| `sage` | `#7C9382` |
| `deep` | `#4A3A38` |

Change a value, re-run `npx exjsx-kit install second-spring`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/second-spring.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `consult_scene` | `media/consult_scene.jpg` | A menopause-trained doctor speaking with a patient over a video consultation |
| `portrait_calm` | `media/portrait_calm.jpg` | A woman in her fifties sitting calmly by a window |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
