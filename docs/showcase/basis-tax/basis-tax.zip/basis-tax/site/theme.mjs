/** Basis — design tokens. Every page receives these as `theme`. */
export default defineTheme({
  name: 'basis',
  color: {
    ground: '#0C0D12',   // page background
    lift: '#12131B',     // raised band background
    ink: '#E6E7F0',      // display + body text
    dim: '#9497AC',      // secondary body copy (ink, dimmed)
    chain: '#7A5CFF',    // accent / on-chain
    gain: '#3ED598',     // positive figures
    loss: '#FF5C5C',     // flags, negative figures
    line: '#1E2029',     // hairlines and borders
  },
  font: { head: 'Major Mono Display', body: 'Sora' },
  mode: 'literal',
});
