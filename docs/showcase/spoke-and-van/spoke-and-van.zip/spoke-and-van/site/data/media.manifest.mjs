/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "spoke-and-van--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'spoke-and-van--';

export default [
  { slot: `${PREFIX}hands_repair`, file: join(MEDIA_DIR, "hands_repair.jpg"), alt: "Mechanic hands adjusting a bicycle derailleur at the kerb" },
  { slot: `${PREFIX}van_open`, file: join(MEDIA_DIR, "van_open.jpg"), alt: "The Spoke & Van mobile workshop with its rear doors open" },
];
