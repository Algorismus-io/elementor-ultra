/** Byte Cubs design tokens — children's coding clubs. */
export default defineTheme({
  name: 'byte-cubs',
  color: {
    ground: '#FFF9E8',
    ink: '#20223A',
    berry: '#FF5D8F',
    sky: '#3AA7FF',
    lime: '#8BE04E',
    sun: '#FFC93C',
    white: '#FFFFFF',
    dim: '#C9CCE0',   // body copy on ink
  },
  font: { head: 'Fredoka', body: 'Nunito' },
  mode: 'literal',
});
