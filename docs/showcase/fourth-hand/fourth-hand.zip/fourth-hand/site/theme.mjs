/** Fourth Hand — vintage watch marketplace tokens. */
export default defineTheme({
  name: 'fourth-hand',
  color: {
    ground: '#131417',   // page ground
    ink: '#E9E7E2',      // primary text
    gold: '#C9A227',     // accent, grades, rules
    steel: '#8E959C',    // secondary text
    card: '#1C1E22',     // catalogue cells
    line: '#2A2D33',     // hairlines
  },
  font: { head: 'Bodoni Moda', body: 'Lora' },
  mode: 'literal',
});
