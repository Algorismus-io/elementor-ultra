/** Sinkstone — eleven claims. Numbered manifesto. Slug: sinkstone */
export const meta = {
  title: 'Sinkstone — Eleven claims. Every one of them checkable.',
  seo: {
    title: 'Sinkstone — a public registry for enhanced rock weathering',
    description:
      'Eleven claims, every one checkable. Every tonne is linked to the field, the sample batch, the lab and the retirement record.',
  },
};

/* ── palette (mirrors theme.mjs) ─────────────────────────────────────────── */
const C = {
  ground: '#0B0F0D',
  raised: '#0E1512',
  ink: '#E4EDE7',
  mineral: '#8FD6B4',
  warn: '#E0C060',
  line: '#1E2724',
  muted: '#7E8F86',
};
const HEAD = 'Space Mono';
const BODY = 'IBM Plex Mono';
const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* fresh instance per call — never reuse a node */
const Rule = () => <div w="100%" h={1} bg={C.line} />;

const Eyebrow = ({ children, tone = C.mineral }) => (
  <text font={HEAD} size={12} weight={700} ls="2.4px" color={tone} w="100%">
    {children}
  </text>
);

/* ── repeaters (content props only) ──────────────────────────────────────── */

const Claim = defineComponent(
  ({ num = '01', body = '', href = '/registry/', link = 'See the data' }) => (
    <div w="100%" pad={0} gap={0}>
      <Rule />
      <grid
        cols={12}
        gap={20}
        w="100%"
        pad={{ t: 26, b: 26 }}
        hover={{ bg: '#101815' }}
      >
        <text span={2} font={HEAD} size={22} weight={700} color={C.mineral} lh={1.25} mobile={{ size: 18 }}>
          {num}
        </text>
        <text span={7} font={BODY} size={17} color={C.ink} lh={1.6} mobile={{ size: 15 }}>
          {body}
        </text>
        <text
          span={3}
          href={href}
          font={HEAD}
          size={12}
          weight={700}
          ls="1.6px"
          color={C.muted}
          lh={1.6}
          ta="right"
          hover={{ color: C.mineral }}
          mobile={{ ta: 'left' }}
        >
          {link} →
        </text>
      </grid>
    </div>
  ),
  {
    title: 'Sinkstone claim row',
    props: {
      num: { label: 'Number', group: 'Claim' },
      body: { label: 'Claim text', group: 'Claim' },
      href: { label: 'Data link', group: 'Claim' },
      link: { label: 'Link label', group: 'Claim' },
    },
  },
);

const Step = defineComponent(
  ({ idx = '1', name = '', detail = '', artifact = '' }) => (
    <div span={2} w="100%" gap={12} pad={{ t: 20 }} border={[1, C.line]} radius={2}>
      <div w="100%" pad={{ l: 16, r: 16 }} gap={10}>
        <text font={HEAD} size={11} weight={700} ls="2px" color={C.mineral}>
          STEP {idx}
        </text>
        <text font={HEAD} size={16} weight={700} color={C.ink} lh={1.35}>
          {name}
        </text>
        <text font={BODY} size={13} color={C.muted} lh={1.6}>
          {detail}
        </text>
      </div>
      <div w="100%" pad={{ t: 14, b: 14, l: 16, r: 16 }} bg="#0A100E">
        <text font={BODY} size={11} ls="0.6px" color={C.warn}>
          {artifact}
        </text>
      </div>
    </div>
  ),
  {
    title: 'Sinkstone measurement step',
    props: {
      idx: { label: 'Step number', group: 'Step' },
      name: { label: 'Step name', group: 'Step' },
      detail: { label: 'Detail', group: 'Step' },
      artifact: { label: 'Artifact left behind', group: 'Step' },
    },
  },
);

const LedgerRow = defineComponent(
  ({ id = '', date = '', tonnes = '', holder = '', status = 'RETIRED' }) => (
    <div w="100%" gap={0} pad={0}>
      <Rule />
      <grid cols={12} gap={16} w="100%" pad={{ t: 14, b: 14 }} hover={{ bg: '#0F1613' }}>
        <text span={3} font={BODY} size={13} color={C.mineral} lh={1.5}>
          {id}
        </text>
        <text span={2} font={BODY} size={13} color={C.muted} lh={1.5}>
          {date}
        </text>
        <text span={2} font={BODY} size={13} color={C.ink} lh={1.5}>
          {tonnes}
        </text>
        <text span={3} font={BODY} size={13} color={C.ink} lh={1.5}>
          {holder}
        </text>
        <text span={2} font={HEAD} size={11} weight={700} ls="1.4px" color={C.warn} lh={1.6} ta="right" mobile={{ ta: 'left' }}>
          {status}
        </text>
      </grid>
    </div>
  ),
  {
    title: 'Sinkstone ledger row',
    props: {
      id: { label: 'Certificate id', group: 'Ledger' },
      date: { label: 'Retired on', group: 'Ledger' },
      tonnes: { label: 'Tonnes', group: 'Ledger' },
      holder: { label: 'Holder', group: 'Ledger' },
      status: { label: 'Status', group: 'Ledger' },
    },
  },
);

const Verifier = defineComponent(
  ({ name = '', scope = '', conflict = '', href = '/registry/verifiers/' }) => (
    <div w="100%" gap={0} pad={0}>
      <Rule />
      <grid cols={12} gap={20} w="100%" pad={{ t: 24, b: 24 }}>
        <div span={4} gap={8} w="100%">
          <text font={HEAD} size={17} weight={700} color={C.ink} lh={1.35}>
            {name}
          </text>
          <text
            href={href}
            font={HEAD}
            size={11}
            weight={700}
            ls="1.4px"
            color={C.muted}
            hover={{ color: C.mineral }}
          >
            Engagement file →
          </text>
        </div>
        <text span={4} font={BODY} size={14} color={C.ink} lh={1.65}>
          {scope}
        </text>
        <text span={4} font={BODY} size={14} color={C.warn} lh={1.65}>
          {conflict}
        </text>
      </grid>
    </div>
  ),
  {
    title: 'Sinkstone verifier row',
    props: {
      name: { label: 'Verifier', group: 'Verifier' },
      scope: { label: 'Scope of work', group: 'Verifier' },
      conflict: { label: 'Disclosed conflict', group: 'Verifier' },
      href: { label: 'Engagement file link', group: 'Verifier' },
    },
  },
);

const Failure = defineComponent(
  ({ when = '', headline = '', body = '', href = '/registry/incidents/' }) => (
    <div span={4} w="100%" gap={14} pad={24} bg="#0F1512" border={[1, C.line]} radius={2} hover={{ border: [1, '#3A4A40'] }}>
      <text font={HEAD} size={11} weight={700} ls="2px" color={C.warn}>
        {when}
      </text>
      <text font={HEAD} size={19} weight={700} color={C.ink} lh={1.35}>
        {headline}
      </text>
      <text font={BODY} size={14} color={C.muted} lh={1.7}>
        {body}
      </text>
      <text href={href} font={HEAD} size={12} weight={700} ls="1.4px" color={C.mineral} hover={{ color: C.ink }}>
        Read the write-up →
      </text>
    </div>
  ),
  {
    title: 'Sinkstone failure case',
    props: {
      when: { label: 'Date', group: 'Failure' },
      headline: { label: 'Headline', group: 'Failure' },
      body: { label: 'What happened', group: 'Failure' },
      href: { label: 'Write-up link', group: 'Failure' },
    },
  },
);

/* ── data ────────────────────────────────────────────────────────────────── */

const CLAIMS = [
  ['01', 'No tonne is issued before the soil samples are in. We have never issued a forward credit and never will.', '/registry/claims/01/'],
  ['02', 'Every certificate links to the raw lab data, including the runs that disagreed with each other.', '/registry/claims/02/'],
  ['03', 'Retirement is final and public. You cannot quietly unretire a tonne here, because the ledger does not have that function.', '/registry/claims/03/'],
  ['04', 'Every field has a name, a boundary polygon and an operator we can put you in a room with.', '/registry/claims/04/'],
  ['05', 'Sampling depth, date and method are recorded per batch. If a batch is resampled, both results stay visible.', '/registry/claims/05/'],
  ['06', 'We publish the lab, the instrument and the run identifier. Anonymous chemistry is not evidence.', '/registry/claims/06/'],
  ['07', 'Weathering is modelled with published parameters, and the model version is stamped onto every tonne it issued.', '/registry/claims/07/'],
  ['08', 'Uncertainty is carried through to the certificate. We publish the deduction, not only the headline number.', '/registry/claims/08/'],
  ['09', 'Our fee is flat and published per transaction. It does not scale with the price you agree to pay.', '/registry/claims/09/'],
  ['10', 'Any tonne can be challenged in public. The challenge and its outcome stay on the record either way.', '/registry/claims/10/'],
  ['11', 'When we get it wrong we void the tonnes and say so at the top of the page, permanently.', '/registry/claims/11/'],
];

const STEPS = [
  ['1', 'Field registered', 'Boundary polygon, soil series, baseline cores and the operator agreement are filed before any rock moves.', 'BASELINE-CORE-SET'],
  ['2', 'Rock applied', 'Tonnage, grain-size distribution and application date logged against the field, per spreading pass.', 'APPLICATION-LOG'],
  ['3', 'Samples taken', 'Fixed depth, fixed grid, fixed method. Every batch carries its own chain-of-custody record.', 'BATCH-CUSTODY-CHAIN'],
  ['4', 'Lab run', 'Named lab, named instrument, run identifier. Duplicate and disagreeing runs are published too.', 'RAW-LAB-EXPORT'],
  ['5', 'Model applied', 'Published parameters, versioned. The version that issued the tonne is stamped on the tonne.', 'MODEL-V4.2'],
  ['6', 'Certificate issued', 'Uncertainty deduction applied, then the tonne lists — linked back through every step above.', 'CERT-PDF + JSON'],
];

const LEDGER = [
  ['SK-2026-0418-A', '2026-04-18', '2,400 t', 'Northwind Logistics', 'RETIRED'],
  ['SK-2026-0402-C', '2026-04-02', '860 t', 'Halden Insurance Group', 'RETIRED'],
  ['SK-2026-0311-B', '2026-03-11', '1,150 t', 'Marrow & Fen Foods', 'RETIRED'],
  ['SK-2026-0227-A', '2026-02-27', '318 t', 'Cartwright Steel', 'RETIRED'],
  ['SK-2025-1119-D', '2025-11-19', '1,140 t', 'Basalt Field 07 — sampling error', 'VOIDED'],
];

const VERIFIERS = [
  ['Meridian Soil Assay', 'Independent re-sampling on 20 percent of batches, unannounced, at our cost.', 'Also runs paid analysis for two operators listed here. Both engagements are named in the file.'],
  ['Kolbe & Ash Metrology', 'Instrument calibration audits and blind duplicate submission across all partner labs.', 'A partner holds equity in an aggregator that buys tonnes here. Recused from pricing work.'],
  ['Delta Weathering Review', 'Model parameter review and annual re-derivation of the uncertainty deduction.', 'Authored two of the parameters they now review. Disclosed since 2024, second reviewer required.'],
];

const FAILURES = [
  ['NOVEMBER 2025', '1,140 tonnes voided', 'A sampling error at Basalt Field 07 put the cores at the wrong depth for two batches. We caught it ourselves, voided every affected tonne, and refunded at the original clearing price.', '/registry/incidents/2025-basalt-07/'],
  ['JUNE 2025', 'Lab disagreement published', 'Two labs returned cation results 19 percent apart on the same batch. We published both, held issuance for eleven weeks, and re-ran under a third lab before anything listed.', '/registry/incidents/2025-lab-split/'],
  ['FEBRUARY 2024', 'Operator delisted', 'An operator could not produce chain-of-custody records for four batches. We delisted them, voided the unretired tonnes and named the fields involved.', '/registry/incidents/2024-custody-gap/'],
];

/* ── page ────────────────────────────────────────────────────────────────── */

export default () => (
  <box w="100%" pad={0} gap={0} bg={C.ground}>

    {/* 0 — masthead + manifesto opening (asymmetric, left-aligned) */}
    <section w="100%" pad={0} gap={0} grad={[165, '#0B0F0D', '#101A15']}>
      <div w="100%" maxw={1160} m={{ l: 'auto', r: 'auto' }} pad={{ t: 40, b: 96, l: 24, r: 24 }} gap={0}>
        <grid cols={12} gap={20} w="100%" pad={{ b: 28 }}>
          <text span={6} font={HEAD} size={13} weight={700} ls="3px" color={C.mineral}>
            SINKSTONE
          </text>
          <text span={6} font={BODY} size={12} ls="1px" color={C.muted} ta="right" mobile={{ ta: 'left' }}>
            PUBLIC REGISTRY · ENHANCED ROCK WEATHERING
          </text>
        </grid>
        <Rule />
        <grid cols={12} gap={40} w="100%" pad={{ t: 64 }}>
          <div span={8} w="100%" gap={28}>
            <h1
              font={HEAD}
              size={68}
              weight={700}
              color={C.ink}
              lh={1.06}
              ls="-1.5px"
              tablet={{ size: 52 }}
              mobile={{ size: 34, ls: "-0.5px" }}
            >
              Eleven claims.<br />Every one of them <em>checkable</em>.
            </h1>
            <text font={BODY} size={17} color={C.muted} lh={1.75} maxw={620} mobile={{ size: 15 }}>
              Sinkstone is a public registry for enhanced rock weathering. Every tonne is linked to the field, the sample batch, the lab, and the retirement record. If any of that is missing, the tonne does not list.
            </text>
            <div w="hug" pad={0} gap={0}>
              <text
                href="/registry/"
                font={HEAD}
                size={14}
                weight={700}
                ls="1.6px"
                color={C.ground}
                bg={C.mineral}
                pad={{ t: 16, b: 16, l: 28, r: 28 }}
                radius={2}
                hover={{ bg: C.ink }}
              >
                Open the registry →
              </text>
            </div>
          </div>
          <div span={4} w="100%" gap={0} border={[1, C.line]} radius={2} pad={0}>
            <div w="100%" pad={{ t: 18, b: 18, l: 18, r: 18 }} gap={4} bg="#0A100E">
              <text font={HEAD} size={11} weight={700} ls="2px" color={C.mineral}>
                LIVE ON THE LEDGER
              </text>
            </div>
            <div w="100%" pad={{ t: 20, b: 20, l: 18, r: 18 }} gap={6}>
              <text font={HEAD} size={30} weight={700} color={C.ink}>41,208 t</text>
              <text font={BODY} size={12} color={C.muted} lh={1.6}>retired, irreversibly</text>
            </div>
            <Rule />
            <div w="100%" pad={{ t: 20, b: 20, l: 18, r: 18 }} gap={6}>
              <text font={HEAD} size={30} weight={700} color={C.ink}>0 t</text>
              <text font={BODY} size={12} color={C.muted} lh={1.6}>issued forward, ever</text>
            </div>
            <Rule />
            <div w="100%" pad={{ t: 20, b: 20, l: 18, r: 18 }} gap={6}>
              <text font={HEAD} size={30} weight={700} color={C.warn}>1,140 t</text>
              <text font={BODY} size={12} color={C.muted} lh={1.6}>voided by us, published</text>
            </div>
          </div>
        </grid>
      </div>
    </section>

    {/* 1 — eleven numbered claims */}
    <section w="100%" pad={0} gap={0} bg={C.ground} id="claims">
      <div w="100%" maxw={1160} m={{ l: 'auto', r: 'auto' }} pad={{ t: 96, b: 104, l: 24, r: 24 }} gap={0}>
        <grid cols={12} gap={20} w="100%" pad={{ b: 44 }}>
          <div span={7} w="100%" gap={16}>
            <Eyebrow>01 / THE MANIFESTO</Eyebrow>
            <h2 font={HEAD} size={34} weight={700} color={C.ink} lh={1.2} mobile={{ size: 24 }} motion={FADE}>
              Eleven claims, each one falsifiable.
            </h2>
          </div>
          <text span={5} font={BODY} size={14} color={C.muted} lh={1.75}>
            Each claim links to the record that would prove it wrong. If you find one that does not hold, the challenge goes on the register with our answer beside it.
          </text>
        </grid>
        {CLAIMS.map(([num, body, href]) => (
          <Claim num={num} body={body} href={href} link="See the data" />
        ))}
        <Rule />
      </div>
    </section>

    {/* 2 — how a tonne is measured */}
    <section w="100%" pad={0} gap={0} bg={C.raised}>
      <div w="100%" maxw={1160} m={{ l: 'auto', r: 'auto' }} pad={{ t: 96, b: 104, l: 24, r: 24 }} gap={40}>
        <div w="100%" gap={16}>
          <Eyebrow>02 / MEASUREMENT</Eyebrow>
          <h2 font={HEAD} size={34} weight={700} color={C.ink} lh={1.2} maxw={720} mobile={{ size: 24 }} motion={FADE}>
            How a tonne is measured, from field to certificate.
          </h2>
          <text font={BODY} size={15} color={C.muted} lh={1.75} maxw={680}>
            Six steps. Each one leaves an artifact that outlives the people who made it, and each artifact is readable without asking us for permission.
          </text>
        </div>
        <grid cols={6} gap={16} w="100%" tablet={{ gridCols: 3 }}>
          {STEPS.map(([idx, name, detail, artifact]) => (
            <Step idx={idx} name={name} detail={detail} artifact={artifact} />
          ))}
        </grid>
      </div>
    </section>

    {/* 3 — the retirement ledger */}
    <section w="100%" pad={0} gap={0} bg={C.ground}>
      <div w="100%" maxw={1160} m={{ l: 'auto', r: 'auto' }} pad={{ t: 96, b: 104, l: 24, r: 24 }} gap={36}>
        <grid cols={12} gap={20} w="100%">
          <div span={6} w="100%" gap={16}>
            <Eyebrow>03 / THE LEDGER</Eyebrow>
            <h2 font={HEAD} size={34} weight={700} color={C.ink} lh={1.2} mobile={{ size: 24 }} motion={FADE}>
              The retirement ledger, publicly readable.
            </h2>
          </div>
          <text span={6} font={BODY} size={14} color={C.muted} lh={1.75}>
            Retirement is a one-way write. There is no unretire function to call, no admin key that restores a tonne, and no private view of this table that differs from the one you are reading.
          </text>
        </grid>
        <div w="100%" gap={0} pad={0}>
          <grid cols={12} gap={16} w="100%" pad={{ b: 12 }}>
            <text span={3} font={HEAD} size={11} weight={700} ls="1.6px" color={C.muted}>CERTIFICATE</text>
            <text span={2} font={HEAD} size={11} weight={700} ls="1.6px" color={C.muted}>RETIRED</text>
            <text span={2} font={HEAD} size={11} weight={700} ls="1.6px" color={C.muted}>TONNES</text>
            <text span={3} font={HEAD} size={11} weight={700} ls="1.6px" color={C.muted}>HOLDER</text>
            <text span={2} font={HEAD} size={11} weight={700} ls="1.6px" color={C.muted} ta="right" mobile={{ ta: 'left' }}>STATUS</text>
          </grid>
          {LEDGER.map(([id, date, tonnes, holder, status]) => (
            <LedgerRow id={id} date={date} tonnes={tonnes} holder={holder} status={status} />
          ))}
          <Rule />
        </div>
        <text
          href="/registry/ledger/"
          font={HEAD}
          size={13}
          weight={700}
          ls="1.6px"
          color={C.mineral}
          hover={{ color: C.ink }}
        >
          Read the whole ledger →
        </text>
      </div>
    </section>

    {/* 4 — what we refuse to list */}
    <section w="100%" pad={0} gap={0} grad={[200, '#0E1512', '#0B0F0D']}>
      <div w="100%" maxw={1160} m={{ l: 'auto', r: 'auto' }} pad={{ t: 96, b: 104, l: 24, r: 24 }} gap={0}>
        <grid cols={12} gap={48} w="100%">
          <div span={6} w="100%" gap={20}>
            <Eyebrow tone={C.warn}>04 / REFUSALS</Eyebrow>
            <h2 font={HEAD} size={38} weight={700} color={C.ink} lh={1.18} mobile={{ size: 26 }} motion={FADE}>
              What we refuse to list, and why.
            </h2>
            <text font={BODY} size={16} color={C.ink} lh={1.75}>
              We do not list avoided emissions, cookstoves, forestry offsets, or anything where the counterfactual is an argument rather than a measurement.
            </text>
            <text font={BODY} size={14} color={C.muted} lh={1.75}>
              The test is simple and we apply it the same way every time: if the tonne only exists because of a story about what would otherwise have happened, it is not a tonne we can hand you evidence for.
            </text>
          </div>
          <div span={6} w="100%" gap={0} pad={0}>
            {[
              ['Avoided emissions', 'The counterfactual is unobservable. There is no sample to take.'],
              ['Cookstoves', 'Usage estimates drift, and nothing in the field can be re-measured later.'],
              ['Forestry offsets', 'Reversal risk is real and the buffer pool is an accounting device, not a measurement.'],
              ['Forward credits', 'A promise is not a tonne. Sample first, issue after.'],
              ['Unnamed labs', 'If we cannot name the instrument and the run, we cannot defend the number.'],
            ].map(([name, why]) => (
              <div w="100%" gap={0} pad={0}>
                <div w="100%" h={1} bg={C.line} />
                <div w="100%" pad={{ t: 20, b: 20 }} gap={8}>
                  <text font={HEAD} size={16} weight={700} color={C.warn} lh={1.4}>
                    {name}
                  </text>
                  <text font={BODY} size={14} color={C.muted} lh={1.65}>
                    {why}
                  </text>
                </div>
              </div>
            ))}
            <div w="100%" h={1} bg={C.line} />
          </div>
        </grid>
      </div>
    </section>

    {/* 5 — verifiers and their conflicts */}
    <section w="100%" pad={0} gap={0} bg={C.ground}>
      <div w="100%" maxw={1160} m={{ l: 'auto', r: 'auto' }} pad={{ t: 96, b: 104, l: 24, r: 24 }} gap={36}>
        <grid cols={12} gap={20} w="100%">
          <div span={7} w="100%" gap={16}>
            <Eyebrow>05 / VERIFICATION</Eyebrow>
            <h2 font={HEAD} size={34} weight={700} color={C.ink} lh={1.2} mobile={{ size: 24 }} motion={FADE}>
              Third-party verifiers, and the conflicts they carry.
            </h2>
          </div>
          <text span={5} font={BODY} size={14} color={C.muted} lh={1.75}>
            Nobody in this industry is unconflicted. Pretending otherwise is the failure mode, so we publish each engagement, who pays for it, and what the verifier had to recuse themselves from.
          </text>
        </grid>
        <div w="100%" gap={0} pad={0}>
          <grid cols={12} gap={20} w="100%" pad={{ b: 12 }}>
            <text span={4} font={HEAD} size={11} weight={700} ls="1.6px" color={C.muted}>VERIFIER</text>
            <text span={4} font={HEAD} size={11} weight={700} ls="1.6px" color={C.muted}>SCOPE</text>
            <text span={4} font={HEAD} size={11} weight={700} ls="1.6px" color={C.muted}>DISCLOSED CONFLICT</text>
          </grid>
          {VERIFIERS.map(([name, scope, conflict]) => (
            <Verifier name={name} scope={scope} conflict={conflict} href="/registry/verifiers/" />
          ))}
          <Rule />
        </div>
      </div>
    </section>

    {/* 6 — price, spread, and where the money goes */}
    <section w="100%" pad={0} gap={0} bg={C.raised}>
      <div w="100%" maxw={1160} m={{ l: 'auto', r: 'auto' }} pad={{ t: 96, b: 104, l: 24, r: 24 }} gap={44}>
        <grid cols={12} gap={48} w="100%">
          <div span={5} w="100%" gap={16}>
            <Eyebrow>06 / PRICE</Eyebrow>
            <h2 font={HEAD} size={34} weight={700} color={C.ink} lh={1.2} mobile={{ size: 24 }} motion={FADE}>
              Price, spread, and where the money goes.
            </h2>
            <text font={BODY} size={16} color={C.ink} lh={1.75}>
              Tonnes clear between 174 and 240 dollars. Our take is a flat 4 percent, published per transaction. 82 percent reaches the field operator.
            </text>
          </div>
          <div span={7} w="100%" gap={28}>
            <grid cols={12} gap={20} w="100%" pad={{ t: 4 }}>
              <div span={6} w="100%" gap={6}>
                <text font={HEAD} size={44} weight={700} color={C.mineral} lh={1.1} mobile={{ size: 32 }}>$174</text>
                <text font={BODY} size={12} ls="1px" color={C.muted}>LOWEST CLEARING PRICE, LAST 90 DAYS</text>
              </div>
              <div span={6} w="100%" gap={6}>
                <text font={HEAD} size={44} weight={700} color={C.ink} lh={1.1} mobile={{ size: 32 }}>$240</text>
                <text font={BODY} size={12} ls="1px" color={C.muted}>HIGHEST CLEARING PRICE, LAST 90 DAYS</text>
              </div>
            </grid>
            <div w="100%" gap={14}>
              {/* Gap-aware proportional bar: CSS grid tracks, not %-widths on a flex row.
                  82/14/4 flex-row children + a gap overflow by the gap total (Elementor rejects it);
                  82fr/14fr/4fr tracks hold the same proportions with the gap subtracted. */}
              <grid cols="82fr 14fr 4fr" gap={3} w="100%" h={54} mobile={{ gridCols: '82fr 14fr 4fr' }}>
                <div w="100%" h="100%" bg={C.mineral} radius={2} pad={0} />
                <div w="100%" h="100%" bg="#3F5C4E" radius={2} pad={0} />
                <div w="100%" h="100%" bg={C.warn} radius={2} pad={0} />
              </grid>
              <div w="100%" gap={0} pad={0}>
                {[
                  ['82%', 'Field operator — spreading, haulage, sampling labour', C.mineral],
                  ['14%', 'Lab work, model review and independent re-sampling', '#3F5C4E'],
                  ['4%', 'Sinkstone, flat, published on every transaction', C.warn],
                ].map(([pct, label, tone]) => (
                  <div w="100%" gap={0} pad={0}>
                    <div w="100%" h={1} bg={C.line} />
                    <grid cols={12} gap={12} w="100%" pad={{ t: 14, b: 14 }}>
                      <text span={2} font={HEAD} size={15} weight={700} color={tone}>{pct}</text>
                      <text span={10} font={BODY} size={13} color={C.muted} lh={1.6}>{label}</text>
                    </grid>
                  </div>
                ))}
                <div w="100%" h={1} bg={C.line} />
              </div>
            </div>
          </div>
        </grid>
      </div>
    </section>

    {/* 7 — failure cases we have published */}
    <section w="100%" pad={0} gap={0} bg={C.ground}>
      <div w="100%" maxw={1160} m={{ l: 'auto', r: 'auto' }} pad={{ t: 96, b: 104, l: 24, r: 24 }} gap={36}>
        <grid cols={12} gap={20} w="100%">
          <div span={7} w="100%" gap={16}>
            <Eyebrow tone={C.warn}>07 / FAILURES</Eyebrow>
            <h2 font={HEAD} size={34} weight={700} color={C.ink} lh={1.2} mobile={{ size: 24 }} motion={FADE}>
              Failure cases we have published.
            </h2>
          </div>
          <text span={5} font={BODY} size={14} color={C.muted} lh={1.75}>
            In 2025 we voided 1,140 tonnes from one site after a sampling error we caught ourselves. The write-up is on the registry, top of the page, permanently.
          </text>
        </grid>
        <grid cols={12} gap={20} w="100%" tablet={{ gridCols: 1 }}>
          {FAILURES.map(([when, headline, body, href]) => (
            <Failure when={when} headline={headline} body={body} href={href} />
          ))}
        </grid>
      </div>
    </section>

    {/* 8 — open the registry (the one centred section) */}
    <section w="100%" pad={0} gap={0} grad={[180, '#0B0F0D', '#122019']} id="open">
      <div
        w="100%"
        maxw={820}
        m={{ l: 'auto', r: 'auto' }}
        pad={{ t: 112, b: 120, l: 24, r: 24 }}
        gap={28}
        align="center"
        ta="center"
      >
        <Eyebrow>08 / OPEN ACCESS</Eyebrow>
        <h2
          font={HEAD}
          size={46}
          weight={700}
          color={C.ink}
          lh={1.15}
          ta="center"
          mobile={{ size: 28 }}
          motion={FADE}
        >
          Open the registry. Check the eleven.
        </h2>
        <text font={BODY} size={16} color={C.muted} lh={1.75} maxw={600} ta="center" mobile={{ size: 15 }}>
          No account, no sales call, no gated data room. Every field, batch, lab run and retirement is readable right now — including the ones that went wrong.
        </text>
        <div w="hug" pad={{ t: 8 }} gap={0} align="center">
          <text
            href="/registry/"
            font={HEAD}
            size={15}
            weight={700}
            ls="1.6px"
            color={C.ground}
            bg={C.mineral}
            pad={{ t: 18, b: 18, l: 34, r: 34 }}
            radius={2}
            hover={{ bg: C.ink }}
          >
            Open the registry →
          </text>
        </div>
        <text font={BODY} size={12} ls="1px" color={C.muted} ta="center">
          SINKSTONE · ENHANCED ROCK WEATHERING · EVERY TONNE, EVERY SAMPLE, ON THE RECORD
        </text>
      </div>
    </section>

  </box>
);
