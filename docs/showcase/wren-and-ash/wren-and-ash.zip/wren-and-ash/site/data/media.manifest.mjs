/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "wren-and-ash--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'wren-and-ash--';

export default [
  { slot: `${PREFIX}joinery_macro`, file: join(MEDIA_DIR, "joinery_macro.jpg"), alt: "Close view of a hand-cut dovetail joint in oak" },
  { slot: `${PREFIX}table_room`, file: join(MEDIA_DIR, "table_room.jpg"), alt: "A solid oak refectory table in a plain room" },
  { slot: `${PREFIX}timber_stack`, file: join(MEDIA_DIR, "timber_stack.jpg"), alt: "Air-drying boards stacked in stick in the timber rack" },
  { slot: `${PREFIX}workshop`, file: join(MEDIA_DIR, "workshop.jpg"), alt: "The two-person workshop in the Welsh borders" },
];
