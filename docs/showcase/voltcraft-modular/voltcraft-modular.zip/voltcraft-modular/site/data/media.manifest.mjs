/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "voltcraft-modular--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'voltcraft-modular--';

export default [
  { slot: `${PREFIX}module_front`, file: join(MEDIA_DIR, "module_front.jpg"), alt: "Voltcraft VX module front panel with knobs and patch jacks" },
  { slot: `${PREFIX}rack_patched`, file: join(MEDIA_DIR, "rack_patched.jpg"), alt: "Eurorack case patched with Voltcraft VX modules" },
  { slot: `${PREFIX}workshop_solder`, file: join(MEDIA_DIR, "workshop_solder.jpg"), alt: "Soldering a Voltcraft VX board in the Tallinn workshop" },
];
