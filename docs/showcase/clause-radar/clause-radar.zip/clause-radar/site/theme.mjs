/** Clause Radar — design tokens. */
export default defineTheme({
  name: 'clause-radar',
  color: {
    ground: '#FFFFFF',
    ink: '#101418',
    legal: '#1F3A5F',
    flag: '#B3341E',
    safe: '#2E7D5B',
    rule: '#E1E5E9',
  },
  font: { head: 'IBM Plex Serif', body: 'IBM Plex Mono' },
  mode: 'literal',
});
