/** Moss Hollow — design tokens. Every page receives these as `theme`. */
export default defineTheme({
  name: 'moss-hollow',
  color: {
    ground: '#F3F7EC',  // page background
    tile: '#E4EEDA',    // bento tile fill
    ink: '#26331F',     // display + body text
    moss: '#6E9152',    // primary accent
    berry: '#A8446B',   // secondary accent
    honey: '#E4A93C',   // highlight
    white: '#FFFFFF',
  },
  font: { head: 'Pacifico', body: 'Nunito' },
  mode: 'literal',
});
