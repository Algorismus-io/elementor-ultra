/** Content data for the Quarter Inserted page. 44 cabinets, eight taps, six pizzas. */

export const decades = [
  {
    label: 'The Seventies',
    range: '1976 — 1979',
    cabinets: ['Breakout', 'Sprint 2', 'Space Invaders', 'Asteroids', 'Galaxian', 'Lunar Lander'],
  },
  {
    label: 'The Eighties',
    range: '1980 — 1989',
    cabinets: [
      'Pac-Man', 'Ms. Pac-Man', 'Donkey Kong', 'Donkey Kong Jr.', 'Defender', 'Robotron: 2084',
      'Centipede', 'Millipede', 'Dig Dug', 'Galaga', 'Frogger', 'Q*bert', 'Joust', 'Tempest',
      'Gauntlet', 'Rampage', 'Bubble Bobble', 'Out Run',
    ],
  },
  {
    label: 'The Nineties',
    range: '1991 — 1999',
    cabinets: [
      'Street Fighter II: Champion Edition', 'Super Street Fighter II Turbo', 'Mortal Kombat II',
      'Killer Instinct', 'The King of Fighters ’98', 'Marvel vs. Capcom',
      'X-Men: Children of the Atom', 'Metal Slug', 'NBA Jam', 'Daytona USA',
      'Sega Rally Championship', 'Time Crisis', 'Puzzle Bobble', 'Windjammers',
    ],
  },
  {
    label: 'After That',
    range: '2000 — 2006',
    cabinets: [
      'Metal Slug 3', 'Capcom vs. SNK 2', 'Guilty Gear XX Accent Core',
      'Tekken 5: Dark Resurrection', 'Initial D Arcade Stage 4', 'Ketsui',
    ],
  },
];

export const cabinetCount = decades.reduce((n, d) => n + d.cabinets.length, 0); // 44

export const pinball = [
  'Medieval Madness', 'The Addams Family', 'Attack from Mars',
  'Twilight Zone', 'Theatre of Magic', 'Monster Bash',
];

export const taps = [
  { n: '01', name: 'Hallmark Bitter', note: 'Local. Four miles up the road.', abv: '3.8%' },
  { n: '02', name: 'Fifth Quarter Pale', note: 'Local. Brewed for us, badged for us.', abv: '4.4%' },
  { n: '03', name: 'Backstreet Porter', note: 'Local. Cold nights, long games.', abv: '5.0%' },
  { n: '04', name: 'Meadowgate Session IPA', note: 'Local. The one you can have three of.', abv: '4.0%' },
  { n: '05', name: 'Keller Pils', note: 'Lager that is actually good. Unfiltered.', abv: '4.8%' },
  { n: '06', name: 'Continental Helles', note: 'Lager that is actually good. Very cold.', abv: '4.6%' },
  { n: '07', name: 'House Dry Cider', note: 'No apple sweets in it.', abv: '5.2%' },
  { n: '08', name: 'The Guest Line', note: 'Rotates every Tuesday. Ask what is on.', abv: 'Varies' },
];

export const pizzas = [
  { n: '01', name: 'Fennel Sausage', desc: 'The correct order. The staff will tell you so before you finish asking.' },
  { n: '02', name: 'Margherita', desc: 'Fior di latte, basil, nothing clever. Twelve inches of restraint.' },
  { n: '03', name: 'Nduja and Honey', desc: 'Hot, then sweet, then hot again. Order a Keller Pils with it.' },
  { n: '04', name: 'Mushroom and Taleggio', desc: 'No tomato. Thyme, garlic, a lot of black pepper.' },
  { n: '05', name: 'Pepperoni', desc: 'Cupped, crisped at the edges, grease in the little bowls. Yes.' },
  { n: '06', name: 'Marinara', desc: 'No cheese at all. Tomato, oregano, garlic, oil. The purist option.' },
];

export const hours = [
  { day: 'Monday', time: 'Closed' },
  { day: 'Tuesday — Thursday', time: '4pm — midnight' },
  { day: 'Friday — Saturday', time: 'noon — 2am' },
  { day: 'Sunday', time: 'noon — 11pm' },
];

export const rules = [
  { n: '01', title: 'Over 21 after 8pm', body: 'Under-21s are welcome on the floor until 8pm, with an adult, every day we are open. After 8pm it is a bar and we will ask for ID. Bring the real one.' },
  { n: '02', title: 'No drinks on the cabinets', body: 'And we do mean it. There is a shelf beside every machine and a rail along every wall. A spilled pint is a dead board and a dead board is a month of somebody’s evenings.' },
  { n: '03', title: 'Be decent to whoever is on the machine', body: 'Coin up on the marquee, stand where they can see you, and wait. No backseat play, no leaning on the cabinet, no reaching over a stranger to hit a button.' },
  { n: '04', title: 'Free play is not a free-for-all', body: 'If there is a queue at a cabinet, it is one game and hand over. Tournament nights, the tournament machines are for the tournament from 7pm.' },
];
