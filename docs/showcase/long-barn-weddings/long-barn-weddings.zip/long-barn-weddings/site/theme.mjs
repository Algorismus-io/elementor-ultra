/** The Long Barn — design tokens. Every page receives these as `theme`. */
export default defineTheme({
  name: 'long-barn',
  color: {
    ground: '#F8F4ED',  // page background — limewashed plaster
    ink: '#2E2A24',     // body + display text, dark bands
    stone: '#9E9585',   // secondary / captions
    meadow: '#7B8F5A',  // timestamps, accents
    rose: '#C08B8B',    // the one warm accent
    rule: '#E0D8CB',    // hairlines, the timeline spine
    white: '#FFFFFF',
    // tinted bands (derived from the palette above, kept here so nothing is re-declared in pages)
    linen: '#F1EADD',   // warm band
    moss: '#47543A',    // darkened meadow band
    parchment: '#FCFAF6',
  },
  font: { head: 'Amatic SC', body: 'Crimson Pro' },
  mode: 'literal',
});
