/** Boardsmith design tokens. */
export default defineTheme({
  name: 'boardsmith',
  color: {
    ground: '#141414',  // page ground / dark bands
    ink: '#F0EFEC',     // light text on ground
    paper: '#E8E2D6',   // paper bands
    mark: '#E2483C',    // grease-pencil mark
    grey: '#57565A',    // rules, secondary copy
  },
  font: { head: 'Bricolage Grotesque', body: 'Onest' },
  mode: 'literal',
});
