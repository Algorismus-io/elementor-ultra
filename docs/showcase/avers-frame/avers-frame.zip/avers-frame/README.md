# Avers Frame

Almost all white space. An index rail and photographs that carry the whole page.

|  |  |
|---|---|
| **Slug** | `avers-frame` (deploys to `/avers-frame/`) |
| **Archetype** | editorial index rail |
| **Industry** | Architectural photography portfolio |
| **Page title** | Avers Frame — Architectural Photography |
| **Fonts** | Cormorant Garamond, Jost — Google Fonts, imported by Elementor automatically |
| **Elements** | 125 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (48 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install avers-frame
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
avers-frame/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/avers-frame.page.jsx           the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FFFFFF` |
| `ink` | `#101010` |
| `grey` | `#8A8A8A` |
| `hairline` | `#E4E4E4` |
| `accent` | `#1F3BFF` |

Change a value, re-run `npx exjsx-kit install avers-frame`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/avers-frame.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `detail_stair` | `media/detail_stair.jpg` | Concrete stair detail, raking daylight |
| `exterior_dusk` | `media/exterior_dusk.jpg` | Completed building photographed at dusk |
| `interior_plate` | `media/interior_plate.jpg` | Finished interior, furnished and lived in |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
