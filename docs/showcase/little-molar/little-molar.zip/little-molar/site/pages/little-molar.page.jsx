import { img } from '../data/media.mjs';

export const meta = {
  title: 'Little Molar — a children’s dental practice',
  slug: 'little-molar',
  seo: {
    title: 'Little Molar | Pediatric dentistry where the first visit is just a visit',
    description:
      'A dental practice only for children. No treatment on the first appointment — sit in the chair, count teeth, choose a sticker, go home. Check-up £46, NHS places, emergency slots every morning.',
  },
};

const MUTED = '#5C6779';
const SOFT = '#EAF7FB';

/* Three feature cards — content props only (Elementor component overrides cannot carry styles). */
const PromiseCard = defineComponent(
  ({ step, title, body }) => (
    <box
      cls="promise-card"
      tw="flex flex-col gap-4 p-8 rounded-[28px] max-md:p-6"
      bg="#FFFFFF"
      border={[1, '#F0E8D8']}
      shadow={[
        [2, 6, 0, 'rgba(36,48,67,0.04)'],
        [18, 40, -18, 'rgba(36,48,67,0.16)'],
      ]}
      hover={{ shadow: [[10, 18, 0, 'rgba(78,195,224,0.18)'], [26, 48, -20, 'rgba(36,48,67,0.22)']] }}
    >
      <text
        tw="w-[44px] h-[44px] rounded-[22px] text-center"
        bg={SOFT}
        color="#243043"
        font="Baloo 2"
        size={20}
        weight={700}
        lh={2.2}
      >
        {step}
      </text>
      <heading tag="h3" font="Baloo 2" size={24} weight={600} color="#243043" lh={1.25}>
        {title}
      </heading>
      <text font="Quicksand" size={16} color={MUTED} lh={1.75}>
        {body}
      </text>
    </box>
  ),
  {
    title: 'Promise card',
    props: {
      step: { label: 'Step', group: 'Content' },
      title: { label: 'Title', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
    },
  },
);

const CARDS = [
  {
    step: '01',
    title: 'No treatment on the first visit',
    body:
      'No treatment on the first visit, even if we spot something. We book that separately, so your child never learns that coming here means something scary happens.',
  },
  {
    step: '02',
    title: 'Your child picks the room',
    body:
      'Three treatment rooms with different themes and your child picks. It sounds small. It is the difference between a child who walks in and one who is carried in.',
  },
  {
    step: '03',
    title: 'Tell, show, do',
    body:
      'Tell, show, do. Every instrument is explained, then demonstrated on a finger or a toy, then used. Nothing touches a child that they have not already met.',
  },
];

const STATS = [
  { k: '£46', v: 'A check-up, privately. Nothing is added without you agreeing to it first.' },
  { k: '40', v: 'NHS places held for under-18s. The waiting list is currently about seven weeks.' },
  { k: '8:30 & 11:00', v: 'Emergency slots kept free every single morning for children in pain.' },
];

const Cta = ({ label = 'Book a first visit', bg = '#FF8A7A' }) => (
  <text
    href="#book"
    cls="cta"
    tw="inline-block px-8 py-4 rounded-[999px] text-center max-md:w-full hover:bg-[#FFD25E]"
    bg={bg}
    color="#243043"
    font="Baloo 2"
    size={18}
    weight={700}
  >
    {label}
  </text>
);

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full items-center gap-0" pad={0} bg={t.color.ground}>
    {/* 1 — hero (the page's ONE centred single-column section) */}
    <section tw="flex flex-col items-center text-center gap-6 w-full px-6 pt-28 pb-24 max-md:pt-16 max-md:pb-14" bg={t.color.ground}>
      <text font="Quicksand" size={14} weight={700} ls="2px" color={t.color.bubble} tw="uppercase">
        Little Molar · dentistry for children only
      </text>
      <heading
        tag="h1"
        font={t.font.head}
        size={72}
        weight={700}
        lh={1.05}
        color={t.color.ink}
        maxw={840}
        tablet={{ size: 54 }}
        mobile={{ size: 36 }}
        motion={{ effect: 'fade', trigger: 'load' }}
      >
        The first visit is a visit. Nothing else happens.
      </heading>
      <text font={t.font.body} size={19} lh={1.75} color={MUTED} maxw={640} mobile={{ size: 16 }}>
        Little Molar is a dental practice only for children. The first appointment involves sitting in
        the chair, counting teeth, choosing a sticker, and going home. No drill, no needle, no
        surprises, ever.
      </text>
      <box tw="flex flex-row items-center gap-4 pt-2 max-md:flex-col max-md:w-full">
        <Cta />
        <text font={t.font.body} size={15} weight={600} color={t.color.ink}>
          Or call us — we will talk it through first.
        </text>
      </box>
    </section>

    {/* 2 — three cards */}
    <section tw="flex flex-col gap-10 w-full px-6 py-24 max-md:py-14" bg="#FFFFFF">
      <box tw="flex flex-row items-end justify-between gap-6 w-full max-w-[1120px] mx-auto max-lg:flex-col max-lg:items-start">
        <heading tag="h2" font={t.font.head} size={40} weight={700} lh={1.15} color={t.color.ink} maxw={520} mobile={{ size: 30 }}>
          What we promise before you ever walk in
        </heading>
        <text font={t.font.body} size={16} lh={1.7} color={MUTED} maxw={380}>
          Three rules we do not bend, because a frightened child remembers the first appointment for
          the next twenty years.
        </text>
      </box>
      <grid
        cols={3}
        gap={24}
        tw="w-full max-w-[1120px] mx-auto"
        tablet={{ gridCols: 1 }}
        mobile={{ gridCols: 1 }}
        motion={{ effect: 'fade', trigger: 'scrollIn' }}
      >
        {CARDS.map((c) => (
          <PromiseCard step={c.step} title={c.title} body={c.body} />
        ))}
      </grid>
    </section>

    {/* 3 — what happens if your child says no */}
    <section tw="flex flex-row items-center gap-16 w-full px-6 py-24 max-lg:flex-col max-lg:gap-10 max-md:py-14" bg={t.color.bubble}>
      <box flex={1.05} tw="flex flex-col gap-6 min-w-0 max-w-[560px]">
        <text font={t.font.body} size={14} weight={700} ls="2px" color="#0E5F76" tw="uppercase">
          If your child says no
        </text>
        <heading tag="h2" font={t.font.head} size={40} weight={700} lh={1.15} color={t.color.ink} mobile={{ size: 28 }}>
          If your child says no, we stop.
        </heading>
        <text font={t.font.body} size={18} lh={1.8} color="#173445">
          We might get three teeth counted the first time and all twenty the third time, and that is a
          completely normal and successful course of treatment.
        </text>
        <text font={t.font.body} size={16} lh={1.7} color="#173445" tw="pl-5" border={[0, 'transparent']} raw="& { border-left: 4px solid #FFFDF7; }">
          Nobody is held down. Nobody is talked over. Coming back a second time is progress, not a
          failed appointment.
        </text>
      </box>
      {img('child_chair') ? (
        <img
          src={img('child_chair')}
          tw="flex-1 min-w-0 rounded-[32px] max-lg:w-full"
          h={420}
          fit="cover"
          shadow={[[24, 60, -24, 'rgba(23,52,69,0.35)']]}
          mobile={{ h: 260 }}
        />
      ) : null}
    </section>

    {/* 4 — the team */}
    <section tw="flex flex-col gap-14 w-full px-6 py-24 max-lg:gap-10 max-md:py-14" bg={t.color.ground}>
      <box tw="flex flex-row-reverse items-center gap-16 w-full max-w-[1120px] mx-auto max-lg:flex-col max-lg:gap-10">
        <box flex={1} tw="flex flex-col gap-6 max-w-[540px]">
          <heading tag="h2" font={t.font.head} size={38} weight={700} lh={1.15} color={t.color.ink} mobile={{ size: 28 }}>
            Trained for children, not adapted to them
          </heading>
          <text font={t.font.body} size={18} lh={1.8} color={MUTED}>
            Two dentists with pediatric postgraduate qualifications, two therapists, and a nurse who
            has been calming small children here since 2009.
          </text>
        </box>
        {img('waiting_room') ? (
          <img
            src={img('waiting_room')}
            tw="flex-1 min-w-0 rounded-[32px] max-lg:w-full"
            h={440}
            fit="cover"
            shadow={[[20, 50, -22, 'rgba(36,48,67,0.28)']]}
            mobile={{ h: 260 }}
          />
        ) : null}
      </box>
      <grid cols={3} gap={16} tw="w-full max-w-[1120px] mx-auto" mobile={{ gridCols: 1 }}>
          <box cls="team-tile" tw="flex flex-col gap-1 p-5 rounded-[20px]" bg="#FFFFFF" border={[1, '#F0E8D8']}>
            <text cls="team-tile-num" font={t.font.head} size={26} weight={700} color={t.color.bubble}>2</text>
            <text cls="team-tile-label" font={t.font.body} size={14} color={MUTED} lh={1.5}>Dentists with pediatric postgrad training</text>
          </box>
          <box cls="team-tile" tw="flex flex-col gap-1 p-5 rounded-[20px]" bg="#FFFFFF" border={[1, '#F0E8D8']}>
            <text cls="team-tile-num" font={t.font.head} size={26} weight={700} color={t.color.mint}>2</text>
            <text cls="team-tile-label" font={t.font.body} size={14} color={MUTED} lh={1.5}>Therapists for prevention and sealants</text>
          </box>
          <box cls="team-tile" tw="flex flex-col gap-1 p-5 rounded-[20px]" bg="#FFFFFF" border={[1, '#F0E8D8']}>
            <text cls="team-tile-num" font={t.font.head} size={26} weight={700} color={t.color.coral}>2009</text>
            <text cls="team-tile-label" font={t.font.body} size={14} color={MUTED} lh={1.5}>The year our nurse started here</text>
          </box>
      </grid>
    </section>

    {/* 5 — costs and NHS places */}
    <section tw="flex flex-col gap-10 w-full px-6 py-24 max-md:py-14" bg={t.color.ink}>
      <box tw="flex flex-row items-end justify-between gap-6 w-full max-w-[1120px] mx-auto max-lg:flex-col max-lg:items-start">
        <heading tag="h2" font={t.font.head} size={38} weight={700} lh={1.15} color={t.color.ground} maxw={520} mobile={{ size: 28 }}>
          What it costs, before you ask
        </heading>
        <text font={t.font.body} size={16} lh={1.7} color="#B9C2D0" maxw={400}>
          Check-up £46. We hold 40 NHS places for under-18s and the waiting list is currently about
          seven weeks.
        </text>
      </box>
      <grid cols={3} gap={20} tw="w-full max-w-[1120px] mx-auto" tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
        {STATS.map((s) => (
          <box cls="stat-tile" tw="flex flex-col gap-3 p-8 rounded-[24px] max-md:p-6" bg="#2E3B51">
            <text cls="stat-num" font={t.font.head} size={40} weight={700} color={t.color.sun} lh={1.1} mobile={{ size: 30 }}>
              {s.k}
            </text>
            <text cls="stat-label" font={t.font.body} size={15} lh={1.7} color="#D6DDE7">
              {s.v}
            </text>
          </box>
        ))}
      </grid>
    </section>

    {/* 6 — parent testimonial */}
    <section tw="flex flex-row items-start gap-12 w-full px-6 py-24 max-lg:flex-col max-lg:gap-6 max-md:py-14" bg={t.color.sun}>
      <text font={t.font.head} size={90} weight={700} color="#B37A00" lh={0.9} tw="max-md:text-[56px]">
        &#8220;
      </text>
      <box tw="flex flex-col gap-6 max-w-[760px]">
        <heading tag="h2" font={t.font.head} size={34} weight={600} lh={1.4} color={t.color.ink} mobile={{ size: 24 }}>
          My son screamed in the car park at our old dentist. At Little Molar he asked whether he
          could come back next week. I nearly cried in reception.
        </heading>
        <text font={t.font.body} size={15} weight={700} color="#7A5400" ls="1px">
          Parent of a six-year-old · Little Molar patient since 2024
        </text>
      </box>
    </section>

    {/* 7 — emergency same-day slots */}
    <section tw="flex flex-row items-center justify-between gap-10 w-full px-6 py-16 max-lg:flex-col max-lg:items-start max-md:py-12" bg={t.color.mint}>
      <box tw="flex flex-col gap-3 max-w-[560px]">
        <heading tag="h2" font={t.font.head} size={30} weight={700} color={t.color.ink} lh={1.2} mobile={{ size: 24 }}>
          A child in pain today is seen today
        </heading>
        <text font={t.font.body} size={16} lh={1.7} color="#1D4B37">
          Emergency slots are kept free every morning. Call before 8:30 and you will almost always be
          in the same day — even if you have never been here before.
        </text>
      </box>
      <box tw="flex flex-row gap-3 max-md:w-full max-md:flex-col">
        <text cls="time-chip" font={t.font.head} size={22} weight={700} color={t.color.ink} tw="px-7 py-4 rounded-[999px] text-center" bg="#FFFDF7">
          8:30
        </text>
        <text cls="time-chip" font={t.font.head} size={22} weight={700} color={t.color.ink} tw="px-7 py-4 rounded-[999px] text-center" bg="#FFFDF7">
          11:00
        </text>
      </box>
    </section>

    {/* 8 — book a first visit */}
    <section id="book" tw="flex flex-col w-full px-6 py-24 max-md:py-14" bg={t.color.ground}>
      <box
        tw="flex flex-row items-center justify-between gap-10 w-full max-w-[1120px] mx-auto p-14 rounded-[40px] max-lg:flex-col max-lg:items-start max-md:p-8"
        bg="#FFFFFF"
        border={[1, '#F0E8D8']}
        shadow={[[24, 60, -30, 'rgba(36,48,67,0.25)']]}
        motion={{ effect: 'fade', trigger: 'scrollIn' }}
      >
        <box tw="flex flex-col gap-4 max-w-[600px]">
          <heading tag="h2" font={t.font.head} size={40} weight={700} lh={1.15} color={t.color.ink} mobile={{ size: 28 }}>
            Book a first visit
          </heading>
          <text font={t.font.body} size={17} lh={1.75} color={MUTED}>
            Tell us your child&#8217;s name and age and anything that frightens them. The first
            appointment is a visit — sit in the chair, count teeth, choose a sticker, go home.
          </text>
        </box>
        <box tw="flex flex-col gap-3 items-start max-md:w-full">
          <Cta />
          <text font={t.font.body} size={14} color={MUTED}>
            NHS and private · Check-up £46 · Under-18s only
          </text>
        </box>
      </box>
    </section>
  </box>
);
