/** Iron Ledger — one page, eight full-bleed colour blocks with hard seams. */
import { defineComponent } from 'elementor-jsx';
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Iron Ledger',
  slug: 'iron-ledger',
  seo: {
    title: 'Iron Ledger — a turn-based tactics game about supply, not combat',
    description:
      'You are the quartermaster of a losing army. Forty linked campaigns of rationing, retreat and permanent consequence. Early access 12 November.',
  },
};

const GROUND = '#12100E';
const INK = '#F0E6D2';
const RUST = '#A63A22';
const BRASS = '#D8A64A';
const MOSS = '#3E5240';
const BONE = '#E8DCC4';
const CHAR = '#1A1714';   // one step off ground, for zebra seams
const DIM = '#C0B49B';    // ink, dimmed for body copy on dark
const SOOT = 'rgba(18,16,14,0.62)'; // ground, dimmed for body copy on light

const HEAD = 'Chakra Petch';
const BODY = 'Rubik';

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 520 };
const RISE = { effect: 'slide', direction: 'bottom', trigger: 'scrollIn', duration: 560 };

/* ── shared bits ─────────────────────────────────────────────────────────── */

const Band = ({ bg, children, pt = 112, pb = 112 }) => (
  <section w="100%" pad={0} bg={bg} tw="flex flex-col" gap={0}>
    <div
      w="100%"
      maxw={1180}
      m={{ l: 'auto', r: 'auto' }}
      cls="band-inner"
      pad={{ t: pt, b: pb, l: 48, r: 48 }}
      tw="flex flex-col"
      gap={0}
      mobile={{ pad: { t: 64, b: 64, l: 20, r: 20 } }}
    >
      {children}
    </div>
  </section>
);

const Marker = ({ n, label, color }) => (
  <text
    cls="marker"
    size={13}
    weight={700}
    ls={0.22}
    font={HEAD}
    color={color}
    tw="uppercase"
    mobile={{ size: 12 }}
  >
    {`${n} — ${label}`}
  </text>
);

const Cta = ({ label, href, bg, color, hoverTw }) => (
  <text
    cls="cta"
    href={href}
    tag="span"
    tw={`inline-block ${hoverTw}`}
    w="hug"
    bg={bg}
    color={color}
    font={HEAD}
    size={16}
    weight={700}
    ls={0.08}
    ta="center"
    pad={{ t: 18, b: 18, l: 34, r: 34 }}
    border={[2, bg]}
  >
    {label}
  </text>
);

/* ── repeaters (native components — content props only) ──────────────────── */

const NotItem = defineComponent(
  ({ label = 'No base building', body = '' }) => (
    <div cls="not-item" tw="flex flex-col" gap={10} bg={BONE} pad={{ t: 28, b: 28, l: 28, r: 28 }}>
      <text cls="not-item-eyebrow" size={13} weight={700} ls={0.22} font={HEAD} color={RUST} tw="uppercase">
        NOT IN THIS GAME
      </text>
      <heading cls="not-item-title" tag="h3" size={26} weight={700} font={HEAD} color={GROUND} lh={1.1} mobile={{ size: 21 }}>
        {label}
      </heading>
      <text cls="not-item-body" size={15} font={BODY} color={SOOT} lh={1.6}>
        {body}
      </text>
    </div>
  ),
  {
    title: 'Iron Ledger — Not Item',
    props: {
      label: { label: 'Heading', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
    },
  },
);

const DevEntry = defineComponent(
  ({ date = '', title = '', body = '' }) => (
    <div cls="dev-entry" tw="flex flex-col" gap={8}>
      <text cls="dev-entry-date" size={12} weight={700} ls={0.22} font={HEAD} color={BRASS} tw="uppercase">
        {date}
      </text>
      <heading cls="dev-entry-title" tag="h3" size={21} weight={700} font={HEAD} color={INK} lh={1.2} mobile={{ size: 18 }}>
        {title}
      </heading>
      <text cls="dev-entry-body" size={15} font={BODY} color={DIM} lh={1.65}>
        {body}
      </text>
    </div>
  ),
  {
    title: 'Iron Ledger — Dev Log Entry',
    props: {
      date: { label: 'Date', group: 'Content' },
      title: { label: 'Title', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
    },
  },
);

/* ── local (inline) repeaters that need per-row styling ──────────────────── */

const LedgerRow = ({ line, into, out, note, tint }) => (
  <div cls="ledger-row" tw="flex flex-col" gap={6} bg={tint ? CHAR : GROUND} pad={{ t: 16, b: 16, l: 20, r: 20 }}>
    <row cls="ledger-row-head" w="100%" justify="space-between" align="center" gap={16} wrap>
      <text cls="ledger-line" size={15} weight={600} font={HEAD} color={INK} flex={1}>
        {line}
      </text>
      <row cls="ledger-figures" gap={18} align="center">
        <text cls="ledger-in" size={15} weight={700} font={HEAD} color="#8FA98C">
          {`+${into}`}
        </text>
        <text cls="ledger-out" size={15} weight={700} font={HEAD} color={RUST}>
          {`−${out}`}
        </text>
      </row>
    </row>
    <text cls="ledger-note" size={13} font={BODY} color={DIM} lh={1.5}>
      {note}
    </text>
  </div>
);

const Stat = ({ k, v, tint }) => (
  <div cls="stat" bg={tint ? CHAR : GROUND} pad={{ t: 34, b: 34, l: 28, r: 28 }} tw="flex flex-col" gap={6}>
    <heading cls="stat-value" tag="h2" size={34} weight={700} font={HEAD} color={BRASS} lh={1} mobile={{ size: 28 }}>
      {v}
    </heading>
    <text cls="stat-key" size={13} weight={600} ls={0.18} font={HEAD} color={DIM} tw="uppercase">
      {k}
    </text>
  </div>
);

const Frame = ({ src, cap, sub }) => (
  <div
    cls="frame"
    tw="flex flex-col"
    gap={0}
    bg={CHAR}
    border={[1, '#2C2721']}
    shadow={[
      [6, 0, 0, RUST, 6],
      [12, 0, 0, BRASS, 12],
    ]}
  >
    <img cls="frame-img" src={src} w="100%" h={260} fit="cover" mobile={{ h: 200 }} />
    <div cls="frame-cap" tw="flex flex-col" gap={6} pad={{ t: 20, b: 22, l: 22, r: 22 }}>
      <text cls="frame-cap-label" size={12} weight={700} ls={0.18} font={HEAD} color={BRASS} tw="uppercase">
        {cap}
      </text>
      <text cls="frame-cap-body" size={14} font={BODY} color={DIM} lh={1.55}>
        {sub}
      </text>
    </div>
  </div>
);

/* ── page ────────────────────────────────────────────────────────────────── */

export default () => (
  <box tw="flex flex-col w-full" gap={0} pad={0} bg={GROUND}>

    {/* 01 — BLACK BLOCK ─────────────────────────────────────────────────── */}
    <section w="100%" pad={0} bg={GROUND} tw="flex flex-col" gap={0}>
      <div
        w="100%"
        maxw={1180}
        m={{ l: 'auto', r: 'auto' }}
        pad={{ t: 128, b: 96, l: 48, r: 48 }}
        tw="flex flex-col"
        gap={28}
        mobile={{ pad: { t: 76, b: 60, l: 20, r: 20 } }}
      >
        <Marker n="IRON LEDGER" label="TURN-BASED SUPPLY TACTICS" color={BRASS} />
        <h1
          size={82}
          weight={700}
          font={HEAD}
          color={INK}
          lh={0.98}
          ls={-0.02}
          maxw={980}
          tablet={{ size: 60 }}
          mobile={{ size: 38, ls: 0 }}
          motion={FADE}
        >
          The army loses. Your job is to decide how slowly.
        </h1>
        <text size={19} font={BODY} color={DIM} lh={1.65} maxw={620} mobile={{ size: 16 }}>
          A turn-based tactics game about supply lines, rationing and retreat. You never move a
          soldier. You decide who eats, what gets abandoned, and which road the column takes at
          dawn.
        </text>
        <row gap={14} align="center" wrap>
          <Cta
            label="WISHLIST ON STEAM"
            href="https://store.steampowered.com/"
            bg={BRASS}
            color={GROUND}
            hoverTw="hover:bg-[#E8DCC4] hover:border-[#E8DCC4]"
          />
          <text size={14} font={BODY} color={DIM} lh={1.5}>
            Early access 12 November · 22 euro
          </text>
        </row>
      </div>
      <grid cols={4} gap={0} w="100%" mobile={{ gridCols: 2 }}>
        <Stat v="11,000" k="mouths to feed" />
        <Stat v="14" k="wagons left" tint />
        <Stat v="40" k="linked campaigns" />
        <Stat v="0" k="soldiers you command" tint />
      </grid>
    </section>

    {/* 02 — RUST BLOCK ──────────────────────────────────────────────────── */}
    <section w="100%" pad={0} bg={RUST} tw="flex flex-col" gap={0}>
      <div
        w="100%"
        maxw={1180}
        m={{ l: 'auto', r: 'auto' }}
        pad={{ t: 104, b: 96, l: 48, r: 48 }}
        mobile={{ pad: { t: 64, b: 60, l: 20, r: 20 } }}
      >
        <grid cols="minmax(0,0.85fr) minmax(0,2fr)" gap={48} w="100%" mobile={{ gridCols: 1, gap: 24 }}>
          <div tw="flex flex-col" gap={10}>
            <heading tag="h2" size={92} weight={700} font={HEAD} color="#7C2716" lh={0.85} mobile={{ size: 56 }}>
              01
            </heading>
            <text size={13} weight={700} ls={0.22} font={HEAD} color="#F3D6CE" tw="uppercase">
              THE ROLE
            </text>
          </div>
          <div tw="flex flex-col" gap={22} motion={FADE}>
            <heading tag="h3" size={44} weight={700} font={HEAD} color={INK} lh={1.05} maxw={640} mobile={{ size: 28 }}>
              You are the quartermaster, not the general.
            </heading>
            <text size={18} font={BODY} color="#F6E2DC" lh={1.7} maxw={620} mobile={{ size: 16 }}>
              Generals get statues. Quartermasters get blamed. You have 11,000 mouths, 14 wagons,
              and a bridge that will not hold both.
            </text>
            <text size={16} font={BODY} color="#EDC9C0" lh={1.7} maxw={620}>
              No one salutes when the column reaches the next valley intact. They only count the
              wagons that did not. Every order you sign is a subtraction from somewhere else on the
              page.
            </text>
          </div>
        </grid>
      </div>
      <img src={media.camp_night.id} w="100%" h={340} fit="cover" mobile={{ h: 200 }} />
    </section>

    {/* 03 — BRASS BLOCK ─────────────────────────────────────────────────── */}
    <Band bg={BRASS} pt={104} pb={104}>
      <grid cols="minmax(0,1fr) minmax(0,1.15fr)" gap={56} w="100%" mobile={{ gridCols: 1, gap: 32 }}>
        <div tw="flex flex-col" gap={20}>
          <Marker n="02" label="THE LEDGER" color="#6B4A11" />
          <heading tag="h2" size={44} weight={700} font={HEAD} color={GROUND} lh={1.05} mobile={{ size: 28 }}>
            Every turn is a ledger.
          </heading>
          <text size={18} font={BODY} color="#3A2E14" lh={1.7} maxw={520} mobile={{ size: 16 }}>
            Grain in, grain out, boots lost to mud, a column of numbers that becomes a column of
            people two turns later.
          </text>
          <img src={media.ledger_still.id} w="100%" h={220} fit="cover" border={[2, GROUND]} mobile={{ h: 170 }} />
        </div>
        <div tw="flex flex-col" gap={0} bg={GROUND} border={[2, GROUND]} motion={FADE}>
          <div tw="flex flex-col" gap={4} pad={{ t: 22, b: 18, l: 20, r: 20 }} bg={GROUND}>
            <text size={12} weight={700} ls={0.22} font={HEAD} color={BRASS} tw="uppercase">
              TURN 14 · THE VEREL ROAD
            </text>
            <text size={13} font={BODY} color={DIM} lh={1.5}>
              Closed at dusk. Signed by you, in your own hand.
            </text>
          </div>
          <LedgerRow line="Grain, sacks" into="900" out="1,240" note="Two days at half ration, then nothing." tint />
          <LedgerRow line="Boots, pairs" into="0" out="310" note="Third company crosses the ford barefoot." />
          <LedgerRow line="Wagons" into="0" out="3" note="The bridge took the rest. It always does." tint />
          <LedgerRow line="Wounded, carried" into="212" out="44" note="Left at the mill with a note and a lamp." />
          <div pad={{ t: 18, b: 22, l: 20, r: 20 }} bg={CHAR}>
            <text size={14} font={BODY} color={BRASS} lh={1.6}>
              Balance carried forward: eleven days of march, nine days of bread.
            </text>
          </div>
        </div>
      </grid>
    </Band>

    {/* 04 — MOSS BLOCK ──────────────────────────────────────────────────── */}
    <section w="100%" pad={0} bg={MOSS} tw="flex flex-col" gap={0}>
      <div
        w="100%"
        maxw={1180}
        m={{ l: 'auto', r: 'auto' }}
        pad={{ t: 104, b: 88, l: 48, r: 48 }}
        tw="flex flex-col"
        gap={36}
        mobile={{ pad: { t: 64, b: 56, l: 20, r: 20 } }}
      >
        <grid cols="minmax(0,0.7fr) minmax(0,2fr)" gap={48} w="100%" mobile={{ gridCols: 1, gap: 20 }}>
          <div tw="flex flex-col" gap={8}>
            <heading tag="h2" size={132} weight={700} font={HEAD} color={BONE} lh={0.82} mobile={{ size: 76 }}>
              40
            </heading>
            <text size={13} weight={700} ls={0.22} font={HEAD} color="#B9CBB4" tw="uppercase">
              LINKED CAMPAIGNS
            </text>
          </div>
          <div tw="flex flex-col" gap={20} motion={FADE}>
            <heading tag="h3" size={40} weight={700} font={HEAD} color={BONE} lh={1.08} maxw={620} mobile={{ size: 26 }}>
              Permanent consequences, and no reminder that you caused them.
            </heading>
            <text size={18} font={BODY} color="#D6E0D2" lh={1.7} maxw={640} mobile={{ size: 16 }}>
              Forty linked campaigns. Abandon a wounded company in campaign three and their village
              refuses you bread in campaign nineteen. The game remembers everything and never
              reminds you.
            </text>
          </div>
        </grid>
        <grid cols={2} gap={2} w="100%" mobile={{ gridCols: 1 }}>
          <div bg="#33452F" pad={{ t: 28, b: 28, l: 28, r: 28 }} tw="flex flex-col" gap={10}>
            <text size={12} weight={700} ls={0.22} font={HEAD} color={BRASS} tw="uppercase">
              CAMPAIGN 03 · WHAT YOU DECIDED
            </text>
            <text size={17} font={BODY} color={BONE} lh={1.6}>
              The mill road is flooding. You leave forty wounded and one lamp, and the column makes
              the ridge before dark.
            </text>
          </div>
          <div bg="#2C3B29" pad={{ t: 28, b: 28, l: 28, r: 28 }} tw="flex flex-col" gap={10}>
            <text size={12} weight={700} ls={0.22} font={HEAD} color={RUST} tw="uppercase">
              CAMPAIGN 19 · WHAT IT COST
            </text>
            <text size={17} font={BODY} color={BONE} lh={1.6}>
              Sixteen turns later the same valley has bread to sell and will not sell it to you. No
              cutscene says why. The ledger does.
            </text>
          </div>
        </grid>
      </div>
    </section>

    {/* 05 — BONE BLOCK ──────────────────────────────────────────────────── */}
    <Band bg={BONE} pt={96} pb={96}>
      <div tw="flex flex-col" gap={20} maxw={720}>
        <Marker n="04" label="WHAT IT IS NOT" color={RUST} />
        <heading tag="h2" size={44} weight={700} font={HEAD} color={GROUND} lh={1.05} mobile={{ size: 28 }}>
          There is only a better and a worse retreat.
        </heading>
        <text size={18} font={BODY} color={SOOT} lh={1.7} mobile={{ size: 16 }}>
          No base building. No hero units. No respawns, no difficulty slider, no way to win the war.
        </text>
      </div>
      <grid cols={2} gap={2} w="100%" m={{ t: 40 }} mobile={{ gridCols: 1 }}>
        <NotItem label="No base building" body="Nothing to construct. The camp is wherever the column stopped, and it is gone by morning." />
        <NotItem label="No hero units" body="No one on the roster is irreplaceable, and no one is exempt from the ration table." />
        <NotItem label="No respawns" body="A company lost in campaign six is absent from the manifest for the remaining thirty-four." />
        <NotItem label="No difficulty slider" body="The war is fixed. Only your bookkeeping changes, and only ever by degree." />
      </grid>
    </Band>

    {/* 06 — SCREENSHOT BAND ─────────────────────────────────────────────── */}
    <Band bg={GROUND} pt={104} pb={104}>
      <div tw="flex flex-col" gap={16} maxw={720}>
        <Marker n="05" label="FOUR FRAMES" color={BRASS} />
        <heading tag="h2" size={40} weight={700} font={HEAD} color={INK} lh={1.08} mobile={{ size: 26 }}>
          Four frames from the second retreat.
        </heading>
      </div>
      <grid cols={2} gap={28} w="100%" m={{ t: 44 }} mobile={{ gridCols: 1, gap: 32 }}>
        <Frame
          src={media.battle_map.id}
          cap="FRAME 01 · THE ROUTE"
          sub="Two roads out of the valley. One is shorter and takes the wagons; the other keeps the wounded."
        />
        <Frame
          src={media.ledger_still.id}
          cap="FRAME 02 · CLOSING THE TURN"
          sub="The turn will not close until every line balances. It will let you balance it badly."
        />
        <Frame
          src={media.camp_night.id}
          cap="FRAME 03 · CAMP, 03:40"
          sub="Fires are a ration too. Cold nights cost boots; warm nights cost the woodpile."
        />
        <div
          tw="flex flex-col"
          gap={14}
          bg={RUST}
          justify="center"
          pad={{ t: 40, b: 40, l: 30, r: 30 }}
          shadow={[
            [6, 0, 0, BRASS, 6],
            [12, 0, 0, MOSS, 12],
          ]}
        >
          <text size={12} weight={700} ls={0.18} font={HEAD} color="#F3D6CE" tw="uppercase">
            FRAME 04 · THE MANIFEST
          </text>
          <heading tag="h3" size={30} weight={700} font={HEAD} color={INK} lh={1.1} mobile={{ size: 24 }}>
            Every name on the roll, and the date it stopped moving.
          </heading>
          <text size={15} font={BODY} color="#F6E2DC" lh={1.6}>
            Sortable, searchable, and never cleared between campaigns. It is the only monument in
            the game.
          </text>
        </div>
      </grid>
    </Band>

    {/* 07 — DEV LOG / EARLY ACCESS ──────────────────────────────────────── */}
    <section w="100%" pad={0} tw="flex flex-col" gap={0} bg={CHAR}>
      <grid cols={2} gap={0} w="100%" mobile={{ gridCols: 1 }}>
        <div
          bg={MOSS}
          pad={{ t: 88, b: 88, l: 56, r: 56 }}
          tw="flex flex-col"
          gap={30}
          mobile={{ pad: { t: 56, b: 56, l: 20, r: 20 } }}
        >
          <Marker n="06" label="DEV LOG" color={BRASS} />
          <heading tag="h2" size={34} weight={700} font={HEAD} color={BONE} lh={1.1} mobile={{ size: 26 }}>
            Written every second Friday, whether or not it went well.
          </heading>
          <DevEntry
            date="04 AUGUST"
            title="Rations, third rewrite"
            body="Half rations used to be a slider. It is now a decision with a name attached to it, and the name shows up again later."
          />
          <DevEntry
            date="18 JULY"
            title="The bridge at Verel"
            body="Load-bearing in both senses. Three wagons or two hundred wounded — the model finally refuses to let you cheat it."
          />
          <DevEntry
            date="27 JUNE"
            title="Memory pass, campaigns 1–11"
            body="Every abandonment now writes a row that campaign nineteen can read. Eleven campaigns wired, twenty-nine to go."
          />
        </div>
        <div
          bg={CHAR}
          pad={{ t: 88, b: 88, l: 56, r: 56 }}
          tw="flex flex-col"
          gap={26}
          mobile={{ pad: { t: 56, b: 56, l: 20, r: 20 } }}
        >
          <Marker n="07" label="EARLY ACCESS" color={BRASS} />
          <heading tag="h2" size={34} weight={700} font={HEAD} color={INK} lh={1.1} mobile={{ size: 26 }}>
            Early access opens 12 November.
          </heading>
          <text size={17} font={BODY} color={DIM} lh={1.7} mobile={{ size: 16 }}>
            Eleven campaigns playable, roughly 30 hours. Full release when the last twenty-nine are
            done and not before.
          </text>
          <grid cols={2} gap={2} w="100%" mobile={{ gridCols: 2 }}>
            <div bg={GROUND} pad={{ t: 22, b: 22, l: 22, r: 22 }} tw="flex flex-col" gap={6}>
              <heading tag="h3" size={26} weight={700} font={HEAD} color={BRASS} lh={1} mobile={{ size: 22 }}>
                22 €
              </heading>
              <text size={13} font={BODY} color={DIM} lh={1.5}>
                In early access, and it will not get cheaper at launch.
              </text>
            </div>
            <div bg={GROUND} pad={{ t: 22, b: 22, l: 22, r: 22 }} tw="flex flex-col" gap={6}>
              <heading tag="h3" size={26} weight={700} font={HEAD} color={BRASS} lh={1} mobile={{ size: 22 }}>
                11 / 40
              </heading>
              <text size={13} font={BODY} color={DIM} lh={1.5}>
                Campaigns playable on day one, about 30 hours.
              </text>
            </div>
          </grid>
          <text size={14} font={BODY} color="#8E8272" lh={1.6}>
            Windows, macOS and Linux. No launcher, no account, no online check.
          </text>
        </div>
      </grid>
    </section>

    {/* 08 — WISHLIST ────────────────────────────────────────────────────── */}
    <section w="100%" pad={0} bg={RUST} tw="flex flex-col" gap={0}>
      <div
        w="100%"
        maxw={860}
        m={{ l: 'auto', r: 'auto' }}
        pad={{ t: 112, b: 112, l: 48, r: 48 }}
        tw="flex flex-col items-center text-center"
        gap={26}
        mobile={{ pad: { t: 72, b: 72, l: 20, r: 20 } }}
      >
        <Marker n="08" label="WISHLIST ON EVERY STORE" color="#F3D6CE" />
        <heading
          tag="h2"
          size={54}
          weight={700}
          font={HEAD}
          color={INK}
          lh={1.02}
          ta="center"
          mobile={{ size: 32 }}
          motion={RISE}
        >
          Put it on the list. The column moves in November.
        </heading>
        <text size={18} font={BODY} color="#F6E2DC" lh={1.7} ta="center" maxw={560} mobile={{ size: 16 }}>
          A wishlist is the only supply line we have. It decides how loudly the storefronts mention
          us on 12 November.
        </text>
        <Cta
          label="WISHLIST ON STEAM"
          href="https://store.steampowered.com/"
          bg={BRASS}
          color={GROUND}
          hoverTw="hover:bg-[#E8DCC4] hover:border-[#E8DCC4]"
        />
        <grid cols={3} gap={2} w="100%" m={{ t: 18 }} mobile={{ gridCols: 1 }}>
          <text
            href="https://www.gog.com/"
            tag="span"
            tw="hover:bg-[#12100E] hover:text-[#D8A64A]"
            bg="#8E2F1B"
            color={INK}
            font={HEAD}
            size={15}
            weight={700}
            ls={0.08}
            ta="center"
            pad={{ t: 18, b: 18, l: 16, r: 16 }}
          >
            GOG
          </text>
          <text
            href="https://itch.io/"
            tag="span"
            tw="hover:bg-[#12100E] hover:text-[#D8A64A]"
            bg="#8E2F1B"
            color={INK}
            font={HEAD}
            size={15}
            weight={700}
            ls={0.08}
            ta="center"
            pad={{ t: 18, b: 18, l: 16, r: 16 }}
          >
            ITCH.IO
          </text>
          <text
            href="https://store.epicgames.com/"
            tag="span"
            tw="hover:bg-[#12100E] hover:text-[#D8A64A]"
            bg="#8E2F1B"
            color={INK}
            font={HEAD}
            size={15}
            weight={700}
            ls={0.08}
            ta="center"
            pad={{ t: 18, b: 18, l: 16, r: 16 }}
          >
            EPIC
          </text>
        </grid>
        <text size={13} font={BODY} color="#EDC9C0" lh={1.6} ta="center">
          Iron Ledger · early access 12 November · 22 euro · no way to win the war
        </text>
      </div>
    </section>
  </box>
);
