export default { name: 'quarter-inserted' };
