# Little Molar

Friendly pastel pediatric; safe by design for anxious parents.

|  |  |
|---|---|
| **Slug** | `little-molar` (deploys to `/little-molar/`) |
| **Archetype** | centred hero, three feature cards, testimonial, CTA |
| **Industry** | Pediatric dentistry |
| **Page title** | Little Molar — a children’s dental practice |
| **Fonts** | Baloo 2, Quicksand — Google Fonts, imported by Elementor automatically |
| **Elements** | 75 |
| **Images** | 2 |
| **Global classes used** | 0 — built `--inline` (56 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install little-molar
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
little-molar/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/little-molar.page.jsx          the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#FFFDF7` |
| `ink` | `#243043` |
| `bubble` | `#4EC3E0` |
| `coral` | `#FF8A7A` |
| `mint` | `#8ED9B4` |
| `sun` | `#FFD25E` |

Change a value, re-run `npx exjsx-kit install little-molar`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/little-molar.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `child_chair` | `media/child_chair.jpg` | A young child sitting calmly in a dental chair at Little Molar |
| `waiting_room` | `media/waiting_room.jpg` | The bright, toy-filled waiting room at Little Molar |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
