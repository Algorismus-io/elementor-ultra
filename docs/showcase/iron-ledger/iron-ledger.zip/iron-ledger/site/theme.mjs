/** Iron Ledger — design tokens. */
export default defineTheme({
  name: 'iron-ledger',
  color: {
    ground: '#12100E',
    ink: '#F0E6D2',
    rust: '#A63A22',
    brass: '#D8A64A',
    moss: '#3E5240',
    bone: '#E8DCC4',
  },
  font: { head: 'Chakra Petch', body: 'Rubik' },
  mode: 'literal',
});
