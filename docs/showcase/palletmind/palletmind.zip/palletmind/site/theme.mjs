/** Palletmind design tokens. */
export default defineTheme({
  name: 'palletmind',
  color: {
    ground: '#F1F3F5',
    ink: '#0F1519',
    machine: '#2E3F4C',
    hazard: '#FFD400',
    ok: '#2F9E6B',
    line: '#D5DBE0',
    white: '#FFFFFF',
  },
  font: { head: 'Michroma', body: 'IBM Plex Sans' },
  mode: 'literal',
});
