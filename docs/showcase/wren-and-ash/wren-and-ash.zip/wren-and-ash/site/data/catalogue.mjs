/** Past commissions — the catalogue proper. */
export const PIECES = [
  { piece: 'Refectory table', dim: '2.8m', wood: 'Pippy oak from a wind-thrown tree at Cwmcarn', year: '2025' },
  { piece: 'Dresser base', dim: '1.6m', wood: 'Brown oak from a hedgerow tree at Llangattock', year: '2025' },
  { piece: 'Six dining chairs', dim: 'seat 460mm', wood: 'Ash from Coed Cefn', year: '2025' },
  { piece: 'Writing desk', dim: '1.4m', wood: 'Cherry from an orchard at Wormbridge', year: '2025' },
  { piece: 'Blanket chest', dim: '1.1m', wood: 'Elm from a churchyard tree at Grosmont', year: '2025' },
  { piece: 'Library bookcase', dim: '3.2m run', wood: 'Oak from Trelleck', year: '2024' },
  { piece: 'Console table', dim: '1.8m', wood: 'Olive ash from Llanthony', year: '2024' },
  { piece: 'Window bench', dim: '2.4m', wood: 'Oak from the same Cwmcarn tree', year: '2024' },
  { piece: 'Bedside pair', dim: '480mm', wood: 'Cherry from Wormbridge', year: '2024' },
  { piece: 'Kitchen island', dim: '2.2m', wood: 'Brown oak from Skenfrith', year: '2024' },
  { piece: 'Round dining table', dim: '1.4m dia.', wood: 'Ash from Coed Cefn', year: '2024' },
  { piece: 'Wardrobe', dim: '1.9m', wood: 'Elm from Grosmont', year: '2024' },
  { piece: 'Coffee table', dim: '1.2m', wood: 'Burr oak from a wind-thrown tree at Tintern', year: '2023' },
  { piece: 'Eight dining chairs', dim: 'seat 460mm', wood: 'Oak from Trelleck', year: '2023' },
  { piece: 'Hall settle', dim: '1.7m', wood: 'Oak from Llangattock', year: '2023' },
  { piece: 'Chest of drawers', dim: '900mm', wood: 'Cherry from Monmouth', year: '2023' },
  { piece: 'Refectory table', dim: '3.4m', wood: 'Oak from Tintern', year: '2023' },
  { piece: 'Sideboard', dim: '2.0m', wood: 'Ripple ash from Llanthony', year: '2022' },
  { piece: 'Desk and shelf run', dim: '2.6m', wood: 'Elm from Raglan', year: '2022' },
  { piece: 'Nursing chair', dim: 'seat 420mm', wood: 'Ash from Coed Cefn', year: '2022' },
  { piece: 'Dining table', dim: '2.0m', wood: 'Cherry from an orchard at Wormbridge', year: '2022' },
  { piece: 'Fitted pantry', dim: '2.8m run', wood: 'Oak from Skenfrith', year: '2021' },
  { piece: 'Low bookcase', dim: '1.5m', wood: 'Brown oak from Trelleck', year: '2021' },
  { piece: 'Trestle table', dim: '2.4m', wood: 'Ash from a wind-thrown tree at Usk', year: '2021' },
];

/** The rack, tree by tree. */
export const TREES = [
  { species: 'Oak', place: 'Cwmcarn', note: 'Wind-thrown in the February gales. Pippy through the butt.', felled: 'Felled 2021', ready: 'In the rack until 2024' },
  { species: 'Ash', place: 'Coed Cefn', note: 'Standing, taken for dieback. Straight and pale, olive at the heart.', felled: 'Felled 2022', ready: 'Ready now' },
  { species: 'Elm', place: 'Grosmont', note: 'A churchyard tree the parish had to take down. Wild figure.', felled: 'Felled 2020', ready: 'Ready now' },
  { species: 'Cherry', place: 'Wormbridge', note: 'An orchard grubbed out for a new planting. Short boards, deep colour.', felled: 'Felled 2023', ready: 'In the rack until 2026' },
  { species: 'Oak', place: 'Skenfrith', note: 'Brown oak, beefsteak fungus through two of the four butts.', felled: 'Felled 2024', ready: 'In the rack until 2027' },
  { species: 'Ash', place: 'Usk', note: 'Riverside tree, undercut and leaning. The board that will be a table in 2029.', felled: 'Felled 2026', ready: 'In the rack until 2029' },
];

/** How a commission works. */
export const STAGES = [
  { n: '01', title: 'We visit and measure', body: 'We come to the room the piece will live in, measure it, and look at the light. No charge and no obligation — it is the only way to get proportion right.' },
  { n: '02', title: 'A drawing and a fixed price', body: 'A hand drawing at a proper scale, with a fixed price against it. Nothing moves until you are happy with both. The price does not change afterwards.' },
  { n: '03', title: 'Timber selection', body: 'We pick the boards out of the rack and lay them out. You are welcome to attend and most people do — it is the part where the piece stops being a drawing.' },
  { n: '04', title: 'Twelve to twenty weeks, then delivery', body: 'The two of us in the workshop, no subcontracting. We deliver and install it ourselves, in our own van, and take the packing away with us.' },
];

/** Prices, banded. */
export const BANDS = [
  { what: 'Dining and refectory tables', detail: 'Solid top, drawbore or wedged frame, any length to 3.6m', from: 'from 4,800' },
  { what: 'Chairs and benches', detail: 'Steam-bent or joined, seat woven or shaped, priced each', from: 'from 1,150' },
  { what: 'Bookcases and fitted work', detail: 'Scribed to the wall, per run, including fitting', from: 'from 6,500' },
  { what: 'Casegoods — chests, dressers, wardrobes', detail: 'Dovetailed throughout, drawers hand-fitted', from: 'from 3,900' },
  { what: 'Deposit', detail: 'A third at drawing stage, refundable until the timber is cut', from: 'one third' },
];
