/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "housecell-home--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'housecell-home--';

export default [
  { slot: `${PREFIX}battery_wall`, file: join(MEDIA_DIR, "battery_wall.jpg"), alt: "Two stacked Housecell battery modules mounted on a utility room wall" },
  { slot: `${PREFIX}house_solar`, file: join(MEDIA_DIR, "house_solar.jpg"), alt: "A British semi-detached house with solar panels on the roof" },
  { slot: `${PREFIX}install_day`, file: join(MEDIA_DIR, "install_day.jpg"), alt: "A certified installer fitting a Housecell battery unit" },
];
