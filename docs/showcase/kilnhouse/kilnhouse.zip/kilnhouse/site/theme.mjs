/** Kilnhouse design tokens — flame-fired stoneware, printed-catalogue palette. */
export default defineTheme({
  name: 'kilnhouse',
  color: {
    ground: '#F4EFE6',
    ink: '#221D18',
    clay: '#B4572F',
    glaze: '#2F4A46',
    chalk: '#FFFFFF',
    rule: '#CDC3B4',
  },
  font: { head: 'Fraunces', body: 'Karla' },
  mode: 'literal',
});
