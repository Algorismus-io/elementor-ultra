/** Carrow Valve Works — the selection table IS the hero. */
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Valve selection table — Carrow Valve Works',
  slug: 'carrow-valve',
  seo: {
    title: 'Valve selection table | Carrow Valve Works, Sheffield since 1911',
    description:
      'Forged ball, gate and check valves from DN15 to DN600, Class 150 to Class 2500. Machined and tested in Sheffield. Sizes, classes, materials, seats and lead times in one table.',
  },
};

/* ── data ─────────────────────────────────────────────────────────────── */

const COLS = 'minmax(120px,1.15fr) .75fr 1.2fr .95fr .9fr';

const ROWS = [
  { size: 'DN15 – DN50', cls: 'Class 150 – 800', material: 'F316 forged', seat: 'PTFE / PEEK', lead: '6 weeks' },
  { size: 'DN15 – DN50', cls: 'Class 1500 – 2500', material: 'F316 / duplex F51', seat: 'PEEK', lead: '9 weeks' },
  { size: 'DN80 – DN150', cls: 'Class 150 – 600', material: 'Carbon steel LF2', seat: 'Stellite 6', lead: '8 weeks' },
  { size: 'DN80 – DN150', cls: 'Class 900 – 1500', material: 'F316 forged', seat: 'Stellite 6', lead: '11 weeks' },
  { size: 'DN250 – DN400', cls: 'Class 150 – 300', material: 'Carbon steel A105', seat: 'Stellite 6', lead: '12 weeks' },
  { size: 'DN250 – DN400', cls: 'Class 600 – 900', material: 'Duplex F51', seat: 'Stellite 6', lead: '16 weeks' },
  { size: 'DN450 – DN600', cls: 'Class 150 – 300', material: 'Carbon steel A105', seat: 'Stellite 6', lead: '18 weeks' },
  { size: 'DN450 – DN600', cls: 'Class 600', material: 'Inconel 625', seat: 'Stellite 21', lead: '22 weeks' },
];

const CERTS = [
  { name: 'API 6D', number: 'Licence 6D-0421', note: 'Pipeline ball, gate and check valves. Monogram held continuously since 1979.' },
  { name: 'API 607 Fire Safe', number: 'Report FS-1187-C', note: 'Soft and metal seated ball valves, tested to the sixth edition burn schedule.' },
  { name: 'PED 2014/68/EU', number: 'Module H · NB 0038 · H-2291-04', note: 'Full quality assurance. Annual surveillance audit, no open findings.' },
  { name: 'ATEX 2014/34/EU', number: 'File ATEX/CVW/117', note: 'Where specified. Category 2G non-electrical assessment for actuated sets.' },
  { name: "Lloyd's Register", number: 'Type approval LR/TA/22/00418', note: 'Marine service. Accepted for hull and machinery on classed tonnage.' },
  { name: 'ISO 9001:2015', number: 'Certificate GB-19-0044', note: 'The works quality system. Certified since the first edition in 1987.' },
];

const SECTORS = [
  {
    sector: 'Refineries',
    job: 'Humber, 2024',
    detail: 'Forty-two DN200 Class 600 F316 ball valves for a hydrotreater revamp, stellite seated, delivered inside the 14 week standard lead.',
  },
  {
    sector: 'Water authorities',
    job: 'Kielder transfer, 2023',
    detail: 'DN600 Class 150 carbon steel gate valves on raw water transfer, WRAS listed internal coating, 60 year design life.',
  },
  {
    sector: 'Shipbuilders',
    job: 'Clyde yard, 2025',
    detail: "Eighteen DN80 Class 800 duplex ball valves for a fuel transfer main, Lloyd's Register type approved and witness tested at the yard.",
  },
];

const TESTS = [
  {
    n: '01',
    name: 'Hydrostatic shell',
    detail: 'Every valve, every time, at 1.5x the rated pressure held to the API 598 duration with no visible leakage through the body, bonnet or gland.',
  },
  {
    n: '02',
    name: 'Seat closure',
    detail: 'Seat test to API 598, high pressure and low pressure gas, both directions on bidirectional valves. Rate recorded, not just passed.',
  },
  {
    n: '03',
    name: 'Cryogenic',
    detail: 'BS 6364 immersion testing down to −196 °C in the cryogenic bay, with extended bonnet valves cycled cold before the leak count is taken.',
  },
];

const DRAWINGS = [
  { title: 'Ball valve · DN200 Class 600 · general arrangement', format: 'PDF', weight: '1.2 MB' },
  { title: 'Gate valve · DN450 Class 300 · general arrangement', format: 'PDF', weight: '1.6 MB' },
  { title: 'Ball valve · DN15 – DN600 · dimensional data sheet', format: 'PDF', weight: '840 KB' },
  { title: 'Ball valve · DN200 Class 600 · solid model', format: 'STEP AP214', weight: '4.4 MB' },
  { title: 'Gate valve · DN450 Class 300 · solid model', format: 'STEP AP214', weight: '6.1 MB' },
  { title: 'Trim and seat option schedule · all classes', format: 'DWG', weight: '2.3 MB' },
];

const MAIL = 'mailto:drawings@carrowvalveworks.co.uk';

/* ── repeaters (content props only) ───────────────────────────────────── */

const cell = (label, value, opts = {}) => (
  <div tw="flex flex-col gap-1">
    <text size={10} ls={0.14} font="Roboto Mono" color="#5B676E" tw="hidden max-md:block">
      {label}
    </text>
    <text size={14} lh={1.4} font="Roboto Mono" color={opts.color || '#1A1D20'} weight={opts.weight || 400}>
      {value}
    </text>
  </div>
);

const rowFn = (standard) => ({ size, cls, material, seat, lead }) => (
  <grid
    cols={COLS}
    gapX={20}
    gapY={14}
    pad={{ t: 16, b: 16, l: 20, r: 20 }}
    bg={standard ? '#1A1D20' : '#FFFFFF'}
    mobile={{ gridCols: 2, pad: { t: 16, b: 16, l: 16, r: 16 } }}
    hover={{ bg: standard ? '#1A1D20' : '#F2F3F4' }}
  >
    {cell('SIZE', size, { color: standard ? '#FFFFFF' : '#1A1D20', weight: 500 })}
    {cell('CLASS', cls, { color: standard ? '#DDE1E4' : '#1A1D20' })}
    {cell('BODY MATERIAL', material, { color: standard ? '#DDE1E4' : '#5B676E' })}
    {cell('SEAT', seat, { color: standard ? '#DDE1E4' : '#5B676E' })}
    {cell('LEAD TIME', lead, { color: standard ? '#C8102E' : '#1A1D20', weight: 500 })}
  </grid>
);

const SpecRow = defineComponent(rowFn(false), {
  title: 'Spec row',
  props: {
    size: { label: 'Size', group: 'Row' },
    cls: { label: 'Class', group: 'Row' },
    material: { label: 'Body material', group: 'Row' },
    seat: { label: 'Seat', group: 'Row' },
    lead: { label: 'Lead time', group: 'Row' },
  },
});

const SpecRowStandard = defineComponent(rowFn(true), {
  title: 'Spec row (standard bore)',
  props: {
    size: { label: 'Size', group: 'Row' },
    cls: { label: 'Class', group: 'Row' },
    material: { label: 'Body material', group: 'Row' },
    seat: { label: 'Seat', group: 'Row' },
    lead: { label: 'Lead time', group: 'Row' },
  },
});

const CertCard = defineComponent(
  ({ name, number, note }) => (
    <div tw="flex flex-col gap-3" pad={24} bg="#22262A" border={[1, '#33383D']} hover={{ border: [1, '#C8102E'] }}>
      <div h={3} w={44} bg="#C8102E" pad={0} />
      <heading tag="h3" size={20} weight={500} font="Oswald" ls={0.02} color="#FFFFFF">
        {name}
      </heading>
      <text size={12} font="Roboto Mono" color="#DDE1E4" ls={0.06}>
        {number}
      </text>
      <text size={13} lh={1.7} font="Roboto Mono" color="#9AA3A9">
        {note}
      </text>
    </div>
  ),
  {
    title: 'Certificate card',
    props: {
      name: { label: 'Approval', group: 'Certificate' },
      number: { label: 'Certificate number', group: 'Certificate' },
      note: { label: 'Scope note', group: 'Certificate' },
    },
  },
);

const DownloadRow = defineComponent(
  ({ title, format, weight, href }) => (
    <grid
      cols="1fr 150px 150px"
      gapX={20}
      gapY={8}
      pad={{ t: 18, b: 18, l: 20, r: 20 }}
      bg="#FFFFFF"
      align="center"
      mobile={{ gridCols: 1, gapY: 6, pad: { t: 16, b: 16, l: 16, r: 16 } }}
      hover={{ bg: '#F2F3F4' }}
    >
      <text size={14} lh={1.5} font="Roboto Mono" color="#1A1D20" href={href}>
        {title}
      </text>
      <text size={12} font="Roboto Mono" color="#5B676E" ls={0.08}>
        {format}
      </text>
      <text size={12} font="Roboto Mono" color="#C8102E" ls={0.06}>
        {weight} · GET FILE
      </text>
    </grid>
  ),
  {
    title: 'Drawing download row',
    props: {
      title: { label: 'Drawing', group: 'Download' },
      format: { label: 'Format', group: 'Download' },
      weight: { label: 'File size', group: 'Download' },
      href: { label: 'Link', group: 'Download' },
    },
  },
);

/* ── shared bits ──────────────────────────────────────────────────────── */

const Eyebrow = ({ text, color = '#C8102E' }) => (
  <text size={11} ls={0.18} font="Roboto Mono" weight={500} color={color}>
    {text}
  </text>
);

const Rule = ({ color = '#DDE1E4' }) => <div h={1} w="100%" bg={color} pad={0} />;

const fade = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* ── page ─────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
    {/* ── masthead ─────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ink}>
      <div
        tw="flex flex-row w-full max-w-[1240px] mx-auto items-center justify-between gap-6 px-8 py-4 max-md:flex-col max-md:items-start max-md:gap-3 max-md:px-5"
      >
        <div tw="flex flex-col gap-1">
          <text size={19} weight={600} ls={0.16} font={t.font.head} color={t.color.white}>
            CARROW VALVE WORKS
          </text>
          <text size={10} ls={0.12} font={t.font.body} color="#9AA3A9">
            SHEFFIELD · FORGING SINCE 1911
          </text>
        </div>
        <div tw="flex flex-row items-center gap-7 max-md:gap-4 max-md:flex-wrap">
          <text size={12} font={t.font.body} color="#9AA3A9" href="#standards" hover={{ color: '#FFFFFF' }}>
            Approvals
          </text>
          <text size={12} font={t.font.body} color="#9AA3A9" href="#materials" hover={{ color: '#FFFFFF' }}>
            Materials
          </text>
          <text size={12} font={t.font.body} color="#9AA3A9" href="#drawings" hover={{ color: '#FFFFFF' }}>
            Drawings
          </text>
          <text size={12} font={t.font.body} color={t.color.white} ls={0.04} href="tel:+441142721911">
            +44 114 272 1911
          </text>
        </div>
      </div>
    </box>
    <div h={3} w="100%" bg={t.color.safety} pad={0} />

    {/* ── 1 · hero: the selection table ─────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ground} id="table">
      <div tw="flex flex-col w-full max-w-[1240px] mx-auto gap-10 px-8 pt-16 pb-20 max-md:px-5 max-md:pt-10 max-md:pb-12">
        <grid cols="1.1fr .9fr" gapX={56} gapY={28} mobile={{ gridCols: 1 }}>
          <div tw="flex flex-col gap-5">
            <Eyebrow text="SELECTION · DN15–DN600 · CLASS 150–2500" />
            <h1 size={78} weight={600} lh={1} ls={-0.01} font={t.font.head} color={t.color.ink} tablet={{ size: 58 }} mobile={{ size: 38 }}>
              Valve selection table
            </h1>
            <text size={15} lh={1.75} font={t.font.body} color={t.color.steel} maxw={560}>
              Forged ball, gate and check valves from DN15 to DN600, Class 150 to Class 2500. Everything is machined and
              tested in Sheffield. Find your line in the table and download the drawing.
            </text>
          </div>

          <div tw="flex flex-col gap-5" pad={28} bg={t.color.ink} mobile={{ pad: 20 }}>
            <Eyebrow text="STANDARD CONFIGURATION" />
            <text size={14} lh={1.8} font={t.font.body} color={t.color.white}>
              Standard bore DN200 Class 600, F316 body, stellite seat, 14 week lead. Reduced bore available on the same
              lead time.
            </text>
            <Rule color="#33383D" />
            <div tw="flex flex-row gap-8 max-md:gap-6">
              <div tw="flex flex-col gap-1">
                <text size={26} weight={500} font={t.font.head} color={t.color.white}>
                  1911
                </text>
                <text size={10} ls={0.1} font={t.font.body} color="#9AA3A9">
                  SAME WORKS
                </text>
              </div>
              <div tw="flex flex-col gap-1">
                <text size={26} weight={500} font={t.font.head} color={t.color.white}>
                  3 days
                </text>
                <text size={10} ls={0.1} font={t.font.body} color="#9AA3A9">
                  QUOTE TURNAROUND
                </text>
              </div>
            </div>
            <text
              size={13}
              ls={0.1}
              weight={500}
              font={t.font.body}
              color={t.color.white}
              bg={t.color.safety}
              ta="center"
              pad={{ t: 14, b: 14, l: 20, r: 20 }}
              href="#quote"
              hover={{ bg: '#A50D25' }}
            >
              REQUEST A QUOTATION
            </text>
          </div>
        </grid>

        {/* the table */}
        <div tw="flex flex-col w-full" gap={1} bg={t.color.band} pad={1} motion={fade}>
          <grid
            cols={COLS}
            gapX={20}
            pad={{ t: 14, b: 14, l: 20, r: 20 }}
            bg={t.color.ink}
            tw="max-md:hidden"
          >
            <text size={10} ls={0.14} font={t.font.body} color="#9AA3A9">SIZE</text>
            <text size={10} ls={0.14} font={t.font.body} color="#9AA3A9">CLASS</text>
            <text size={10} ls={0.14} font={t.font.body} color="#9AA3A9">BODY MATERIAL</text>
            <text size={10} ls={0.14} font={t.font.body} color="#9AA3A9">SEAT</text>
            <text size={10} ls={0.14} font={t.font.body} color="#9AA3A9">LEAD TIME</text>
          </grid>
          {ROWS.slice(0, 4).map((r, i) => (
            <SpecRow {...r} />
          ))}
          <SpecRowStandard size="DN200" cls="Class 600" material="F316 forged" seat="Stellite 6" lead="14 weeks" />
          {ROWS.slice(4).map((r, i) => (
            <SpecRow {...r} />
          ))}
        </div>

        <div tw="flex flex-row gap-4 items-start max-md:flex-col max-md:gap-2">
          <text size={12} ls={0.1} font={t.font.body} color={t.color.safety} weight={500}>
            NOTE
          </text>
          <text size={13} lh={1.7} font={t.font.body} color={t.color.steel} maxw={720}>
            Standard bore DN200 Class 600, F316 body, stellite seat, 14 week lead. Reduced bore available on the same
            lead time. Anything outside the table is quoted on the drawing, not refused.
          </text>
        </div>
      </div>
    </box>

    {/* ── 2 · standards and approvals ───────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ink} id="standards">
      <div tw="flex flex-col w-full max-w-[1240px] mx-auto gap-10 px-8 py-24 max-md:px-5 max-md:py-14">
        <grid cols="1fr 1.15fr" gapX={56} gapY={20} mobile={{ gridCols: 1 }}>
          <div tw="flex flex-col gap-4">
            <Eyebrow text="02 · STANDARDS HELD" />
            <heading tag="h2" size={46} weight={500} lh={1.1} font={t.font.head} color={t.color.white} mobile={{ size: 32 }}>
              Approvals, with the certificate numbers
            </heading>
          </div>
          <text size={15} lh={1.85} font={t.font.body} color="#9AA3A9" motion={fade}>
            API 6D, API 607 Fire Safe, PED 2014/68/EU Module H, ATEX where specified, and Lloyd's Register type approval
            for marine service. Every certificate is current and every number below can be verified with the issuing
            body before you place an order.
          </text>
        </grid>
        <grid cols={3} gapX={20} gapY={20} tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
          {CERTS.map((c, i) => (
            <CertCard {...c} />
          ))}
        </grid>
      </div>
    </box>

    {/* ── 3 · materials ─────────────────────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.white} id="materials">
      <div tw="flex flex-col w-full max-w-[1240px] mx-auto px-8 py-24 gap-12 max-md:px-5 max-md:py-14 max-md:gap-8">
        <grid cols=".95fr 1.05fr" gapX={56} gapY={28} mobile={{ gridCols: 1 }}>
          <img src={media.valve_machined.id} w="100%" h={420} fit="cover" mobile={{ h: 260 }} />
          <div tw="flex flex-col gap-5">
            <Eyebrow text="03 · MATERIALS" />
            <heading tag="h2" size={46} weight={500} lh={1.1} font={t.font.head} color={t.color.ink} mobile={{ size: 32 }}>
              What we forge, and what we will not cast
            </heading>
            <text size={15} lh={1.85} font={t.font.body} color={t.color.steel}>
              We forge carbon steel, F316, duplex and Inconel 625. We do not supply cast bodies for anything above Class
              300, on principle, and have not since 1974.
            </text>
            <grid cols={2} gapX={16} gapY={16} mobile={{ gridCols: 1 }}>
              {[
                ['Carbon steel', 'A105 · LF2 · LF3'],
                ['Stainless', 'F316 · F316L · F304'],
                ['Duplex', 'F51 · F53 super duplex'],
                ['Nickel alloy', 'Inconel 625 · Monel 400'],
              ].map(([k, v], i) => (
                <div tw="flex flex-col gap-1" pad={{ t: 14, b: 14, l: 16, r: 16 }} bg={t.color.ground}>
                  <text size={14} weight={500} font={t.font.body} color={t.color.ink}>
                    {k}
                  </text>
                  <text size={12} font={t.font.body} color={t.color.steel}>
                    {v}
                  </text>
                </div>
              ))}
            </grid>
            <div tw="flex flex-col gap-2" pad={18} bg={t.color.ground} border={[1, '#DDE1E4']}>
              <text size={12} ls={0.1} weight={500} font={t.font.body} color={t.color.safety}>
                SINCE 1974
              </text>
              <text size={13} lh={1.7} font={t.font.body} color={t.color.ink}>
                No cast body above Class 300. A casting hides its porosity until the line is up to pressure; a forging
                does not. It has cost us work and we have kept the rule.
              </text>
            </div>
          </div>
        </grid>
      </div>
    </box>

    {/* ── 4 · testing regime ────────────────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.band} id="testing">
      <div tw="flex flex-col w-full max-w-[1240px] mx-auto px-8 py-24 gap-12 max-md:px-5 max-md:py-14 max-md:gap-8">
        <grid cols="1.1fr .9fr" gapX={56} gapY={24} mobile={{ gridCols: 1 }}>
          <div tw="flex flex-col gap-5">
            <Eyebrow text="04 · TESTING REGIME" />
            <heading tag="h2" size={46} weight={500} lh={1.1} font={t.font.head} color={t.color.ink} mobile={{ size: 32 }}>
              Nothing leaves the bay untested
            </heading>
            <text size={15} lh={1.85} font={t.font.body} color={t.color.steel} maxw={620}>
              Every valve gets a hydrostatic shell test at 1.5x rating, a seat test to API 598, and a witnessed
              certificate with the heat number traceable to the billet.
            </text>
          </div>
          <img src={media.test_bay.id} w="100%" h={280} fit="cover" mobile={{ h: 220 }} />
        </grid>
        <grid cols={3} gapX={20} gapY={20} mobile={{ gridCols: 1 }}>
          {TESTS.map((x, i) => (
            <div tw="flex flex-col gap-3" pad={24} bg={t.color.white} motion={fade}>
              <text size={30} weight={600} font={t.font.head} color={t.color.safety}>
                {x.n}
              </text>
              <heading tag="h3" size={19} weight={500} font={t.font.head} color={t.color.ink}>
                {x.name}
              </heading>
              <text size={13} lh={1.75} font={t.font.body} color={t.color.steel}>
                {x.detail}
              </text>
            </div>
          ))}
        </grid>
      </div>
    </box>

    {/* ── 5 · sectors served ────────────────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ground} id="sectors">
      <div tw="flex flex-col w-full max-w-[1240px] mx-auto px-8 py-24 gap-10 max-md:px-5 max-md:py-14">
        <grid cols=".8fr 1.2fr" gapX={56} gapY={16} mobile={{ gridCols: 1 }}>
          <div tw="flex flex-col gap-4">
            <Eyebrow text="05 · SECTORS SERVED" />
            <heading tag="h2" size={46} weight={500} lh={1.1} font={t.font.head} color={t.color.ink} mobile={{ size: 32 }}>
              Refineries, water, marine
            </heading>
          </div>
          <text size={15} lh={1.85} font={t.font.body} color={t.color.steel}>
            Three trades, one order book. Each line below is a real job with a real reference we will put you in touch
            with, on request, once a quotation is live.
          </text>
        </grid>
        <div tw="flex flex-col w-full" gap={1} bg={t.color.band} pad={1}>
          {SECTORS.map((s, i) => (
            <grid
             
              cols=".55fr .45fr 1.6fr"
              gapX={28}
              gapY={10}
              pad={{ t: 26, b: 26, l: 24, r: 24 }}
              bg={t.color.white}
              mobile={{ gridCols: 1, pad: { t: 20, b: 20, l: 18, r: 18 } }}
              hover={{ bg: '#FAFAFA' }}
            >
              <heading tag="h3" size={24} weight={500} font={t.font.head} color={t.color.ink}>
                {s.sector}
              </heading>
              <text size={12} ls={0.08} font={t.font.body} color={t.color.safety}>
                {s.job}
              </text>
              <text size={13} lh={1.75} font={t.font.body} color={t.color.steel}>
                {s.detail}
              </text>
            </grid>
          ))}
        </div>
        <img src={media.forge_floor.id} w="100%" h={320} fit="cover" mobile={{ h: 200 }} motion={fade} />
      </div>
    </box>

    {/* ── 6 · spares ────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ink} id="spares">
      <div tw="flex flex-col w-full max-w-[1240px] mx-auto px-8 py-24 gap-10 max-md:px-5 max-md:py-14">
        <grid cols="1.15fr .85fr" gapX={56} gapY={28} mobile={{ gridCols: 1 }}>
          <div tw="flex flex-col gap-5">
            <Eyebrow text="06 · SPARES" />
            <heading tag="h2" size={46} weight={500} lh={1.1} font={t.font.head} color={t.color.white} mobile={{ size: 32 }}>
              Forty year part availability
            </heading>
            <text size={15} lh={1.85} font={t.font.body} color="#9AA3A9" maxw={620}>
              We hold or can remake spares for every valve we have shipped since 1986. Send us a nameplate photograph
              and we will identify it within two working days.
            </text>
            <text
              size={13}
              ls={0.08}
              font={t.font.body}
              color={t.color.white}
              href="mailto:spares@carrowvalveworks.co.uk"
              hover={{ color: '#C8102E' }}
            >
              spares@carrowvalveworks.co.uk →
            </text>
          </div>
          <grid cols={1} gapY={1} bg="#33383D" pad={1} h="hug">
            {[
              ['1986', 'Earliest shipment we still stock spares for'],
              ['2 days', 'Nameplate photograph to positive identification'],
              ['40 years', 'Guaranteed part availability from date of shipment'],
            ].map(([k, v], i) => (
              <div tw="flex flex-col gap-1" pad={20} bg={t.color.ink}>
                <text size={28} weight={500} font={t.font.head} color={t.color.safety}>
                  {k}
                </text>
                <text size={12} lh={1.6} font={t.font.body} color="#9AA3A9">
                  {v}
                </text>
              </div>
            ))}
          </grid>
        </grid>
      </div>
    </box>

    {/* ── 7 · drawings and CAD ──────────────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ground} id="drawings">
      <div tw="flex flex-col w-full max-w-[1240px] mx-auto px-8 py-24 gap-8 max-md:px-5 max-md:py-14">
        <grid cols="1fr 1fr" gapX={56} gapY={16} mobile={{ gridCols: 1 }}>
          <div tw="flex flex-col gap-4">
            <Eyebrow text="07 · DRAWINGS AND CAD" />
            <heading tag="h2" size={46} weight={500} lh={1.1} font={t.font.head} color={t.color.ink} mobile={{ size: 32 }}>
              General arrangements and solid models
            </heading>
          </div>
          <text size={15} lh={1.85} font={t.font.body} color={t.color.steel}>
            General arrangements as PDF, solid models as STEP AP214 and DWG. No registration wall and no sales call
            afterwards. If the size you need is not listed, ask and we will cut the drawing from the model.
          </text>
        </grid>
        <div tw="flex flex-col w-full" gap={1} bg={t.color.band} pad={1}>
          <grid
            cols="1fr 150px 150px"
            gapX={20}
            pad={{ t: 12, b: 12, l: 20, r: 20 }}
            bg={t.color.ink}
            tw="max-md:hidden"
          >
            <text size={10} ls={0.14} font={t.font.body} color="#9AA3A9">DRAWING</text>
            <text size={10} ls={0.14} font={t.font.body} color="#9AA3A9">FORMAT</text>
            <text size={10} ls={0.14} font={t.font.body} color="#9AA3A9">FILE</text>
          </grid>
          {DRAWINGS.map((d, i) => (
            <DownloadRow
             
              title={d.title}
              format={d.format}
              weight={d.weight}
              href={`${MAIL}?subject=${encodeURIComponent(d.title)}`}
            />
          ))}
        </div>
      </div>
    </box>

    {/* ── 8 · request a quotation ───────────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.white} id="quote">
      <div tw="flex flex-col w-full max-w-[1240px] mx-auto px-8 py-24 max-md:px-5 max-md:py-14">
        <grid cols="1.15fr .85fr" gapX={56} gapY={32} mobile={{ gridCols: 1 }}>
          <div tw="flex flex-col gap-5">
            <Eyebrow text="08 · ENQUIRIES" />
            <heading tag="h2" size={52} weight={500} lh={1.05} font={t.font.head} color={t.color.ink} mobile={{ size: 34 }}>
              Request a quotation
            </heading>
            <text size={15} lh={1.85} font={t.font.body} color={t.color.steel} maxw={620}>
              Technical enquiries go straight to an engineer, not a form queue. Quotations returned in 3 working days
              for standard configurations.
            </text>
            <text size={13} lh={1.8} font={t.font.body} color={t.color.steel} maxw={620}>
              Send the line size, pressure class, medium and temperature. A P&amp;ID extract or a tag list is enough to
              start; we will come back with the seat and trim recommendation, not just a price.
            </text>
            <div tw="flex flex-row gap-4 max-md:flex-col">
              <text
                size={13}
                ls={0.1}
                weight={500}
                font={t.font.body}
                color={t.color.white}
                bg={t.color.safety}
                ta="center"
                pad={{ t: 15, b: 15, l: 26, r: 26 }}
                href="mailto:enquiries@carrowvalveworks.co.uk?subject=Quotation%20request"
                hover={{ bg: '#A50D25' }}
              >
                EMAIL THE TECHNICAL DESK
              </text>
              <text
                size={13}
                ls={0.1}
                weight={500}
                font={t.font.body}
                color={t.color.ink}
                border={[1, '#1A1D20']}
                ta="center"
                pad={{ t: 15, b: 15, l: 26, r: 26 }}
                href="tel:+441142721911"
                hover={{ bg: '#1A1D20', color: '#FFFFFF' }}
              >
                +44 114 272 1911
              </text>
            </div>
          </div>
          <div tw="flex flex-col gap-5" pad={28} bg={t.color.ground} mobile={{ pad: 20 }}>
            <text size={11} ls={0.16} weight={500} font={t.font.body} color={t.color.safety}>
              THE WORKS
            </text>
            <text size={14} lh={1.8} font={t.font.body} color={t.color.ink}>
              Carrow Valve Works
              <br />
              Attercliffe Road
              <br />
              Sheffield S9 3RJ
              <br />
              United Kingdom
            </text>
            <Rule />
            <text size={13} lh={1.8} font={t.font.body} color={t.color.steel}>
              Works open 07:00–17:00, Monday to Thursday, 07:00–13:00 Friday. Witness testing is booked by the week and
              visitors are welcome on the test bay floor.
            </text>
          </div>
        </grid>
      </div>
    </box>

    {/* ── footer ───────────────────────────────────────────────── */}
    <box tw="flex flex-col w-full" pad={0} bg={t.color.ink}>
      <div tw="flex flex-row w-full max-w-[1240px] mx-auto items-center justify-between gap-6 px-8 py-8 max-md:flex-col max-md:items-start max-md:gap-3 max-md:px-5">
        <text size={11} ls={0.06} font={t.font.body} color="#9AA3A9">
          © 2026 Carrow Valve Works Ltd · Registered in England 00114911
        </text>
        <text size={11} ls={0.06} font={t.font.body} color="#9AA3A9">
          Forged, machined and tested in Sheffield since 1911
        </text>
      </div>
    </box>
  </box>
);
