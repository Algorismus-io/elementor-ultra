export default { name: 'clause-radar' };
