/** The nine — canonical manifesto entries. */
export const FAILURES = [
  {
    num: '01',
    title: 'Zero-basis fill.',
    body: 'Most tools silently set an unknown cost basis to zero, which turns a break-even trade into a taxable gain. We flag it, quantify it, and make you decide.',
  },
  {
    num: '02',
    title: 'Bridges as disposals.',
    body: 'Moving the same asset across a bridge is not always a disposal. We track wrapped and bridged representations as one position and show the trail.',
  },
  {
    num: '03',
    title: 'LP positions treated as a black box.',
    body: 'We decompose liquidity positions into their underlying tokens at entry and exit, including impermanent loss and accrued fees, per block.',
  },
  {
    num: '04',
    title: 'Airdrops stamped at the wrong moment.',
    body: 'Tools price an airdrop at the block you claimed it, not the block it became yours. We record both, apply the rule your jurisdiction actually uses, and show which one moved the number.',
  },
  {
    num: '05',
    title: 'Staking rewards rolled into one annual lump.',
    body: 'Rewards accrue per epoch and each accrual carries its own basis. We keep every one at its own timestamp and price, then let you collapse the view without losing the rows underneath it.',
  },
  {
    num: '06',
    title: 'Gas written off as nothing.',
    body: 'A fee paid in the asset you are disposing of is itself a disposal, and a fee on an acquisition belongs in the basis. We allocate every unit of gas to the event that caused it.',
  },
  {
    num: '07',
    title: 'Your own transfers read as sales.',
    body: 'A move between two wallets you control is not a taxable event, but a tool that only sees one side of it books a disposal. We match both sides across chains and label the internal transfer.',
  },
  {
    num: '08',
    title: 'Reverted transactions counted as trades.',
    body: 'A reverted transaction still burns gas but moves no asset. Most tools either drop the fee or book a phantom trade. We keep the fee, discard the trade, and say so on the line.',
  },
  {
    num: '09',
    title: 'One price feed stretched over every chain.',
    body: 'A token on an L2 at 03:14 is not the same print as the same token on mainnet. We source prices per venue, record which feed we used, and mark any figure that fell back to another.',
  },
];

/** Pricing by transaction count. */
export const TIERS = [
  { amount: 'free', unit: '', count: 'under 100 transactions', note: 'Full reconstruction, full audit trail. Not a trial.' },
  { amount: '89', unit: 'per tax year', count: 'to 10,000 transactions', note: 'Every chain and exchange connector included.' },
  { amount: '249', unit: 'per tax year', count: 'to 100,000 transactions', note: 'LP decomposition and bridge matching at volume.' },
  { amount: '599', unit: 'per tax year', count: 'above 100,000 transactions', note: 'Includes a call with a human who has actually filed one of these.' },
];
