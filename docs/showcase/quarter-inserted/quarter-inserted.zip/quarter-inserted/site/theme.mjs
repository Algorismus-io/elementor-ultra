/** Quarter Inserted — arcade bar. Loud full-bleed colour blocks with hard seams. */
export default defineTheme({
  name: 'quarter-inserted',
  color: {
    ground: '#12061F',
    ink: '#F5F0FF',
    magenta: '#FF00A8',
    cyan: '#00E5FF',
    amber: '#FFC400',
    deep: '#2A0B45',
  },
  font: { head: 'Monoton', body: 'Chivo' },
  mode: 'literal',
});
