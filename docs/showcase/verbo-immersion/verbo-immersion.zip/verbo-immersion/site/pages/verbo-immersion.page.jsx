import { IMG } from '../data/media.mjs';

export const meta = {
  title: 'Verbo — eight-week live immersion courses',
  seo: {
    title: 'Verbo — eight weeks, four people in the room',
    description:
      'Live immersion language courses of four students, twice a week, ninety minutes each. By week eight you hold a fifteen-minute conversation with a stranger. £420, sixteen sessions.',
  },
};

const C = {
  ground: '#FFF8F0',
  ink: '#22201E',
  terracotta: '#C25E3A',
  indigo: '#31456B',
  olive: '#7C8C4E',
  rule: '#E4D8C9',
  white: '#FFFFFF',
};

const HEAD = 'Zilla Slab';
const BODY = 'Epilogue';

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 600 };

/* ── small building blocks ─────────────────────────────────────────── */

const Eyebrow = ({ children, color = C.terracotta }) => (
  <text font={BODY} size={12} weight={700} ls="2.4px" color={color} tw="uppercase">
    {children}
  </text>
);

const Rule = ({ color = C.rule }) => <box h={1} w="100%" bg={color} pad={0} />;

/* ── native components (content props only) ────────────────────────── */

const WeekRow = defineComponent(
  ({ num = '1', head = '', body = '' }) => (
    <row tw="flex flex-row w-full items-stretch gap-6 max-md:gap-4" pad={0}>
      <col tw="flex flex-col items-center w-[72px] max-md:w-[52px] shrink-0" pad={0} gap={0}>
        <box
          w={56}
          h={56}
          radius={999}
          bg={C.white}
          border={[2, C.terracotta]}
          tw="flex items-center justify-center shrink-0 max-md:w-[44px] max-md:h-[44px]"
          pad={0}
        >
          <text font={HEAD} size={22} weight={600} color={C.terracotta} mobile={{ size: 17 }}>
            {num}
          </text>
        </box>
        <box w={2} flex={1} minh={24} bg={C.rule} pad={0} />
      </col>
      <col tw="flex flex-col gap-2 pb-12 max-md:pb-9" pad={0} flex={1}>
        <h3 font={HEAD} size={25} weight={600} color={C.ink} lh={1.25} mobile={{ size: 21 }}>
          {head}
        </h3>
        <text font={BODY} size={16} color="#4A443E" lh={1.7} maxw={620} mobile={{ size: 15 }}>
          {body}
        </text>
      </col>
    </row>
  ),
  {
    title: 'Verbo Week Row',
    props: {
      num: { label: 'Week number', group: 'Week' },
      head: { label: 'Headline', group: 'Week' },
      body: { label: 'Body', group: 'Week' },
    },
  },
);

const Teacher = defineComponent(
  ({ name = '', line = '' }) => (
    <col tw="flex flex-col gap-1 w-full" pad={{ t: 16, b: 16 }} raw="& { border-top: 1px solid rgba(255,248,240,0.22); }">
      <h3 font={HEAD} size={20} weight={600} color={C.white}>
        {name}
      </h3>
      <text font={BODY} size={14.5} color="#C9D2E2" lh={1.6}>
        {line}
      </text>
    </col>
  ),
  {
    title: 'Verbo Teacher',
    props: {
      name: { label: 'Name', group: 'Teacher' },
      line: { label: 'Home town · language', group: 'Teacher' },
    },
  },
);

const LangCard = defineComponent(
  ({ lang = '', native = '', levels = 'Complete beginner → B2' }) => (
    <col
      tw="flex flex-col gap-2 w-full h-full"
      pad={22}
      bg={C.white}
      radius={3}
      border={[1, C.rule]}
      shadow={[[2, 0, 0, C.rule], [10, 24, -18, 'rgba(34,32,30,0.35)']]}
      hover={{ border: [1, C.olive], shadow: [[4, 0, 0, C.olive], [14, 30, -18, 'rgba(34,32,30,0.4)']] }}
    >
      <h3 font={HEAD} size={22} weight={600} color={C.ink}>
        {lang}
      </h3>
      <text font={BODY} size={13.5} color={C.olive} weight={600} ls="0.6px">
        {native}
      </text>
      <text font={BODY} size={14} color="#5C554E" lh={1.6}>
        {levels}
      </text>
    </col>
  ),
  {
    title: 'Verbo Language Card',
    props: {
      lang: { label: 'Language', group: 'Language' },
      native: { label: 'Endonym', group: 'Language' },
      levels: { label: 'Levels', group: 'Language' },
    },
  },
);

const FactRow = defineComponent(
  ({ label = '', value = '' }) => (
    <row tw="flex flex-row w-full items-start gap-8 max-md:flex-col max-md:gap-2" pad={{ t: 20, b: 20 }} raw="& { border-bottom: 1px solid #E4D8C9; }">
      <text font={BODY} size={12.5} weight={700} ls="1.8px" color={C.terracotta} w="220px" tw="uppercase shrink-0 max-md:w-full">
        {label}
      </text>
      <text font={BODY} size={16.5} color={C.ink} lh={1.65} flex={1}>
        {value}
      </text>
    </row>
  ),
  {
    title: 'Verbo Fact Row',
    props: {
      label: { label: 'Label', group: 'Fact' },
      value: { label: 'Value', group: 'Fact' },
    },
  },
);

/* ── the button ────────────────────────────────────────────────────── */

const Cta = ({ href = '#placement', bg = C.terracotta, color = C.white, label = 'Book a placement call' }) => (
  <text
    href={href}
    font={BODY}
    size={16}
    weight={600}
    color={color}
    bg={bg}
    pad={[17, 30]}
    radius={2}
    ta="center"
    tw="w-fit"
    shadow={[[4, 0, 0, 'rgba(34,32,30,0.9)']]}
    hover={{ bg: C.indigo, color: C.white, shadow: [[2, 0, 0, 'rgba(34,32,30,0.9)']] }}
  >
    {label}
  </text>
);

const WEEKS = [
  { num: '1', head: 'Introduce yourself without translating', body: 'Week 1: you will introduce yourself and ask three follow-up questions without translating in your head. It will be exhausting.' },
  { num: '2', head: 'Order, ask, misunderstand, ask again', body: 'Week 2: you will order food, ask for directions and misunderstand the answer. Then you will ask a second time, differently, and get it.' },
  { num: '3', head: 'Talk about yesterday, badly', body: 'Week 3: the past tense arrives and it arrives wrong. You will tell the room what you did at the weekend and nobody will stop you mid-sentence.' },
  { num: '4', head: 'Argue about something small', body: 'Week 4: you will argue about something small. Food, weather, football. You will be wrong grammatically and understood completely.' },
  { num: '5', head: 'Take a phone call with no notes', body: 'Week 5: your teacher rings you without warning. Four minutes, no script, no screen to read from. Everyone survives it.' },
  { num: '6', head: 'Explain your job to a stranger', body: 'Week 6: you will explain what you do for a living to someone who does not do it, twice, in two different ways, until the second way is shorter.' },
  { num: '7', head: 'Choose your topic and defend it', body: 'Week 7: you choose the subject for week eight and you argue for that choice in the language. Homework is one conversation with someone outside the class.' },
  { num: '8', head: 'Fifteen minutes with a stranger', body: 'Week 8: fifteen minutes with a stranger over video, unscripted, on a topic you chose in week seven. We record it and send it to you, and you should keep it.' },
];

const TEACHERS = [
  { name: 'Núria Bosch', line: 'Girona, Catalonia · teaches Spanish' },
  { name: 'Tiago Almeida', line: 'Porto, Portugal · teaches Portuguese' },
  { name: 'Giulia Ferrero', line: 'Bologna, Italy · teaches Italian' },
  { name: 'Malik Ferhat', line: 'Marseille, France · teaches French' },
  { name: 'Eleni Ráptis', line: 'Thessaloniki, Greece · teaches Greek' },
];

const LANGS = [
  { lang: 'Spanish', native: 'Español', levels: 'Complete beginner → B2. Four cohorts a month.' },
  { lang: 'Portuguese', native: 'Português', levels: 'Complete beginner → B2. European and Brazilian.' },
  { lang: 'Italian', native: 'Italiano', levels: 'Complete beginner → B2. Two cohorts a month.' },
  { lang: 'French', native: 'Français', levels: 'Complete beginner → B2. Four cohorts a month.' },
  { lang: 'Greek', native: 'Ελληνικά', levels: 'Complete beginner → B1. One cohort a month.' },
];

const FACTS = [
  { label: 'Price', value: '£420 for the eight weeks, sixteen sessions. Paid after your placement call, in one payment or two.' },
  { label: 'Schedule', value: 'Twice a week, ninety minutes each, evenings at 18:30 or 19:30 UK time. You keep the same two slots for the whole course.' },
  { label: 'If you miss a week', value: 'Miss up to two and you can sit them with another cohort at no cost. Miss four and we move you to the next intake for free.' },
  { label: 'Class size', value: 'Four students. Never five. If a cohort fills, you go to the next intake rather than into a bigger room.' },
  { label: 'What you need', value: 'A camera, headphones and ninety minutes where nobody will interrupt you. No textbook — we send the material each Sunday.' },
];

/* ── page ──────────────────────────────────────────────────────────── */

export default () => (
  <box tw="flex flex-col w-full items-center" pad={0} bg={C.ground}>

    {/* 0 — hero: asymmetric, left-aligned */}
    <section tw="flex flex-col w-full items-center px-6 pt-20 pb-24 max-md:pt-12 max-md:pb-16" pad={0} bg={C.ground}>
      <box tw="flex flex-col w-full max-w-[1120px] gap-12" pad={0}>
        <row tw="flex flex-row w-full items-end justify-between gap-6 max-md:flex-col max-md:items-start max-md:gap-2" pad={{ b: 18 }} raw="& { border-bottom: 2px solid #22201E; }">
          <text font={HEAD} size={26} weight={600} ls="0.5px" color={C.ink}>
            Verbo
          </text>
          <text font={BODY} size={13} weight={600} ls="1.6px" color={C.indigo} tw="uppercase" w="100%" ta="right" flex={1} mobile={{ size: 11, ta: 'left', ls: "1px" }}>
            Live immersion · Spanish · Portuguese · Italian · French · Greek
          </text>
        </row>

        <row tw="flex flex-row w-full items-start gap-16 max-lg:gap-10 max-md:flex-col max-md:gap-8" pad={0}>
          <col tw="flex flex-col gap-7 max-md:gap-5" pad={0} flex={1} maxw={720}>
            <h1 font={HEAD} size={68} weight={600} color={C.ink} lh={1.06} ls="-1px" tablet={{ size: 52 }} mobile={{ size: 34 }}>
              Eight weeks. Four people in the room. No English after minute three.
            </h1>
            <text font={BODY} size={19} color="#4A443E" lh={1.7} maxw={620} mobile={{ size: 16 }}>
              Verbo runs live immersion courses of four students, twice a week, ninety minutes each. By week eight you will hold a fifteen-minute conversation with a stranger about something that matters to you.
            </text>
            <row tw="flex flex-row items-center gap-5 max-md:flex-col max-md:items-start max-md:gap-3" pad={{ t: 4 }}>
              <Cta />
              <text font={BODY} size={14.5} color="#6B635B" lh={1.6}>
                Twenty minutes, free, nobody buys before it.
              </text>
            </row>
          </col>

          <col tw="flex flex-col w-[300px] max-lg:w-[260px] max-md:w-full gap-0 shrink-0" pad={0} bg={C.white} border={[1, C.rule]} radius={3} shadow={[[3, 0, 0, C.rule], [24, 40, -28, 'rgba(34,32,30,0.45)']]}>
            <col tw="flex flex-col gap-1" pad={22} raw="& { border-bottom: 1px solid #E4D8C9; }">
              <text font={HEAD} size={44} weight={600} color={C.terracotta} lh={1}>4</text>
              <text font={BODY} size={13.5} color="#5C554E" lh={1.5}>students in the room, every session</text>
            </col>
            <col tw="flex flex-col gap-1" pad={22} raw="& { border-bottom: 1px solid #E4D8C9; }">
              <text font={HEAD} size={44} weight={600} color={C.indigo} lh={1}>22</text>
              <text font={BODY} size={13.5} color="#5C554E" lh={1.5}>minutes an hour you personally speak</text>
            </col>
            <col tw="flex flex-col gap-1" pad={22}>
              <text font={HEAD} size={44} weight={600} color={C.olive} lh={1}>16</text>
              <text font={BODY} size={13.5} color="#5C554E" lh={1.5}>ninety-minute sessions, £420 total</text>
            </col>
          </col>
        </row>
      </box>
    </section>

    {/* 1 — the spine */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:py-16" pad={0} bg={C.white}>
      <box tw="flex flex-col w-full max-w-[1120px] gap-14 max-md:gap-10" pad={0}>
        <row tw="flex flex-row w-full items-end justify-between gap-10 max-md:flex-col max-md:items-start max-md:gap-4" pad={0}>
          <col tw="flex flex-col gap-3" pad={0} maxw={620}>
            <Eyebrow>The spine · week by week</Eyebrow>
            <h2 font={HEAD} size={44} weight={600} color={C.ink} lh={1.12} mobile={{ size: 30 }}>
              What you can do by Friday
            </h2>
          </col>
          <text font={BODY} size={16} color="#5C554E" lh={1.7} maxw={380}>
            Not a syllabus. A list of things you could not do on Monday and can do by the end of the week, out loud, to a person.
          </text>
        </row>

        <col tw="flex flex-col w-full" pad={0} gap={0}>
          {WEEKS.map((w) => (
            <WeekRow num={w.num} head={w.head} body={w.body} />
          ))}
        </col>

        <row tw="flex flex-row items-center gap-6 max-md:flex-col max-md:items-start max-md:gap-4" pad={{ t: 8 }}>
          <Cta label="Start at week one" />
          <text font={BODY} size={15} color="#5C554E" lh={1.6} maxw={520}>
            Intakes begin the first Monday of every month. Cohorts of four fill in about nine days.
          </text>
        </row>
      </box>
    </section>

    {/* 2 — why four and not twelve */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:py-16" pad={0} bg={C.ground} motion={FADE}>
      <row tw="flex flex-row w-full max-w-[1120px] items-center gap-16 max-lg:gap-10 max-md:flex-col max-md:gap-8" pad={0}>
        <box tw="flex w-[46%] max-md:w-full shrink-0" pad={0} radius={3} shadow={[[6, 0, 0, C.terracotta], [30, 50, -30, 'rgba(34,32,30,0.5)']]}>
          <img src={IMG.classSmall} w="100%" radius={3} fit="cover" />
        </box>
        <col tw="flex flex-col gap-6" pad={0} flex={1}>
          <Eyebrow>The whole method</Eyebrow>
          <h2 font={HEAD} size={42} weight={600} color={C.ink} lh={1.14} mobile={{ size: 29 }}>
            Why four students and not twelve
          </h2>
          <text font={BODY} size={17.5} color="#4A443E" lh={1.75} maxw={580} mobile={{ size: 16 }}>
            Four students. In a class of twelve you speak for six minutes an hour. In a class of four you speak for twenty-two. That single number is the whole method.
          </text>

          <col tw="flex flex-col gap-4 w-full max-w-[520px]" pad={{ t: 8 }}>
            <col tw="flex flex-col gap-2 w-full" pad={0}>
              <text font={BODY} size={13.5} weight={600} color="#6B635B" ls="0.8px">Class of twelve — 6 min / hour</text>
              <box tw="flex w-full" h={14} bg={C.rule} radius={2} pad={0}>
                <box w="27%" h={14} bg="#B9AC9B" radius={2} pad={0} />
              </box>
            </col>
            <col tw="flex flex-col gap-2 w-full" pad={0}>
              <text font={BODY} size={13.5} weight={600} color={C.terracotta} ls="0.8px">Class of four — 22 min / hour</text>
              <box tw="flex w-full" h={14} bg={C.rule} radius={2} pad={0}>
                <box w="100%" h={14} bg={C.terracotta} radius={2} pad={0} />
              </box>
            </col>
          </col>
        </col>
      </row>
    </section>

    {/* 3 — teachers */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:py-16" pad={0} bg={C.indigo}>
      <row tw="flex flex-row w-full max-w-[1120px] items-stretch gap-16 max-lg:gap-10 max-md:flex-col max-md:gap-8" pad={0}>
        <col tw="flex flex-col gap-6 w-[46%] max-md:w-full shrink-0" pad={0}>
          <Eyebrow color="#E2A98C">The people in the room with you</Eyebrow>
          <h2 font={HEAD} size={42} weight={600} color={C.white} lh={1.14} mobile={{ size: 29 }}>
            The teachers, and where they are from
          </h2>
          <text font={BODY} size={17} color="#C9D2E2" lh={1.75} maxw={520} mobile={{ size: 15.5 }}>
            Teachers are native speakers who live in the language, not in a curriculum. They will talk to you about their own street, their own football team and their own arguments with their own mother.
          </text>
          <box tw="flex w-full" pad={0} radius={3} shadow={[[26, 44, -28, 'rgba(0,0,0,0.55)']]}>
            <img src={IMG.streetLife} w="100%" radius={3} fit="cover" />
          </box>
        </col>

        {/* no w-full: flex={1} is `1 1 0`, so the declared width never applied on the main axis —
            but Elementor reads 46%+100% on a gapped flex row as an overflow and rejects the save. */}
        <col tw="flex flex-col" pad={0} flex={1} gap={0} justify="center">
          {TEACHERS.map((t) => (
            <Teacher name={t.name} line={t.line} />
          ))}
          <text font={BODY} size={14.5} color="#9FB0C9" lh={1.7} pad={{ t: 18 }} maxw={460}>
            Every teacher has been through our own placement call from the other side of the screen. None of them will let you switch to English at minute four.
          </text>
        </col>
      </row>
    </section>

    {/* 4 — languages and levels */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:py-16" pad={0} bg={C.ground}>
      <box tw="flex flex-col w-full max-w-[1120px] gap-10" pad={0}>
        <row tw="flex flex-row w-full items-end justify-between gap-10 max-md:flex-col max-md:items-start max-md:gap-4" pad={{ b: 16 }} raw="& { border-bottom: 2px solid #22201E; }">
          <col tw="flex flex-col gap-3" pad={0}>
            <Eyebrow color={C.olive}>Five languages</Eyebrow>
            <h2 font={HEAD} size={42} weight={600} color={C.ink} lh={1.14} mobile={{ size: 29 }}>
              Languages and levels offered
            </h2>
          </col>
          <text font={BODY} size={16} color="#5C554E" lh={1.7} maxw={400}>
            Spanish, Portuguese, Italian, French and Greek, from complete beginner to B2. Your level is set on the call, not by a form.
          </text>
        </row>

        <grid cols={5} gap={18} mobile={{ gridCols: 1 }} tablet={{ gridCols: 2 }} tw="w-full" pad={0} motion={FADE}>
          {LANGS.map((l) => (
            <LangCard lang={l.lang} native={l.native} levels={l.levels} />
          ))}
        </grid>
      </box>
    </section>

    {/* 5 — the one rule (the single centred section) */}
    <section tw="flex flex-col w-full items-center px-6 py-28 max-md:py-16 text-center" pad={0} bg={C.ink}>
      <col tw="flex flex-col items-center gap-6 w-full max-w-[760px] text-center" pad={0} align="center" motion={FADE}>
        <Eyebrow color="#E2A98C">The one rule</Eyebrow>
        <h2 font={HEAD} size={54} weight={600} color={C.ground} lh={1.1} ta="center" tablet={{ size: 42 }} mobile={{ size: 31 }}>
          No English after minute three
        </h2>
        <text font={BODY} size={17.5} color="#CFC5B8" lh={1.8} ta="center" maxw={640} mobile={{ size: 15.5 }}>
          The first three minutes are for admin and nerves. After that the room switches and stays switched for eighty-seven minutes. You will point, mime, draw, use the wrong word on purpose and get there anyway — and the teacher will help you get there in the language, never around it.
        </text>
        <text font={BODY} size={15} color="#8E857A" lh={1.7} ta="center" maxw={560}>
          Homework is only conversation. No worksheets, no gap-fills, no streaks to protect.
        </text>
      </col>
    </section>

    {/* 6 — placement call */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:py-16" pad={0} bg={C.white}>
      <row tw="flex flex-row w-full max-w-[1120px] items-start gap-16 max-lg:gap-10 max-md:flex-col max-md:gap-8" pad={0}>
        <col tw="flex flex-col gap-5" pad={0} flex={1} maxw={620}>
          <Eyebrow color={C.indigo}>Before any money moves</Eyebrow>
          <h2 font={HEAD} size={42} weight={600} color={C.ink} lh={1.14} mobile={{ size: 29 }}>
            A placement call before you pay
          </h2>
          <text font={BODY} size={17.5} color="#4A443E" lh={1.75} mobile={{ size: 16 }}>
            Nobody buys before a twenty-minute placement call. Roughly one in six people we speak to are told to start a level higher than they expected.
          </text>
          <text font={BODY} size={16} color="#5C554E" lh={1.75}>
            It is a conversation, not a test. Ten minutes in English about why you are doing this, ten minutes in the language you are learning — however little of it you have. We tell you the level, the next intake date and, sometimes, that you should not book yet.
          </text>
          <box pad={{ t: 6 }}><Cta bg={C.indigo} label="Book a placement call" /></box>
        </col>

        <col tw="flex flex-col w-[360px] max-lg:w-[300px] max-md:w-full shrink-0 gap-0" pad={0} bg={C.ground} border={[1, C.rule]} radius={3}>
          <col tw="flex flex-col gap-2" pad={24} raw="& { border-bottom: 1px solid #E4D8C9; }">
            <text font={HEAD} size={20} weight={600} color={C.ink}>Minute 0–10</text>
            <text font={BODY} size={15} color="#5C554E" lh={1.65}>In English: three years of an app, and what still happens when a waiter answers you.</text>
          </col>
          <col tw="flex flex-col gap-2" pad={24} raw="& { border-bottom: 1px solid #E4D8C9; }">
            <text font={HEAD} size={20} weight={600} color={C.ink}>Minute 10–20</text>
            <text font={BODY} size={15} color="#5C554E" lh={1.65}>In the language. Badly is fine. Silence is fine. We are listening for what you reach for.</text>
          </col>
          <col tw="flex flex-col gap-2" pad={24}>
            <text font={HEAD} size={20} weight={600} color={C.ink}>Same day</text>
            <text font={BODY} size={15} color="#5C554E" lh={1.65}>An email with your level, your intake date and the two evening slots you would keep for eight weeks.</text>
          </col>
        </col>
      </row>
    </section>

    {/* 7 — price, schedule, missed weeks */}
    <section tw="flex flex-col w-full items-center px-6 py-24 max-md:py-16" pad={0} bg={C.ground}>
      <box tw="flex flex-col w-full max-w-[900px] gap-8" pad={0}>
        <col tw="flex flex-col gap-3" pad={0}>
          <Eyebrow>Plainly</Eyebrow>
          <h2 font={HEAD} size={42} weight={600} color={C.ink} lh={1.14} mobile={{ size: 29 }}>
            Price, schedule and what happens if you miss a week
          </h2>
        </col>
        <col tw="flex flex-col w-full" pad={0} gap={0} raw="& { border-top: 2px solid #22201E; }">
          {FACTS.map((f) => (
            <FactRow label={f.label} value={f.value} />
          ))}
        </col>
      </box>
    </section>

    {/* 8 — book */}
    <section id="placement" tw="flex flex-col w-full items-center px-6 py-24 max-md:py-16" pad={0} bg={C.terracotta}>
      <row tw="flex flex-row w-full max-w-[1120px] items-center justify-between gap-12 max-md:flex-col max-md:items-start max-md:gap-7" pad={0}>
        <col tw="flex flex-col gap-4" pad={0} maxw={640}>
          <h2 font={HEAD} size={46} weight={600} color={C.ground} lh={1.12} mobile={{ size: 30 }}>
            Book a placement call
          </h2>
          <text font={BODY} size={17.5} color="#FBE7DC" lh={1.75} mobile={{ size: 16 }}>
            Twenty minutes, free, no card. You will speak the language for ten of them and we will tell you honestly where you are. The next cohort of four starts the first Monday of the month.
          </text>
        </col>
        <col tw="flex flex-col gap-3 items-start shrink-0" pad={0}>
          <Cta href="mailto:hello@verbo.school?subject=Placement%20call" bg={C.ink} label="Book a placement call" />
          <text font={BODY} size={14} color="#FBE7DC" lh={1.6}>
            hello@verbo.school · £420 · sixteen sessions
          </text>
        </col>
      </row>
    </section>

    <box tw="flex flex-col w-full items-center px-6 py-8" pad={0} bg={C.ink}>
      <row tw="flex flex-row w-full max-w-[1120px] items-center justify-between gap-6 max-md:flex-col max-md:gap-2" pad={0}>
        <text font={HEAD} size={17} weight={600} color={C.ground}>Verbo</text>
        <text font={BODY} size={13} color="#8E857A" lh={1.6}>Live immersion language courses · four students · eight weeks</text>
      </row>
    </box>
  </box>
);
