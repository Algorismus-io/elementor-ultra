/** RUNTIME — a typographic poster for a two-day, single-track production conference. */
export const meta = {
  title: 'RUNTIME — 4—5 Nov, Rotterdam',
  slug: 'runtime-conf',
  seo: {
    title: 'RUNTIME · 4—5 Nov · Rotterdam — two days, one track, real incident data',
    description:
      'RUNTIME is a two-day single-track conference about what actually runs in production. Nineteen talks, 900 engineers, zero sponsor talks. Every speaker shows real graphs from a real incident.',
  },
};

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 500 };

/* ── repeaters (content props only — no style props cross the boundary) ───────── */

const Talk = defineComponent(
  ({ num = '01', title = 'Talk', speaker = 'Speaker', org = 'Org', slot = '25 min' }) => (
    <grid
      cols="96px 1fr 300px"
      gap={24}
      cls="talk-row"
      tw="w-full py-8 border-t border-[#EAEAEA] items-start hover:bg-[#FAFAFA] max-lg:grid-cols-[72px_1fr] max-md:py-6"
      mobile={{ gridCols: 1, gap: 10 }}
    >
      <text cls="talk-num" size={15} weight={500} color="#FF4A00" font="Space Grotesk" ls={0.08}>
        {num}
      </text>
      <heading
        tag="h3"
        cls="talk-title"
        size={46}
        lh={0.98}
        ls={-0.015}
        weight={400}
        font="Anton"
        color="#000000"
        tablet={{ size: 34 }}
        mobile={{ size: 27 }}
        raw="text-transform: uppercase;"
      >
        {title}
      </heading>
      <box cls="talk-meta" tw="flex flex-col gap-1 max-lg:col-span-2 max-md:col-span-1">
        <text cls="talk-speaker" size={16} weight={500} color="#000000" font="Space Grotesk">
          {speaker}
        </text>
        <text cls="talk-org" size={15} color="#6B6B72" font="Space Grotesk">
          {org} · {slot}
        </text>
      </box>
    </grid>
  ),
  {
    title: 'RUNTIME Talk Row',
    props: {
      num: { label: 'Number', group: 'Talk' },
      title: { label: 'Talk title', group: 'Talk' },
      speaker: { label: 'Speaker', group: 'Talk' },
      org: { label: 'Organisation', group: 'Talk' },
      slot: { label: 'Length', group: 'Talk' },
    },
  },
);

const Slot = defineComponent(
  ({ time = '09:00', session = 'Session', note = '' }) => (
    <grid
      cols="120px 1fr"
      gap={20}
      cls="slot-row"
      tw="w-full py-4 border-t border-[#EAEAEA] items-start"
      mobile={{ gridCols: '84px 1fr', gap: 12 }}
    >
      <text cls="slot-time" size={15} weight={500} color="#FF4A00" font="Space Grotesk" ls={0.04}>
        {time}
      </text>
      <box cls="slot-body" tw="flex flex-col gap-1">
        <text cls="slot-session" size={17} weight={500} color="#000000" font="Space Grotesk" lh={1.3}>
          {session}
        </text>
        <text cls="slot-note" size={14} color="#6B6B72" font="Space Grotesk" lh={1.4}>
          {note}
        </text>
      </box>
    </grid>
  ),
  {
    title: 'RUNTIME Schedule Slot',
    props: {
      time: { label: 'Time', group: 'Slot' },
      session: { label: 'Session', group: 'Slot' },
      note: { label: 'Note', group: 'Slot' },
    },
  },
);

/* ── page ─────────────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" bg={t.color.ground}>

    {/* 1 ─ TYPE WALL ─────────────────────────────────────────────────────────── */}
    <section
      tw="flex flex-col w-full px-10 pt-8 pb-20 max-lg:px-8 max-md:px-5 max-md:pt-6 max-md:pb-12"
      bg={t.color.ground}
    >
      <row tw="flex flex-row w-full justify-between items-center pb-5 border-b border-[#EAEAEA] flex-wrap gap-3">
        <text size={14} weight={500} ls={0.14} color={t.color.ink} font={t.font.body} raw="text-transform: uppercase;">
          Runtime 2026
        </text>
        <text size={14} weight={500} ls={0.14} color="#6B6B72" font={t.font.body} raw="text-transform: uppercase;" tw="max-md:hidden">
          Two days · one track · nineteen talks
        </text>
        <text size={14} weight={500} ls={0.14} color={t.color.flash} font={t.font.body} raw="text-transform: uppercase;">
          Zero sponsor talks
        </text>
      </row>

      <h1
        tw="w-full pt-8 max-md:pt-6"
        size={252}
        tablet={{ size: 148 }}
        mobile={{ size: 74 }}
        lh={0.84}
        ls={-0.02}
        weight={400}
        font={t.font.head}
        color={t.color.ink}
        raw="text-transform: uppercase; & em { color: #FF4A00; font-style: normal; }"
      >
        RUNTIME<br /><em>4—5 NOV</em><br />ROTTERDAM
      </h1>

      <grid
        cols={12}
        gap={32}
        tw="w-full pt-14 border-t border-[#EAEAEA] mt-12 items-start max-md:pt-8 max-md:mt-8"
        mobile={{ gridCols: 1, gap: 28 }}
      >
        <text
          span={7}
          size={22}
          lh={1.45}
          weight={400}
          color={t.color.ink}
          font={t.font.body}
          tablet={{ size: 19 }}
          mobile={{ size: 17 }}
        >
          Two days, one track, 900 engineers, and nineteen talks about systems that actually broke.
          Every speaker shows real graphs from a real incident or they do not get the slot.
        </text>
        <box span={5} tw="flex flex-col items-start gap-5 max-md:col-span-1">
          <text
            href="#tickets"
            size={20}
            weight={500}
            font={t.font.body}
            color="#FFFFFF"
            bg={t.color.flash}
            pad={[18, 34]}
            tw="no-underline hover:bg-[#000000]"
          >
            Get a ticket
          </text>
          <text size={15} color="#6B6B72" font={t.font.body} lh={1.5}>
            Early 340 · standard 420 · corporate 690. 120 pay-what-you-can tickets, no questions asked.
          </text>
        </box>
      </grid>
    </section>

    {/* 2 ─ THE RULE ──────────────────────────────────────────────────────────── */}
    <section
      tw="flex flex-col w-full px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16"
      bg={t.color.night}
    >
      <grid cols={12} gap={40} tw="w-full items-start" mobile={{ gridCols: 1, gap: 24 }}>
        <heading
          tag="h2"
          span={5}
          size={132}
          tablet={{ size: 86 }}
          mobile={{ size: 62 }}
          lh={0.82}
          ls={-0.02}
          weight={400}
          font={t.font.head}
          color="#FFFFFF"
          raw="text-transform: uppercase; & em { color: #FF4A00; font-style: normal; }"
        >
          ONE<br /><em>TRACK</em>
        </heading>
        <box span={7} tw="flex flex-col gap-10 max-md:col-span-1 max-md:gap-7">
          <text
            size={26}
            lh={1.4}
            color="#FFFFFF"
            font={t.font.body}
            tablet={{ size: 21 }}
            mobile={{ size: 18 }}
            motion={FADE}
          >
            One track. Everybody sees the same talks, so the hallway conversation is about the same
            thing all day. This is the whole point.
          </text>
          <grid cols={3} gap={24} tw="w-full pt-8 border-t border-[#2A2A34]" mobile={{ gridCols: 3, gap: 12 }}>
            <box tw="flex flex-col gap-2">
              <text size={54} weight={400} font={t.font.head} color={t.color.flash} lh={1} mobile={{ size: 34 }}>
                900
              </text>
              <text size={14} color="#8A8A96" font={t.font.body} ls={0.06} raw="text-transform: uppercase;">
                Engineers
              </text>
            </box>
            <box tw="flex flex-col gap-2">
              <text size={54} weight={400} font={t.font.head} color="#FFFFFF" lh={1} mobile={{ size: 34 }}>
                19
              </text>
              <text size={14} color="#8A8A96" font={t.font.body} ls={0.06} raw="text-transform: uppercase;">
                Talks
              </text>
            </box>
            <box tw="flex flex-col gap-2">
              <text size={54} weight={400} font={t.font.head} color="#FFFFFF" lh={1} mobile={{ size: 34 }}>
                0
              </text>
              <text size={14} color="#8A8A96" font={t.font.body} ls={0.06} raw="text-transform: uppercase;">
                Parallel rooms
              </text>
            </box>
          </grid>
        </box>
      </grid>
    </section>

    {/* 3 ─ THE TALKS ─────────────────────────────────────────────────────────── */}
    <section
      tw="flex flex-col w-full px-10 pt-24 pb-24 max-lg:px-8 max-md:px-5 max-md:pt-16 max-md:pb-16"
      bg={t.color.ground}
    >
      <row tw="flex flex-row w-full justify-between items-end pb-10 flex-wrap gap-4 max-md:pb-6">
        <heading
          tag="h2"
          size={104}
          tablet={{ size: 72 }}
          mobile={{ size: 46 }}
          lh={0.86}
          ls={-0.02}
          weight={400}
          font={t.font.head}
          color={t.color.ink}
          raw="text-transform: uppercase;"
        >
          The talks
        </heading>
        <text size={15} color="#6B6B72" font={t.font.body} ls={0.06} raw="text-transform: uppercase;">
          Four of nineteen · full list in September
        </text>
      </row>

      {Talk({
        num: '01',
        title: 'How we lost 40 minutes of writes and got them back',
        speaker: 'Marlies Boone',
        org: 'Payments infrastructure, Adyen',
        slot: '35 min',
      })}
      {Talk({
        num: '02',
        title: 'Nine years of one Postgres',
        speaker: 'Tarek Idrissi',
        org: 'Data platform, Bol',
        slot: '35 min',
      })}
      {Talk({
        num: '03',
        title: 'The queue that was actually a memory leak',
        speaker: 'Priya Raman',
        org: 'Core services, Backbase',
        slot: '25 min',
      })}
      {Talk({
        num: '04',
        title: 'Deleting our service mesh',
        speaker: 'Joris Vandenberg',
        org: 'Platform engineering, Mollie',
        slot: '35 min',
      })}

      <text
        size={17}
        color="#6B6B72"
        font={t.font.body}
        tw="pt-8 border-t border-[#EAEAEA]"
        lh={1.5}
      >
        Fifteen more talks announced in two waves. Every one of them ships a graph, a timeline and the
        commit that fixed it — <strong>no slideware architecture, no roadmap keynotes</strong>.
      </text>
    </section>

    {/* 4 ─ NO SPONSOR TALKS ──────────────────────────────────────────────────── */}
    <section
      tw="flex flex-col w-full px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16"
      bg={t.color.flash}
    >
      <grid cols={12} gap={40} tw="w-full items-end" mobile={{ gridCols: 1, gap: 24 }}>
        <heading
          tag="h2"
          span={6}
          size={116}
          tablet={{ size: 74 }}
          mobile={{ size: 54 }}
          lh={0.82}
          ls={-0.02}
          weight={400}
          font={t.font.head}
          color={t.color.ink}
          raw="text-transform: uppercase;"
          motion={FADE}
        >
          Zero<br />minutes<br />on stage
        </heading>
        <box span={6} tw="flex flex-col gap-6 max-md:col-span-1">
          <text size={26} lh={1.4} color={t.color.ink} font={t.font.body} tablet={{ size: 21 }} mobile={{ size: 18 }}>
            Sponsors get a table, their logo on the wall, and zero minutes on stage. Three of them
            still came back this year.
          </text>
          <text
            size={16}
            lh={1.55}
            color="#3A1200"
            font={t.font.body}
            tw="pt-6 border-t border-[#000000]"
          >
            No sponsored slots, no logo-led lightning talks, no "partner keynote" wedged in before
            lunch. The programme committee reads submissions with the company name removed.
          </text>
        </box>
      </grid>
    </section>

    {/* 5 ─ SCHEDULE ──────────────────────────────────────────────────────────── */}
    <section
      tw="flex flex-col w-full px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16"
      bg={t.color.ground}
    >
      <heading
        tag="h2"
        size={104}
        tablet={{ size: 72 }}
        mobile={{ size: 46 }}
        lh={0.86}
        ls={-0.02}
        weight={400}
        font={t.font.head}
        color={t.color.ink}
        raw="text-transform: uppercase;"
        tw="pb-10 max-md:pb-6"
      >
        Two days
      </heading>

      <grid cols={2} gap={56} tw="w-full items-start" mobile={{ gridCols: 1, gap: 40 }}>
        <box tw="flex flex-col w-full">
          <heading
            tag="h3"
            size={30}
            weight={400}
            font={t.font.head}
            color={t.color.ink}
            tw="pb-4"
            raw="text-transform: uppercase;"
          >
            Tue 4 Nov
          </heading>
          {Slot({ time: '08:30', session: 'Doors, coffee, name badges written by hand', note: 'De Doelen, Rotterdam' })}
          {Slot({ time: '09:30', session: 'How we lost 40 minutes of writes and got them back', note: 'Marlies Boone' })}
          {Slot({ time: '10:30', session: 'The queue that was actually a memory leak', note: 'Priya Raman' })}
          {Slot({ time: '11:30', session: 'Hallway track', note: 'One hour, deliberately unscheduled' })}
          {Slot({ time: '13:00', session: 'Nine years of one Postgres', note: 'Tarek Idrissi' })}
          {Slot({ time: '14:30', session: 'Incident clinic, first sitting', note: 'Four staff engineers, twenty minutes each' })}
          {Slot({ time: '17:00', session: 'Close, then the bar downstairs', note: 'No sponsor stage, no branded lanyards' })}
        </box>
        <box tw="flex flex-col w-full">
          <heading
            tag="h3"
            size={30}
            weight={400}
            font={t.font.head}
            color={t.color.ink}
            tw="pb-4"
            raw="text-transform: uppercase;"
          >
            Wed 5 Nov
          </heading>
          {Slot({ time: '09:00', session: 'Deleting our service mesh', note: 'Joris Vandenberg' })}
          {Slot({ time: '10:00', session: 'Workshops, three rooms, ninety minutes', note: 'Postgres, tracing, on-call design' })}
          {Slot({ time: '12:00', session: 'Hallway track', note: 'Same talks, same argument, better coffee' })}
          {Slot({ time: '13:30', session: 'Two incident retrospectives, told live', note: 'Speakers announced in October' })}
          {Slot({ time: '15:00', session: 'Incident clinic, second sitting', note: 'Bring the diagram you are embarrassed by' })}
          {Slot({ time: '16:30', session: 'One last talk, then we all go home', note: 'Nineteen down' })}
          {Slot({ time: '18:00', session: 'Venue closes', note: 'Slides and graphs published the same week' })}
        </box>
      </grid>
    </section>

    {/* 6 ─ HALLWAY, WORKSHOPS, CLINIC ────────────────────────────────────────── */}
    <section
      tw="flex flex-col w-full px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16"
      bg={t.color.night}
    >
      <grid cols={12} gap={32} tw="w-full items-stretch" mobile={{ gridCols: 1, gap: 20 }}>
        <box span={7} tw="flex flex-col gap-5 p-10 max-md:col-span-1 max-md:p-6" bg="#1B1B26">
          <text size={15} ls={0.1} color="#8A8A96" font={t.font.body} raw="text-transform: uppercase;">
            01 — Hallway track
          </text>
          <heading
            tag="h2"
            size={68}
            tablet={{ size: 48 }}
            mobile={{ size: 38 }}
            lh={0.9}
            weight={400}
            font={t.font.head}
            color="#FFFFFF"
            raw="text-transform: uppercase;"
          >
            The corridor is on the schedule
          </heading>
          <text size={18} lh={1.55} color="#C7C7D1" font={t.font.body}>
            Two full hours of nothing programmed, because the single track means everyone is arguing
            about the same failure at the same time. Tables, whiteboards, and a wall of open questions
            you can write on.
          </text>
        </box>
        <box span={5} tw="flex flex-col gap-5 p-10 max-md:col-span-1 max-md:p-6" bg={t.color.flash}>
          <text size={15} ls={0.1} color="#3A1200" font={t.font.body} raw="text-transform: uppercase;">
            02 — Incident clinic
          </text>
          <heading
            tag="h3"
            size={56}
            tablet={{ size: 40 }}
            mobile={{ size: 34 }}
            lh={0.9}
            weight={400}
            font={t.font.head}
            color={t.color.ink}
            raw="text-transform: uppercase;"
          >
            Brutal and free
          </heading>
          <text size={18} lh={1.55} color={t.color.ink} font={t.font.body}>
            Bring your worst architecture diagram to the incident clinic. Four staff engineers, twenty
            minutes each, brutal and free.
          </text>
        </box>
        <box
          span={12}
          tw="flex flex-row w-full justify-between items-center gap-8 p-10 flex-wrap max-md:col-span-1 max-md:p-6"
          border={[1, '#2A2A34']}
        >
          <text size={15} ls={0.1} color="#8A8A96" font={t.font.body} raw="text-transform: uppercase;">
            03 — Workshops
          </text>
          <text
            size={44}
            tablet={{ size: 32 }}
            mobile={{ size: 26 }}
            lh={1}
            weight={400}
            font={t.font.head}
            color="#FFFFFF"
            raw="text-transform: uppercase;"
          >
            Postgres · tracing · on-call design
          </text>
          <text size={16} color="#C7C7D1" font={t.font.body}>
            Ninety minutes, thirty seats each, included with every ticket.
          </text>
        </box>
      </grid>
    </section>

    {/* 7 ─ TICKETS ───────────────────────────────────────────────────────────── */}
    <section
      id="tickets"
      tw="flex flex-col w-full px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16"
      bg={t.color.ground}
    >
      <row tw="flex flex-row w-full justify-between items-end pb-10 flex-wrap gap-4 max-md:pb-6">
        <heading
          tag="h2"
          size={104}
          tablet={{ size: 72 }}
          mobile={{ size: 46 }}
          lh={0.86}
          ls={-0.02}
          weight={400}
          font={t.font.head}
          color={t.color.ink}
          raw="text-transform: uppercase;"
        >
          Tickets
        </heading>
        <text size={15} color="#6B6B72" font={t.font.body} ls={0.06} raw="text-transform: uppercase;">
          Prices in euro · VAT included
        </text>
      </row>

      <grid cols={3} gap={0} tw="w-full border-t border-[#EAEAEA]" mobile={{ gridCols: 1 }}>
        <box tw="flex flex-col gap-2 py-10 pr-8 border-b border-[#EAEAEA] max-md:py-6 max-md:pr-0">
          <text size={92} tablet={{ size: 64 }} mobile={{ size: 58 }} lh={0.9} weight={400} font={t.font.head} color={t.color.ink}>
            340
          </text>
          <text size={16} weight={500} color={t.color.flash} font={t.font.body} ls={0.08} raw="text-transform: uppercase;">
            Early
          </text>
          <text size={15} color="#6B6B72" font={t.font.body} lh={1.5}>
            Gone when they are gone. No countdown timers, no fake scarcity.
          </text>
        </box>
        <box tw="flex flex-col gap-2 py-10 px-8 border-b border-l border-[#EAEAEA] max-md:py-6 max-md:px-0">
          <text size={92} tablet={{ size: 64 }} mobile={{ size: 58 }} lh={0.9} weight={400} font={t.font.head} color={t.color.ink}>
            420
          </text>
          <text size={16} weight={500} color={t.color.flash} font={t.font.body} ls={0.08} raw="text-transform: uppercase;">
            Standard
          </text>
          <text size={15} color="#6B6B72" font={t.font.body} lh={1.5}>
            Both days, both clinics, every workshop, lunch that is actually lunch.
          </text>
        </box>
        <box tw="flex flex-col gap-2 py-10 pl-8 border-b border-l border-[#EAEAEA] max-md:py-6 max-md:pl-0">
          <text size={92} tablet={{ size: 64 }} mobile={{ size: 58 }} lh={0.9} weight={400} font={t.font.head} color={t.color.ink}>
            690
          </text>
          <text size={16} weight={500} color={t.color.flash} font={t.font.body} ls={0.08} raw="text-transform: uppercase;">
            Corporate
          </text>
          <text size={15} color="#6B6B72" font={t.font.body} lh={1.5}>
            For the expense system. It funds the pay-what-you-can allocation below.
          </text>
        </box>
      </grid>

      <grid
        cols={12}
        gap={32}
        tw="w-full mt-14 p-12 items-center max-md:mt-8 max-md:p-6"
        bg={t.color.night}
        mobile={{ gridCols: 1, gap: 20 }}
      >
        <text
          span={3}
          size={128}
          tablet={{ size: 88 }}
          mobile={{ size: 72 }}
          lh={0.86}
          weight={400}
          font={t.font.head}
          color={t.color.flash}
        >
          120
        </text>
        <box span={6} tw="flex flex-col gap-3 max-md:col-span-1">
          <heading tag="h3" size={26} weight={400} font={t.font.head} color="#FFFFFF" raw="text-transform: uppercase;">
            Pay what you can
          </heading>
          <text size={18} lh={1.55} color="#C7C7D1" font={t.font.body}>
            120 pay-what-you-can tickets released in two batches, no questions asked, no proof
            required. Same seat, same badge, nothing on it that says which kind you bought.
          </text>
        </box>
        <box span={3} tw="flex flex-col items-start gap-3 max-md:col-span-1">
          <text
            href="#tickets"
            size={18}
            weight={500}
            font={t.font.body}
            color={t.color.ink}
            bg="#FFFFFF"
            pad={[16, 28]}
            tw="no-underline hover:bg-[#FF4A00] hover:text-[#FFFFFF]"
          >
            Get a ticket
          </text>
          <text size={14} color="#8A8A96" font={t.font.body}>
            Batch two opens 12 September, 10:00 CET.
          </text>
        </box>
      </grid>
    </section>

    {/* 8 ─ CODE OF CONDUCT ───────────────────────────────────────────────────── */}
    <section
      tw="flex flex-col w-full px-10 py-24 max-lg:px-8 max-md:px-5 max-md:py-16"
      bg={t.color.night}
    >
      <grid cols={12} gap={40} tw="w-full items-start" mobile={{ gridCols: 1, gap: 24 }}>
        <heading
          tag="h2"
          span={6}
          size={92}
          tablet={{ size: 62 }}
          mobile={{ size: 44 }}
          lh={0.86}
          ls={-0.02}
          weight={400}
          font={t.font.head}
          color="#FFFFFF"
          raw="text-transform: uppercase; & em { color: #FF4A00; font-style: normal; }"
        >
          Code of<br /><em>conduct</em>
        </heading>
        <box span={6} tw="flex flex-col gap-8 max-md:col-span-1 max-md:gap-6">
          <text size={22} lh={1.5} color="#FFFFFF" font={t.font.body} tablet={{ size: 19 }} mobile={{ size: 17 }}>
            Full code of conduct, three named enforcers with photos, and a phone number that reaches a
            human during the event.
          </text>
          <box tw="flex flex-col gap-2 pt-8 border-t border-[#2A2A34]">
            <text size={14} ls={0.1} color="#8A8A96" font={t.font.body} raw="text-transform: uppercase;">
              During the event, 24 hours
            </text>
            <text
              href="tel:+31103400045"
              size={58}
              tablet={{ size: 42 }}
              mobile={{ size: 32 }}
              lh={1}
              weight={400}
              font={t.font.head}
              color={t.color.flash}
              tw="no-underline hover:text-[#FFFFFF]"
            >
              +31 10 340 0045
            </text>
            <text size={15} lh={1.55} color="#C7C7D1" font={t.font.body}>
              Reports go to Ilse, Femi and Dana — photographed on the wall by the entrance so you know
              who to look for. Reports are acted on the same day, and sanctions are published in the
              post-event write-up without naming the reporter.
            </text>
          </box>
        </box>
      </grid>

      <row tw="flex flex-row w-full justify-between items-center pt-16 mt-16 border-t border-[#2A2A34] flex-wrap gap-4 max-md:pt-8 max-md:mt-8">
        <text size={14} ls={0.1} color="#8A8A96" font={t.font.body} raw="text-transform: uppercase;">
          Runtime · 4—5 Nov 2026 · De Doelen, Rotterdam
        </text>
        <text size={14} ls={0.1} color="#8A8A96" font={t.font.body} raw="text-transform: uppercase;">
          Nineteen talks · one track · zero sponsor slots
        </text>
      </row>
    </section>
  </box>
);
