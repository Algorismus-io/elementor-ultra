/** Hard Turn — asymmetric diagonal collage landing page. */
import { MEDIA as map } from '../data/media.mjs';

const IMG = { print: map.print_detail.id, wall: map.studio_wall.id, team: map.team_working.id };

export const meta = {
  title: 'Hard Turn',
  slug: 'hard-turn',
  seo: {
    title: 'Hard Turn — four people who only take rebrands',
    description:
      'Hard Turn is a four-person identity studio that only takes rebrands. Three clients at a time, eight weeks each. Identity from 42,000.',
  },
};

/* ── repeaters (content props only — Elementor components cannot override styles) ── */

const PriceRow = ({ n, price, title, note }) => (
    <grid cols={12} gap={20} cls="price-row" tw="w-full py-9 max-md:py-6 border-t border-[#0A0A0A]">
      <box span={1} mobile={{ span: 1 }}>
        <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font="DM Sans" color="#2B00FF">
          {n}
        </text>
      </box>
      <box span={3} mobile={{ span: 1 }}>
        <heading tag="h3" tw="text-[46px] max-lg:text-[36px] max-md:text-[34px] leading-none" weight={800} font="Syne" color="#0A0A0A">
          {price}
        </heading>
      </box>
      <box span={4} mobile={{ span: 1 }}>
        <text tw="text-[20px] max-md:text-[18px] leading-snug" weight={600} font="Syne" color="#0A0A0A">
          {title}
        </text>
      </box>
      <box span={4} mobile={{ span: 1 }}>
        <text tw="text-[15px] leading-relaxed" font="DM Sans" color="#0A0A0A">
          {note}
        </text>
      </box>
  </grid>
);

const TeamRow = ({ name, role, does }) => (
    <grid cols={12} gap={16} cls="team-row" tw="w-full py-6 border-t border-[#0A0A0A]">
      <box span={4} mobile={{ span: 1 }} tw="flex flex-col gap-1">
        <heading tag="h3" tw="text-[26px] leading-none" weight={700} font="Syne" color="#0A0A0A">
          {name}
        </heading>
        <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font="DM Sans" color="#FF3B00">
          {role}
        </text>
      </box>
      <box span={8} mobile={{ span: 1 }}>
        <text tw="text-[16px] leading-relaxed" font="DM Sans" color="#0A0A0A">
          {does}
        </text>
      </box>
  </grid>
);

/* ── the enquiry form (free core has no atomic form widgets — real HTML, real fields) ── */

const FORM_HTML = `
<style>
.ht-f{font-family:'DM Sans',system-ui,sans-serif;display:grid;grid-template-columns:1fr 1fr;gap:20px}
.ht-f .ht-wide{grid-column:1 / -1}
.ht-f label{display:block;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:#EFEFEA;margin-bottom:9px}
.ht-f input,.ht-f select,.ht-f textarea{width:100%;box-sizing:border-box;background:transparent;border:0;border-bottom:1px solid #4a4a4a;color:#FFFFFF;font-family:'DM Sans',system-ui,sans-serif;font-size:16px;padding:10px 0;border-radius:0}
.ht-f textarea{min-height:120px;resize:vertical}
.ht-f select{appearance:none;-webkit-appearance:none}
.ht-f option{color:#0A0A0A}
.ht-f input:focus,.ht-f select:focus,.ht-f textarea:focus{outline:0;border-bottom-color:#FF3B00}
.ht-f input::placeholder,.ht-f textarea::placeholder{color:#7a7a7a}
.ht-f button{grid-column:1 / -1;justify-self:start;background:#FF3B00;color:#FFFFFF;border:0;cursor:pointer;font-family:'Syne',system-ui,sans-serif;font-weight:700;font-size:17px;letter-spacing:.02em;padding:18px 40px;transition:background .15s ease}
.ht-f button:hover,.ht-f button:focus-visible{background:#2B00FF}
.ht-note{grid-column:1 / -1;font-family:'DM Sans',system-ui,sans-serif;font-size:13px;color:#8d8d8d;margin:0}
@media (max-width:767px){.ht-f{grid-template-columns:1fr;gap:18px}.ht-f button{width:100%;text-align:center;justify-self:stretch}}
</style>
<form class="ht-f" action="mailto:hello@hardturn.studio" method="post" enctype="text/plain">
  <div class="ht-wide">
    <label for="ht-broke">What broke?</label>
    <textarea id="ht-broke" name="What broke" required placeholder="The thing your current identity can no longer carry. Be specific, be unflattering."></textarea>
  </div>
  <div>
    <label for="ht-name">Your name</label>
    <input id="ht-name" name="Name" type="text" required placeholder="First and last">
  </div>
  <div>
    <label for="ht-company">Company</label>
    <input id="ht-company" name="Company" type="text" required placeholder="And the URL if it exists">
  </div>
  <div>
    <label for="ht-email">Email</label>
    <input id="ht-email" name="Email" type="email" required placeholder="you@company.com">
  </div>
  <div>
    <label for="ht-scope">Which of the three</label>
    <select id="ht-scope" name="Scope">
      <option>Identity system — 42,000</option>
      <option>Identity plus website design system — 68,000</option>
      <option>Identity plus brand operating manual and rollout — 95,000</option>
      <option>Not sure yet — tell me which one</option>
    </select>
  </div>
  <div class="ht-wide">
    <label for="ht-revenue">Last twelve months of revenue</label>
    <input id="ht-revenue" name="Revenue" type="text" required placeholder="A number. We only work with companies past their first shape.">
  </div>
  <button type="submit">Send it</button>
  <p class="ht-note">Nadia reads every one of these and answers within two working days, including the nos.</p>
</form>`;

/* ── the page ── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>

    {/* 1 — diagonal work collage with the studio name cut across it */}
    <box tw="relative w-full overflow-hidden" bg={t.color.ground} pad={{ t: 28, b: 0 }}>
      <box tw="flex flex-row justify-between items-center gap-4 px-12 max-lg:px-8 max-md:px-5 pb-8">
        <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.ink}>
          Hard Turn — identity studio
        </text>
        <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.ultra}>
          Three at a time
        </text>
      </box>

      <grid cols={12} gap={14} mobile={{ gap: 34 }} tw="px-12 max-lg:px-8 max-md:px-5">
        <box span={5} mobile={{ span: 1 }} tw="rotate-[-3deg] mt-2 max-md:mt-0">
          <img src={IMG.print} w="100%" h={300} fit="cover" mobile={{ h: 200 }} />
        </box>
        <box
          span={4}
          mobile={{ span: 1 }}
          tw="rotate-[2deg] mt-16 max-md:mt-0 px-7 py-8 flex flex-col justify-between gap-6"
          bg={t.color.shock}
        >
          <text tw="text-[26px] max-md:text-[22px] leading-tight" weight={700} font={t.font.head} color={t.color.paper}>
            Rebrands only. Never launches.
          </text>
          <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.paper}>
            Fragment 01 — packaging
          </text>
        </box>
        <box
          span={3}
          mobile={{ span: 1 }}
          tw="rotate-[-6deg] mt-6 max-md:mt-0 px-6 py-8 flex flex-col justify-between gap-6"
          bg={t.color.ultra}
        >
          <text tw="text-[46px] max-md:text-[38px] leading-none" weight={800} font={t.font.head} color={t.color.paper}>
            8
          </text>
          <text tw="text-[13px] leading-snug" font={t.font.body} color={t.color.paper}>
            weeks, start to recorded handover
          </text>
        </box>

        <box span={3} mobile={{ span: 1 }} tw="rotate-[4deg] -mt-8 max-md:mt-0">
          <img src={IMG.wall} w="100%" h={230} fit="cover" mobile={{ h: 190 }} />
        </box>
        <box span={6} mobile={{ span: 1 }} tw="rotate-[-2deg] mt-8 max-md:mt-0">
          <img src={IMG.team} w="100%" h={260} fit="cover" mobile={{ h: 200 }} />
        </box>
        <box
          span={3}
          mobile={{ span: 1 }}
          tw="rotate-[5deg] -mt-4 max-md:mt-0 px-6 py-8 flex flex-col justify-between gap-6"
          bg={t.color.ink}
        >
          <text tw="text-[46px] max-md:text-[38px] leading-none" weight={800} font={t.font.head} color={t.color.shock}>
            4
          </text>
          <text tw="text-[13px] leading-snug" font={t.font.body} color={t.color.ground}>
            people, all of whom you will meet
          </text>
        </box>
      </grid>

      {/* the name, cut across the collage on the diagonal */}
      <box
        tw="rotate-[-4deg] w-[124%] -ml-32 mt-2 mb-14 py-6 relative z-2 flex flex-row justify-center items-center max-md:w-[150%] max-md:-ml-20 max-md:mt-4 max-md:mb-8 max-md:py-4"
        bg={t.color.ultra}
      >
        <text
          tw="text-[74px] max-lg:text-[54px] max-md:text-[34px] leading-none uppercase whitespace-nowrap tracking-[0.02em]"
          weight={800}
          font={t.font.head}
          color={t.color.paper}
          ta="center"
        >
          Hard Turn · Hard Turn
        </text>
      </box>

      <grid cols={12} gap={32} tw="px-12 max-lg:px-8 max-md:px-5 pb-24 max-md:pb-16">
        <box span={8} mobile={{ span: 1 }} tw="flex flex-col gap-8 items-start">
          <h1
            tw="text-[78px] max-lg:text-[56px] max-md:text-[38px] leading-none tracking-[-0.02em]"
            weight={800}
            font={t.font.head}
            color={t.color.ink}
          >
            You outgrew the logo you drew in a hurry.
          </h1>
          <text tw="text-[20px] max-md:text-[17px] leading-relaxed max-w-2xl" font={t.font.body} color={t.color.ink}>
            Hard Turn is four people who only take rebrands. Not launches, not decks, not naming exercises for products
            that do not exist yet. Three clients at a time, eight weeks each.
          </text>
          <text
            href="#enquiry"
            tw="text-[17px] px-10 py-5 uppercase tracking-widest hover:bg-[#2B00FF]"
            weight={700}
            font={t.font.head}
            color={t.color.paper}
            bg={t.color.shock}
            w="hug"
          >
            Tell us what broke
          </text>
        </box>
        <box span={4} mobile={{ span: 1 }} tw="flex flex-col gap-4 pt-4 border-t border-[#0A0A0A]">
          <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.ultra}>
            Availability
          </text>
          <text tw="text-[17px] leading-relaxed" font={t.font.body} color={t.color.ink}>
            Next opening: late October. We take deposits to hold a slot and we have never moved one.
          </text>
        </box>
      </grid>
    </box>

    {/* 2 — we only do rebrands, stated flatly */}
    <box tw="w-full px-12 max-lg:px-8 max-md:px-5 py-28 max-md:py-16" bg={t.color.ink}>
      <grid cols={12} gap={32}>
        <box span={3} mobile={{ span: 1 }} tw="flex flex-col gap-3">
          <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.shock}>
            02 — What we do
          </text>
          <text tw="text-[15px] leading-relaxed" font={t.font.body} color="#8d8d8d">
            Said flatly, so nobody wastes a call finding out.
          </text>
        </box>
        <box span={9} mobile={{ span: 1 }} tw="flex flex-col gap-8">
          <h2
            tw="text-[62px] max-lg:text-[46px] max-md:text-[32px] leading-none tracking-[-0.02em]"
            weight={800}
            font={t.font.head}
            color={t.color.paper}
            motion={{ effect: 'fade', trigger: 'scrollIn' }}
          >
            We only do rebrands.
          </h2>
          <text tw="text-[21px] max-md:text-[17px] leading-relaxed max-w-3xl" font={t.font.body} color={t.color.ground}>
            You already have customers, a category, a sales deck someone hates, and a mark that was drawn in an
            afternoon four years ago. That is the work. If the company does not exist yet, there is nothing for us to
            turn, and we will say so in one line rather than three meetings.
          </text>
        </box>
      </grid>
    </box>

    {/* 3 — three engagements, three prices, no packages */}
    <box tw="w-full px-12 max-lg:px-8 max-md:px-5 py-28 max-md:py-16 flex flex-col gap-10" bg={t.color.ground}>
      <grid cols={12} gap={32}>
        <box span={7} mobile={{ span: 1 }}>
          <h2
            tw="text-[54px] max-lg:text-[42px] max-md:text-[30px] leading-none tracking-[-0.02em]"
            weight={800}
            font={t.font.head}
            color={t.color.ink}
          >
            Three engagements. Three prices. No packages.
          </h2>
        </box>
        <box span={5} mobile={{ span: 1 }} tw="flex flex-col justify-end">
          <text tw="text-[16px] leading-relaxed" font={t.font.body} color={t.color.ink}>
            Identity system, 42,000. Identity plus a website design system, 68,000. Identity plus a full brand operating
            manual and rollout, 95,000.
          </text>
        </box>
      </grid>

      <box tw="flex flex-col w-full">
        <PriceRow n="01" price="42,000" title="Identity system" note="Marks, type, colour, motion rules, and the files that make them behave. The core of every engagement." />
        <box tw="pl-16 max-md:pl-0">
          <PriceRow n="02" price="68,000" title="Identity plus a website design system" note="The above, plus components, states and page shapes built to survive whoever ships the site after us." />
        </box>
        <box tw="pl-32 max-md:pl-0">
          <PriceRow n="03" price="95,000" title="Identity plus a brand operating manual and rollout" note="The above, plus the manual, the rollout order, and the recorded handover your next hire will actually watch." />
        </box>
      </box>

      <box tw="border-t border-[#0A0A0A] pt-8 flex flex-row justify-end max-md:justify-start">
        <text
          tw="text-[38px] max-md:text-[26px] leading-none uppercase"
          weight={800}
          font={t.font.head}
          color={t.color.shock}
        >
          Those are the three. There is no fourth.
        </text>
      </box>
    </box>

    {/* 4 — the eight-week shape of a project */}
    <box tw="w-full px-12 max-lg:px-8 max-md:px-5 py-28 max-md:py-16 flex flex-col gap-12" bg={t.color.paper}>
      <grid cols={12} gap={32}>
        <box span={4} mobile={{ span: 1 }}>
          <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.ultra}>
            04 — The shape
          </text>
        </box>
        <box span={8} mobile={{ span: 1 }}>
          <h2
            tw="text-[50px] max-lg:text-[40px] max-md:text-[30px] leading-none tracking-[-0.02em]"
            weight={800}
            font={t.font.head}
            color={t.color.ink}
          >
            Eight weeks, and you know what happens in each of them.
          </h2>
        </box>
      </grid>

      <grid cols={4} gap={20} mobile={{ gridCols: 1 }}>
        <box tw="px-6 py-8 flex flex-col gap-4 mt-0" bg={t.color.ground} motion={{ effect: 'fade', trigger: 'scrollIn' }}>
          <text tw="text-[13px] uppercase tracking-widest" font={t.font.body} color={t.color.shock}>
            Week 1 — 2
          </text>
          <text tw="text-[19px] leading-snug" weight={600} font={t.font.head} color={t.color.ink}>
            We interview your customers, not you.
          </text>
        </box>
        <box tw="px-6 py-8 flex flex-col gap-4 mt-8 max-md:mt-0" bg={t.color.ink} motion={{ effect: 'fade', trigger: 'scrollIn', delay: 90 }}>
          <text tw="text-[13px] uppercase tracking-widest" font={t.font.body} color={t.color.shock}>
            Week 3
          </text>
          <text tw="text-[19px] leading-snug" weight={600} font={t.font.head} color={t.color.paper}>
            We show one direction, not six.
          </text>
        </box>
        <box tw="px-6 py-8 flex flex-col gap-4 mt-16 max-md:mt-0" bg={t.color.ultra} motion={{ effect: 'fade', trigger: 'scrollIn', delay: 180 }}>
          <text tw="text-[13px] uppercase tracking-widest" font={t.font.body} color={t.color.ground}>
            Week 4 — 7
          </text>
          <text tw="text-[19px] leading-snug" weight={600} font={t.font.head} color={t.color.paper}>
            We build it out until it survives contact with your worst use case.
          </text>
        </box>
        <box tw="px-6 py-8 flex flex-col gap-4 mt-24 max-md:mt-0" bg={t.color.shock} motion={{ effect: 'fade', trigger: 'scrollIn', delay: 270 }}>
          <text tw="text-[13px] uppercase tracking-widest" font={t.font.body} color={t.color.ink}>
            Week 8
          </text>
          <text tw="text-[19px] leading-snug" weight={600} font={t.font.head} color={t.color.paper}>
            Files, fonts, rules and a recorded handover.
          </text>
        </box>
      </grid>
    </box>

    {/* 5 — two case fragments: before, after, and what moved */}
    <box tw="w-full px-12 max-lg:px-8 max-md:px-5 py-28 max-md:py-16 flex flex-col gap-20 max-md:gap-12" bg={t.color.ground}>
      <h2
        tw="text-[50px] max-lg:text-[40px] max-md:text-[30px] leading-none tracking-[-0.02em] max-w-3xl"
        weight={800}
        font={t.font.head}
        color={t.color.ink}
      >
        Two fragments. Before, after, and what actually moved.
      </h2>

      <grid cols={12} gap={36}>
        <box span={5} mobile={{ span: 1 }} tw="rotate-[-2deg]">
          <img src={IMG.print} w="100%" h={340} fit="cover" mobile={{ h: 220 }} />
        </box>
        <box span={7} mobile={{ span: 1 }} tw="flex flex-col gap-6">
          <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.ultra}>
            Fragment A — logistics platform
          </text>
          <box tw="flex flex-col gap-4 pb-2">
            <text tw="text-[16px] leading-relaxed" font={t.font.body} color={t.color.ink}>
              <strong>Before</strong> — a wordmark stretched across eleven product surfaces, redrawn locally in four
              countries, and a truck livery nobody could match to the invoice.
            </text>
            <text tw="text-[16px] leading-relaxed" font={t.font.body} color={t.color.ink}>
              <strong>After</strong> — one mark, one grid, one motion rule, and a livery spec a print shop in Rotterdam
              can hit without calling us.
            </text>
          </box>
          <text tw="text-[22px] max-md:text-[18px] leading-snug" weight={600} font={t.font.head} color={t.color.ink}>
            A logistics platform went from 11 percent unaided recall to 34 percent in nine months. The new mark is worse
            as a drawing and far better as a system, and we will explain why on a call.
          </text>
        </box>
      </grid>

      <grid cols={12} gap={36}>
        <box span={7} mobile={{ span: 1 }} tw="flex flex-col gap-6">
          <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.shock}>
            Fragment B — fourteen-year-old accountancy group
          </text>
          <box tw="flex flex-col gap-4 pb-2">
            <text tw="text-[16px] leading-relaxed" font={t.font.body} color={t.color.ink}>
              <strong>Before</strong> — three founders' initials, a serif borrowed from a bank, and a proposal template
              that made a forty-person firm read as two.
            </text>
            <text tw="text-[16px] leading-relaxed" font={t.font.body} color={t.color.ink}>
              <strong>After</strong> — a name that survives the founders leaving, and a document system that does most
              of the selling before anyone speaks.
            </text>
          </box>
          <text tw="text-[22px] max-md:text-[18px] leading-snug" weight={600} font={t.font.head} color={t.color.ink}>
            Referral conversations that reached a proposal went from one in five to one in two within two quarters.
            Nothing about the accounting changed. The way it arrived did.
          </text>
        </box>
        <box span={5} mobile={{ span: 1 }} tw="rotate-[3deg]">
          <img src={IMG.wall} w="100%" h={340} fit="cover" mobile={{ h: 220 }} />
        </box>
      </grid>
    </box>

    {/* 6 — who we say no to */}
    <box tw="w-full px-12 max-lg:px-8 max-md:px-5 py-28 max-md:py-16" bg={t.color.shock}>
      <grid cols={12} gap={36}>
        <box span={5} mobile={{ span: 1 }} tw="flex flex-col gap-6">
          <h2
            tw="text-[56px] max-lg:text-[44px] max-md:text-[32px] leading-none tracking-[-0.02em]"
            weight={800}
            font={t.font.head}
            color={t.color.paper}
          >
            Who we say no to.
          </h2>
          <text tw="text-[16px] leading-relaxed" font={t.font.body} color={t.color.ink}>
            Three slots a year means the no is the important half of the job. None of this is personal and all of it is
            final.
          </text>
        </box>
        <box span={7} mobile={{ span: 1 }} tw="flex flex-col">
          <box tw="border-t border-[#0A0A0A] py-5">
            <text tw="text-[28px] max-md:text-[22px] leading-tight" weight={700} font={t.font.head} color={t.color.ink}>
              Pre-revenue startups
            </text>
          </box>
          <box tw="border-t border-[#0A0A0A] py-5">
            <text tw="text-[28px] max-md:text-[22px] leading-tight" weight={700} font={t.font.head} color={t.color.ink}>
              Anyone who says make it pop
            </text>
          </box>
          <box tw="border-t border-[#0A0A0A] py-5">
            <text tw="text-[28px] max-md:text-[22px] leading-tight" weight={700} font={t.font.head} color={t.color.ink}>
              Board-by-committee approval
            </text>
          </box>
          <box tw="border-t border-b border-[#0A0A0A] py-5">
            <text tw="text-[28px] max-md:text-[22px] leading-tight" weight={700} font={t.font.head} color={t.color.ink}>
              Any brief with the word disruptive in it
            </text>
          </box>
        </box>
      </grid>
    </box>

    {/* 7 — the four of us, and what we each actually do */}
    <box tw="w-full px-12 max-lg:px-8 max-md:px-5 py-28 max-md:py-16" bg={t.color.paper}>
      <grid cols={12} gap={36}>
        <box span={5} mobile={{ span: 1 }} tw="flex flex-col gap-6">
          <box tw="rotate-[-2deg]">
            <img src={IMG.team} w="100%" h={420} fit="cover" mobile={{ h: 240 }} />
          </box>
          <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.ultra}>
            07 — The four of us
          </text>
        </box>
        <box span={7} mobile={{ span: 1 }} tw="flex flex-col gap-8">
          <h2
            tw="text-[48px] max-lg:text-[38px] max-md:text-[30px] leading-none tracking-[-0.02em]"
            weight={800}
            font={t.font.head}
            color={t.color.ink}
          >
            Four people. No account layer between you and the work.
          </h2>
          <box tw="flex flex-col">
            <TeamRow name="Ellis" role="Draws" does="Ellis draws. Marks, type, the awkward middle states nobody asks for until launch week." />
            <TeamRow name="Priya" role="Strategy" does="Priya writes and holds the strategy, which mostly means holding it still when the fourth stakeholder arrives late." />
            <TeamRow name="Marcus" role="Systems" does="Marcus builds every system in code so it survives handover, not just the presentation it was born in." />
            <TeamRow name="Nadia" role="Studio" does="Nadia runs the studio and tells you the truth about timelines, including the parts you would rather hear in week seven." />
          </box>
        </box>
      </grid>
    </box>

    {/* 8 — enquiry with a real question form */}
    <box id="enquiry" tw="w-full px-12 max-lg:px-8 max-md:px-5 py-28 max-md:py-16 flex flex-col gap-14" bg={t.color.ink}>
      <grid cols={12} gap={40}>
        <box span={5} mobile={{ span: 1 }} tw="flex flex-col gap-7">
          <h2
            tw="text-[56px] max-lg:text-[44px] max-md:text-[32px] leading-none tracking-[-0.02em]"
            weight={800}
            font={t.font.head}
            color={t.color.paper}
          >
            Tell us what broke.
          </h2>
          <text tw="text-[18px] leading-relaxed" font={t.font.body} color={t.color.ground}>
            Not what you want made. What stopped working. The first two questions on a call are the same two here, so
            you may as well answer them now and save us both the introductions.
          </text>
          <box tw="border-t border-[#4a4a4a] pt-6 flex flex-col gap-3">
            <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color={t.color.shock}>
              Availability
            </text>
            <text tw="text-[17px] leading-relaxed" font={t.font.body} color={t.color.ground}>
              Next opening: late October. We take deposits to hold a slot and we have never moved one.
            </text>
            <text
              href="mailto:hello@hardturn.studio"
              tw="text-[17px] hover:text-[#FF3B00]"
              weight={600}
              font={t.font.head}
              color={t.color.paper}
              w="hug"
            >
              hello@hardturn.studio
            </text>
          </box>
        </box>
        <box span={7} mobile={{ span: 1 }}>
          <html raw={FORM_HTML} />
        </box>
      </grid>

      <box tw="border-t border-[#4a4a4a] pt-7 flex flex-row justify-between items-center gap-5 max-md:flex-col max-md:items-start">
        <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color="#8d8d8d">
          Hard Turn — brand identity, rebrands only
        </text>
        <text cls="eyebrow" tw="text-[12px] uppercase tracking-widest" font={t.font.body} color="#8d8d8d">
          Three clients at a time · Eight weeks each
        </text>
      </box>
    </box>
  </box>
);
