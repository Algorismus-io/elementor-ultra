/** Hutbook — alpine hut-to-hut booking. Design tokens. */
export default defineTheme({
  name: 'hutbook',
  color: {
    ground: '#F0F3F6',
    ink: '#1A2430',
    rock: '#5E6D7A',
    snow: '#FFFFFF',
    alp: '#2F7DA8',
    warn: '#E07B39',
  },
  font: { head: 'Rokkitt', body: 'Merriweather Sans' },
  mode: 'literal',
});
