# Tideline

Cool marine palette, device tables, credible data storytelling.

|  |  |
|---|---|
| **Slug** | `tideline-collect` (deploys to `/tideline-collect/`) |
| **Archetype** | single-column long-form |
| **Industry** | Marine conservation nonprofit |
| **Page title** | Tideline — 14 booms, 41 tonnes, published weekly |
| **Fonts** | Fraunces, Nunito Sans — Google Fonts, imported by Elementor automatically |
| **Elements** | 254 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (119 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install tideline-collect
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
tideline-collect/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/tideline-collect.page.jsx      the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F2F7F8` |
| `ink` | `#132226` |
| `sea` | `#1E6B7A` |
| `kelp` | `#4A7A4E` |
| `plastic` | `#E2653A` |
| `rule` | `#D4E0E2` |

Change a value, re-run `npx exjsx-kit install tideline-collect`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/tideline-collect.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `boom_river` | `media/boom_river.jpg` | A Tideline interception boom strung across a river mouth, catching floating plastic on the ebb tide |
| `estuary` | `media/estuary.jpg` | Wide estuary where the river meets open water, the last place plastic can be caught cheaply |
| `sorting` | `media/sorting.jpg` | Volunteers hand-sorting recovered plastic into type-graded bags on a windy hard standing |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
