/** Little Molar — pediatric dentistry. Warm, simple, reassuring. */
export default defineTheme({
  name: 'little-molar',
  color: {
    ground: '#FFFDF7',   // page background — warm paper
    ink: '#243043',      // display + body text
    bubble: '#4EC3E0',   // primary accent (water blue)
    coral: '#FF8A7A',    // CTA / warmth
    mint: '#8ED9B4',     // calm bands
    sun: '#FFD25E',      // highlight / sticker yellow
    white: '#FFFFFF',
  },
  font: { head: 'Baloo 2', body: 'Quicksand' },
  radius: { sm: 12, md: 20, lg: 28, xl: 40 },
  mode: 'literal',
});
