# Common Ground Trust

Deep green, a real map, a curlew. Nonprofit work that isn't generic.

|  |  |
|---|---|
| **Slug** | `commonground-trust` (deploys to `/commonground-trust/`) |
| **Archetype** | map-first geographic |
| **Industry** | Land conservation nonprofit |
| **Page title** | Common Ground Trust |
| **Fonts** | Newsreader, Source Sans 3 — Google Fonts, imported by Elementor automatically |
| **Elements** | 302 |
| **Images** | 3 |
| **Global classes used** | 0 — built `--inline` (158 would-be classes stay off the site registry) |

## Install

From the kit root, with `WP_URL` / `WP_USER` / `WP_APP_PASSWORD` set (or in `.env`):

```sh
npx exjsx-kit install commonground-trust
```

That sideloads this page's imagery, rewrites the attachment ids, builds the bundle `--inline`,
deploys it, and verifies the live render. See `../../KIT.md` for requirements and the full story.

## What is in here

```
commonground-trust/
  page.json                     this page's metadata (machine-readable)
  site/
    site.config.mjs             project name
    theme.mjs                   design tokens — colours, fonts, mode
    pages/commonground-trust.page.jsx    the page itself: layout + copy
    data/media.manifest.mjs     what to sideload (relative paths into ../../media/)
    data/media-map.json         slot -> attachment id, REGENERATED per target site
    data/media.mjs              the one media-wiring module every page imports
    page.bundle.json            the built, inline bundle that gets deployed
  media/                        the raw image files
```

## Customise

**Colours and fonts** — `site/theme.mjs`. This page's palette:

| token | value |
|---|---|
| `ground` | `#F3F5EF` |
| `ink` | `#1B2A20` |
| `river` | `#2C6E8F` |
| `grass` | `#6E8B3D` |
| `ochre` | `#C4913C` |
| `rule` | `#C9D1C2` |

Change a value, re-run `npx exjsx-kit install commonground-trust`, and every element that referenced the token
follows. `theme.mjs` also sets the emit mode: `literal` writes hex/font-name straight onto elements
(renders on every Elementor build); `var` binds to Elementor variables so edits in Class Manager
propagate live, at the cost of needing Elementor to resolve them.

**Copy** — `site/pages/commonground-trust.page.jsx`. The text is plain JSX children; edit in place.

**Imagery** — drop a replacement into `media/` under the same filename and re-install; the
manifest resolves paths relative to itself, so nothing else changes.

| slot | file | alt |
|---|---|---|
| `curlew` | `media/curlew.jpg` | A curlew standing in wet meadow grass on the Wenn floodplain |
| `meadow_wide` | `media/meadow_wide.jpg` | Wide view of unploughed floodplain meadow along the river Wenn |
| `volunteer_survey` | `media/volunteer_survey.jpg` | Volunteers carrying out a bank survey along the river |

Pages address slots by name through `site/data/media.mjs` (`MEDIA`, `IMG`, `img()`, `alt()`,
`has()`). Attachment ids are never written into page source.

## Known behaviour

- Components in this page are Elementor **Pro** features. On free Elementor they fall back to
  inline expansion, which is why the page renders identically without a Pro licence.
- Requires **Elementor V4** (4.2.x tested). V3-only sites will not render atomic elements.
