/**
 * media.manifest.mjs — what `exjsx media` sideloads into the target WordPress.
 * Paths are RELATIVE to this file (../../media/), so the kit is portable.
 * Slots are namespaced "backhaul-freight--" so several kit pages can share one WordPress.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MEDIA_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'media');
export const PREFIX = 'backhaul-freight--';

export default [
  { slot: `${PREFIX}driver_cab`, file: join(MEDIA_DIR, "driver_cab.jpg"), alt: "Owner-operator driver in the cab of an artic at a truck stop" },
  { slot: `${PREFIX}loading_bay`, file: join(MEDIA_DIR, "loading_bay.jpg"), alt: "Pallets being loaded at a warehouse loading bay" },
  { slot: `${PREFIX}truck_dusk`, file: join(MEDIA_DIR, "truck_dusk.jpg"), alt: "Articulated lorry on a motorway at dusk" },
];
