import { FAILURES, TIERS } from '../data/failures.mjs';

export const meta = {
  title: 'Basis — crypto tax software that shows its working',
  slug: 'basis-tax',
  seo: {
    title: 'Basis — nine things your tax tool got wrong',
    description:
      'Basis reconstructs cost basis across 41 chains and 120 exchanges and shows the working for every number. If we cannot determine a basis we tell you, rather than quietly filling in zero.',
  },
};

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 520 };

/* ── small local helpers (inline-expanded) ───────────────────────────── */

const Rule = ({ c }) => <div w="100%" h={1} bg={c} />;

const Eyelet = ({ children, c }) => (
  <text font="Major Mono Display" size={12} ls={0.22} color={c} lh={1.4}>
    {children}
  </text>
);

/* ── registered repeaters (content props only) ───────────────────────── */

const FailureRow = defineComponent(
  ({ num = '00', title = '', body = '' }) => {
    const t = useTheme();
    return (
      <grid
        cols="132px 1fr"
        gapX={32}
        gapY={12}
        w="100%"
        pad={{ t: 30, b: 30 }}
        mobile={{ gridCols: 1, pad: { t: 22, b: 22 } }}
      >
        <text font="Major Mono Display" size={40} lh={1} color={t.color.chain} mobile={{ size: 30 }}>
          {num}
        </text>
        <div gap={12} w="100%">
          <heading tag="h3" size={22} weight={600} font="Sora" color={t.color.ink} lh={1.35} mobile={{ size: 19 }}>
            {title}
          </heading>
          <text size={16} font="Sora" color={t.color.dim} lh={1.7} maxw={720} mobile={{ size: 15 }}>
            {body}
          </text>
        </div>
      </grid>
    );
  },
  {
    title: 'Basis — Failure Row',
    props: {
      num: { label: 'Number', group: 'Content' },
      title: { label: 'Title', group: 'Content' },
      body: { label: 'Body', group: 'Content' },
    },
  },
);

const PriceTier = defineComponent(
  ({ amount = '', unit = '', count = '', note = '' }) => {
    const t = useTheme();
    return (
      <div
        w="100%"
        h="100%"
        gap={14}
        pad={26}
        bg="#0F1017"
        border={[1, t.color.line]}
        radius={3}
        hover={{ border: [1, t.color.chain], bg: '#141522' }}
      >
        <text font="Major Mono Display" size={44} lh={1} color={t.color.ink} mobile={{ size: 36 }}>
          {amount}
        </text>
        <text font="Major Mono Display" size={11} ls={0.16} color={t.color.chain}>
          {unit}
        </text>
        <div w="100%" h={1} bg={t.color.line} m={{ t: 4, b: 4 }} />
        <text size={15} font="Sora" weight={600} color={t.color.ink} lh={1.5}>
          {count}
        </text>
        <text size={14} font="Sora" color={t.color.dim} lh={1.65}>
          {note}
        </text>
      </div>
    );
  },
  {
    title: 'Basis — Price Tier',
    props: {
      amount: { label: 'Amount', group: 'Content' },
      unit: { label: 'Unit', group: 'Content' },
      count: { label: 'Transaction count', group: 'Content' },
      note: { label: 'Note', group: 'Content' },
    },
  },
);

/* ── page ────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => {
  const C = t.color;
  const wrap = { w: '100%', maxw: 1160, m: { l: 'auto', r: 'auto' } };

  const LedgerRow = ({ k, v, c }) => (
    <div w="100%" gap={8}>
      <div dir="row" w="100%" justify="space-between" align="center" gap={16}>
        <text size={13} font="Sora" color={C.dim} lh={1.5}>
          {k}
        </text>
        <text font="Major Mono Display" size={16} color={c || C.ink} lh={1.4}>
          {v}
        </text>
      </div>
      <Rule c={C.line} />
    </div>
  );

  const TraceLine = ({ label, value, c }) => (
    <div dir="row" gap={18} w="100%" wrap="wrap" align="flex-start">
      <text font="Major Mono Display" size={12} ls={0.1} color={C.chain} w={104} lh={1.6}>
        {label}
      </text>
      <text font="Major Mono Display" size={13} color={c || C.ink} lh={1.6} flex={1} mobile={{ size: 12 }}>
        {value}
      </text>
    </div>
  );

  const Handled = ({ n, head, before, after }) => (
    <div w="100%" gap={14} pad={{ t: 26, b: 26 }}>
      <Rule c={C.line} />
      <div dir="row" gap={14} align="flex-start" pad={{ t: 12 }}>
        <text font="Major Mono Display" size={13} color={C.chain}>
          {n}
        </text>
        <heading tag="h3" size={20} weight={600} font="Sora" color={C.ink} lh={1.4} flex={1}>
          {head}
        </heading>
      </div>
      <div dir="row" gap={10} align="flex-start">
        <text font="Major Mono Display" size={12} color={C.loss} w={64} lh={1.7}>
          them
        </text>
        <text size={15} font="Sora" color={C.dim} lh={1.7} flex={1}>
          {before}
        </text>
      </div>
      <div dir="row" gap={10} align="flex-start">
        <text font="Major Mono Display" size={12} color={C.gain} w={64} lh={1.7}>
          basis
        </text>
        <text size={15} font="Sora" color={C.ink} lh={1.7} flex={1}>
          {after}
        </text>
      </div>
    </div>
  );

  const Chip = ({ children, c }) => (
    <text
      font="Major Mono Display"
      size={13}
      color={c || C.ink}
      pad={[9, 16]}
      bg="#101119"
      border={[1, C.line]}
      radius={999}
      w="hug"
      lh={1.3}
      hover={{ border: [1, C.chain], color: C.chain }}
    >
      {children}
    </text>
  );

  const Mark = ({ sign, c, children }) => (
    <div dir="row" gap={12} align="flex-start" w="100%">
      <text font="Major Mono Display" size={14} color={c} lh={1.7} w={16}>
        {sign}
      </text>
      <text size={15} font="Sora" color={C.dim} lh={1.7} flex={1}>
        {children}
      </text>
    </div>
  );

  return (
    <box w="100%" pad={0} bg={C.ground} align="center">
      {/* ── 0 · hero + ledger ───────────────────────────────────────── */}
      <section w="100%" pad={{ t: 104, b: 96, l: 24, r: 24 }} bg={C.ground} align="center">
        <grid
          cols="1.12fr 0.88fr"
          gapX={64}
          gapY={48}
          {...wrap}
          tablet={{ gridCols: 1 }}
          mobile={{ gridCols: 1, gapY: 36 }}
        >
          <div gap={26} w="100%">
            <Eyelet c={C.chain}>basis // cost basis, reconstructed</Eyelet>
            <h1
              size={68}
              weight={400}
              font="Major Mono Display"
              color={C.ink}
              lh={1.08}
              ls={-0.01}
              tablet={{ size: 54 }}
              mobile={{ size: 33 }}
            >
              Nine things your tax tool got wrong.
            </h1>
            <text size={17} font="Sora" color={C.dim} lh={1.75} maxw={620} mobile={{ size: 15 }}>
              Basis reconstructs cost basis across 41 chains and 120 exchanges and shows the working for every number.
              If we cannot determine a basis we tell you, rather than quietly filling in zero.
            </text>
            <div dir="row" gap={14} wrap="wrap" align="center" pad={{ t: 6 }}>
              <text
                href="#import"
                size={15}
                weight={600}
                font="Sora"
                color="#0C0D12"
                bg={C.chain}
                pad={[15, 28]}
                radius={2}
                lh={1.2}
                w="hug"
                tw="hover:bg-[#9B85FF]"
              >
                Import your first wallet
              </text>
              <text
                href="#audit"
                size={15}
                weight={500}
                font="Sora"
                color={C.ink}
                pad={[15, 24]}
                radius={2}
                lh={1.2}
                w="hug"
                border={[1, C.line]}
                hover={{ border: [1, C.chain], color: C.chain }}
              >
                See the audit trail
              </text>
            </div>
          </div>

          <div
            w="100%"
            gap={18}
            pad={28}
            bg="#0F1017"
            border={[1, C.line]}
            radius={4}
            shadow={[
              [1, 0, 0, '#1E2029'],
              [40, 80, -40, 'rgba(122,92,255,0.28)'],
            ]}
            motion={FADE}
          >
            <Eyelet c={C.chain}>reconciliation // 2024-25</Eyelet>
            <Rule c={C.line} />
            <LedgerRow k="chains indexed" v="41" />
            <LedgerRow k="exchange connectors" v="120" />
            <LedgerRow k="lines with a source" v="100%" c={C.gain} />
            <LedgerRow k="basis we could not determine" v="flagged" c={C.loss} />
            <LedgerRow k="numbers quietly guessed" v="0" c={C.gain} />
            <text size={13} font="Sora" color={C.dim} lh={1.65}>
              Every figure above expands into the transactions behind it. Nothing on this page is an estimate we hid
              from you.
            </text>
          </div>
        </grid>
      </section>

      {/* ── 1 · the nine ────────────────────────────────────────────── */}
      <section w="100%" pad={{ t: 88, b: 104, l: 24, r: 24 }} bg={C.ground} align="center" id="nine">
        <div {...wrap} gap={0}>
          <div w="100%" gap={16} pad={{ b: 40 }} motion={FADE}>
            <Eyelet c={C.loss}>the nine</Eyelet>
            <h2 size={40} weight={400} font="Major Mono Display" color={C.ink} lh={1.15} maxw={780} mobile={{ size: 27 }}>
              Nine numbered failures of every other tool.
            </h2>
            <text size={16} font="Sora" color={C.dim} lh={1.7} maxw={640}>
              Not opinions. Each one is a decision the software made on your behalf, without telling you, that changes
              what you owe.
            </text>
          </div>
          <Rule c={C.chain} />
          {FAILURES.map((f, i) => (
            <div w="100%" gap={0}>
              <FailureRow num={f.num} title={f.title} body={f.body} />
              {i < FAILURES.length - 1 ? <Rule c={C.line} /> : <Rule c={C.chain} />}
            </div>
          ))}
        </div>
      </section>

      {/* ── 2 · the ones nobody handles ─────────────────────────────── */}
      <section w="100%" pad={{ t: 96, b: 96, l: 24, r: 24 }} bg={C.lift} align="center">
        <grid cols="0.8fr 1.2fr" gapX={64} gapY={36} {...wrap} tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
          <div gap={18} w="100%" motion={FADE}>
            <Eyelet c={C.chain}>02 // hard cases</Eyelet>
            <h2 size={34} weight={400} font="Major Mono Display" color={C.ink} lh={1.2} mobile={{ size: 25 }}>
              How we handle the ones nobody handles.
            </h2>
            <text size={16} font="Sora" color={C.dim} lh={1.7}>
              LP positions, wrapped assets and bridges are where every other reconstruction quietly gives up. They are
              the first thing Basis was built to get right.
            </text>
          </div>
          <div w="100%" gap={0}>
            <Handled
              n="lp"
              head="Liquidity positions, decomposed per block."
              before="One opaque LP token in, one opaque LP token out, and a gain invented from the difference."
              after="We resolve the position into its underlying tokens at entry and at exit, separate impermanent loss from accrued fees, and carry a basis for each leg at the block it moved."
            />
            <Handled
              n="wrap"
              head="Wrapping is not a sale."
              before="wETH is booked as a different asset from ETH, so wrapping triggers a disposal you never made."
              after="Wrapped representations inherit the position and the basis of the asset they represent. The wrap appears in the trail as a wrap, not as a trade."
            />
            <Handled
              n="bridge"
              head="Bridges tracked as one position across chains."
              before="The asset leaves one chain and arrives on another as a brand-new acquisition with no history."
              after="We match the outbound and inbound legs, keep the acquisition date and basis intact, and show both transaction hashes on the same line."
            />
            <Rule c={C.line} />
          </div>
        </grid>
      </section>

      {/* ── 3 · missing data ────────────────────────────────────────── */}
      <section
        w="100%"
        pad={{ t: 100, b: 100, l: 24, r: 24 }}
        grad={[165, '#0C0D12', '#14101F']}
        align="center"
      >
        <div {...wrap} gap={40}>
          <div w="100%" gap={16} maxw={720} motion={FADE}>
            <Eyelet c={C.loss}>03 // missing data</Eyelet>
            <h2 size={34} weight={400} font="Major Mono Display" color={C.ink} lh={1.2} mobile={{ size: 25 }}>
              What we do instead of guessing.
            </h2>
            <text size={16} font="Sora" color={C.dim} lh={1.7}>
              A gap in the data is a fact about your history, not a hole to be filled with a convenient number. Every
              gap in Basis is typed, visible and yours to resolve.
            </text>
          </div>
          <grid cols={2} gapX={28} gapY={28} w="100%" mobile={{ gridCols: 1 }}>
            {[
              ['unknown basis', C.loss, 'We mark the lot as undetermined and show what the figure would be under each assumption you could reasonably make. Nothing is filed until you pick one.'],
              ['missing price', C.chain, 'We use the nearest verifiable print from a named venue, record the gap in minutes, and label the line as sourced by proximity rather than exact match.'],
              ['unknown counterparty', C.chain, 'An address we cannot classify stays unclassified. We will not guess that it is your own wallet in order to make a transfer non-taxable.'],
              ['incomplete history', C.loss, 'We state the date range we can stand behind and the range we cannot, per chain and per account, before you ever see a total.'],
            ].map(([head, c, body]) => (
              <div
                w="100%"
                h="100%"
                gap={14}
                pad={26}
                bg="rgba(12,13,18,0.6)"
                border={[1, C.line]}
                radius={3}
                hover={{ border: [1, C.chain] }}
              >
                <div dir="row" gap={10} align="center">
                  <div w={6} h={6} radius={999} bg={c} />
                  <text font="Major Mono Display" size={14} color={c} lh={1.3}>
                    {head}
                  </text>
                </div>
                <text size={15} font="Sora" color={C.dim} lh={1.7}>
                  {body}
                </text>
              </div>
            ))}
          </grid>
        </div>
      </section>

      {/* ── 4 · audit trail ─────────────────────────────────────────── */}
      <section w="100%" pad={{ t: 100, b: 100, l: 24, r: 24 }} bg={C.ground} align="center" id="audit">
        <div {...wrap} gap={44}>
          <div w="100%" gap={16} maxw={760}>
            <Eyelet c={C.chain}>04 // audit trail</Eyelet>
            <h2 size={34} weight={400} font="Major Mono Display" color={C.ink} lh={1.2} mobile={{ size: 25 }}>
              The audit trail behind every single line.
            </h2>
            <text size={16} font="Sora" color={C.dim} lh={1.7}>
              Every figure on the report expands into the transaction hashes, the price source, the timestamp and the
              rule applied. Print it and hand it to an accountant or an auditor without a covering explanation.
            </text>
          </div>
          <div
            w="100%"
            gap={14}
            pad={[30, 30]}
            bg="#0A0B10"
            border={[1, C.line]}
            radius={4}
            motion={FADE}
            mobile={{ pad: [20, 16] }}
          >
            <div dir="row" justify="space-between" align="center" w="100%" gap={16} wrap="wrap">
              <text font="Major Mono Display" size={13} color={C.ink} lh={1.4}>
                disposal 0.4211 eth
              </text>
              <text font="Major Mono Display" size={13} color={C.gain} lh={1.4}>
                gain 233.71
              </text>
            </div>
            <Rule c={C.line} />
            <TraceLine label="tx in" value="0x9f3c 41ab e7d2 a12b  ·  base  ·  block 12,884,901" />
            <TraceLine label="tx out" value="0x41de 9b02 cc17 5f80  ·  mainnet  ·  block 19,441,207" />
            <TraceLine label="timestamp" value="2024-03-14 09:41:07 utc  (venue clock, not ours)" />
            <TraceLine label="price" value="3,412.08  ·  coinbase spot  ·  exact match, 0s drift" c={C.gain} />
            <TraceLine label="rule" value="uk s.104 pooling  ·  30-day window checked, no match" c={C.chain} />
            <TraceLine label="basis" value="1,203.44  ·  acquired 2021-11-08  ·  carried through 1 bridge" />
            <TraceLine label="fees" value="gas 4.19 allocated to this disposal, not written off" />
            <Rule c={C.line} />
            <text size={13} font="Sora" color={C.dim} lh={1.65}>
              This is one line of one report, expanded. Every other line expands the same way, including the ones that
              net to nothing.
            </text>
          </div>
        </div>
      </section>

      {/* ── 5 · jurisdictions ───────────────────────────────────────── */}
      <section w="100%" pad={{ t: 84, b: 84, l: 24, r: 24 }} bg={C.lift} align="center">
        <grid cols="0.9fr 1.1fr" gapX={56} gapY={32} {...wrap} tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
          <div gap={16} w="100%">
            <Eyelet c={C.chain}>05 // jurisdictions</Eyelet>
            <h2 size={32} weight={400} font="Major Mono Display" color={C.ink} lh={1.2} mobile={{ size: 24 }}>
              Jurisdictions and methods supported.
            </h2>
            <text size={16} font="Sora" color={C.dim} lh={1.7}>
              UK share pooling with the 30-day rule, US FIFO/LIFO/HIFO and wash sale treatment, plus Germany,
              Australia, Canada and Ireland. Method locked per jurisdiction, not per user preference.
            </text>
          </div>
          <div w="100%" gap={24} motion={FADE}>
            <div dir="row" gap={10} wrap="wrap" w="100%">
              <Chip c={C.chain}>uk · s.104 pool + 30 day</Chip>
              <Chip c={C.chain}>us · fifo / lifo / hifo</Chip>
              <Chip>de · 1 year holding</Chip>
              <Chip>au · cgt discount</Chip>
              <Chip>ca · adjusted cost base</Chip>
              <Chip>ie · fifo + 4 week</Chip>
            </div>
            <Rule c={C.line} />
            <text size={15} font="Sora" color={C.dim} lh={1.7}>
              Locking the method to the jurisdiction is deliberate. A dropdown that lets you pick the method with the
              smallest number is not a feature, it is a liability with a nice interface.
            </text>
          </div>
        </grid>
      </section>

      {/* ── 6 · keys and data ───────────────────────────────────────── */}
      <section w="100%" pad={{ t: 96, b: 96, l: 24, r: 24 }} bg={C.ground} align="center">
        <grid cols="1.05fr 0.95fr" gapX={56} gapY={36} {...wrap} tablet={{ gridCols: 1 }} mobile={{ gridCols: 1 }}>
          <div gap={16} w="100%">
            <Eyelet c={C.gain}>06 // keys and data</Eyelet>
            <h2 size={32} weight={400} font="Major Mono Display" color={C.ink} lh={1.2} mobile={{ size: 24 }}>
              Your keys, your data, and what we can see.
            </h2>
            <text size={16} font="Sora" color={C.dim} lh={1.7}>
              Read-only API keys and public addresses only. We never ask for a seed phrase or a withdrawal permission,
              and the key form rejects any key with trading scope.
            </text>
          </div>
          <div w="100%" gap={26} pad={26} bg="#0F1017" border={[1, C.line]} radius={3}>
            <div w="100%" gap={12}>
              <Eyelet c={C.gain}>what basis can see</Eyelet>
              <Mark sign="+" c={C.gain}>Public addresses you paste in, and their on-chain history.</Mark>
              <Mark sign="+" c={C.gain}>Read-only exchange keys, scoped to trade and transfer history.</Mark>
              <Mark sign="+" c={C.gain}>The reports you generate, until you delete them.</Mark>
            </div>
            <Rule c={C.line} />
            <div w="100%" gap={12}>
              <Eyelet c={C.loss}>what basis never asks for</Eyelet>
              <Mark sign="-" c={C.loss}>A seed phrase or private key. There is no field for one.</Mark>
              <Mark sign="-" c={C.loss}>Withdrawal or trading permission on any exchange key.</Mark>
              <Mark sign="-" c={C.loss}>Custody of anything. Basis reads; it never moves an asset.</Mark>
            </div>
          </div>
        </grid>
      </section>

      {/* ── 7 · pricing ─────────────────────────────────────────────── */}
      <section w="100%" pad={{ t: 96, b: 100, l: 24, r: 24 }} bg={C.lift} align="center" id="pricing">
        <div {...wrap} gap={36}>
          <div w="100%" gap={14} maxw={680}>
            <Eyelet c={C.chain}>07 // pricing</Eyelet>
            <h2 size={32} weight={400} font="Major Mono Display" color={C.ink} lh={1.2} mobile={{ size: 24 }}>
              Pricing by transaction count.
            </h2>
            <text size={16} font="Sora" color={C.dim} lh={1.7}>
              Free under 100 transactions. 89 to 10,000. 249 to 100,000. 599 above that, including a call with a human
              who has actually filed one of these.
            </text>
          </div>
          <grid cols={4} gapX={20} gapY={20} w="100%" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
            {TIERS.map((p) => (
              <PriceTier amount={p.amount} unit={p.unit} count={p.count} note={p.note} />
            ))}
          </grid>
          <text size={14} font="Sora" color={C.dim} lh={1.7} maxw={640}>
            One price per tax year, per person. No per-chain surcharge, no paywall on the audit trail, and no upsell
            standing between you and a number you can defend.
          </text>
        </div>
      </section>

      {/* ── 8 · import (the one centred section) ────────────────────── */}
      <section
        w="100%"
        pad={{ t: 124, b: 124, l: 24, r: 24 }}
        grad={[180, '#0C0D12', '#1A1230']}
        align="center"
        id="import"
      >
        <div {...wrap} maxw={720} align="center" gap={26} ta="center" motion={FADE}>
          <Eyelet c={C.chain}>08 // start</Eyelet>
          <h2
            size={46}
            weight={400}
            font="Major Mono Display"
            color={C.ink}
            lh={1.14}
            ta="center"
            mobile={{ size: 29 }}
          >
            Import your first wallet.
          </h2>
          <text size={17} font="Sora" color={C.dim} lh={1.75} ta="center" maxw={560} mobile={{ size: 15 }}>
            Paste one address. Basis reconstructs what it can, tells you plainly what it cannot, and shows the working
            for both. Under 100 transactions it stays free, permanently.
          </text>
          <text
            href="#import"
            size={16}
            weight={600}
            font="Sora"
            color="#0C0D12"
            bg={C.chain}
            pad={[17, 34]}
            radius={2}
            lh={1.2}
            w="hug"
            ta="center"
            tw="hover:bg-[#9B85FF]"
          >
            Import your first wallet
          </text>
          <text font="Major Mono Display" size={12} ls={0.14} color={C.dim} ta="center">
            read-only · no seed phrase · deadline in view
          </text>
        </div>
      </section>

      {/* ── footer ──────────────────────────────────────────────────── */}
      <section w="100%" pad={{ t: 36, b: 44, l: 24, r: 24 }} bg={C.ground} align="center">
        <div {...wrap} gap={18}>
          <Rule c={C.line} />
          <div dir="row" w="100%" justify="space-between" gap={16} wrap="wrap" align="center" pad={{ t: 4 }}>
            <text font="Major Mono Display" size={14} color={C.ink} lh={1.4}>
              basis
            </text>
            <text size={13} font="Sora" color={C.dim} lh={1.6}>
              Crypto tax software that shows its working. Not tax advice; the audit trail is so your adviser does not
              have to take our word for it either.
            </text>
          </div>
        </div>
      </section>
    </box>
  );
};
