/** Safe Passage — refugee legal aid. Sober, print-adjacent tokens. */
export default defineTheme({
  name: 'safe-passage',
  color: {
    ground: '#FFFFFF',
    ink: '#1A1A1A',
    deep: '#153A5B',
    amber: '#D98324',
    line: '#DCDCDC',
    muted: '#4A4A4A',
    wash: '#F4F2EE',
  },
  font: { head: 'Libre Baskerville', body: 'Assistant' },
  mode: 'literal',
});
