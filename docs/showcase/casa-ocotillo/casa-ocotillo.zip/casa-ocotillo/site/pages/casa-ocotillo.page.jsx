/**
 * Casa Ocotillo — split-screen scroller.
 * Still image on one side, quiet detail on the other, side alternating down the page.
 */
import { MEDIA as media } from '../data/media.mjs';
import { RoomLine, RateLine, PlainLine, StepLine } from '../components/pieces.jsx';

export const meta = {
  title: 'Casa Ocotillo',
  slug: 'casa-ocotillo',
  seo: {
    title: 'Casa Ocotillo — eleven rooms, one road in, no televisions',
    description:
      'An eleven-room adobe hotel at 1,400 metres, built around a spring-fed pool and a courtyard of ocotillo. Three nights minimum. From 240 euro a night.',
  },
};

const fade = { effect: 'fade', trigger: 'scrollIn', duration: 700 };
const fadeSlow = { effect: 'fade', trigger: 'scrollIn', duration: 900, delay: 120 };

export default ({ theme: t }) => {
  const c = t.color;

  /** Small caps eyebrow — the recurring section marker. */
  const Eyebrow = ({ text, color, ta = 'left' }) => (
    <text cls="eyebrow" size={12} weight={600} ls={0.18} font={t.font.body} color={color} w="100%" ta={ta} mobile={{ size: 10, ls: 0.16 }}>
      {text}
    </text>
  );

  return (
    <box tw="flex flex-col w-full" pad={0} gap={0} bg={c.ground}>
      {/* ── 1 · Split hero ─────────────────────────────────────────────── */}
      <section pad={0} gap={0} w="100%" bg={c.ground}>
        <grid
          cols="1.02fr 1fr"
          gap={0}
          w="100%"
          tablet={{ gridCols: '1fr 1fr' }}
          mobile={{ gridCols: 1 }}
        >
          <box
            dir="column"
            justify="center"
            gap={30}
            pad={{ t: 128, b: 128, l: 88, r: 72 }}
            tablet={{ pad: { t: 80, b: 80, l: 40, r: 36 } }}
            mobile={{ pad: { t: 64, b: 64, l: 24, r: 24 }, gap: 24 }}
          >
            <Eyebrow text="HIGH DESERT · 1,400 M" color={c.adobe} />
            <h1
              size={62}
              weight={400}
              font={t.font.head}
              color={c.ink}
              lh={1.08}
              maxw={560}
              tablet={{ size: 46 }}
              mobile={{ size: 34 }}
              motion={{ effect: 'fade', trigger: 'load', duration: 800 }}
            >
              Eleven rooms, one road in, no televisions.
            </h1>
            <text
              size={18}
              font={t.font.body}
              color="rgba(51,42,34,0.78)"
              lh={1.75}
              maxw={520}
              tablet={{ size: 17 }}
              mobile={{ size: 16 }}
            >
              An adobe house at 1,400 metres, built around a spring-fed pool and a courtyard of
              ocotillo. Three nights minimum, because two is not long enough to stop checking your
              phone.
            </text>
            <box dir="row" gap={18} align="center" wrap m={{ t: 6 }}>
              <text
                href="#availability"
                cls="cta"
                size={15}
                weight={600}
                ls={0.02}
                font={t.font.body}
                color={c.ground}
                bg={c.adobe}
                pad={{ t: 17, b: 17, l: 34, r: 34 }}
                radius={2}
                w="hug"
                ta="center"
                hover={{ bg: c.ink, color: c.ground }}
              >
                Check availability
              </text>
              <text size={14} font={t.font.body} color="rgba(51,42,34,0.55)" lh={1.6}>
                From 240 € · three-night minimum
              </text>
            </box>
          </box>

          <img
            src={media.courtyard.id}
            w="100%"
            h="100%"
            minh={760}
            fit="cover"
            tablet={{ minh: 560, h: '100%' }}
            mobile={{ minh: 340, h: 340 }}
          />
        </grid>
      </section>

      {/* ── 2 · Eleven rooms, three types ──────────────────────────────── */}
      <section pad={0} gap={0} w="100%" bg={c.ground}>
        <grid cols="1fr 1.02fr" gap={0} w="100%" tablet={{ gridCols: '1fr 1fr' }} mobile={{ gridCols: 1 }}>
          <img
            src={media.room_interior.id}
            w="100%"
            h="100%"
            minh={760}
            fit="cover"
            tablet={{ minh: 600, h: '100%' }}
            mobile={{ minh: 320, h: 320 }}
          />

          <box
            dir="column"
            justify="center"
            gap={20}
            pad={{ t: 128, b: 128, l: 80, r: 88 }}
            tablet={{ pad: { t: 72, b: 72, l: 36, r: 40 } }}
            mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 } }}
            motion={fade}
          >
            <Eyebrow text="THE ROOMS" color={c.adobe} />
            <h2
              size={40}
              weight={400}
              font={t.font.head}
              color={c.ink}
              lh={1.15}
              maxw={460}
              tablet={{ size: 32 }}
              mobile={{ size: 27 }}
            >
              Eleven rooms, three types, honest sizes.
            </h2>
            <text size={16} font={t.font.body} color="rgba(51,42,34,0.66)" lh={1.75} maxw={470} m={{ b: 14 }}>
              Thick walls, lime plaster, linen. No room number is a surprise once you are standing
              in it — the square metres below are the real ones, measured wall to wall.
            </text>

            <box dir="column" gap={0} w="100%">
              <RoomLine
                name="Courtyard rooms"
                size="24 SQ M"
                note="Ground floor, private terrace, opening onto the ocotillo courtyard. Six of them."
              />
              <RoomLine
                name="Tower rooms"
                size="31 SQ M"
                note="Upstairs, deep window seats, and the good light in the afternoon. Four of them."
              />
              <RoomLine
                name="The Long Room"
                size="46 SQ M"
                note="Its own plunge pool and worth the difference. There is only one, so it books first."
              />
            </box>
          </box>
        </grid>
      </section>

      {/* ── 3 · The pool and the hours it is silent ────────────────────── */}
      <section pad={0} gap={0} w="100%" bg={c.shade}>
        <grid cols="1.35fr 1fr" gap={0} w="100%" tablet={{ gridCols: '1fr 1fr' }} mobile={{ gridCols: 1 }}>
          <box
            dir="column"
            justify="center"
            gap={26}
            pad={{ t: 132, b: 132, l: 88, r: 80 }}
            tablet={{ pad: { t: 76, b: 76, l: 40, r: 36 } }}
            mobile={{ pad: { t: 60, b: 60, l: 24, r: 24 } }}
            motion={fade}
          >
            <Eyebrow text="THE POOL" color={c.cactus} />
            <h2
              size={44}
              weight={400}
              font={t.font.head}
              color={c.ground}
              lh={1.18}
              maxw={640}
              tablet={{ size: 33 }}
              mobile={{ size: 27 }}
            >
              The pool is spring-fed and cold. It is silent from 7am to 10am by house rule, and
              nobody has ever complained.
            </h2>
            <text size={17} font={t.font.body} color="rgba(237,227,214,0.62)" lh={1.8} maxw={520} mobile={{ size: 15 }}>
              The spring runs at fourteen degrees year-round and we do not heat it. Towels are by
              the door in the wall. After ten it is an ordinary pool again, and children are
              welcome in it.
            </text>
          </box>

          <box
            bg={c.cactus}
            dir="column"
            justify="center"
            align="flex-start"
            gap={14}
            pad={{ t: 132, b: 132, l: 64, r: 64 }}
            tablet={{ pad: { t: 76, b: 76, l: 36, r: 36 } }}
            mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 } }}
            motion={fadeSlow}
          >
            <text size={12} weight={600} ls={0.18} font={t.font.body} color="rgba(237,227,214,0.7)">
              SILENT HOURS
            </text>
            <text size={68} weight={400} font={t.font.head} color={c.ground} lh={1.05} tablet={{ size: 48 }} mobile={{ size: 42 }}>
              07:00
            </text>
            <text size={20} font={t.font.head} color="rgba(237,227,214,0.6)" lh={1.2}>
              to
            </text>
            <text size={68} weight={400} font={t.font.head} color={c.ground} lh={1.05} tablet={{ size: 48 }} mobile={{ size: 42 }}>
              10:00
            </text>
            <text size={15} font={t.font.body} color="rgba(237,227,214,0.72)" lh={1.7} maxw={260} m={{ t: 12 }}>
              No conversation, no phones, no service. Coffee is left on the wall at six.
            </text>
          </box>
        </grid>
      </section>

      {/* ── 4 · The kitchen ────────────────────────────────────────────── */}
      <section pad={0} gap={0} w="100%" bg={c.ground}>
        <grid cols="1fr 1.05fr" gap={0} w="100%" tablet={{ gridCols: '1fr 1fr' }} mobile={{ gridCols: 1 }}>
          <box
            dir="column"
            justify="center"
            gap={24}
            pad={{ t: 128, b: 128, l: 88, r: 76 }}
            tablet={{ pad: { t: 72, b: 72, l: 40, r: 36 } }}
            mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 } }}
            motion={fade}
          >
            <Eyebrow text="THE KITCHEN" color={c.adobe} />
            <h2
              size={40}
              weight={400}
              font={t.font.head}
              color={c.ink}
              lh={1.15}
              maxw={480}
              tablet={{ size: 32 }}
              mobile={{ size: 27 }}
            >
              One menu, changed daily.
            </h2>
            <text size={17} font={t.font.body} color="rgba(51,42,34,0.75)" lh={1.8} maxw={500} mobile={{ size: 16 }}>
              One menu a night, four courses, written at noon based on what came up from the
              valley. Tell us about allergies when you book and we will build around them
              properly.
            </text>

            <box dir="row" gap={0} w="100%" wrap m={{ t: 10 }}>
              <box dir="column" gap={6} pad={{ t: 20, b: 20, r: 32 }} flex={1} minh={0}>
                <text size={12} weight={600} ls={0.16} font={t.font.body} color={c.cactus}>
                  DINNER
                </text>
                <text size={22} font={t.font.head} color={c.ink} lh={1.3}>
                  20:00, one sitting
                </text>
              </box>
              <box dir="column" gap={6} pad={{ t: 20, b: 20, r: 32 }} flex={1} minh={0}>
                <text size={12} weight={600} ls={0.16} font={t.font.body} color={c.cactus}>
                  BREAKFAST
                </text>
                <text size={22} font={t.font.head} color={c.ink} lh={1.3}>
                  Whenever you appear
                </text>
              </box>
            </box>
          </box>

          <img
            src={media.table_dinner.id}
            w="100%"
            h="100%"
            minh={720}
            fit="cover"
            tablet={{ minh: 560, h: '100%' }}
            mobile={{ minh: 320, h: 320 }}
          />
        </grid>
      </section>

      {/* ── 5 · What there is, and what there deliberately is not ──────── */}
      <section pad={0} gap={0} w="100%" bg="#E4D8C7">
        <grid cols="1fr 1.15fr" gap={0} w="100%" tablet={{ gridCols: '1fr 1fr' }} mobile={{ gridCols: 1 }}>
          <img
            src={media.desert_walk.id}
            w="100%"
            h="100%"
            minh={760}
            fit="cover"
            tablet={{ minh: 600, h: '100%' }}
            mobile={{ minh: 300, h: 300 }}
          />

          <box
            dir="column"
            justify="center"
            gap={30}
            pad={{ t: 124, b: 124, l: 80, r: 88 }}
            tablet={{ pad: { t: 72, b: 72, l: 36, r: 40 } }}
            mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 } }}
            motion={fade}
          >
            <Eyebrow text="WHAT THERE IS TO DO" color={c.adobe} />
            <h2
              size={38}
              weight={400}
              font={t.font.head}
              color={c.ink}
              lh={1.18}
              maxw={520}
              tablet={{ size: 30 }}
              mobile={{ size: 26 }}
            >
              There is no spa, no gym, no activities desk.
            </h2>

            <grid cols={2} gap={40} w="100%" mobile={{ gridCols: 1, gap: 24 }}>
              <box dir="column" gap={0}>
                <text size={12} weight={600} ls={0.16} font={t.font.body} color={c.cactus} m={{ b: 10 }}>
                  THERE IS NOT
                </text>
                <PlainLine label="A spa, or anything with the word wellness on it" />
                <PlainLine label="A gym" />
                <PlainLine label="An activities desk" />
                <PlainLine label="A television, in any of the eleven rooms" />
              </box>
              <box dir="column" gap={0}>
                <text size={12} weight={600} ls={0.16} font={t.font.body} color={c.cactus} m={{ b: 10 }}>
                  THERE IS
                </text>
                <PlainLine label="40 km of walking tracks, from the gate" />
                <PlainLine label="A good hammock" />
                <PlainLine label="220 books" />
                <PlainLine label="A sky with no light pollution in any direction" />
              </box>
            </grid>
          </box>
        </grid>
      </section>

      {/* ── 6 · Getting here ───────────────────────────────────────────── */}
      <section pad={0} gap={0} w="100%" bg={c.ink}>
        <grid cols="1fr 1fr" gap={0} w="100%" mobile={{ gridCols: 1 }}>
          <box
            dir="column"
            justify="center"
            gap={22}
            pad={{ t: 120, b: 120, l: 88, r: 72 }}
            tablet={{ pad: { t: 72, b: 72, l: 40, r: 36 } }}
            mobile={{ pad: { t: 56, b: 56, l: 24, r: 24 } }}
            motion={fade}
          >
            <Eyebrow text="GETTING HERE" color={c.adobe} />
            <h2
              size={40}
              weight={400}
              font={t.font.head}
              color={c.ground}
              lh={1.15}
              maxw={460}
              tablet={{ size: 31 }}
              mobile={{ size: 26 }}
            >
              The last 14 km are unpaved.
            </h2>
            <text size={17} font={t.font.body} color="rgba(237,227,214,0.66)" lh={1.8} maxw={460} mobile={{ size: 16 }}>
              Two and a half hours from the airport, the last 14 km on graded dirt. A normal car is
              fine, a low sports car is not. We will send exact coordinates, not an address.
            </text>
          </box>

          <box
            dir="column"
            justify="center"
            gap={0}
            pad={{ t: 120, b: 120, l: 72, r: 88 }}
            bg="#2A231C"
            tablet={{ pad: { t: 72, b: 72, l: 36, r: 40 } }}
            mobile={{ pad: { t: 48, b: 56, l: 24, r: 24 } }}
            motion={fadeSlow}
          >
            <StepLine num="01" label="Fly to the regional airport" note="Two direct arrivals a day; we can meet either." />
            <StepLine num="02" label="Two and a half hours of road" note="Sealed the whole way, one petrol stop worth taking." />
            <StepLine num="03" label="The last 14 km, graded dirt" note="Slow, washboarded in places, and perfectly passable." />
            <StepLine num="04" label="Coordinates, not an address" note="Sent with your confirmation. The address does not exist." />
          </box>
        </grid>
      </section>

      {/* ── 7 · Rates ──────────────────────────────────────────────────── */}
      <section
        pad={{ t: 120, b: 120, l: 88, r: 88 }}
        gap={44}
        w="100%"
        bg={c.shade}
        tablet={{ pad: { t: 80, b: 80, l: 40, r: 40 } }}
        mobile={{ pad: { t: 60, b: 60, l: 24, r: 24 }, gap: 30 }}
      >
        <box dir="row" justify="space-between" align="flex-end" gap={30} w="100%" wrap>
          <box dir="column" gap={16} maxw={520}>
            <Eyebrow text="RATES" color={c.adobe} />
            <h2
              size={40}
              weight={400}
              font={t.font.head}
              color={c.ground}
              lh={1.15}
              tablet={{ size: 32 }}
              mobile={{ size: 27 }}
            >
              By season, with minimum stays.
            </h2>
          </box>
          <text size={16} font={t.font.body} color="rgba(237,227,214,0.6)" lh={1.75} maxw={400} mobile={{ size: 15 }}>
            From 240 euro a night in low season to 410 in October. Three-night minimum year-round,
            five nights over New Year. Dinner is 55 € a head and breakfast is included.
          </text>
        </box>

        <grid cols={4} gap={18} w="100%" tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }} motion={fade}>
          <RateLine season="Low season" months="JUNE — AUGUST" price="240 €" stay="Three nights minimum" />
          <RateLine season="Shoulder" months="MARCH — MAY, NOVEMBER" price="310 €" stay="Three nights minimum" />
          <RateLine season="October" months="THE BEST LIGHT OF THE YEAR" price="410 €" stay="Three nights minimum" />
          <RateLine season="New Year" months="27 DECEMBER — 2 JANUARY" price="410 €" stay="Five nights minimum" />
        </grid>

        <text size={14} font={t.font.body} color="rgba(237,227,214,0.45)" lh={1.7} maxw={640}>
          Per room per night, two people, taxes included. The Long Room is 90 € above the season
          rate. We do not run promotions and the price you are quoted is the price.
        </text>
      </section>

      {/* ── 8 · Availability check ─────────────────────────────────────── */}
      <section
        id="availability"
        pad={{ t: 132, b: 132, l: 24, r: 24 }}
        gap={26}
        w="100%"
        bg={c.adobe}
        align="center"
        tablet={{ pad: { t: 96, b: 96, l: 32, r: 32 } }}
        mobile={{ pad: { t: 72, b: 72, l: 24, r: 24 }, gap: 20 }}
      >
        <Eyebrow text="AVAILABILITY" color="rgba(30,26,23,0.62)" ta="center" />
        <h2
          size={48}
          weight={400}
          font={t.font.head}
          color={c.shade}
          lh={1.12}
          maxw={720}
          ta="center"
          tablet={{ size: 36 }}
          mobile={{ size: 29 }}
        >
          Tell us the nights, and we will tell you which of the eleven are free.
        </h2>
        <text
          size={17}
          font={t.font.body}
          color="rgba(30,26,23,0.82)"
          lh={1.75}
          maxw={560}
          ta="center"
          mobile={{ size: 16 }}
        >
          Three nights minimum, year-round. Write to us with your dates, how many of you there are,
          and anything the kitchen should know. We answer every enquiry by hand, usually inside a
          day.
        </text>
        <text
          href="mailto:reservations@casaocotillo.example?subject=Availability%20—%20three%20nights"
          cls="cta"
          size={15}
          weight={600}
          ls={0.02}
          font={t.font.body}
          color={c.ground}
          bg={c.shade}
          pad={{ t: 18, b: 18, l: 40, r: 40 }}
          radius={2}
          w="hug"
          ta="center"
          m={{ t: 10 }}
          hover={{ bg: c.ink, color: c.white }}
        >
          Check availability
        </text>
        <text size={14} font={t.font.body} color="rgba(30,26,23,0.7)" lh={1.7} ta="center">
          reservations@casaocotillo.example · coordinates sent on confirmation
        </text>
      </section>
    </box>
  );
};
