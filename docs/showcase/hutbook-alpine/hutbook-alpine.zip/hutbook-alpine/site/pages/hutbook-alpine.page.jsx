/** Hutbook — alpine hut-to-hut booking landing page.
 *  Structural archetype: overlapping stacked cards, repeated at every scale. */
import { MEDIA as media } from '../data/media.mjs';

export const meta = {
  title: 'Hutbook — book a whole alpine traverse in one basket',
  slug: 'hutbook-alpine',
  seo: {
    title: 'Hutbook — book eight huts in one basket',
    description:
      '1,140 mountain huts across six alpine countries. Pick a traverse, we check every consecutive night is a realistic day for your pace, and book the whole chain at once.',
  },
};

/* ── data ─────────────────────────────────────────────────────────────── */

const ROUTES = [
  {
    name: 'Haute Route',
    arc: 'Chamonix to Zermatt',
    country: 'France · Switzerland',
    days: '11 days',
    dist: '180 km',
    up: '12,600 m ascent',
    beds: '7 of 11 huts have beds',
    window: '4 to 15 September',
  },
  {
    name: 'Tour du Mont Blanc',
    arc: 'Les Houches, full loop',
    country: 'France · Italy · Switzerland',
    days: '10 days',
    dist: '170 km',
    up: '10,000 m ascent',
    beds: '9 of 10 huts have beds',
    window: '1 to 11 September',
  },
  {
    name: 'Alta Via 1',
    arc: 'Lago di Braies to Belluno',
    country: 'Italy',
    days: '9 days',
    dist: '120 km',
    up: '6,800 m ascent',
    beds: '8 of 9 rifugi have beds',
    window: '6 to 15 September',
  },
  {
    name: 'Stubai Höhenweg',
    arc: 'Neustift circuit, Tyrol',
    country: 'Austria',
    days: '7 days',
    dist: '80 km',
    up: '6,400 m ascent',
    beds: '6 of 7 hütten have beds',
    window: '2 to 9 September',
  },
  {
    name: 'Triglav Traverse',
    arc: 'Vrata valley to Bohinj',
    country: 'Slovenia',
    days: '5 days',
    dist: '62 km',
    up: '4,900 m ascent',
    beds: '4 of 5 koče have beds',
    window: '8 to 13 September',
  },
  {
    name: 'Berchtesgaden Round',
    arc: 'Königssee to Wimbachgries',
    country: 'Germany',
    days: '6 days',
    dist: '74 km',
    up: '5,200 m ascent',
    beds: '6 of 6 huts have beds',
    window: '3 to 9 September',
  },
];

const LEGS = [
  { leg: 'Day 4 · Cabane du Mont Fort to Louvie', num: '5h 40', verdict: 'Comfortable at your stated pace.' },
  { leg: 'Day 7 · Arolla to Cabane des Dix', num: '9h 20', verdict: 'Over nine hours. We flag it before you pay.' },
  { leg: 'Day 9 · Schönbiel to Zermatt', num: '4h 05', verdict: 'Short day. Room for the Matterhorn detour.' },
];

const BASKET = [
  { hut: 'Refuge du Trient', night: 'Night 3 · 2 beds', price: '€68' },
  { hut: 'Cabane de Prafleuri', night: 'Night 5 · 2 beds', price: '€74' },
  { hut: 'Cabane des Dix', night: 'Night 7 · 2 beds', price: '€79' },
  { hut: 'Schönbielhütte', night: 'Night 10 · 2 beds', price: '€71' },
];

const EVENING = [
  { time: '17:00', what: 'Boots off at the door, soup on the table, the warden takes your name.' },
  { time: '18:00', what: 'Half board is served. One sitting, everybody at once, no late plates.' },
  { time: '22:00', what: 'Generator off, lights out. The 4am starters are already packed.' },
];

const CLUBS = [
  { club: 'DAV · Germany', save: '€12 to €18 a night', note: 'Honoured across Austria and South Tyrol too.' },
  { club: 'ÖAV · Austria', save: '€14 to €22 a night', note: 'Reciprocal rights on 1,100 of our huts.' },
  { club: 'SAC · Switzerland', save: '€12 to €20 a night', note: 'Applies automatically on the Haute Route chain.' },
];

/* ── registered components (content props only) ───────────────────────── */

const RouteCard = defineComponent(
  ({ name, arc, country, days, dist, up, beds, window: win }) => (
    <div
      cls="route-card"
      tw="flex flex-col gap-5 w-full rounded-2xl p-8 bg-[#FFFFFF] max-md:p-6 max-md:gap-4"
      shadow={[
        [1, 0, 0, '#D5DEE6', 0],
        [18, 40, -24, 'rgba(26,36,48,0.34)', 0],
      ]}
    >
      <div tw="flex flex-col gap-1">
        <text size={12} weight={700} ls={0.12} font="Merriweather Sans" color="#2F7DA8" tw="uppercase">
          {country}
        </text>
        <h3 size={34} weight={700} lh={1.05} font="Rokkitt" color="#1A2430" tw="max-md:text-[27px]">
          {name}
        </h3>
        <text size={15} font="Merriweather Sans" color="#5E6D7A" lh={1.5}>
          {arc}
        </text>
      </div>

      <div tw="flex flex-row flex-wrap gap-x-6 gap-y-2 items-end">
        <text size={15} weight={700} font="Rokkitt" color="#1A2430">{days}</text>
        <text size={15} weight={700} font="Rokkitt" color="#1A2430">{dist}</text>
        <text size={15} weight={700} font="Rokkitt" color="#1A2430">{up}</text>
      </div>

      <div
        tw="flex flex-row flex-wrap items-center justify-between gap-3 rounded-xl px-5 py-4 bg-[#F0F3F6] max-md:px-4"
        border={[1, '#DCE3EA']}
      >
        <text size={15} weight={700} font="Merriweather Sans" color="#1A2430">
          {beds}
        </text>
        <text size={13} font="Merriweather Sans" color="#5E6D7A">
          {win}
        </text>
      </div>
    </div>
  ),
  {
    title: 'Hutbook Route Card',
    props: {
      name: { label: 'Route name', group: 'Route' },
      arc: { label: 'Start to finish', group: 'Route' },
      country: { label: 'Countries', group: 'Route' },
      days: { label: 'Days', group: 'Numbers' },
      dist: { label: 'Distance', group: 'Numbers' },
      up: { label: 'Ascent', group: 'Numbers' },
      beds: { label: 'Bed availability', group: 'Availability' },
      window: { label: 'Date window', group: 'Availability' },
    },
  },
);

const LegRow = defineComponent(
  ({ leg, num, verdict }) => (
    <div
      cls="leg-row"
      tw="flex flex-row gap-5 w-full rounded-xl p-6 bg-[#FFFFFF] max-md:p-5 max-md:gap-4"
      shadow={[[10, 24, -18, 'rgba(26,36,48,0.28)', 0]]}
    >
      <text size={26} weight={700} font="Rokkitt" color="#2F7DA8" tw="w-[92px] shrink-0 max-md:text-[22px] max-md:w-[74px]">
        {num}
      </text>
      <div tw="flex flex-col gap-1">
        <text size={15} weight={700} font="Merriweather Sans" color="#1A2430" lh={1.4}>
          {leg}
        </text>
        <text size={14} font="Merriweather Sans" color="#5E6D7A" lh={1.55}>
          {verdict}
        </text>
      </div>
    </div>
  ),
  {
    title: 'Hutbook Leg Row',
    props: {
      leg: { label: 'Leg', group: 'Leg' },
      num: { label: 'Walking time', group: 'Leg' },
      verdict: { label: 'Verdict', group: 'Leg' },
    },
  },
);

const BasketRow = defineComponent(
  ({ hut, night, price }) => (
    <div
      cls="basket-row"
      tw="flex flex-row flex-wrap items-center justify-between gap-3 w-full py-4 border-b"
      border={[0, '#DCE3EA']}
      raw="& { border-bottom: 1px solid #DCE3EA; }"
    >
      <div tw="flex flex-col gap-1">
        <text size={16} weight={700} font="Merriweather Sans" color="#1A2430">{hut}</text>
        <text size={13} font="Merriweather Sans" color="#5E6D7A">{night}</text>
      </div>
      <text size={20} weight={700} font="Rokkitt" color="#1A2430">{price}</text>
    </div>
  ),
  {
    title: 'Hutbook Basket Row',
    props: {
      hut: { label: 'Hut name', group: 'Line' },
      night: { label: 'Night and beds', group: 'Line' },
      price: { label: 'Price', group: 'Line' },
    },
  },
);

const ClubCard = defineComponent(
  ({ club, save, note }) => (
    <div
      cls="club-card"
      tw="flex flex-col gap-2 w-full rounded-2xl p-7 bg-[#FFFFFF] max-md:p-6"
      shadow={[
        [1, 0, 0, '#E07B39', 0],
        [16, 34, -22, 'rgba(0,0,0,0.45)', 0],
      ]}
    >
      <text size={13} weight={700} ls={0.1} font="Merriweather Sans" color="#5E6D7A" tw="uppercase">
        {club}
      </text>
      <text size={30} weight={700} font="Rokkitt" color="#1A2430" lh={1.1} tw="max-md:text-[25px]">
        {save}
      </text>
      <text size={14} font="Merriweather Sans" color="#5E6D7A" lh={1.55}>
        {note}
      </text>
    </div>
  ),
  {
    title: 'Hutbook Club Card',
    props: {
      club: { label: 'Club', group: 'Club' },
      save: { label: 'Saving', group: 'Club' },
      note: { label: 'Note', group: 'Club' },
    },
  },
);

/* ── shared bits ──────────────────────────────────────────────────────── */

const Eyebrow = ({ children, color = '#2F7DA8' }) => (
  <text size={12} weight={700} ls={0.14} font="Merriweather Sans" color={color} tw="uppercase">
    {children}
  </text>
);

const Cta = ({ children, href, tone = 'alp' }) => (
  <text
    href={href}
    tag="a"
    tw="rounded-full px-8 py-4 no-underline w-fit text-center max-md:px-6"
    size={16}
    weight={700}
    font="Merriweather Sans"
    bg={tone === 'alp' ? '#2F7DA8' : '#E07B39'}
    color="#FFFFFF"
    shadow={[[10, 26, -14, 'rgba(47,125,168,0.55)', 0]]}
    hover={{ bg: tone === 'alp' ? '#1A2430' : '#C4652A', color: '#FFFFFF' }}
  >
    {children}
  </text>
);

const FADE = { effect: 'fade', trigger: 'scrollIn', duration: 600 };

/* ── page ─────────────────────────────────────────────────────────────── */

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>

    {/* ══ 1. Route card stack ══════════════════════════════════════════ */}
    <section tw="flex flex-col items-center w-full px-6 pt-8 pb-32 max-md:px-4 max-md:pb-20" bg={t.color.ink}>
      {/* slim bar */}
      <div tw="flex flex-row flex-wrap items-center justify-between gap-4 w-full max-w-[1180px] py-4">
        <text size={22} weight={700} ls={-0.01} font={t.font.head} color={t.color.snow}>
          Hutbook
        </text>
        <div tw="flex flex-row flex-wrap items-center gap-7 max-md:gap-4">
          <text href="#walkability" tag="a" size={14} font={t.font.body} color="#B9C6D2" tw="no-underline" hover={{ color: '#FFFFFF' }}>
            Walkability
          </text>
          <text href="#huts" tag="a" size={14} font={t.font.body} color="#B9C6D2" tw="no-underline" hover={{ color: '#FFFFFF' }}>
            Hut nights
          </text>
          <text href="#basket" tag="a" size={14} font={t.font.body} color="#B9C6D2" tw="no-underline" hover={{ color: '#FFFFFF' }}>
            One basket
          </text>
          <text href="#search" tag="a" size={14} weight={700} font={t.font.body} color={t.color.snow} tw="no-underline" hover={{ color: '#2F7DA8' }}>
            Search a traverse
          </text>
        </div>
      </div>

      <grid cols="minmax(0,1fr) minmax(0,1fr)" gap={64} tw="w-full max-w-[1180px] pt-16 max-lg:gap-10 max-md:pt-8" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col gap-7 pt-6 max-md:pt-0 max-md:gap-5">
          <Eyebrow>1,140 huts · six alpine countries</Eyebrow>
          <h1 size={62} weight={700} lh={1.02} ls={-0.01} font={t.font.head} color={t.color.snow} tw="max-lg:text-[48px] max-md:text-[36px]">
            Book eight huts in one basket, and know you can actually walk between them.
          </h1>
          <text size={17} font={t.font.body} color="#B9C6D2" lh={1.7} maxw={520} tw="max-md:text-[15px]">
            Hutbook covers 1,140 mountain huts across six countries. Pick a traverse, we check every
            consecutive night is a realistic day for your pace, and book the whole chain at once.
          </text>
          <div tw="flex flex-row flex-wrap items-center gap-5">
            <Cta href="#search">Search a traverse</Cta>
            <text size={14} font={t.font.body} color="#8C9BAA" lh={1.6} maxw={230}>
              €3 per booked night. We never mark up a bed.
            </text>
          </div>
        </div>

        {/* the stack: each card overlaps the one above it */}
        <div tw="flex flex-col w-full">
          <text size={13} weight={700} ls={0.12} font={t.font.body} color="#8C9BAA" tw="uppercase pb-6">
            Six classic traverses, live beds
          </text>
          {ROUTES.map((r, i) => (
            <div
              tw={i === 0 ? 'flex flex-col w-full' : 'flex flex-col w-full -mt-6 max-md:-mt-4'}
              pad={{ l: i % 2 ? 28 : 0 }}
              mobile={{ pad: { l: 0 } }}
              motion={i < 3 ? FADE : { ...FADE, delay: 80 }}
            >
              <RouteCard {...r} />
            </div>
          ))}
        </div>
      </grid>
    </section>

    {/* ══ 2. The walkability check ═════════════════════════════════════ */}
    <section id="walkability" tw="flex flex-col items-center w-full px-6 py-28 max-md:px-4 max-md:py-16" bg={t.color.ground}>
      <grid cols="minmax(0,1.05fr) minmax(0,1fr)" gap={72} tw="w-full max-w-[1180px] items-start max-lg:gap-12" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col w-full">
          <img
            src={media.traverse_walkers.id}
            tw="w-full rounded-2xl object-cover h-[480px] max-lg:h-[360px] max-md:h-[260px]"
            shadow={[[24, 60, -30, 'rgba(26,36,48,0.35)', 0]]}
          />
          {/* card overlapping the photo's lower edge */}
          <div
            tw="flex flex-col gap-3 rounded-2xl p-7 bg-[#1A2430] w-[86%] -mt-16 max-md:w-full max-md:-mt-10 max-md:p-6"
            m={{ l: 'auto' }}
            shadow={[[20, 44, -22, 'rgba(26,36,48,0.5)', 0]]}
            motion={FADE}
          >
            <Eyebrow color="#E07B39">Your pace, not an average one</Eyebrow>
            <text size={17} font={t.font.body} color="#FFFFFF" lh={1.65} tw="max-md:text-[15px]">
              We check each leg against your stated pace, the ascent, the technical grade and the
              daylight. <strong>If a leg is over nine hours for you we say so before you pay</strong>,
              not after.
            </text>
          </div>
        </div>

        <div tw="flex flex-col gap-8 pt-4 max-md:pt-0 max-md:gap-6">
          <Eyebrow>The walkability check</Eyebrow>
          <h2 size={46} weight={700} lh={1.06} font={t.font.head} color={t.color.ink} tw="max-lg:text-[38px] max-md:text-[30px]">
            A chain of beds is only a route if every night is a real day.
          </h2>
          <text size={16} font={t.font.body} color={t.color.rock} lh={1.7}>
            Four inputs, one verdict per leg. Change your pace and the whole chain re-checks itself
            in front of you — before a card is ever charged.
          </text>
          <div tw="flex flex-col gap-4">
            {LEGS.map((l, i) => (
              <div tw={i === 0 ? 'flex flex-col w-full' : 'flex flex-col w-full'} pad={{ l: i * 18 }} mobile={{ pad: { l: 0 } }} motion={FADE}>
                <LegRow {...l} />
              </div>
            ))}
          </div>
        </div>
      </grid>
    </section>

    {/* ══ 3. Huts: what a night actually involves ══════════════════════ */}
    <section id="huts" tw="flex flex-col items-center w-full px-6 py-28 max-md:px-4 max-md:py-16" bg="#243040">
      <grid cols="minmax(0,1fr) minmax(0,1.1fr)" gap={72} tw="w-full max-w-[1180px] items-center max-lg:gap-12" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col gap-7 max-md:gap-5">
          <Eyebrow color="#E07B39">What a night actually involves</Eyebrow>
          <h2 size={46} weight={700} lh={1.06} font={t.font.head} color={t.color.snow} tw="max-lg:text-[38px] max-md:text-[30px]">
            A bunk, a shared bathroom, and dinner at six o'clock sharp.
          </h2>
          <text size={17} font={t.font.body} color="#B9C6D2" lh={1.7} tw="max-md:text-[15px]">
            A hut night is a bunk in a shared room, a shared bathroom, a hot meal at 6pm sharp, and
            lights out at 10. Bring a sleeping liner, earplugs and cash. That is the whole packing
            list debate.
          </text>
          <div tw="flex flex-row flex-wrap gap-3">
            {['Sleeping liner', 'Earplugs', 'Cash', 'Hut shoes provided'].map((chip) => (
              <text
                size={13}
                weight={700}
                font={t.font.body}
                color="#FFFFFF"
                tw="rounded-full px-4 py-2"
                border={[1, '#3E5064']}
              >
                {chip}
              </text>
            ))}
          </div>
        </div>

        <div tw="flex flex-col w-full">
          <img
            src={media.dorm.id}
            tw="w-full rounded-2xl object-cover h-[440px] w-[92%] max-lg:h-[340px] max-md:h-[240px] max-md:w-full"
            shadow={[[26, 64, -32, 'rgba(0,0,0,0.6)', 0]]}
          />
          <div
            tw="flex flex-col gap-2 rounded-2xl p-7 bg-[#FFFFFF] w-[78%] -mt-20 max-md:w-full max-md:-mt-12 max-md:p-6"
            m={{ l: 'auto' }}
            shadow={[
              [1, 0, 0, '#D5DEE6', 0],
              [22, 48, -26, 'rgba(0,0,0,0.55)', 0],
            ]}
            motion={FADE}
          >
            <text size={38} weight={700} font={t.font.head} color={t.color.ink} lh={1} tw="max-md:text-[30px]">
              22:00
            </text>
            <text size={15} font={t.font.body} color={t.color.rock} lh={1.6}>
              Lights out, every hut, no exceptions. The 4am alpine starts are why.
            </text>
          </div>
        </div>
      </grid>
    </section>

    {/* ══ 4. One basket ════════════════════════════════════════════════ */}
    <section id="basket" tw="flex flex-col items-center w-full px-6 py-28 max-md:px-4 max-md:py-16" bg={t.color.snow}>
      <grid cols="minmax(0,1fr) minmax(0,1fr)" gap={72} tw="w-full max-w-[1180px] items-start max-lg:gap-12" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col gap-7 max-md:gap-5">
          <Eyebrow>Booking a whole traverse</Eyebrow>
          <h2 size={46} weight={700} lh={1.06} font={t.font.head} color={t.color.ink} tw="max-lg:text-[38px] max-md:text-[30px]">
            Eleven wardens, eleven emails, eleven bank transfers. Or one basket.
          </h2>
          <text size={16} font={t.font.body} color={t.color.rock} lh={1.7}>
            Every hut on the chain is held together and confirmed together. If night seven cannot be
            filled, nothing is charged — you are never left holding six beds and a gap in the middle.
          </text>
          <text size={16} font={t.font.body} color={t.color.rock} lh={1.7}>
            <strong>We charge 3 euro per booked night.</strong> The hut gets the rest, at the price
            they set, and we never mark up a bed.
          </text>
          <Cta href="#search">Search a traverse</Cta>
        </div>

        <div tw="flex flex-col w-full">
          <div
            tw="flex flex-col gap-1 w-full rounded-2xl p-8 bg-[#F0F3F6] max-md:p-6"
            border={[1, '#DCE3EA']}
            motion={FADE}
          >
            <text size={13} weight={700} ls={0.12} font={t.font.body} color={t.color.rock} tw="uppercase pb-4">
              Basket · Haute Route, 4 to 15 September
            </text>
            {BASKET.map((b) => (
              <BasketRow {...b} />
            ))}
            <div tw="flex flex-row flex-wrap items-end justify-between gap-3 pt-6">
              <text size={16} font={t.font.body} color={t.color.rock}>
                11 nights, 2 walkers, held together
              </text>
              <text size={34} weight={700} font={t.font.head} color={t.color.ink} tw="max-md:text-[28px]">
                €1,612
              </text>
            </div>
          </div>
          {/* fee tag overlapping the basket */}
          <div
            tw="flex flex-col gap-1 rounded-2xl px-7 py-6 bg-[#2F7DA8] w-[74%] -mt-8 max-md:w-full max-md:px-6"
            m={{ l: 'auto' }}
            shadow={[[18, 40, -20, 'rgba(47,125,168,0.6)', 0]]}
          >
            <text size={15} weight={700} font={t.font.body} color="#FFFFFF" lh={1.55}>
              Our cut of that: €66. Three euro a night, and nothing else.
            </text>
          </div>
        </div>
      </grid>
    </section>

    {/* ══ 5. Weather windows ═══════════════════════════════════════════ */}
    <section tw="flex flex-col items-center w-full px-6 py-28 max-md:px-4 max-md:py-16" bg={t.color.alp}>
      <grid cols="minmax(0,1.1fr) minmax(0,1fr)" gap={72} tw="w-full max-w-[1180px] items-start max-lg:gap-12" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col gap-7 max-md:gap-5">
          <Eyebrow color="#CFE4F0">Weather windows</Eyebrow>
          <h2 size={46} weight={700} lh={1.06} font={t.font.head} color={t.color.snow} tw="max-lg:text-[38px] max-md:text-[30px]">
            Move the whole chain by three days, once, for free.
          </h2>
          <text size={17} font={t.font.body} color="#E4F0F7" lh={1.7} tw="max-md:text-[15px]">
            Book a chain, then move the whole thing by up to three days once for free if the forecast
            turns. That single feature is why most people use us instead of emailing eleven wardens.
          </text>
        </div>

        <div tw="flex flex-col w-full">
          {[
            { h: 'Shift, do not cancel', p: 'One free shift of up to three days on the entire chain, re-checked for walkability at the new dates.' },
            { h: 'Cancel free to 14 days', p: 'Full refund, our fee included, up to fourteen days before the first night.' },
            { h: 'Storm clause', p: 'If a warden closes a hut for weather, that night is refunded whatever the notice.' },
          ].map((c, i) => (
            <div
              tw={i === 0 ? 'flex flex-col w-full' : 'flex flex-col w-full -mt-5 max-md:-mt-4'}
              pad={{ l: i * 22 }}
              mobile={{ pad: { l: 0 } }}
              motion={FADE}
            >
              <div
                tw="flex flex-col gap-2 w-full rounded-2xl p-7 bg-[#FFFFFF] max-md:p-6"
                shadow={[[16, 38, -20, 'rgba(0,0,0,0.4)', 0]]}
              >
                <h3 size={26} weight={700} font={t.font.head} color={t.color.ink} lh={1.15} tw="max-md:text-[22px]">
                  {c.h}
                </h3>
                <text size={15} font={t.font.body} color={t.color.rock} lh={1.6}>
                  {c.p}
                </text>
              </div>
            </div>
          ))}
        </div>
      </grid>
    </section>

    {/* ══ 6. Half board, diet, the 6pm rule ════════════════════════════ */}
    <section tw="flex flex-col items-center w-full px-6 py-28 max-md:px-4 max-md:py-16" bg={t.color.ground}>
      <grid cols="minmax(0,1fr) minmax(0,1.05fr)" gap={72} tw="w-full max-w-[1180px] items-start max-lg:gap-12" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col w-full">
          <text size={13} weight={700} ls={0.12} font={t.font.body} color={t.color.rock} tw="uppercase pb-6">
            An evening at 1,900 metres
          </text>
          {EVENING.map((e, i) => (
            <div
              tw={i === 0 ? 'flex flex-col w-full' : 'flex flex-col w-full -mt-4'}
              pad={{ l: i * 20 }}
              mobile={{ pad: { l: 0 } }}
              motion={FADE}
            >
              <div
                tw="flex flex-row gap-5 w-full rounded-2xl p-7 bg-[#FFFFFF] max-md:p-5 max-md:gap-4"
                shadow={[
                  [1, 0, 0, '#DCE3EA', 0],
                  [14, 32, -20, 'rgba(26,36,48,0.3)', 0],
                ]}
              >
                <text size={28} weight={700} font={t.font.head} color={t.color.warn} tw="w-[86px] shrink-0 max-md:text-[22px] max-md:w-[68px]">
                  {e.time}
                </text>
                <text size={15} font={t.font.body} color={t.color.rock} lh={1.6}>
                  {e.what}
                </text>
              </div>
            </div>
          ))}
        </div>

        <div tw="flex flex-col gap-7 max-md:gap-5">
          <Eyebrow>Half board and dietary needs</Eyebrow>
          <h2 size={46} weight={700} lh={1.06} font={t.font.head} color={t.color.ink} tw="max-lg:text-[38px] max-md:text-[30px]">
            The kitchen is told in its own language, weeks before you arrive.
          </h2>
          <text size={17} font={t.font.body} color={t.color.rock} lh={1.7} tw="max-md:text-[15px]">
            Dietary requirements are passed to the warden in the local language when you book, not
            when you arrive hungry at 1,900 metres.
          </text>
          <img
            src={media.hut_dusk.id}
            tw="w-full rounded-2xl object-cover h-[300px] max-md:h-[220px]"
            shadow={[[22, 52, -28, 'rgba(26,36,48,0.4)', 0]]}
          />
          <div
            tw="flex flex-col gap-2 rounded-2xl p-7 bg-[#1A2430] w-[80%] -mt-14 max-md:w-full max-md:-mt-10 max-md:p-6"
            shadow={[[18, 42, -22, 'rgba(26,36,48,0.5)', 0]]}
            motion={FADE}
          >
            <text size={15} font={t.font.body} color="#FFFFFF" lh={1.65}>
              Vegetarian, vegan, gluten free, nut allergy and halal are carried on the booking in
              German, French, Italian and Slovene. <em>The 6pm sitting waits for nobody, so tell us
              once and it travels with you.</em>
            </text>
          </div>
        </div>
      </grid>
    </section>

    {/* ══ 7. Alpine club membership ════════════════════════════════════ */}
    <section tw="flex flex-col items-center w-full px-6 py-28 max-md:px-4 max-md:py-16" bg={t.color.ink}>
      <grid cols="minmax(0,0.9fr) minmax(0,1.1fr)" gap={72} tw="w-full max-w-[1180px] items-start max-lg:gap-12" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col gap-6 max-md:gap-4">
          <Eyebrow color="#E07B39">Alpine club membership</Eyebrow>
          <text size={78} weight={700} font={t.font.head} color={t.color.snow} lh={0.95} tw="max-lg:text-[60px] max-md:text-[46px]">
            €12–22
          </text>
          <text size={17} font={t.font.body} color="#B9C6D2" lh={1.7} maxw={420} tw="max-md:text-[15px]">
            Alpine club members save between 12 and 22 euro a night. Enter your membership number
            once and it applies to every hut that honours it, automatically.
          </text>
          <div
            tw="flex flex-row flex-wrap items-center justify-between gap-4 rounded-xl px-6 py-5 w-full max-w-[420px]"
            border={[1, '#3E5064']}
          >
            <text size={15} font={t.font.body} color="#8C9BAA">
              DAV · 4820 1179 6
            </text>
            <text size={13} weight={700} font={t.font.body} color={t.color.warn} tw="uppercase">
              Applied
            </text>
          </div>
        </div>

        <div tw="flex flex-col w-full pt-10 max-md:pt-0">
          {CLUBS.map((c, i) => (
            <div
              tw={i === 0 ? 'flex flex-col w-full' : 'flex flex-col w-full -mt-5 max-md:-mt-4'}
              pad={{ l: i % 2 ? 30 : 0 }}
              mobile={{ pad: { l: 0 } }}
              motion={FADE}
            >
              <ClubCard {...c} />
            </div>
          ))}
          <text size={14} font={t.font.body} color="#8C9BAA" lh={1.6} tw="pt-8">
            Reciprocal rights vary by hut. We only show the discount where the warden actually
            honours it, so the price you see is the price at the door.
          </text>
        </div>
      </grid>
    </section>

    {/* ══ 8. Search a route ════════════════════════════════════════════ */}
    <section id="search" tw="flex flex-col items-center w-full px-6 py-28 max-md:px-4 max-md:py-16" bg={t.color.ground}>
      <grid cols="minmax(0,1fr) minmax(0,1fr)" gap={72} tw="w-full max-w-[1180px] items-center max-lg:gap-10" mobile={{ gridCols: 1 }}>
        <div tw="flex flex-col gap-6 max-md:gap-4">
          <Eyebrow>Search a route</Eyebrow>
          <h2 size={52} weight={700} lh={1.04} font={t.font.head} color={t.color.ink} tw="max-lg:text-[40px] max-md:text-[32px]">
            Tell us the traverse and your pace. We will tell you which nights are real.
          </h2>
          <text size={16} font={t.font.body} color={t.color.rock} lh={1.7} maxw={460}>
            1,140 huts, six countries, one basket, three euro a night. Free to search, free to move
            once, and free to cancel up to fourteen days out.
          </text>
        </div>

        <div tw="flex flex-col w-full">
          <div
            tw="flex flex-col gap-5 w-full rounded-2xl p-8 bg-[#FFFFFF] max-md:p-6"
            shadow={[
              [1, 0, 0, '#DCE3EA', 0],
              [28, 64, -32, 'rgba(26,36,48,0.38)', 0],
            ]}
          >
            {[
              { l: 'Traverse', v: 'Haute Route · Chamonix to Zermatt' },
              { l: 'Nights', v: '4 to 15 September · 2 walkers' },
              { l: 'Pace', v: '350 m ascent an hour, 7 hour days' },
            ].map((f) => (
              <div tw="flex flex-col gap-2 w-full rounded-xl px-5 py-4 bg-[#F0F3F6]" border={[1, '#DCE3EA']}>
                <text size={12} weight={700} ls={0.12} font={t.font.body} color={t.color.rock} tw="uppercase">
                  {f.l}
                </text>
                <text size={16} weight={700} font={t.font.body} color={t.color.ink} lh={1.4}>
                  {f.v}
                </text>
              </div>
            ))}
            <Cta href="#walkability">Check this chain</Cta>
          </div>
          <div
            tw="flex flex-row flex-wrap items-center gap-4 rounded-2xl px-7 py-5 bg-[#1A2430] w-[82%] -mt-6 max-md:w-full max-md:px-6"
            m={{ l: 'auto' }}
            shadow={[[18, 40, -22, 'rgba(26,36,48,0.45)', 0]]}
          >
            <text size={14} font={t.font.body} color="#B9C6D2" lh={1.6}>
              Seven of eleven huts still have beds in that window. Availability moves daily.
            </text>
          </div>
        </div>
      </grid>
    </section>

    {/* ══ footer strip ═════════════════════════════════════════════════ */}
    <section tw="flex flex-row flex-wrap items-center justify-between gap-4 w-full px-6 py-8 max-md:px-4" bg={t.color.ink}>
      <text size={18} weight={700} font={t.font.head} color={t.color.snow}>
        Hutbook
      </text>
      <text size={13} font={t.font.body} color="#8C9BAA" lh={1.6}>
        1,140 huts · Austria, France, Germany, Italy, Slovenia, Switzerland · €3 a booked night
      </text>
    </section>
  </box>
);
