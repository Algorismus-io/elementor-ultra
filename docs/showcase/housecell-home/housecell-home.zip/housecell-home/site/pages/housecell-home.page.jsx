/** Housecell — modular home battery landing page. Bento grid, top to bottom. */
import { MEDIA as M } from '../data/media.mjs';

export const meta = {
  title: 'Housecell — modular home battery',
  seo: {
    title: 'Housecell — start with one 5kWh battery, stack to four',
    description:
      'A modular 5kWh home battery that clips together with more of itself. See the payback in pounds, not kilowatt-hours. MCS registered, fitted in one day.',
  },
};

/* ── one shared tile shell: every number the buyer is trying to work out ── */
const Tile = ({ t, span = 4, tspan, rowSpan, bg, pad = 30, gap = 12, children }) => (
  <box
    cls="tile"
    span={span}
    rowSpan={rowSpan}
    tablet={{ span: tspan ?? Math.min(span, 6) }}
    mobile={{ span: 1, pad: 22 }}
    bg={bg || t.color.tile}
    border={[1, t.color.line]}
    radius={16}
    pad={pad}
    gap={gap}
    tw="flex flex-col"
    motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}
  >
    {children}
  </box>
);

/* huge metric type — the thing the eye lands on first */
const Metric = ({ t, value, unit, color }) => (
  <box cls="metric-row" tw="flex flex-row items-end" gap={6} pad={0}>
    <text cls="metric" font={t.font.head} size={72} weight={700} lh={0.85} ls={-0.02} color={color || t.color.charge} mobile={{ size: 54 }}>
      {value}
    </text>
    {unit ? (
      <text cls="metric-unit" font={t.font.body} size={14} weight={600} lh={1.6} color={t.color.dim} ls={0.06}>
        {unit}
      </text>
    ) : null}
  </box>
);

const Label = ({ t, children, color }) => (
  <text cls="label" font={t.font.body} size={11} weight={700} ls={0.14} color={color || t.color.dim}>
    {children}
  </text>
);

const Body = ({ t, children, size = 15, color, maxw }) => (
  <text cls="body" font={t.font.body} size={size} lh={1.65} color={color || t.color.dim} maxw={maxw} mobile={{ size: 14 }}>
    {children}
  </text>
);

const H2 = ({ t, children, maxw = 620 }) => (
  <h2 cls="section-title" font={t.font.head} size={54} weight={700} lh={0.98} ls={-0.012} color={t.color.ink} maxw={maxw} mobile={{ size: 38 }}>
    {children}
  </h2>
);

const H3 = ({ t, children, color }) => (
  <h3 cls="tile-title" font={t.font.head} size={26} weight={700} lh={1.05} color={color || t.color.ink}>
    {children}
  </h3>
);

const Cta = ({ t, label = 'Book a free survey', wide }) => (
  <text
    href="#survey"
    font={t.font.body}
    size={15}
    weight={700}
    color="#0E1712"
    bg={t.color.charge}
    radius={10}
    pad={[15, 26]}
    ta="center"
    w={wide ? '100%' : 'hug'}
    tw="hover:bg-[#8CF0B0]"
  >
    {label}
  </text>
);

/* a row of two-tone ticks used by the blackout + install lists */
const Line = ({ t, mark, markColor, children }) => (
  <box cls="line" tw="flex flex-row items-start" gap={10} pad={0}>
    <text cls="line-mark" font={t.font.head} size={18} weight={700} lh={1.35} color={markColor} w={16}>
      {mark}
    </text>
    <text cls="line-text" font={t.font.body} size={15} lh={1.45} color={t.color.ink} flex={1}>
      {children}
    </text>
  </box>
);

/* ── native component: the four installed homes repeater (content props only) ── */
const HomeResult = defineComponent(
  ({ place = 'Sheffield', house = '', saved = '£0', period = 'in twelve months' }) => (
    <box bg="#152119" border={[1, '#24352B']} radius={16} pad={26} gap={10} tw="flex flex-col">
      <text font="Archivo" size={11} weight={700} ls={0.14} color="#9BB3A4">
        {place}
      </text>
      <text font="Big Shoulders Display" size={52} weight={700} lh={0.9} color="#5BE38A">
        {saved}
      </text>
      <text font="Archivo" size={12} weight={600} ls={0.06} color="#F2B138">
        {period}
      </text>
      <text font="Archivo" size={14} lh={1.6} color="#9BB3A4">
        {house}
      </text>
    </box>
  ),
  {
    title: 'Housecell home result',
    props: {
      place: { label: 'Location', group: 'Content' },
      house: { label: 'House description', group: 'Content' },
      saved: { label: 'Amount saved', group: 'Content' },
      period: { label: 'Period', group: 'Content' },
    },
  },
);

const HOMES = [
  { place: 'Sheffield · S7', saved: '£612', period: 'saved in twelve months', house: 'A 1930s semi with 4kW of solar and two units. Time-of-use tariff, no EV.' },
  { place: 'Bristol · BS9', saved: '£884', period: 'saved in twelve months', house: 'A 1980s detached with 6kW of solar, an EV on the drive and three units.' },
  { place: 'Leeds · LS6', saved: '£237', period: 'saved in twelve months', house: 'A Victorian terrace with no solar at all. One unit, arbitrage only.' },
  { place: 'Norwich · NR2', saved: '£498', period: 'saved in twelve months', house: 'A 2019 new-build with 3.6kW of solar, a heat pump and two units.' },
];

/* tariff bars: overnight cheap window vs the expensive teatime window */
const HOURS = [
  { at: '00', h: 46, kind: 'cheap' },
  { at: '02', h: 62, kind: 'cheap' },
  { at: '04', h: 58, kind: 'cheap' },
  { at: '06', h: 30, kind: 'flat' },
  { at: '08', h: 34, kind: 'flat' },
  { at: '10', h: 26, kind: 'flat' },
  { at: '12', h: 22, kind: 'flat' },
  { at: '14', h: 28, kind: 'flat' },
  { at: '16', h: 74, kind: 'peak' },
  { at: '18', h: 100, kind: 'peak' },
  { at: '20', h: 68, kind: 'peak' },
  { at: '22', h: 40, kind: 'flat' },
];

const BAR = { cheap: '#5BE38A', peak: '#F2B138', flat: '#24352B' };

export default ({ theme: t }) => (
  <box tw="flex flex-col w-full" pad={0} bg={t.color.ground}>
    {/* ══ 1 · BENTO HERO ══════════════════════════════════════════════ */}
    <section tw="flex flex-col w-full items-center" pad={{ t: 34, b: 90, l: 24, r: 24 }} bg={t.color.ground} mobile={{ pad: { t: 24, b: 56, l: 16, r: 16 } }}>
      <box cls="wrap" tw="flex flex-col w-full" maxw={1220} gap={16} pad={0}>
        <box tw="flex flex-row items-center justify-between w-full" pad={{ b: 6 }} gap={16}>
          <text font={t.font.head} size={26} weight={700} ls={0.04} color={t.color.ink}>
            HOUSECELL
          </text>
          <Label t={t} color={t.color.charge}>MODULAR HOME BATTERY · UK</Label>
        </box>

        <grid cols={12} gap={16} tablet={{ gridCols: 6 }} mobile={{ gridCols: 1 }}>
          <Tile t={t} span={7} tspan={6} pad={38}>
            <h1 font={t.font.head} size={88} weight={700} lh={0.9} ls={-0.025} color={t.color.ink} tablet={{ size: 68 }} mobile={{ size: 44 }}>
              Start with one. Stack to four. Stop guessing at the payback.
            </h1>
            <Body t={t} size={17} maxw={560}>
              A 5kWh home battery that clips together with more of itself. Housecell shows you what it earned you today in pounds, not in kilowatt-hours, so you can tell whether it was worth it.
            </Body>
            <box tw="flex flex-row items-center" gap={14} pad={{ t: 10 }} wrap="wrap">
              <Cta t={t} />
              <Body t={t} size={13}>MCS registered · fitted in one day</Body>
            </box>
          </Tile>

          <box span={5} tablet={{ span: 6 }} mobile={{ span: 1 }} radius={16} pad={0} tw="flex flex-col" border={[1, t.color.line]}>
            <img src={M.battery_wall.id} w="100%" h={430} fit="cover" radius={16} tablet={{ h: 320 }} mobile={{ h: 240 }} />
          </box>

          <Tile t={t} span={4}>
            <Label t={t}>PAYBACK</Label>
            <Metric t={t} value="6y 4m" unit="TWO UNITS · TOU TARIFF" />
            <Body t={t}>
              Typical payback on a two-unit system with a time-of-use tariff: 6 years 4 months. With solar and an EV, <strong>4 years 9 months</strong>.
            </Body>
          </Tile>

          <Tile t={t} span={4}>
            <Label t={t}>CAPACITY</Label>
            <Metric t={t} value="5.2" unit="KWH USABLE PER UNIT" color={t.color.grid} />
            <Body t={t}>
              5.2kWh usable per unit, 3.6kW continuous output, four units maximum on a single-phase supply.
            </Body>
          </Tile>

          <Tile t={t} span={4}>
            <Label t={t}>BLACKOUT</Label>
            <Metric t={t} value="12ms" unit="CUTOVER" />
            <Body t={t}>
              Cuts over in 12 milliseconds. Your fridge, lights, router and one ring circuit stay live. The oven and the shower do not, and we will tell you that before you buy.
            </Body>
          </Tile>
        </grid>
      </box>
    </section>

    {/* ══ 2 · SIZING ══════════════════════════════════════════════════ */}
    <section cls="band" tw="flex flex-col w-full items-center" pad={[90, 24]} bg="#0B120E" border={[1, t.color.line]} mobile={{ pad: [56, 16] }}>
      <box cls="wrap" tw="flex flex-col w-full" maxw={1220} gap={16} pad={0}>
        <grid cols={12} gap={16} tablet={{ gridCols: 6 }} mobile={{ gridCols: 1 }}>
          <Tile t={t} span={4} tspan={6} bg="#0B120E" pad={0}>
            <Label t={t} color={t.color.grid}>SIZING</Label>
            <H2 t={t} maxw={420}>How many units your house actually needs</H2>
            <Body t={t}>
              Every unit is the same 5.2kWh brick. You are not buying a size, you are buying a count — and you can change the count later without changing anything else on the wall.
            </Body>
          </Tile>

          <Tile t={t} span={2} tspan={3}>
            <Metric t={t} value="1" unit="5.2 KWH" />
            <H3 t={t}>One unit</H3>
            <Body t={t} size={14}>Flat or small terrace, no solar. Covers the evening peak and not much more.</Body>
          </Tile>

          <Tile t={t} span={2} tspan={3} bg="#18271D">
            <Metric t={t} value="2" unit="10.4 KWH" />
            <H3 t={t}>Two units</H3>
            <Body t={t} size={14}>The common answer. Three or four bed semi with around 4kW of solar.</Body>
          </Tile>

          <Tile t={t} span={2} tspan={3}>
            <Metric t={t} value="3" unit="15.6 KWH" color={t.color.grid} />
            <H3 t={t}>Three units</H3>
            <Body t={t} size={14}>Bigger house, an EV charging at home, or a heat pump running overnight.</Body>
          </Tile>

          <Tile t={t} span={2} tspan={3}>
            <Metric t={t} value="4" unit="20.8 KWH" color={t.color.grid} />
            <H3 t={t}>Four units</H3>
            <Body t={t} size={14}>The single-phase ceiling. Heat pump, EV and solar all pulling at once.</Body>
          </Tile>
        </grid>
      </box>
    </section>

    {/* ══ 3 · BLACKOUT BEHAVIOUR ══════════════════════════════════════ */}
    <section cls="band" tw="flex flex-col w-full items-center" pad={[90, 24]} bg={t.color.ground} mobile={{ pad: [56, 16] }}>
      <box cls="wrap" tw="flex flex-col w-full" maxw={1220} gap={16} pad={0}>
        <grid cols={12} gap={16} tablet={{ gridCols: 6 }} mobile={{ gridCols: 1 }}>
          <Tile t={t} span={5} tspan={6} bg={t.color.ground} pad={0}>
            <Label t={t} color={t.color.charge}>WHEN THE STREET GOES DARK</Label>
            <H2 t={t} maxw={430}>Twelve milliseconds, and a short list of things that stay on</H2>
            <Body t={t} maxw={430}>
              The changeover is fast enough that your router never reboots. What it is not is a whole-house generator, and pretending otherwise is how people end up disappointed on the one night it matters.
            </Body>
            <Body t={t} size={13} color={t.color.grid} maxw={430}>
              A two-unit system runs the list below for roughly 14 hours.
            </Body>
          </Tile>

          <Tile t={t} span={4} tspan={3}>
            <Label t={t} color={t.color.charge}>STAYS LIVE</Label>
            <box tw="flex flex-col" gap={12} pad={{ t: 4 }}>
              <Line t={t} mark="+" markColor={t.color.charge}>Fridge and freezer</Line>
              <Line t={t} mark="+" markColor={t.color.charge}>Lights, upstairs and down</Line>
              <Line t={t} mark="+" markColor={t.color.charge}>Router, Wi-Fi and the alarm</Line>
              <Line t={t} mark="+" markColor={t.color.charge}>One ring circuit of your choosing</Line>
            </box>
          </Tile>

          <Tile t={t} span={3}>
            <Label t={t} color={t.color.grid}>DOES NOT</Label>
            <box tw="flex flex-col" gap={12} pad={{ t: 4 }}>
              <Line t={t} mark="—" markColor={t.color.grid}>Electric oven</Line>
              <Line t={t} mark="—" markColor={t.color.grid}>Electric shower</Line>
              <Line t={t} mark="—" markColor={t.color.grid}>Immersion heater</Line>
              <Line t={t} mark="—" markColor={t.color.grid}>EV charger</Line>
            </box>
          </Tile>
        </grid>
      </box>
    </section>

    {/* ══ 4 · TARIFF ARBITRAGE ════════════════════════════════════════ */}
    <section cls="band" tw="flex flex-col w-full items-center" pad={[90, 24]} bg="#0B120E" border={[1, t.color.line]} mobile={{ pad: [56, 16] }}>
      <box cls="wrap" tw="flex flex-col w-full" maxw={1220} gap={16} pad={0}>
        <grid cols={12} gap={16} tablet={{ gridCols: 6 }} mobile={{ gridCols: 1 }}>
          <Tile t={t} span={7} tspan={6}>
            <Label t={t} color={t.color.grid}>TARIFF ARBITRAGE</Label>
            <H3 t={t}>A day of your electricity, priced</H3>
            <box tw="flex flex-row items-end w-full" gap={8} h={150} pad={{ t: 10 }} mobile={{ h: 110, gap: 5 }}>
              {HOURS.map((hr) => (
                <box flex={1} h={`${hr.h}%`} minh={8} radius={5} bg={BAR[hr.kind]} pad={0} />
              ))}
            </box>
            <box tw="flex flex-row items-center justify-between w-full" gap={8} pad={0}>
              <Label t={t}>00:00</Label>
              <Label t={t}>08:00</Label>
              <Label t={t}>16:00</Label>
              <Label t={t}>22:00</Label>
            </box>
            <box tw="flex flex-row items-center" gap={18} pad={{ t: 6 }} wrap="wrap">
              <Line t={t} mark="■" markColor={t.color.charge}>Charging on the cheap rate</Line>
              <Line t={t} mark="■" markColor={t.color.grid}>Discharging through the expensive window</Line>
            </box>
          </Tile>

          <Tile t={t} span={5} tspan={6} bg="#18271D">
            <Label t={t} color={t.color.charge}>LAST MONTH</Label>
            <Metric t={t} value="£71" unit="AVERAGE TWO-UNIT SAVING" />
            <Body t={t}>
              Charges on the cheap overnight rate, discharges during the expensive window, and learns your house over about three weeks. Last month the average two-unit customer saved <strong>£71</strong>.
            </Body>
            <Body t={t} size={13} color={t.color.grid}>
              The app reports it in pounds. Kilowatt-hours are there if you want them, on the second tab, where they belong.
            </Body>
          </Tile>
        </grid>
      </box>
    </section>

    {/* ══ 5 · INSTALLATION ════════════════════════════════════════════ */}
    <section cls="band" tw="flex flex-col w-full items-center" pad={[90, 24]} bg={t.color.ground} mobile={{ pad: [56, 16] }}>
      <box cls="wrap" tw="flex flex-col w-full" maxw={1220} gap={16} pad={0}>
        <grid cols={12} gap={16} tablet={{ gridCols: 6 }} mobile={{ gridCols: 1 }}>
          <box span={6} tablet={{ span: 6 }} mobile={{ span: 1 }} radius={16} pad={0} tw="flex flex-col" border={[1, t.color.line]}>
            <img src={M.install_day.id} w="100%" h={420} fit="cover" radius={16} mobile={{ h: 240 }} />
          </box>

          <Tile t={t} span={6} tspan={6} pad={36}>
            <Label t={t} color={t.color.charge}>INSTALLATION</Label>
            <H2 t={t} maxw={440}>One installer. One day. Nothing on the roof.</H2>
            <Body t={t}>
              One certified installer, one day, MCS registered so you keep your export payments. No scaffolding, no roof work, no re-wiring your consumer unit.
            </Body>
            <box tw="flex flex-col" gap={12} pad={{ t: 8 }}>
              <Line t={t} mark="01" markColor={t.color.charge}>Survey, then a fixed price with the tariff maths attached</Line>
              <Line t={t} mark="02" markColor={t.color.charge}>Wall bracket, first unit, isolator — before lunch</Line>
              <Line t={t} mark="03" markColor={t.color.charge}>Commissioning, app pairing and the MCS certificate by post</Line>
            </box>
          </Tile>
        </grid>
      </box>
    </section>

    {/* ══ 6 · WARRANTY ════════════════════════════════════════════════ */}
    <section cls="band" tw="flex flex-col w-full items-center" pad={[90, 24]} bg="#0B120E" border={[1, t.color.line]} mobile={{ pad: [56, 16] }}>
      <box cls="wrap" tw="flex flex-col w-full" maxw={1220} gap={16} pad={0}>
        <grid cols={12} gap={16} tablet={{ gridCols: 6 }} mobile={{ gridCols: 1 }}>
          <Tile t={t} span={3}>
            <Metric t={t} value="10" unit="YEARS" />
            <Body t={t} size={14}>Or 6,000 cycles, whichever lands later.</Body>
          </Tile>
          <Tile t={t} span={3}>
            <Metric t={t} value="6,000" unit="CYCLES" color={t.color.grid} />
            <Body t={t} size={14}>Counted by the unit, reported in the app.</Body>
          </Tile>
          <Tile t={t} span={3}>
            <Metric t={t} value="80%" unit="CAPACITY FLOOR" />
            <Body t={t} size={14}>The number the warranty is measured against.</Body>
          </Tile>
          <Tile t={t} span={3} bg="#18271D">
            <Label t={t} color={t.color.grid}>WARRANTY</Label>
            <H3 t={t}>Modules, not systems</H3>
            <Body t={t} size={14}>
              10 years or 6,000 cycles to 80 percent capacity, whichever is later. Modules are individually replaceable so one failure does not mean a new system.
            </Body>
          </Tile>
        </grid>
      </box>
    </section>

    {/* ══ 7 · REAL NUMBERS ════════════════════════════════════════════ */}
    <section cls="band" tw="flex flex-col w-full items-center" pad={[90, 24]} bg={t.color.ground} mobile={{ pad: [56, 16] }}>
      <box cls="wrap" tw="flex flex-col w-full" maxw={1220} gap={16} pad={0}>
        <box tw="flex flex-row items-end justify-between w-full" gap={20} pad={{ b: 6 }} wrap="wrap">
          <box tw="flex flex-col" gap={10} pad={0}>
            <Label t={t} color={t.color.charge}>REAL NUMBERS · FOUR INSTALLED HOMES</Label>
            <H2 t={t} maxw={560}>What four actual houses banked in twelve months</H2>
          </box>
          <Body t={t} size={14} maxw={330}>
            A 1930s semi in Sheffield with 4kW of solar and two units: £612 saved in twelve months. The full dataset for all four homes is downloadable.
          </Body>
        </box>

        <grid cols={4} gap={16} tablet={{ gridCols: 2 }} mobile={{ gridCols: 1 }}>
          {HOMES.map((h) => (
            <box span={1} mobile={{ span: 1 }} pad={0} tw="flex flex-col" motion={{ effect: 'fade', trigger: 'scrollIn', duration: 500 }}>
              <HomeResult place={h.place} house={h.house} saved={h.saved} period={h.period} />
            </box>
          ))}
        </grid>

        <text href="#survey" font={t.font.body} size={14} weight={700} color={t.color.charge} tw="hover:text-[#F2B138]" pad={{ t: 4 }}>
          Ask for the full four-home dataset at your survey →
        </text>
      </box>
    </section>

    {/* ══ 8 · BOOK A SURVEY ═══════════════════════════════════════════ */}
    <section id="survey" tw="flex flex-col w-full items-center" pad={[90, 24]} bg="#0B120E" border={[1, t.color.line]} mobile={{ pad: [56, 16] }}>
      <box cls="wrap" tw="flex flex-col w-full" maxw={1220} gap={16} pad={0}>
        <grid cols={12} gap={16} tablet={{ gridCols: 6 }} mobile={{ gridCols: 1 }}>
          <Tile t={t} span={7} tspan={6} pad={38}>
            <Label t={t} color={t.color.charge}>BOOK A SURVEY</Label>
            <H2 t={t} maxw={520}>Book a free survey and we will do the payback maths on your house</H2>
            <Body t={t} maxw={520}>
              Forty minutes, no obligation, and you leave with a unit count, a fixed price and the payback in years and months for your tariff — not for a generic house that does not exist.
            </Body>
            <box tw="flex flex-row items-center" gap={14} pad={{ t: 10 }} wrap="wrap">
              <Cta t={t} />
              <Body t={t} size={13}>Surveys run Monday to Saturday · England, Wales and southern Scotland</Body>
            </box>
          </Tile>

          <box span={5} tablet={{ span: 6 }} mobile={{ span: 1 }} radius={16} pad={0} tw="flex flex-col" border={[1, t.color.line]}>
            <img src={M.house_solar.id} w="100%" h={360} fit="cover" radius={16} mobile={{ h: 220 }} />
          </box>

          <Tile t={t} span={12} tspan={6} pad={22} gap={8}>
            <box tw="flex flex-row items-center justify-between w-full" gap={16} pad={0} wrap="wrap">
              <text font={t.font.head} size={22} weight={700} ls={0.04} color={t.color.ink}>
                HOUSECELL
              </text>
              <Body t={t} size={12}>Modular home battery · MCS registered installers · 10 year warranty</Body>
            </box>
          </Tile>
        </grid>
      </box>
    </section>
  </box>
);
